package com.ikon.mongo;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.List;
import java.util.Objects;
import java.util.Properties;

import com.ikon.rest.web.models.MongoTicketDataBean;
import com.ikon.rest.web.models.TicketDataDTO;
import com.ikon.rest.web.models.WorkNoteDTO;
import com.ikon.validator.IKONUtils;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.MongoException;

import lombok.extern.slf4j.Slf4j;

/**
 * The Class MongoDBConnection.
 */
@Slf4j
public class MongoDBConnection {

	/** The mongo con. */
	private static DB mongoCon;

	/** The cnt of uptd rec. */
	private static int cntOfUptdRec;

	/** The cnt of intd rec. */
	private static int cntOfIntdRec;
	
	/** The constant INCIDENT_ID String*/
	private static final String INCIDENT_ID="Incident_id";
	
	/** The Constant logger. */
//	private static final Logger LOGGER = LogManager.getLogger(MongoDBConnection.class);

	/**
	 * Gets the mongo DB connection.
	 *
	 * @return the mongo DB connection
	 */
	public DB getMongoDBConnection(final TicketDataDTO ticketDataDTO) {

		
		Properties prop =null;
		MongoClient mongoClient=null;
		try(InputStream reader = Thread.currentThread().getContextClassLoader().getResourceAsStream("application.properties");) {
			prop = new Properties();
			prop.load(reader);
		}catch(IOException e) {
			log.error(e.getMessage());
		}

		try {
			String hostName = prop.getProperty("mongodb");
			String authUser = prop.getProperty("mongousername");
			String authPwd = prop.getProperty("mongopassword");
			String dbName = prop.getProperty("Mongoconnection");
			String authSource = prop.getProperty("authSource");

			int portNo = Integer.valueOf(prop.getProperty("mongoport"));
			String encodedPwd = URLEncoder.encode(authPwd, "UTF-8");

			String clientUrl = "mongodb://" + authUser + ":" + encodedPwd + "@" + hostName + ":" + portNo + "/"
					+ authSource;
			MongoClientURI uri = new MongoClientURI(clientUrl);
			mongoClient = new MongoClient(uri);
			mongoCon = mongoClient.getDB(dbName);
			
			final MongoTicketDataBean mongoCursorBean = new MongoTicketDataBean();
			mongoDbWhereQuery(mongoCon,mongoCursorBean,ticketDataDTO.getNumber());
			// to update the data in history table..
			mongoDbUpdateQuery(mongoCon,mongoCursorBean,ticketDataDTO);
			
		} catch (MongoException | UnsupportedEncodingException  e) {
			log.error(e.getMessage());
		}finally {
			if(Objects.nonNull(mongoClient))
				mongoClient.close();
		}

		return mongoCon;
	}

	/**
	 * Insert IN cto mongo inter table.
	 *
	 * @param ticketDataDTO the ticket data DTO
	 * @param account_ID    the account ID
	 * @return the int
	 */
	public int insertINCtoMongoInterTable(final TicketDataDTO ticketDataDTO,final int account_ID) {
		
		final int iCnt = 0;
		
		final DB mongoConnection = getMongoDBConnection(ticketDataDTO);
//		final MongoTicketDataBean mongoCursorBean = new MongoTicketDataBean();
//		mongoDbWhereQuery(mongoConnection,mongoCursorBean,ticketDataDTO.getNumber());
//		// to update the data in history table..
//		mongoDbUpdateQuery(mongoConnection,mongoCursorBean,ticketDataDTO);
		return iCnt;
	}

	/**
	 * @param mongoConnection 
	 * @param mongoCursorBean
	 * @param ticketDataDTO
	 */
	private void mongoDbUpdateQuery(final DB mongoConnection,final MongoTicketDataBean mongoCursorBean,final TicketDataDTO ticketDataDTO) {

		final String description = ticketDataDTO.getDescription(); // Notes
		final String summary = ticketDataDTO.getShortDescription(); // getSummary
		final String comments = ticketDataDTO.getResolutionNote();
		
		//String worknotes = ticketDataDTO.getWorkNotes(); // getAdditional_Comments
		final List<WorkNoteDTO> workNotes = ticketDataDTO.getWorkNotes();
		final StringBuilder workNote = new StringBuilder();
		if(workNotes != null) {
			for(final WorkNoteDTO workNoteDto: workNotes) {
				workNote.append(workNoteDto.getValue());
				workNote.append(" ");
			}
		}
		final String incidentText = description + " " + summary + " " + comments + " " + workNote.toString();
		final String descSum = description + " " + summary;
		final DBCollection insertDataToInter = mongoConnection.getCollection("ticket_data_inter");
		final MongoTicketDataBean mbdbean = new MongoTicketDataBean();
		mbdbean.setIncident_id(ticketDataDTO.getNumber()); // Incident ID
		mbdbean.setApp_Name(checkNull(ticketDataDTO.getApplicationName()));
		mbdbean.setAssigned_Group(ticketDataDTO.getAssignmentGroup());
		mbdbean.setStatus(ticketDataDTO.getState()); // getStatus
		mbdbean.setInc_text(incidentText);
		mbdbean.setSummary(descSum);
		
		final DBCollection updateCollection = mongoConnection.getCollection("ticket_data_history");
		final BasicDBObject searchQuery = new BasicDBObject(INCIDENT_ID, ticketDataDTO.getNumber()); // getIncident_ID
		final BasicDBObject updateFields = new BasicDBObject();
		updateFields.append("Inc_text", incidentText);
		updateFields.append("App_Name", checkNull(ticketDataDTO.getApplicationName()));
		updateFields.append("Assigned_Group", ticketDataDTO.getAssignmentGroup());
		updateFields.append("Status", ticketDataDTO.getState());
		updateFields.append("Summary", descSum);
		final BasicDBObject setQuery = new BasicDBObject();
		setQuery.append("$set", updateFields);
		// to update the flags
		if (!IKONUtils.isNullOrEmpty(mongoCursorBean.getIncident_id()) && !IKONUtils.isNullOrEmpty(mongoCursorBean.getSummary())) {
			if ((mongoCursorBean.getIncident_id().equalsIgnoreCase(mbdbean.getIncident_id()))
					&& ((!mongoCursorBean.getInc_text().trim().equalsIgnoreCase(mbdbean.getInc_text()))
							|| (!mongoCursorBean.getApp_Name().trim().equalsIgnoreCase(mbdbean.getApp_Name()))
							|| (!mongoCursorBean.getAssigned_Group().trim().equalsIgnoreCase(mbdbean.getAssigned_Group()))
							|| (!mongoCursorBean.getStatus().trim().equalsIgnoreCase(mbdbean.getStatus()))
							|| (!mongoCursorBean.getSummary().trim().equalsIgnoreCase(mbdbean.getSummary())))) {
				cntOfUptdRec++;
				final BasicDBObject saveFields = new BasicDBObject();
				saveFields.append(INCIDENT_ID, mbdbean.getIncident_id());
				saveFields.append("App_Name", mbdbean.getApp_Name());
				saveFields.append("Assigned_Group", mbdbean.getAssigned_Group());
				saveFields.append("Status", mbdbean.getStatus());
				saveFields.append("Inc_text", mbdbean.getInc_text());
				saveFields.append("Summary", mbdbean.getSummary());
				insertDataToInter.save(saveFields);
			}else{
				updateCollection.update(searchQuery, setQuery);
			}
		}
		else {
			cntOfIntdRec++;
			final BasicDBObject saveFields = new BasicDBObject();
			saveFields.append(INCIDENT_ID, mbdbean.getIncident_id());
			saveFields.append("App_Name", mbdbean.getApp_Name());
			saveFields.append("Assigned_Group", mbdbean.getAssigned_Group());
			saveFields.append("Status", mbdbean.getStatus());
			saveFields.append("Inc_text", mbdbean.getInc_text());
			saveFields.append("Summary", mbdbean.getSummary());
			insertDataToInter.save(saveFields);
		}
		
		
	}

	/**
	 * @param mongoConnection 
	 * @param mongoCursorBean
	 * @param number
	 */
	private void mongoDbWhereQuery(final DB mongoConnection,final MongoTicketDataBean mongoCursorBean,final String number) {

		DBCollection ticketdataCollection = mongoConnection.getCollection("ticket_data_history");
		// to get the incident_id and inc_text from Ticket_Data_Inter in MongoDB
		final BasicDBObject whereQuery = new BasicDBObject();
		whereQuery.put(INCIDENT_ID, number); // getIncident_ID
		final BasicDBObject fields = new BasicDBObject();
		fields.put(INCIDENT_ID, 1);
		fields.put("Inc_text", 1);
		fields.put("App_Name", 1);
		fields.put("Assigned_Group", 1);
		fields.put("Status", 1);
		fields.put("Summary", 1);
		final DBCursor cursor = ticketdataCollection.find(whereQuery, fields);
			while (cursor.hasNext()) {
				final BasicDBObject obj = (BasicDBObject) cursor.next();
				mongoCursorBean.setIncident_id(obj.getString(INCIDENT_ID));
				mongoCursorBean.setApp_Name(obj.getString("App_Name"));
				mongoCursorBean.setAssigned_Group(obj.getString("Assigned_Group"));
				mongoCursorBean.setStatus(obj.getString("Status"));
				mongoCursorBean.setInc_text(obj.getString("Inc_text"));
				mongoCursorBean.setSummary(obj.getString("Summary"));
			}
		
	}
	
	/**
	 * check Null.
	 *
	 * @param obj the obj
	 * @return Object obj
	 */
	private String checkNull(String obj) {
		return Objects.nonNull(obj)?obj:"";
	}
}
