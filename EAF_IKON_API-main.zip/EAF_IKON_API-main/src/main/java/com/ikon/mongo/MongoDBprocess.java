package com.ikon.mongo;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Properties;
import org.bson.Document;
import org.bson.conversions.Bson;
import com.ikon.dto.KOInfoBean;
import com.ikon.rest.web.models.Authentication;
import com.ikon.rest.web.models.SecurityContextHolder;
import com.mongodb.BasicDBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.MongoException;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;

import lombok.extern.slf4j.Slf4j;

/**
 * The Class MongoDBprocess.
 */
@Slf4j
public class MongoDBprocess {

	/** The Constant log. */
//	private static final log log = LogManager.getlog(MongoDBprocess.class);
	
	/** The Constant PUBLICATION_STATUS. */
	private static final String INCIDENT_ID = "incident_id";
	
	/** The Constant PUBLICATION_STATUS. */
	private static final String PUBLICATION_STATUS = "Publication_status";	
	
	/** The Constant Ko_Id. */
	private static final String KO_ID = "Ko_id";

	/** The Constant Ko_Text. */
	private static final String KO_TEXT = "Ko_text";
	
	/** The Constant Summary. */
	private static final String SUMMARY = "Summary";
	
	/** The Constant Ticket_group. */
	private static final String TICKET_GROUP = "Ticket_group";
	
	/** The Constant Ko_Status. */
	private static final String KO_STATUS = "Ko_status";
	
	/** The Constant App_Name. */
	private static final String APP_NAME = "App_name";
	
	/**
	 * Insertko.
	 *
	 * @param col           the col
	 * @param koInfoBean    the ko info bean
	 * @param defaultAcctId the default acct id
	 * @param koId          the ko id
	 * @param getKoStage    the get ko stage
	 */
	private static void insertko(MongoCollection<Document> col, KOInfoBean koInfoBean, String defaultAcctId,
			String koId, String getKoStage) {
		String shortdescription = koInfoBean.getShortDescription();
		String longdescription = koInfoBean.getLongDescription();
		String symptoms = koInfoBean.getSymptoms();
		String resolution = koInfoBean.getResolution();

		String ko_text = shortdescription + " " + longdescription + " " + symptoms + " " + resolution;
		String summary = shortdescription + " " + longdescription;

		Document intertab = new Document();
		intertab.put(KO_ID, koId);
		intertab.put(KO_TEXT, ko_text);
		intertab.put(SUMMARY, summary);
		intertab.put(APP_NAME, koInfoBean.getApplicationName());
		intertab.put(TICKET_GROUP, koInfoBean.getAssignmentGroup());

		intertab.put(KO_STATUS, "1");

		if (getKoStage.equalsIgnoreCase("Indraft")) {
			intertab.put(PUBLICATION_STATUS, "Indraft");
		} else if (getKoStage.equalsIgnoreCase("ReviewSubmit")) {
			intertab.put(PUBLICATION_STATUS, "ReviewSubmit");
		} else {
			intertab.put(PUBLICATION_STATUS, koInfoBean.getPublicationStatus());
		}
		col.insertOne(intertab);
	}

	/**
	 * Insert inckolink.
	 *
	 * @param col           the col
	 * @param koInfoBean    the ko info bean
	 * @param defaultAcctId the default acct id
	 * @param koId          the ko id
	 * @param getKoStage    the get ko stage
	 */
	private static void insertInckolink(MongoCollection<Document> col, KOInfoBean koInfoBean, String defaultAcctId,
			String koId, String getKoStage) {

		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String loginusrname = auth.getName();
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss", Locale.getDefault());
		Date date = new Date();

		Document inckolinktab = new Document();
		inckolinktab.put("ko_id", koId);
		if ((Objects.nonNull(koInfoBean.getTicketsearchbox()) && !koInfoBean.getTicketsearchbox().trim().equalsIgnoreCase("")))
			inckolinktab.put(INCIDENT_ID, koInfoBean.getTicketsearchbox());
		else
			inckolinktab.put(INCIDENT_ID, koInfoBean.getTicketID());
		inckolinktab.put("link_date", dateFormat.format(date));
		inckolinktab.put("User_Id", loginusrname);
		inckolinktab.put("arch_flag", "null");

		col.insertOne(inckolinktab);
	}

	/**
	 * Insert data.
	 *
	 * @param koInfoBean    the ko info bean
	 * @param defaultAcctId the default acct id
	 * @param koId          the ko id
	 * @param getKoStage    the get ko stage
	 * @throws UnsupportedEncodingException 
	 */
	public static void insertData(KOInfoBean koInfoBean, String defaultAcctId, String koId, String getKoStage) throws UnsupportedEncodingException
			{

		ClassLoader loader = Thread.currentThread().getContextClassLoader();
		Properties properties = new Properties();
		try (InputStream resourceStream = loader.getResourceAsStream("application.properties")) {
			properties.load(resourceStream);
		} catch (IOException e) {
			log.error(e.getMessage());
		}

		String Mongoconnection = properties.getProperty("Mongoconnection");
		String host_name = properties.getProperty("mongodb");
		String auth_user = properties.getProperty("mongousername");
		String db_pwd = properties.getProperty("mongopassword");
		String port_no = properties.getProperty("mongoport");
		String auth_source = properties.getProperty("authSource");
		String db_coll_det_inter = "ko_detail_inter";
		String db_coll_ko_link = "incident_ko_link";
		String incident_id;
		String encoded_pwd = URLEncoder.encode(db_pwd, "UTF-8");

		// Mongodb connection string.
		String client_url = "mongodb://" + auth_user + ":" + encoded_pwd + "@" + host_name + ":" + port_no + "/"
				+ auth_source;

		MongoClientURI uri = new MongoClientURI(client_url);

		// Connecting to the mongodb server using the given client uri.
		MongoClient mongo_client = null;
		
		try {
		mongo_client = new MongoClient(uri);

		// Fetching the database from the mongodb.

		MongoDatabase db = mongo_client.getDatabase(Mongoconnection);

		// Fetching the collection from the mongodb.
		MongoCollection<Document> coll_inter = db.getCollection(db_coll_det_inter);

		MongoCollection<Document> coll_ko_link = db.getCollection(db_coll_ko_link);

		List<Document> getvalue_inter = find(coll_inter, koId);

		if ((Objects.nonNull(koInfoBean.getTicketsearchbox()) && !koInfoBean.getTicketsearchbox().trim().equalsIgnoreCase("")))
			incident_id = koInfoBean.getTicketsearchbox();
		else
			incident_id = koInfoBean.getTicketID();

		List<Document> getvalue_ticket = find_ticket(coll_ko_link, incident_id);

		if (Objects.nonNull(getKoStage) && getKoStage.equalsIgnoreCase("ticketview")) {
			if (getvalue_ticket.size() > 0) {
				updatelinkko(coll_ko_link, koInfoBean, defaultAcctId, koId, getKoStage);
				return;
			} else {
				insertInckolink(coll_ko_link, koInfoBean, defaultAcctId, koId, getKoStage);
				return;
			}
		}

		if (getvalue_inter.size() > 0) {
			updateko(coll_inter, koInfoBean, defaultAcctId, koId, getKoStage);
			return;

		} else {
			insertko(coll_inter, koInfoBean, defaultAcctId, koId, getKoStage);
			insertInckolink(coll_ko_link, koInfoBean, defaultAcctId, koId, getKoStage);

		}
		
		String cloneKoLink = "generic_account_ko_mapping";
		MongoCollection<Document> cloneCollection = db.getCollection(cloneKoLink);
		
		if (Objects.nonNull(koInfoBean.getGenericKoID()) && !koInfoBean.getGenericKoID().equalsIgnoreCase("null")
				&& koInfoBean.getGenericKoID().startsWith("GS")) {
			
			insertCloneKo(cloneCollection,koInfoBean, koId);
		}

		}catch(MongoException e) {
			log.error(e.getMessage());
		}finally {
			if(Objects.nonNull(mongo_client))
				mongo_client.close();
		}
	}

	/**
	 * Find.
	 *
	 * @param coll2 the coll 2
	 * @param koid  the koid
	 * @return the list
	 */
	public static List<Document> find(MongoCollection<Document> coll2, String koid) {
		List<Document> res = new ArrayList<Document>();
		try {
			BasicDBObject searchQuery = new BasicDBObject();
			searchQuery.put(KO_ID, Objects.nonNull(koid) ? koid : "");
			Iterable<Document> docs = coll2.find(searchQuery);
			for (Document doc : docs) {
				res.add(doc);
			}
		} catch (MongoException e) {
			log.error(e.getMessage());
		}
		return res;
	}

	/**
	 * Find ticket.
	 *
	 * @param coll2    the coll 2
	 * @param ticketid the ticketid
	 * @return the list
	 */
	public static List<Document> find_ticket(MongoCollection<Document> coll2, String ticketid) {
		List<Document> res = new ArrayList<Document>();
		try {
			BasicDBObject searchQuery = new BasicDBObject();
			searchQuery.put(INCIDENT_ID, ticketid);
			Iterable<Document> docs = coll2.find(searchQuery);
			for (Document doc : docs) {
				res.add(doc);
			}
		} catch (MongoException e) {
			log.error(e.getMessage());
		}
		return res;
	}

	/**
	 * Updateko.
	 *
	 * @param coll          the coll
	 * @param koInfoBean    the ko info bean
	 * @param defaultAcctId the default acct id
	 * @param koId          the ko id
	 * @param getKoStage    the get ko stage
	 */
	private static void updateko(MongoCollection<Document> coll, KOInfoBean koInfoBean, String defaultAcctId,
			String koId, String getKoStage) {
		String shortdescription = koInfoBean.getShortDescription();
		String longdescription = koInfoBean.getLongDescription();
		String symptoms = koInfoBean.getSymptoms();
		String resolution = koInfoBean.getResolution();

		String ko_text = shortdescription + " " + longdescription + " " + symptoms + " " + resolution;
		String summary = shortdescription + " " + longdescription;

		Bson filter = Filters.eq(KO_ID, koId);
		Bson updates = Updates.combine(Updates.set(KO_TEXT, ko_text), Updates.set(KO_TEXT, ko_text),
				Updates.set(SUMMARY, summary), Updates.set(APP_NAME, koInfoBean.getApplicationName()),
				Updates.set(TICKET_GROUP, koInfoBean.getAssignmentGroup()),
				Updates.set(PUBLICATION_STATUS, koInfoBean.getPublicationStatus()), Updates.set(KO_STATUS, "1")
		);

		coll.findOneAndUpdate(filter, updates);
	}


	/**
	 * Updatelinkko.
	 *
	 * @param coll_ko_link  the coll ko link
	 * @param koInfoBean    the ko info bean
	 * @param defaultAcctId the default acct id
	 * @param koId          the ko id
	 * @param getKoStage    the get ko stage
	 */
	private static void updatelinkko(MongoCollection<Document> coll_ko_link, KOInfoBean koInfoBean,
			String defaultAcctId, String koId, String getKoStage) {

		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String loginusrname = auth.getName();
		String incident_id;

		if ((Objects.nonNull(koInfoBean.getTicketsearchbox()) && !koInfoBean.getTicketsearchbox().trim().equalsIgnoreCase("")))
			incident_id = koInfoBean.getTicketsearchbox();
		else
			incident_id = koInfoBean.getTicketID();

		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss", Locale.getDefault());
		Date date = new Date();
		Bson filter = Filters.eq(INCIDENT_ID, incident_id);
		Bson updates = Updates.combine(
				Updates.set("ko_id", koId), Updates.set("User_Id", loginusrname),
				Updates.set("link_date", dateFormat.format(date)));

		coll_ko_link.findOneAndUpdate(filter, updates);

	}
	
	/**
	 * Update generic data.
	 *
	 * @param koInfoBean the ko info bean
	 * @param getKoStage the get ko stage
	 * @throws UnsupportedEncodingException 
	 */
	public static void updateGenericData(KOInfoBean koInfoBean,String getKoStage) throws UnsupportedEncodingException
			 {
				
		ClassLoader loader = Thread.currentThread().getContextClassLoader();
		Properties properties = new Properties();
		try (InputStream resourceStream = loader.getResourceAsStream("application.properties")) {
			properties.load(resourceStream);
		} catch (IOException e) {
			log.error(e.getMessage());
		}

		String Mongoconnection = properties.getProperty("Mongoconnection");
		String host_name = properties.getProperty("mongodb");
		String auth_user = properties.getProperty("mongousername");
		String db_pwd = properties.getProperty("mongopassword");
		String port_no = properties.getProperty("mongoport");
		String auth_source = properties.getProperty("authSource");
		
		//generic ko
		String db_coll_generic_komaster = "ko_detail_inter";
		
		String encoded_pwd = URLEncoder.encode(db_pwd, "UTF-8");

		// Mongodb connection string.
		String client_url = "mongodb://" + auth_user + ":" + encoded_pwd + "@" + host_name + ":" + port_no + "/"
				+ auth_source;

		MongoClientURI uri = new MongoClientURI(client_url);

		// Connecting to the mongodb server using the given client uri.
		MongoClient mongo_client = new MongoClient(uri);

		// Fetching the database from the mongodb.

		MongoDatabase db = mongo_client.getDatabase(Mongoconnection);
		
		// Fetching the collection from the mongodb.
				MongoCollection<Document> col = db.getCollection(db_coll_generic_komaster);
				
				List<Document> getvalue_inter = find(col, koInfoBean.getKoID());
				
				if (getvalue_inter.size() > 0) {
					updateGenericko(col, koInfoBean, getKoStage);
					return;

					 } else {
						 insertGenericko(col, koInfoBean);

					 }

			}
	
	/**
	 * Update genericko.
	 *
	 * @param col the col
	 * @param koInfo the ko info
	 * @param getKoStage the get ko stage
	 */
	private static void updateGenericko(MongoCollection<Document> col, KOInfoBean koInfo,String getKoStage) {
		String koId = koInfo.getKoID();
		String appName = koInfo.getApplicationName();
		String koText = koInfo.getShortDescription() + " " + koInfo.getLongDescription() + " "+ koInfo.getSymptoms() + " "+ koInfo.getResolution();
		String publicationStatus = getKoStage;
		String summary = koInfo.getShortDescription() + " " + koInfo.getLongDescription();
		String ticketGroup = " ";
		Integer bplId = koInfo.getBusinessProcessLevelid();
		String koType = "Generic";
		Integer koStatus = 1;
		
		Bson filter = Filters.eq(KO_ID, koId);
		Bson updates = Updates.combine(Updates.set(KO_TEXT, koText), Updates.set(KO_TEXT, koText),
				Updates.set(SUMMARY, summary), Updates.set(APP_NAME, appName),
				Updates.set(TICKET_GROUP,ticketGroup),
				Updates.set("Publication_status", publicationStatus), Updates.set(KO_STATUS, koStatus),
				Updates.set("Bpl_id", bplId), Updates.set("Ko_type", koType)
		
		);

		col.findOneAndUpdate(filter, updates);
		
	}
	
	/**
	 * Insert genericko.
	 *
	 * @param col the col
	 * @param koInfo the ko info
	 */
	private static void insertGenericko(MongoCollection<Document> col, KOInfoBean koInfo) {
		
		String koId = koInfo.getKoID();
		String appName = koInfo.getApplicationName();
		String koText = koInfo.getShortDescription() + " " + koInfo.getLongDescription() + " "+ koInfo.getSymptoms() + " "+ koInfo.getResolution();
		String publicationStatus = koInfo.getKoStage();
		String summary = koInfo.getShortDescription() + " " + koInfo.getLongDescription();
		String ticketGroup = " ";
		Integer bplId = koInfo.getBusinessProcessLevelid();
		String koType = "Generic";
		Integer koStatus = 1;
		
		Document intertab = new Document();
		intertab.put(KO_ID, koId);
		intertab.put(APP_NAME, appName);
		intertab.put(KO_TEXT, koText);
		intertab.put("Publication_status", publicationStatus);
		intertab.put(SUMMARY, summary);
		intertab.put(TICKET_GROUP, ticketGroup);
		intertab.put("Bpl_id", bplId);
		intertab.put("Ko_type", koType);
		intertab.put(KO_STATUS, koStatus);
		
		col.insertOne(intertab);

	}
	
	/**
	 * Insert generic data.
	 *
	 * @param koInfoBean the ko info bean
	 * @throws UnsupportedEncodingException 
	 */
	public static void insertGenericData(KOInfoBean koInfoBean) throws UnsupportedEncodingException
			{
				
		ClassLoader loader = Thread.currentThread().getContextClassLoader();
		Properties properties = new Properties();
		try (InputStream resourceStream = loader.getResourceAsStream("application.properties")) {
			properties.load(resourceStream);
		} catch (IOException e) {
			log.error(e.getMessage());
		}

		String Mongoconnection = properties.getProperty("Mongoconnection");
		String host_name = properties.getProperty("mongodb");
		String auth_user = properties.getProperty("mongousername");
		String db_pwd = properties.getProperty("mongopassword");
		String port_no = properties.getProperty("mongoport");
		String auth_source = properties.getProperty("authSource");
		
		//generic ko
		String db_coll_generic_komaster = "ko_detail_inter";
		
		String encoded_pwd = URLEncoder.encode(db_pwd, "UTF-8");

		// Mongodb connection string.
		String client_url = "mongodb://" + auth_user + ":" + encoded_pwd + "@" + host_name + ":" + port_no + "/"
				+ auth_source;

		MongoClientURI uri = new MongoClientURI(client_url);

		// Connecting to the mongodb server using the given client uri.
		MongoClient mongo_client = new MongoClient(uri);

		// Fetching the database from the mongodb.

		MongoDatabase db = mongo_client.getDatabase(Mongoconnection);
		
		// Fetching the collection from the mongodb.
				MongoCollection<Document> col = db.getCollection(db_coll_generic_komaster);

				insertGenericko(col, koInfoBean);

			}
	
	/**
	 * Insert clone ko.
	 *
	 * @param col the col
	 * @param koInfoBean the ko info bean
	 * @param koId the ko id
	 */
	public static void insertCloneKo(MongoCollection<Document> col,KOInfoBean koInfoBean, String koId) {
		
		String genericKoId = koInfoBean.getGenericKoID();
	
		Date todaysDate = new Date();
		DateFormat df2 = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss", Locale.getDefault());
		
		String date = df2.format(todaysDate);
        		
		Document intertab = new Document();
		intertab.put("generic_id", genericKoId);
		intertab.put("acc_ko_id", koId);
		intertab.put("link_date", date);

		col.insertOne(intertab);
		
	}

}