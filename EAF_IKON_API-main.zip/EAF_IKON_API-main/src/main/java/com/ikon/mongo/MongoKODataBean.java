package com.ikon.mongo;

import java.util.Map;
import java.util.Set;

import org.bson.BSONObject;

import com.mongodb.DBObject;

/**
 * The Class MongoKODataBean.
 */
public class MongoKODataBean implements DBObject {

	/** The ko id. */
	private String ko_id;

	/** The ko text. */
	private String ko_text;

	/** The app name. */
	private String app_name;

	/** The ticket group. */
	private String ticket_group;

	/** The publication status. */
	private String publication_status;

	/** The ko status. */
	private String ko_status;

	/** The new ko flag. */
	private int new_ko_flag;

	/** The updated ko flag. */
	private int updated_ko_flag;

	/**
	 * Gets the ko id.
	 *
	 * @return the ko_id
	 */
	public String getKo_id() {
		return ko_id;
	}

	/**
	 * Sets the ko id.
	 *
	 * @param kOInfoBeanList_value the ko_id to set
	 */
	public void setKo_id(String kOInfoBeanList_value) {
		this.ko_id = kOInfoBeanList_value;
	}

	/**
	 * Gets the ko text.
	 *
	 * @return the ko_text
	 */
	public String getKo_text() {
		return ko_text;
	}

	/**
	 * Sets the ko text.
	 *
	 * @param ko_text the ko_text to set
	 */
	public void setKo_text(String ko_text) {
		this.ko_text = ko_text;
	}

	/**
	 * Gets the app name.
	 *
	 * @return the app_name
	 */
	public String getApp_name() {
		return app_name;
	}

	/**
	 * Sets the app name.
	 *
	 * @param app_name the app_name to set
	 */
	public void setApp_name(String app_name) {
		this.app_name = app_name;
	}

	/**
	 * Gets the ticket group.
	 *
	 * @return the ticket_group
	 */
	public String getTicket_group() {
		return ticket_group;
	}

	/**
	 * Sets the ticket group.
	 *
	 * @param ticket_group the ticket_group to set
	 */
	public void setTicket_group(String ticket_group) {
		this.ticket_group = ticket_group;
	}

	/**
	 * Gets the publication status.
	 *
	 * @return the publication_status
	 */
	public String getPublication_status() {
		return publication_status;
	}

	/**
	 * Sets the publication status.
	 *
	 * @param publication_status the publication_status to set
	 */
	public void setPublication_status(String publication_status) {
		this.publication_status = publication_status;
	}

	/**
	 * Gets the ko status.
	 *
	 * @return the ko_status
	 */
	public String getKo_status() {
		return ko_status;
	}

	/**
	 * Sets the ko status.
	 *
	 * @param ko_status the ko_status to set
	 */
	public void setKo_status(String ko_status) {
		this.ko_status = ko_status;
	}

	/**
	 * Gets the new ko flag.
	 *
	 * @return the new_ko_flag
	 */
	public int getNew_ko_flag() {
		return new_ko_flag;
	}

	/**
	 * Sets the new ko flag.
	 *
	 * @param new_ko_flag the new_ko_flag to set
	 */
	public void setNew_ko_flag(int new_ko_flag) {
		this.new_ko_flag = new_ko_flag;
	}

	/**
	 * Gets the updated ko flag.
	 *
	 * @return the updated_ko_flag
	 */
	public int getUpdated_ko_flag() {
		return updated_ko_flag;
	}

	/**
	 * Sets the updated ko flag.
	 *
	 * @param updated_ko_flag the updated_ko_flag to set
	 */
	public void setUpdated_ko_flag(int updated_ko_flag) {
		this.updated_ko_flag = updated_ko_flag;
	}

	/**
	 * Put.
	 *
	 * @param key the key
	 * @param v   the v
	 * @return the object
	 */
	@Override
	public Object put(String key, Object v) {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * Put all.
	 *
	 * @param o the o
	 */
	@Override
	public void putAll(BSONObject o) {
		// TODO Auto-generated method stub

	}

	/**
	 * Put all.
	 *
	 * @param m the m
	 */
	@Override
	public void putAll(Map m) {
		// TODO Auto-generated method stub

	}

	/**
	 * Gets the.
	 *
	 * @param key the key
	 * @return the object
	 */
	@Override
	public Object get(String key) {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * To map.
	 *
	 * @return the map
	 */
	@Override
	public Map toMap() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * Removes the field.
	 *
	 * @param key the key
	 * @return the object
	 */
	@Override
	public Object removeField(String key) {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * Contains key.
	 *
	 * @param key the key
	 * @return true, if successful
	 */
	public boolean containsKey(String key) {
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * Contains field.
	 *
	 * @param s the s
	 * @return true, if successful
	 */
	@Override
	public boolean containsField(String s) {
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * Key set.
	 *
	 * @return the sets the
	 */
	@Override
	public Set<String> keySet() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * Mark as partial object.
	 */
	@Override
	public void markAsPartialObject() {
		// TODO Auto-generated method stub

	}

	/**
	 * Checks if is partial object.
	 *
	 * @return true, if is partial object
	 */
	@Override
	public boolean isPartialObject() {
		// TODO Auto-generated method stub
		return false;
	}

}
