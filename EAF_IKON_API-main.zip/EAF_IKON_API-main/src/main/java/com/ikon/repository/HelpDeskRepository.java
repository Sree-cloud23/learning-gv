package com.ikon.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ikon.model.HelpDesk;

	
/**
 * The Interface HelpDeskRepository.
 */
public interface HelpDeskRepository extends JpaRepository<HelpDesk, Long> 
{
	    
 // UserMaster findByEmail(String email_ID);
	
}
