/**
 * 
 */
package com.ikon.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ikon.model.BusinessProcessMaster;



/**
 * The Interface BusinessProcessRepository.
 *
 * @author Capgemini
 */

@Repository
public interface BusinessProcessRepository extends JpaRepository<BusinessProcessMaster, Long>{


	/**
	 * Find all.
	 *
	 * @return the list
	 */
	public List<BusinessProcessMaster> findAll();
	
	/**
	 * Find business process id.
	 *
	 * @param bp3 the bp 3
	 * @return the integer
	 */
	@Query(value = "SELECT id FROM business_process_master WHERE BnsProL3 = :bp3", nativeQuery = true)
	public Integer findBusinessProcessId(@Param("bp3") String bp3);
	
}
