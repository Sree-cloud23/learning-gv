package com.ikon.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ikon.model.Role;

/**
 * The Interface RoleRepository.
 */
public interface RoleRepository extends JpaRepository<Role, Long>{
	
	
}
