package com.ikon.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ikon.model.AccessControl;

/**
 * The Interface AccessControlRepository.
 */
public interface AccessControlRepository extends JpaRepository<AccessControl, Long> {
	 
 	/**
 	 * Gets the access control details by user name.
 	 *
 	 * @param userId the user id
 	 * @return the access control details by user name
 	 */
 	@Query(value = "select accessId,profileId,roleId,userId,accountId,createdBy,createdDate,status,modifiedBy,modifiedDate from access_control where UserID=:userId", nativeQuery = true)	
	 List<AccessControl> getAccessControlDetailsByUserName(@Param("userId") String userId);

}
