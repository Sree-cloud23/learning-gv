package com.ikon.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ikon.model.UserAccountApplicationMapping;


/**
 * The Interface UserAccountAppRepository.
 */
public interface UserAccountAppRepository extends JpaRepository<UserAccountApplicationMapping, Long>{

	
}
