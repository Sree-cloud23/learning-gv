package com.ikon.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ikon.model.IncKoLinkML;

/**
 * The Interface KOUsageRepository.
 */
public interface IncKOLinkMLRepository extends JpaRepository<IncKoLinkML, String> {
	
}
