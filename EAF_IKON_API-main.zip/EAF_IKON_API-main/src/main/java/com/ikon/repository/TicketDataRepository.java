package com.ikon.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ikon.model.TicketData;

/**
 * The Interface TicketDataRepository.
 */
public interface TicketDataRepository extends JpaRepository<TicketData, Long> {

	/**
	 * Checks if is ticket exists.
	 *
	 * @param ticketId the ticket id
	 * @return the number
	 */
	@Query(value = "SELECT count(1) FROM TicketData where ticketID =:ticketId")
	Number isTicketExists(@Param("ticketId") String ticketId);
	
	/**
	 * Gets the ticket data.
	 *
	 * @param ticketId the ticket id
	 * @return the ticket data
	 */
	@Query(value = "SELECT serialNumber FROM TicketData where ticketID =:ticketId")
	Long getTicketData(@Param("ticketId") String ticketId);
}
