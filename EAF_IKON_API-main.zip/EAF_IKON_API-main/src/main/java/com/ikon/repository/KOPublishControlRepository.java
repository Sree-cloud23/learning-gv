package com.ikon.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ikon.model.KOPublishControl;

/**
 * The Interface KOPublishControlRepository.
 */
public interface KOPublishControlRepository extends JpaRepository<KOPublishControl, Long> {

}
