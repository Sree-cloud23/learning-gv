package com.ikon.repository;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ikon.model.UserMaster;

/**
 * The Interface UserRepository.
 */
public interface UserRepository extends JpaRepository<UserMaster, Long> {
   
	/**
    * Find by name.
    *
    * @param username the username
    * @return the user master
    */
	UserMaster findByName(String username);
    
    /**
     * Find by email.
     *
     * @param email_ID the email ID
     * @return the optional
     */
    Optional<UserMaster> findByEmail(String email_ID);
	 
 	/**
 	 * Find by reset token.
 	 *
 	 * @param resetToken the reset token
 	 * @return the optional
 	 */
 	Optional<UserMaster> findByResetToken(String resetToken);
	 
	 /**
 	 * Find by name and isactive.
 	 *
 	 * @param username the username
 	 * @param isactive the isactive
 	 * @return the list
 	 */
 	List<UserMaster> findByNameAndIsactive(String username, short isactive );
     
    /**
     * Find by tokenid and isloggedin.
     *
     * @param tokenid the tokenid
     * @param isloggedin the isloggedin
     * @return the list
     */
    UserMaster findByTokenidAndIsloggedin(String tokenid, Short isloggedin);
}
