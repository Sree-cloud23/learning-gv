package com.ikon.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ikon.model.TicketDataHistory;

/**
 * The Interface TicketDataHistoryRepository.
 */
public interface TicketDataHistoryRepository extends JpaRepository<TicketDataHistory, Long> {

	/**
	 * Gets the tickets linked to KO.
	 *
	 * @param koId the ko id
	 * @return the tickets linked to KO
	 */
	@Query(value = "select ticketid from (\r\n"
			+ "select ticketid, ts_rank_cd(to_tsvector(relevperc), query) as rank\r\n"
			+ "from ticket_data_history, to_tsquery(:koId) query\r\n" + "where to_tsvector(relevperc) @@ query\r\n"
			+ "order by rank desc) as tickets", nativeQuery = true)
	List<String> getTicketsLinkedToKO(@Param("koId") String koId);
	
	/**
	 * 
	 * @param ticketID
	 * @return
	 */
	@Query(value = "select count(ticketid) from ticket_data_history where ticketid = :ticketId", nativeQuery = true)
	 public int fetchByTicketID(String ticketId);

	/**
	 * @param ticketId
	 * @return
	 */
	@Query(value = "select serialnumber from ticket_data_history where ticketid = :ticketId", nativeQuery = true)
	Long getSerialNumberForTicket(String ticketId);

}