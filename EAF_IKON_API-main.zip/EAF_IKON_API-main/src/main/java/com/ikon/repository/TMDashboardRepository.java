package com.ikon.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ikon.model.TicketDataHistory;

/**
 * The Interface TMDashboardRepository.
 */
public interface TMDashboardRepository extends JpaRepository<TicketDataHistory, Long>  {

}
