package com.ikon.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ikon.model.Setting;

/**
 * The Interface SettingRepository.
 */
public interface SettingRepository extends JpaRepository<Setting, Long> {
	 

	/**
	 * Find by user id.
	 *
	 * @param user_ID the user ID
	 * @return the setting
	 */
	Setting findByUserId(String user_ID);
}
