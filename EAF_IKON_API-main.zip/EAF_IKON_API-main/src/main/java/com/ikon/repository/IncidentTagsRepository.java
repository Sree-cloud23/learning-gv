package com.ikon.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ikon.model.IncidentTags;

// TODO: Auto-generated Javadoc
/**
 * The Interface IncidentTagsRepository.
 */
public interface IncidentTagsRepository extends JpaRepository<IncidentTags, Long> {
	
	/**
	 * Find all.
	 *
	 * @return the list
	 */
	public List<IncidentTags> findAll();
}
