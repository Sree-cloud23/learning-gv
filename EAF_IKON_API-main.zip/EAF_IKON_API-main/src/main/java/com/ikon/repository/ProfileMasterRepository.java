package com.ikon.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ikon.model.ProfileMaster;

/**
 * The Interface ProfileMasterRepository.
 */
public interface ProfileMasterRepository extends JpaRepository<ProfileMaster, Long> {

}
