package com.ikon.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ikon.model.RoleMaster;

/**
 * The Interface RoleMasterRepository.
 */
public interface RoleMasterRepository extends JpaRepository<RoleMaster, Long> {

}
