package com.ikon.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ikon.model.AccountInfo;


/**
 * The Interface AccountInfoRepository.
 */
public interface AccountInfoRepository extends JpaRepository<AccountInfo, Long> {
	
	/**
	 * Find by account id.
	 *
	 * @param i the i
	 * @return the account info
	 */
	AccountInfo findByAccountId(int i);
	

	/**
	 * Find display page.
	 *
	 * @param AccountID the account ID
	 * @return the string
	 */
	@Query(value = "select HelpdeskEnabled from account_features where AccountID=:AccountID", nativeQuery = true)
	String findDisplayPage(@Param("AccountID") int AccountID);
	
	/**
	 * Find KO enabled.
	 *
	 * @param AccountID the account ID
	 * @return the string
	 */
	@Query(value = "select KOEnabled from account_features where AccountID=:AccountID", nativeQuery = true)
	String findKOEnabled(@Param("AccountID") int AccountID);

}
