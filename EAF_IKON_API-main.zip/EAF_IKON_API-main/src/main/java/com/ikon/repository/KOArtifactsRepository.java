package com.ikon.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.ikon.model.KOArtifacts;

/**
 * The Interface KOArtifactsRepository.
 */
public interface KOArtifactsRepository  extends JpaRepository<KOArtifacts, Integer>  {

	KOArtifacts findByKoSerialNo(int koserialno);

	@Transactional
	@Modifying
	@Query("update KOArtifacts ka set ka.attachmentName =:attachName  where ka.koSerialNo = :koserialno")
	void deleteAttachment(@Param("attachName") String attachName,@Param("koserialno") int koserialno);
}
