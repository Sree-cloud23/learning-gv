package com.ikon.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ikon.model.KOInfo;

/**
 * The Interface KOInfoRepository.
 */
public interface KOInfoRepository extends JpaRepository<KOInfo, Long> {
	
	/**
	 * Find ko id.
	 *
	 * @return the string
	 */
	@Query(value = "SELECT CONCAT('GS',MAX(CAST(TRIM(LEADING 'GS' FROM KoID) AS Integer))) as koId FROM Ko_info WHERE LEFT(KoID,2)='GS'", nativeQuery = true)
	public String findKoId();

	/**
	 * @param koid
	 * @return
	 */
	public KOInfo findByKoID(String koid);

	/**
	 * @param koSerialNo
	 * @return
	 */
	@Query(value = "select kod.resolution from ko_detail kod where kod.koserialno = :koserialno", nativeQuery = true)
	public String getResolutionForAKO(@Param("koserialno") int koSerialNo);
	
	/**
	 * @param koSerialNo
	 * @return
	 */
	@Query(value = "select ki.koserialno from ko_info ki where ki.koid = :koid", nativeQuery = true)
	public String getKOSerialNo(@Param("koid") String koid);

}
