package com.ikon.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ikon.model.ApplicationMaster;

/**
 * The Interface ApplicationMasterRepository.
 */
public interface ApplicationMasterRepository extends JpaRepository<ApplicationMaster, Long> {

}
