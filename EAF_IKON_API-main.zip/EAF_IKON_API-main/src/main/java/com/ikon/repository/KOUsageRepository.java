package com.ikon.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ikon.model.KOUsage;

/**
 * The Interface KOUsageRepository.
 */
public interface KOUsageRepository extends JpaRepository<KOUsage, Long> {
	
	/**
	 * Find all.
	 *
	 * @return the list
	 */
	public List<KOUsage> findAll();
	
	/**
	 * @param koSerialNo
	 * @return
	 */
	@Query(value = "select count(1) from ko_usage kou where kou.koserialno = :koserialno", nativeQuery = true)
	public Integer getLinkedIncCountForASerialNumber(@Param("koserialno") int koSerialNo);

	/**
	 * Find by serial number.
	 *
	 * @param ticketSerialNumber the ticket serial number
	 * @return the KO usage
	 */
	public KOUsage findBySerialNumber(int ticketSerialNumber);
}
