package com.ikon.model;

import javax.persistence.*;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

/**
 * The Class Role.
 */
@Entity
@Table(name = "role_category")
public class Role implements Serializable{
	
	/** The rolecategory ID. */
	@Id @GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="RolecategoryID")
    private Long rolecategoryID;
	
	/** The role category name. */
	@Column(name="Rolecategoryname")
    private String roleCategoryName;
	
    /** The status. */
    @Column(name="Status")
    private String status;
    
    /** The created date. */
    @Column(name="Createddate")
    private Date createdDate;
    
    /** The created by. */
    @Column(name="Createdby")
    private String createdBy;
    
    /** The modified date. */
    @Column(name="Modifieddate")
    private Date modifiedDate;
    
    /** The modified by. */
    @Column(name="Modifiedby")
    private String modifiedBy;

	
	
	/**
	 * Gets the rolecategory ID.
	 *
	 * @return the rolecategoryID
	 */
	public Long getRolecategoryID() {
		return rolecategoryID;
	}

	/**
	 * Sets the rolecategory ID.
	 *
	 * @param rolecategoryID the rolecategoryID to set
	 */
	private void setRolecategoryID(Long rolecategoryID) {
		this.rolecategoryID = rolecategoryID;
	}

	/**
	 * Gets the role category name.
	 *
	 * @return the roleCategoryName
	 */
	public String getRoleCategoryName() {
		return roleCategoryName;
	}

	/**
	 * Sets the role category name.
	 *
	 * @param roleCategoryName the roleCategoryName to set
	 */
	public void setRoleCategoryName(String roleCategoryName) {
		this.roleCategoryName = roleCategoryName;
	}

	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Sets the status.
	 *
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Gets the created date.
	 *
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * Sets the created date.
	 *
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * Gets the created by.
	 *
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * Sets the created by.
	 *
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * Gets the modified date.
	 *
	 * @return the modifiedDate
	 */
	public Date getModifiedDate() {
		return modifiedDate;
	}

	/**
	 * Sets the modified date.
	 *
	 * @param modifiedDate the modifiedDate to set
	 */
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	/**
	 * Gets the modified by.
	 *
	 * @return the modifiedBy
	 */
	public String getModifiedBy() {
		return modifiedBy;
	}

	/**
	 * Sets the modified by.
	 *
	 * @param modifiedBy the modifiedBy to set
	 */
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	
	/**
	 * Adds the rolecat id pub.
	 *
	 * @param rolecategoryID the rolecategory ID
	 */
	public void addRolecatIdPub(Long rolecategoryID) {
		this.rolecategoryID = rolecategoryID;
	}

	/**
	 * Hash code.
	 *
	 * @return the int
	 */
	@Override
	public int hashCode() {
	    return Objects.hash(getRolecategoryID());
	}
	
	/**
	 * Equals.
	 *
	 * @param o the o
	 * @return true, if successful
	 */
	@Override
	public boolean equals(Object o) {
	    return (this.equals(o) || (o != null && this.getClass().equals(o.getClass())));
		}	
}
