package com.ikon.model;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The Class KOInfo.
 */
@Entity
@Table(name = "ko_info")
public class KOInfo implements Serializable{

	/** The ko serial no. */
	@Column(name = "KOSerialno")
	int koSerialNo;

	/** The account ID. */
	@Column(name = "Accountid")
	int accountID;

	/** The ko ID. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Koid")
	String koID;

	/** The short descrption. */
	@Column(name = "Shortdescription")
	String shortDescrption;

	/** The created in IKON. */
	@Column(name = "Createdinikon")
	Integer createdInIKON;

	/** The attachment present. */
	@Column(name = "Attachmentpresent")
	Integer attachmentPresent;

	/** The application name. */
	@Column(name = "Applicationname")
	String applicationName;

	/** The assignment group. */
	@Column(name = "Assignmentgroup")
	String assignmentGroup;

	/** The publication status. */
	@Column(name = "Publicationstatus")
	String publicationStatus;

	/** The ko status. */
	@Column(name = "KOstatus")
	Integer koStatus;

	/** The it SM tool. */
	@Column(name = "Itsmtool")
	String itSMTool;

	/** The topic. */
	@Column(name = "Topic")
	String topic;

	/** The ko category. */
	@Column(name = "KOcategory")
	String koCategory;

	/** The long description. */
	@Column(name = "Longdescription")
	String longDescription;

	/** The meta keywords. */
	@Column(name = "Metakeywords")
	String metaKeywords;

	/** The feed ID. */
	@Column(name = "Feedid")
	Integer feedID;

	// changed int to Integer

	/**
	 * Hash code.
	 *
	 * @return the int
	 */
	@Override
	public int hashCode() {
		return Objects.hash(getKoID());
	}

	/**
	 * Gets the ko serial no.
	 *
	 * @return the koSerialNo
	 */
	public int getKoSerialNo() {
		return koSerialNo;
	}

	/**
	 * Sets the ko serial no.
	 *
	 * @param koSerialNo the koSerialNo to set
	 */
	public void setKoSerialNo(int koSerialNo) {
		this.koSerialNo = koSerialNo;
	}

	/**
	 * Gets the account ID.
	 *
	 * @return the accountID
	 */
	public int getAccountID() {
		return accountID;
	}

	/**
	 * Sets the account ID.
	 *
	 * @param accountID the accountID to set
	 */
	public void setAccountID(int accountID) {
		this.accountID = accountID;
	}

	/**
	 * Gets the ko ID.
	 *
	 * @return the koID
	 */
	public String getKoID() {
		return koID;
	}

	/**
	 * Sets the ko ID.
	 *
	 * @param koID the koID to set
	 */
	private void setKoID(String koID) {
		this.koID = koID;
	}

	/**
	 * Gets the short descrption.
	 *
	 * @return the shortDescrption
	 */
	public String getShortDescrption() {
		return shortDescrption;
	}

	/**
	 * Sets the short descrption.
	 *
	 * @param shortDescrption the shortDescrption to set
	 */
	public void setShortDescrption(String shortDescrption) {
		this.shortDescrption = shortDescrption;
	}

	/**
	 * Gets the created in IKON.
	 *
	 * @return the createdInIKON
	 */
	public Integer getCreatedInIKON() {
		return createdInIKON;
	}

	/**
	 * Sets the created in IKON.
	 *
	 * @param createdInIKON the createdInIKON to set
	 */
	public void setCreatedInIKON(Integer createdInIKON) {
		this.createdInIKON = createdInIKON;
	}

	/**
	 * Gets the attachment present.
	 *
	 * @return the attachmentPresent
	 */
	public Integer getAttachmentPresent() {
		return attachmentPresent;
	}

	/**
	 * Sets the attachment present.
	 *
	 * @param attachmentPresent the attachmentPresent to set
	 */
	public void setAttachmentPresent(Integer attachmentPresent) {
		this.attachmentPresent = attachmentPresent;
	}

	/**
	 * Gets the application name.
	 *
	 * @return the applicationName
	 */
	public String getApplicationName() {
		return applicationName;
	}

	/**
	 * Sets the application name.
	 *
	 * @param applicationName the applicationName to set
	 */
	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}

	/**
	 * Gets the assignment group.
	 *
	 * @return the assignmentGroup
	 */
	public String getAssignmentGroup() {
		return assignmentGroup;
	}

	/**
	 * Sets the assignment group.
	 *
	 * @param assignmentGroup the assignmentGroup to set
	 */
	public void setAssignmentGroup(String assignmentGroup) {
		this.assignmentGroup = assignmentGroup;
	}

	/**
	 * Gets the publication status.
	 *
	 * @return the publicationStatus
	 */
	public String getPublicationStatus() {
		return publicationStatus;
	}

	/**
	 * Sets the publication status.
	 *
	 * @param publicationStatus the publicationStatus to set
	 */
	public void setPublicationStatus(String publicationStatus) {
		this.publicationStatus = publicationStatus;
	}

	/**
	 * Gets the ko status.
	 *
	 * @return the koStatus
	 */
	public Integer getKoStatus() {
		return koStatus;
	}

	/**
	 * Sets the ko status.
	 *
	 * @param koStatus the koStatus to set
	 */
	public void setKoStatus(Integer koStatus) {
		this.koStatus = koStatus;
	}

	/**
	 * Gets the it SM tool.
	 *
	 * @return the itSMTool
	 */
	public String getItSMTool() {
		return itSMTool;
	}

	/**
	 * Sets the it SM tool.
	 *
	 * @param itSMTool the itSMTool to set
	 */
	public void setItSMTool(String itSMTool) {
		this.itSMTool = itSMTool;
	}

	/**
	 * Gets the topic.
	 *
	 * @return the topic
	 */
	public String getTopic() {
		return topic;
	}

	/**
	 * Sets the topic.
	 *
	 * @param topic the topic to set
	 */
	public void setTopic(String topic) {
		this.topic = topic;
	}

	/**
	 * Gets the ko category.
	 *
	 * @return the koCategory
	 */
	public String getKoCategory() {
		return koCategory;
	}

	/**
	 * Sets the ko category.
	 *
	 * @param koCategory the koCategory to set
	 */
	public void setKoCategory(String koCategory) {
		this.koCategory = koCategory;
	}

	/**
	 * Gets the long description.
	 *
	 * @return the longDescription
	 */
	public String getLongDescription() {
		return longDescription;
	}

	/**
	 * Sets the long description.
	 *
	 * @param longDescription the longDescription to set
	 */
	public void setLongDescription(String longDescription) {
		this.longDescription = longDescription;
	}

	/**
	 * Gets the meta keywords.
	 *
	 * @return the metaKeywords
	 */
	public String getMetaKeywords() {
		return metaKeywords;
	}

	/**
	 * Sets the meta keywords.
	 *
	 * @param metaKeywords the metaKeywords to set
	 */
	public void setMetaKeywords(String metaKeywords) {
		this.metaKeywords = metaKeywords;
	}

	/**
	 * Gets the feed ID.
	 *
	 * @return the feedID
	 */
	public Integer getFeedID() {
		return feedID;
	}

	/**
	 * Sets the feed ID.
	 *
	 * @param feedID the feedID to set
	 */
	public void setFeedID(Integer feedID) {
		this.feedID = feedID;
	}

	/**
	 * Equals.
	 *
	 * @param o the o
	 * @return true, if successful
	 */
	@Override
	public boolean equals(Object o) {
	    return (this.equals(o) || (o != null && this.getClass().equals(o.getClass())));
		}

}
