package com.ikon.model;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.*;

/**
 * The Class TicketData.
 */
@Entity
@Table(name = "ticket_data")
public class TicketData implements Serializable{
    
	/** The serial number. */
	@Column(name="Serialnumber")
    private Long serialNumber;
	
	/** The account ID. */
	@Column(name="Accountid")
    private String accountID;
    
    /** The ticket ID. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="Ticketid")
    private String ticketID;
    
    /** The summary. */
    @Column(name="Summary")
    private String summary;
    
    /** The notes. */
    @Column(name="Notes")
    private String notes;
    
    /** The application name. */
    @Column(name="Applicationname")
    private String applicationName;
    
    /** The assignment group. */
    @Column(name="Assignmentgroup")
    private String assignmentGroup;
    
    /** The assignee name. */
    @Column(name="Assigneename")
    private String assigneeName;
    
    /** The status. */
    @Column(name="status")
    private String status;
    
    /** The closed date. */
    @Column(name="Closeddate")
    private String closedDate;
    
    /** The closed by. */
    @Column(name="Closedby")
    private String closedBy;
    
    /** The resolution note. */
    @Column(name="Resolutionnote")
    private String resolutionNote;
    
    /** The service type. */
    @Column(name="Servicetype")
    private String serviceType;
    
    /** The company. */
    @Column(name="Company")
    private String company;
    
    /** The category. */
    @Column(name="Category")
    private String category;
    
    /** The sub category. */
    @Column(name="Subcategory")
    private String subCategory;
    
    /** The urgency. */
    @Column(name="Urgency")
    private String urgency;
    
    /** The priority. */
    @Column(name="Priority")
    private String priority;
    
    /** The impact. */
    @Column(name="Impact")
    private String impact;
    
    /** The reported date. */
    @Column(name="Reporteddate")
    private String reportedDate;
    
    /** The work notes. */
    @Column(name="Worknotes")
    private String workNotes;
    
    /** The Lastmodified by. */
    @Column(name="Lastmodifiedby")
    private String LastmodifiedBy;
    
    /** The lastmodified date. */
    @Column(name="Lastmodifieddate")
    private String lastmodifiedDate;
    
    /** The resolved date. */
    @Column(name="Resolveddate")
    private String resolvedDate;
    
    /** The opened by. */
    @Column(name="Openedby")
    private String openedBy;
    
    /** The location. */
    @Column(name="Location")
    private String location;
    
    /** The breach exception. */
    @Column(name="Breachexception")
    private String breachException;
    
    /** The breach reason. */
    @Column(name="Breachreason")
    private String breachReason;
    
    /** The contact type. */
    @Column(name="Contacttype")
    private String contactType;
    
    /** The environment. */
    @Column(name="Environment")
    private String environment;
    
    /** The estimated resolution date. */
    @Column(name="Estimatedresolutiondate")
    private String estimatedResolutionDate;
    
    /** The incident association type. */
    @Column(name="Incidentassociationtype")
    private String incidentAssociationType;
    
    /** The support company. */
    @Column(name="Supportcompany")
    private String supportCompany;
    
    /** The app tier. */
    @Column(name="Apptier")
    private String appTier;
    
    /** The inc ageing. */
    @Column(name="Incageing")
    private String incAgeing;
    
    /** The next target date. */
    @Column(name="Nexttargetdate")
    private String nextTargetDate;
    
    /** The operational categorization tier 1. */
    @Column(name="Operationalcategorizationtier1")
    private String operationalCategorizationTier1;
    
    /** The operational categorization tier 2. */
    @Column(name="Operationalcategorizationtier2")
    private String operationalCategorizationTier2;
    
    /** The operational categorization tier 3. */
    @Column(name="Operationalcategorizationtier3")
    private String operationalCategorizationTier3;
    
    /** The product categorization tier 1. */
    @Column(name="Productcategorizationtier1")
    private String productCategorizationTier1;
    
    /** The product categorization tier 2. */
    @Column(name="Productcategorizationtier2")
    private String productCategorizationTier2;
    
    /** The product categorization tier 3. */
    @Column(name="Productcategorizationtier3")
    private String productCategorizationTier3;
    
    /** The SLM status. */
    @Column(name="Slmstatus")
    private String SLMStatus;
    
    /** The support organization. */
    @Column(name="Supportorganization")
    private String supportOrganization;
    
    /** The resolution category. */
    @Column(name="Resolutioncategory")
    private String resolutionCategory;
    
    /** The status reason. */
    @Column(name="Statusreason")
    private String statusReason;
    
    /** The is primary. */
    @Column(name="Isprimary")
    private String isPrimary;
    
    /** The relev perc. */
    @Column(name="Relevperc")
    private String relevPerc;
    
    /** The usage perc. */
    @Column(name="Usageperc")
    private String usagePerc;
    
   /* @Column(name="Tower")
    private String tower;
    
    @Column(name="Cc")
    private String cc;
    
    @Column(name="Cluster")
    private String cluster;*/
    
    /** The feedback perc. */
   @Column(name="Feedbackperc")
    private String feedbackPerc;
    
    /** The master rel. */
    @Column(name="Masterrel")
    private String masterRel;
    
    /** The done flag. */
    @Column(name="Doneflag")
    private String doneFlag;

	
    
	/**
	 * Gets the serial number.
	 *
	 * @return the serialNumber
	 */
	public Long getSerialNumber() {
		return serialNumber;
	}

	/**
	 * Sets the serial number.
	 *
	 * @param serialNumber the serialNumber to set
	 */
	public void setSerialNumber(Long serialNumber) {
		this.serialNumber = serialNumber;
	}

	/**
	 * Gets the account ID.
	 *
	 * @return the accountID
	 */
	public String getAccountID() {
		return accountID;
	}

	/**
	 * Sets the account ID.
	 *
	 * @param accountID the accountID to set
	 */
	public void setAccountID(String accountID) {
		this.accountID = accountID;
	}

	/**
	 * Gets the ticket ID.
	 *
	 * @return the ticketID
	 */
	public String getTicketID() {
		return ticketID;
	}

	/**
	 * Sets the ticket ID.
	 *
	 * @param ticketID the ticketID to set
	 */
	private void setTicketID(String ticketID) {
		this.ticketID = ticketID;
	}

	/**
	 * Gets the summary.
	 *
	 * @return the summary
	 */
	public String getSummary() {
		return summary;
	}

	/**
	 * Sets the summary.
	 *
	 * @param summary the summary to set
	 */
	public void setSummary(String summary) {
		this.summary = summary;
	}

	/**
	 * Gets the notes.
	 *
	 * @return the notes
	 */
	public String getNotes() {
		return notes;
	}

	/**
	 * Sets the notes.
	 *
	 * @param notes the notes to set
	 */
	public void setNotes(String notes) {
		this.notes = notes;
	}

	/**
	 * Gets the application name.
	 *
	 * @return the applicationName
	 */
	public String getApplicationName() {
		return applicationName;
	}

	/**
	 * Sets the application name.
	 *
	 * @param applicationName the applicationName to set
	 */
	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}

	/**
	 * Gets the assignment group.
	 *
	 * @return the assignmentGroup
	 */
	public String getAssignmentGroup() {
		return assignmentGroup;
	}

	/**
	 * Sets the assignment group.
	 *
	 * @param assignmentGroup the assignmentGroup to set
	 */
	public void setAssignmentGroup(String assignmentGroup) {
		this.assignmentGroup = assignmentGroup;
	}

	/**
	 * Gets the assignee name.
	 *
	 * @return the assigneeName
	 */
	public String getAssigneeName() {
		return assigneeName;
	}

	/**
	 * Sets the assignee name.
	 *
	 * @param assigneeName the assigneeName to set
	 */
	public void setAssigneeName(String assigneeName) {
		this.assigneeName = assigneeName;
	}

	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Sets the status.
	 *
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Gets the closed date.
	 *
	 * @return the closedDate
	 */
	public String getClosedDate() {
		return closedDate;
	}

	/**
	 * Sets the closed date.
	 *
	 * @param closedDate the closedDate to set
	 */
	public void setClosedDate(String closedDate) {
		this.closedDate = closedDate;
	}

	/**
	 * Gets the closed by.
	 *
	 * @return the closedBy
	 */
	public String getClosedBy() {
		return closedBy;
	}

	/**
	 * Sets the closed by.
	 *
	 * @param closedBy the closedBy to set
	 */
	public void setClosedBy(String closedBy) {
		this.closedBy = closedBy;
	}

	/**
	 * Gets the resolution note.
	 *
	 * @return the resolutionNote
	 */
	public String getResolutionNote() {
		return resolutionNote;
	}

	/**
	 * Sets the resolution note.
	 *
	 * @param resolutionNote the resolutionNote to set
	 */
	public void setResolutionNote(String resolutionNote) {
		this.resolutionNote = resolutionNote;
	}

	/**
	 * Gets the service type.
	 *
	 * @return the serviceType
	 */
	public String getServiceType() {
		return serviceType;
	}

	/**
	 * Sets the service type.
	 *
	 * @param serviceType the serviceType to set
	 */
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	/**
	 * Gets the company.
	 *
	 * @return the company
	 */
	public String getCompany() {
		return company;
	}

	/**
	 * Sets the company.
	 *
	 * @param company the company to set
	 */
	public void setCompany(String company) {
		this.company = company;
	}

	/**
	 * Gets the category.
	 *
	 * @return the category
	 */
	public String getCategory() {
		return category;
	}

	/**
	 * Sets the category.
	 *
	 * @param category the category to set
	 */
	public void setCategory(String category) {
		this.category = category;
	}

	/**
	 * Gets the sub category.
	 *
	 * @return the subCategory
	 */
	public String getSubCategory() {
		return subCategory;
	}

	/**
	 * Sets the sub category.
	 *
	 * @param subCategory the subCategory to set
	 */
	public void setSubCategory(String subCategory) {
		this.subCategory = subCategory;
	}

	/**
	 * Gets the urgency.
	 *
	 * @return the urgency
	 */
	public String getUrgency() {
		return urgency;
	}

	/**
	 * Sets the urgency.
	 *
	 * @param urgency the urgency to set
	 */
	public void setUrgency(String urgency) {
		this.urgency = urgency;
	}

	/**
	 * Gets the priority.
	 *
	 * @return the priority
	 */
	public String getPriority() {
		return priority;
	}

	/**
	 * Sets the priority.
	 *
	 * @param priority the priority to set
	 */
	public void setPriority(String priority) {
		this.priority = priority;
	}

	/**
	 * Gets the impact.
	 *
	 * @return the impact
	 */
	public String getImpact() {
		return impact;
	}

	/**
	 * Sets the impact.
	 *
	 * @param impact the impact to set
	 */
	public void setImpact(String impact) {
		this.impact = impact;
	}

	/**
	 * Gets the reported date.
	 *
	 * @return the reportedDate
	 */
	public String getReportedDate() {
		return reportedDate;
	}

	/**
	 * Sets the reported date.
	 *
	 * @param reportedDate the reportedDate to set
	 */
	public void setReportedDate(String reportedDate) {
		this.reportedDate = reportedDate;
	}

	/**
	 * Gets the work notes.
	 *
	 * @return the workNotes
	 */
	public String getWorkNotes() {
		return workNotes;
	}

	/**
	 * Sets the work notes.
	 *
	 * @param workNotes the workNotes to set
	 */
	public void setWorkNotes(String workNotes) {
		this.workNotes = workNotes;
	}

	/**
	 * Gets the lastmodified by.
	 *
	 * @return the lastmodifiedBy
	 */
	public String getLastmodifiedBy() {
		return LastmodifiedBy;
	}

	/**
	 * Sets the lastmodified by.
	 *
	 * @param lastmodifiedBy the lastmodifiedBy to set
	 */
	public void setLastmodifiedBy(String lastmodifiedBy) {
		LastmodifiedBy = lastmodifiedBy;
	}

	/**
	 * Gets the lastmodified date.
	 *
	 * @return the lastmodifiedDate
	 */
	public String getLastmodifiedDate() {
		return lastmodifiedDate;
	}

	/**
	 * Sets the lastmodified date.
	 *
	 * @param lastmodifiedDate the lastmodifiedDate to set
	 */
	public void setLastmodifiedDate(String lastmodifiedDate) {
		this.lastmodifiedDate = lastmodifiedDate;
	}

	/**
	 * Gets the resolved date.
	 *
	 * @return the resolvedDate
	 */
	public String getResolvedDate() {
		return resolvedDate;
	}

	/**
	 * Sets the resolved date.
	 *
	 * @param resolvedDate the resolvedDate to set
	 */
	public void setResolvedDate(String resolvedDate) {
		this.resolvedDate = resolvedDate;
	}

	/**
	 * Gets the opened by.
	 *
	 * @return the openedBy
	 */
	public String getOpenedBy() {
		return openedBy;
	}

	/**
	 * Sets the opened by.
	 *
	 * @param openedBy the openedBy to set
	 */
	public void setOpenedBy(String openedBy) {
		this.openedBy = openedBy;
	}

	/**
	 * Gets the location.
	 *
	 * @return the location
	 */
	public String getLocation() {
		return location;
	}

	/**
	 * Sets the location.
	 *
	 * @param location the location to set
	 */
	public void setLocation(String location) {
		this.location = location;
	}

	/**
	 * Gets the breach exception.
	 *
	 * @return the breachException
	 */
	public String getBreachException() {
		return breachException;
	}

	/**
	 * Sets the breach exception.
	 *
	 * @param breachException the breachException to set
	 */
	public void setBreachException(String breachException) {
		this.breachException = breachException;
	}

	/**
	 * Gets the breach reason.
	 *
	 * @return the breachReason
	 */
	public String getBreachReason() {
		return breachReason;
	}

	/**
	 * Sets the breach reason.
	 *
	 * @param breachReason the breachReason to set
	 */
	public void setBreachReason(String breachReason) {
		this.breachReason = breachReason;
	}

	/**
	 * Gets the contact type.
	 *
	 * @return the contactType
	 */
	public String getContactType() {
		return contactType;
	}

	/**
	 * Sets the contact type.
	 *
	 * @param contactType the contactType to set
	 */
	public void setContactType(String contactType) {
		this.contactType = contactType;
	}

	/**
	 * Gets the environment.
	 *
	 * @return the environment
	 */
	public String getEnvironment() {
		return environment;
	}

	/**
	 * Sets the environment.
	 *
	 * @param environment the environment to set
	 */
	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	/**
	 * Gets the estimated resolution date.
	 *
	 * @return the estimatedResolutionDate
	 */
	public String getEstimatedResolutionDate() {
		return estimatedResolutionDate;
	}

	/**
	 * Sets the estimated resolution date.
	 *
	 * @param estimatedResolutionDate the estimatedResolutionDate to set
	 */
	public void setEstimatedResolutionDate(String estimatedResolutionDate) {
		this.estimatedResolutionDate = estimatedResolutionDate;
	}

	/**
	 * Gets the incident association type.
	 *
	 * @return the incidentAssociationType
	 */
	public String getIncidentAssociationType() {
		return incidentAssociationType;
	}

	/**
	 * Sets the incident association type.
	 *
	 * @param incidentAssociationType the incidentAssociationType to set
	 */
	public void setIncidentAssociationType(String incidentAssociationType) {
		this.incidentAssociationType = incidentAssociationType;
	}

	/**
	 * Gets the support company.
	 *
	 * @return the supportCompany
	 */
	public String getSupportCompany() {
		return supportCompany;
	}

	/**
	 * Sets the support company.
	 *
	 * @param supportCompany the supportCompany to set
	 */
	public void setSupportCompany(String supportCompany) {
		this.supportCompany = supportCompany;
	}

	/**
	 * Gets the app tier.
	 *
	 * @return the appTier
	 */
	public String getAppTier() {
		return appTier;
	}

	/**
	 * Sets the app tier.
	 *
	 * @param appTier the appTier to set
	 */
	public void setAppTier(String appTier) {
		this.appTier = appTier;
	}

	/**
	 * Gets the inc ageing.
	 *
	 * @return the incAgeing
	 */
	public String getIncAgeing() {
		return incAgeing;
	}

	/**
	 * Sets the inc ageing.
	 *
	 * @param incAgeing the incAgeing to set
	 */
	public void setIncAgeing(String incAgeing) {
		this.incAgeing = incAgeing;
	}

	/**
	 * Gets the next target date.
	 *
	 * @return the nextTargetDate
	 */
	public String getNextTargetDate() {
		return nextTargetDate;
	}

	/**
	 * Sets the next target date.
	 *
	 * @param nextTargetDate the nextTargetDate to set
	 */
	public void setNextTargetDate(String nextTargetDate) {
		this.nextTargetDate = nextTargetDate;
	}

	/**
	 * Gets the operational categorization tier 1.
	 *
	 * @return the operationalCategorizationTier1
	 */
	public String getOperationalCategorizationTier1() {
		return operationalCategorizationTier1;
	}

	/**
	 * Sets the operational categorization tier 1.
	 *
	 * @param operationalCategorizationTier1 the operationalCategorizationTier1 to set
	 */
	public void setOperationalCategorizationTier1(String operationalCategorizationTier1) {
		this.operationalCategorizationTier1 = operationalCategorizationTier1;
	}

	/**
	 * Gets the operational categorization tier 2.
	 *
	 * @return the operationalCategorizationTier2
	 */
	public String getOperationalCategorizationTier2() {
		return operationalCategorizationTier2;
	}

	/**
	 * Sets the operational categorization tier 2.
	 *
	 * @param operationalCategorizationTier2 the operationalCategorizationTier2 to set
	 */
	public void setOperationalCategorizationTier2(String operationalCategorizationTier2) {
		this.operationalCategorizationTier2 = operationalCategorizationTier2;
	}

	/**
	 * Gets the operational categorization tier 3.
	 *
	 * @return the operationalCategorizationTier3
	 */
	public String getOperationalCategorizationTier3() {
		return operationalCategorizationTier3;
	}

	/**
	 * Sets the operational categorization tier 3.
	 *
	 * @param operationalCategorizationTier3 the operationalCategorizationTier3 to set
	 */
	public void setOperationalCategorizationTier3(String operationalCategorizationTier3) {
		this.operationalCategorizationTier3 = operationalCategorizationTier3;
	}

	/**
	 * Gets the product categorization tier 1.
	 *
	 * @return the productCategorizationTier1
	 */
	public String getProductCategorizationTier1() {
		return productCategorizationTier1;
	}

	/**
	 * Sets the product categorization tier 1.
	 *
	 * @param productCategorizationTier1 the productCategorizationTier1 to set
	 */
	public void setProductCategorizationTier1(String productCategorizationTier1) {
		this.productCategorizationTier1 = productCategorizationTier1;
	}

	/**
	 * Gets the product categorization tier 2.
	 *
	 * @return the productCategorizationTier2
	 */
	public String getProductCategorizationTier2() {
		return productCategorizationTier2;
	}

	/**
	 * Sets the product categorization tier 2.
	 *
	 * @param productCategorizationTier2 the productCategorizationTier2 to set
	 */
	public void setProductCategorizationTier2(String productCategorizationTier2) {
		this.productCategorizationTier2 = productCategorizationTier2;
	}

	/**
	 * Gets the product categorization tier 3.
	 *
	 * @return the productCategorizationTier3
	 */
	public String getProductCategorizationTier3() {
		return productCategorizationTier3;
	}

	/**
	 * Sets the product categorization tier 3.
	 *
	 * @param productCategorizationTier3 the productCategorizationTier3 to set
	 */
	public void setProductCategorizationTier3(String productCategorizationTier3) {
		this.productCategorizationTier3 = productCategorizationTier3;
	}

	/**
	 * Gets the SLM status.
	 *
	 * @return the sLMStatus
	 */
	public String getSLMStatus() {
		return SLMStatus;
	}

	/**
	 * Sets the SLM status.
	 *
	 * @param sLMStatus the sLMStatus to set
	 */
	public void setSLMStatus(String sLMStatus) {
		SLMStatus = sLMStatus;
	}

	/**
	 * Gets the support organization.
	 *
	 * @return the supportOrganization
	 */
	public String getSupportOrganization() {
		return supportOrganization;
	}

	/**
	 * Sets the support organization.
	 *
	 * @param supportOrganization the supportOrganization to set
	 */
	public void setSupportOrganization(String supportOrganization) {
		this.supportOrganization = supportOrganization;
	}

	/**
	 * Gets the resolution category.
	 *
	 * @return the resolutionCategory
	 */
	public String getResolutionCategory() {
		return resolutionCategory;
	}

	/**
	 * Sets the resolution category.
	 *
	 * @param resolutionCategory the resolutionCategory to set
	 */
	public void setResolutionCategory(String resolutionCategory) {
		this.resolutionCategory = resolutionCategory;
	}

	/**
	 * Gets the status reason.
	 *
	 * @return the statusReason
	 */
	public String getStatusReason() {
		return statusReason;
	}

	/**
	 * Sets the status reason.
	 *
	 * @param statusReason the statusReason to set
	 */
	public void setStatusReason(String statusReason) {
		this.statusReason = statusReason;
	}

	/**
	 * Gets the checks if is primary.
	 *
	 * @return the isPrimary
	 */
	public String getIsPrimary() {
		return isPrimary;
	}

	/**
	 * Sets the checks if is primary.
	 *
	 * @param isPrimary the isPrimary to set
	 */
	public void setIsPrimary(String isPrimary) {
		this.isPrimary = isPrimary;
	}

	/**
	 * Gets the relev perc.
	 *
	 * @return the relevPerc
	 */
	public String getRelevPerc() {
		return relevPerc;
	}

	/**
	 * Sets the relev perc.
	 *
	 * @param relevPerc the relevPerc to set
	 */
	public void setRelevPerc(String relevPerc) {
		this.relevPerc = relevPerc;
	}

	/**
	 * Gets the usage perc.
	 *
	 * @return the usagePerc
	 */
	public String getUsagePerc() {
		return usagePerc;
	}

	/**
	 * Sets the usage perc.
	 *
	 * @param usagePerc the usagePerc to set
	 */
	public void setUsagePerc(String usagePerc) {
		this.usagePerc = usagePerc;
	}

	/**
	 * Gets the feedback perc.
	 *
	 * @return the tower
	 *//*
	public String getTower() {
		return tower;
	}

	*//**
	 * @param tower the tower to set
	 *//*
	public void setTower(String tower) {
		this.tower = tower;
	}

	*//**
	 * @return the cc
	 *//*
	public String getCc() {
		return cc;
	}

	*//**
	 * @param cc the cc to set
	 *//*
	public void setCc(String cc) {
		this.cc = cc;
	}

	*//**
	 * @return the cluster
	 *//*
	public String getCluster() {
		return cluster;
	}

	*//**
	 * @param cluster the cluster to set
	 *//*
	public void setCluster(String cluster) {
		this.cluster = cluster;
	}*/

	/**
	 * @return the feedbackPerc
	 */
	public String getFeedbackPerc() {
		return feedbackPerc;
	}

	/**
	 * Sets the feedback perc.
	 *
	 * @param feedbackPerc the feedbackPerc to set
	 */
	public void setFeedbackPerc(String feedbackPerc) {
		this.feedbackPerc = feedbackPerc;
	}

	/**
	 * Gets the master rel.
	 *
	 * @return the masterRel
	 */
	public String getMasterRel() {
		return masterRel;
	}

	/**
	 * Sets the master rel.
	 *
	 * @param masterRel the masterRel to set
	 */
	public void setMasterRel(String masterRel) {
		this.masterRel = masterRel;
	}

	/**
	 * Gets the done flag.
	 *
	 * @return the doneFlag
	 */
	public String getDoneFlag() {
		return doneFlag;
	}

	/**
	 * Sets the done flag.
	 *
	 * @param doneFlag the doneFlag to set
	 */
	public void setDoneFlag(String doneFlag) {
		this.doneFlag = doneFlag;
	}

	/**
	 * Hash code.
	 *
	 * @return the int
	 */
	@Override
	public int hashCode() {
	    return Objects.hash(getTicketID());
	}
	
	/**
	 * Equals.
	 *
	 * @param o the o
	 * @return true, if successful
	 */
	@Override
	public boolean equals(Object o) {
	    return (this.equals(o) || (o != null && this.getClass().equals(o.getClass())));
		}
	
}
