package com.ikon.model;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Setter;

@Entity
@Table(name = "incident_ko_link_mongo")
@Setter
public class IncKoLinkML implements Serializable {
	
	/** The Incident ID. */
	@Id
	@Column(name="incident_id")
	private String incidentID;
	
	/** The KO ID. */
	@Column(name="ko_id")
	private String koID;
	
	/** The Linked Date. */
	@Column(name="link_date")
	private LocalDateTime linkedDate;
	
}
