package com.ikon.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The Class KOArtifacts.
 */
@Entity
@Table(name = "ko_artifacts")
public class KOArtifacts {
	
	/** The ko serial no. */
	@Id
	@Column(name="koserialno")
	private Integer koSerialNo;
	
	/** The ko file type. */
	@Column(name="kofiletype")
	private String koFileType;
	
	/** The attachment number. */
	@Column(name="attachmentnumber")
	private Integer attachmentNumber;
	
	/** The attachment name. */
	@Column(name="attachmentname")
	private String attachmentName;
	
	/** The attachment path. */
	@Column(name="attachmentpath")
	private String attachmentPath;

	/**
	 * Gets the ko serial no.
	 *
	 * @return the ko serial no
	 */
	public Integer getKoSerialNo() {
		return koSerialNo;
	}

	/**
	 * Sets the ko serial no.
	 *
	 * @param koSerialNo the new ko serial no
	 */
	public void setKoSerialNo(Integer koSerialNo) {
		this.koSerialNo = koSerialNo;
	}

	/**
	 * Gets the ko file type.
	 *
	 * @return the ko file type
	 */
	public String getKoFileType() {
		return koFileType;
	}

	/**
	 * Sets the ko file type.
	 *
	 * @param koFileType the new ko file type
	 */
	public void setKoFileType(String koFileType) {
		this.koFileType = koFileType;
	}

	/**
	 * Gets the attachment number.
	 *
	 * @return the attachment number
	 */
	public Integer getAttachmentNumber() {
		return attachmentNumber;
	}

	/**
	 * Sets the attachment number.
	 *
	 * @param attachmentNumber the new attachment number
	 */
	public void setAttachmentNumber(Integer attachmentNumber) {
		this.attachmentNumber = attachmentNumber;
	}

	/**
	 * Gets the attachment name.
	 *
	 * @return the attachment name
	 */
	public String getAttachmentName() {
		return attachmentName;
	}

	/**
	 * Sets the attachment name.
	 *
	 * @param attachmentName the new attachment name
	 */
	public void setAttachmentName(String attachmentName) {
		this.attachmentName = attachmentName;
	}

	/**
	 * Gets the attachment path.
	 *
	 * @return the attachment path
	 */
	public String getAttachmentPath() {
		return attachmentPath;
	}

	/**
	 * Sets the attachment path.
	 *
	 * @param attachmentPath the new attachment path
	 */
	public void setAttachmentPath(String attachmentPath) {
		this.attachmentPath = attachmentPath;
	}

	/**
	 * Instantiates a new KO artifacts.
	 */
	public KOArtifacts() {
		super();
	}

	/**
	 * Instantiates a new KO artifacts.
	 *
	 * @param koSerialNo the ko serial no
	 * @param attachmentName the attachment name
	 * @param attachmentPath the attachment path
	 */
	public KOArtifacts(Integer koSerialNo, String attachmentName,
			String attachmentPath) {
		super();
		this.koSerialNo = koSerialNo;
		this.attachmentName = attachmentName;
		this.attachmentPath = attachmentPath;
	}

	/**
	 * To string.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return "KOArtifacts [koSerialNo=" + koSerialNo + ", koFileType=" + koFileType + ", attachmentNumber="
				+ attachmentNumber + ", attachmentName=" + attachmentName + ", attachmentPath=" + attachmentPath + "]";
	}
	
	

}
