package com.ikon.model;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.*;

/**
 * The Class ApplicationMaster.
 */
@Entity
@Table(name = "application_master")
public class ApplicationMaster implements Serializable{
    
    /** The app master id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="Appmasterid")
    private Long appMasterId;
    
    /** The Account id. */
    @Column(name="Accountid")
    private Long AccountId;
    
    /** The app name. */
    @Column(name="Applicationname")
    private String appName;
    
    /** The assignment group. */
    @Column(name="Assignmentgroup")
    private String assignmentGroup;
    
    /** The tower. */
    @Column(name="Tower")
    private String tower;
    
    /** The cc. */
    @Column(name="CC")
    private String cc;
    
    /** The cluster. */
    @Column(name="Cluster")
    private String cluster;
    
    /** The technology. */
    @Column(name="Technology")
    private String technology;

	
	
	/**
	 * Gets the app master id.
	 *
	 * @return the appMasterId
	 */
	public Long getAppMasterId() {
		return appMasterId;
	}

	/**
	 * Sets the app master id.
	 *
	 * @param appMasterId the appMasterId to set
	 */
	private void setAppMasterId(Long appMasterId) {
		this.appMasterId = appMasterId;
	}

	/**
	 * Gets the account id.
	 *
	 * @return the accountId
	 */
	public Long getAccountId() {
		return AccountId;
	}

	/**
	 * Sets the account id.
	 *
	 * @param accountId the accountId to set
	 */
	public void setAccountId(Long accountId) {
		AccountId = accountId;
	}

	/**
	 * Gets the app name.
	 *
	 * @return the appName
	 */
	public String getAppName() {
		return appName;
	}

	/**
	 * Sets the app name.
	 *
	 * @param appName the appName to set
	 */
	public void setAppName(String appName) {
		this.appName = appName;
	}

	/**
	 * Gets the assignment group.
	 *
	 * @return the assignmentGroup
	 */
	public String getAssignmentGroup() {
		return assignmentGroup;
	}

	/**
	 * Sets the assignment group.
	 *
	 * @param assignmentGroup the assignmentGroup to set
	 */
	public void setAssignmentGroup(String assignmentGroup) {
		this.assignmentGroup = assignmentGroup;
	}

	/**
	 * Gets the tower.
	 *
	 * @return the tower
	 */
	public String getTower() {
		return tower;
	}

	/**
	 * Sets the tower.
	 *
	 * @param tower the tower to set
	 */
	public void setTower(String tower) {
		this.tower = tower;
	}

	/**
	 * Gets the cc.
	 *
	 * @return the cc
	 */
	public String getCc() {
		return cc;
	}

	/**
	 * Sets the cc.
	 *
	 * @param cc the cc to set
	 */
	public void setCc(String cc) {
		this.cc = cc;
	}

	/**
	 * Gets the cluster.
	 *
	 * @return the cluster
	 */
	public String getCluster() {
		return cluster;
	}

	/**
	 * Sets the cluster.
	 *
	 * @param cluster the cluster to set
	 */
	public void setCluster(String cluster) {
		this.cluster = cluster;
	}

	/**
	 * Gets the technology.
	 *
	 * @return the technology
	 */
	public String getTechnology() {
		return technology;
	}

	/**
	 * Sets the technology.
	 *
	 * @param technology the technology to set
	 */
	public void setTechnology(String technology) {
		this.technology = technology;
	}

	/**
	 * Hash code.
	 *
	 * @return the int
	 */
	@Override
	public int hashCode() {
	    return Objects.hash(getAppMasterId());
	}
	
	/**
	 * Equals.
	 *
	 * @param o the o
	 * @return true, if successful
	 */
	@Override
	public boolean equals(Object o) {
	    return (this.equals(o) || (o != null && this.getClass().equals(o.getClass())));
	}

}
