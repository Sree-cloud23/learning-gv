package com.ikon.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The Class KOUsage.
 */
@Entity
@Table(name = "ko_usage")
public class KOUsage implements Serializable{
	
	/** The ko serial no. */
	@Column(name="koserialno")
	int koSerialNo ;
	
	/** The account ID. */
	@Column(name="accountid")
	int accountID ;
	
	/** The serial number. */
	@Id
	@Column(name="serialnumber")
	int serialNumber ;
	
	/** The user ID. */
	@Column(name="userid")
	String userID;
	
	/** The linked date. */
	@Column(name="linkeddate")
	Date linkedDate;
	
	/** The feed id. */
	@Column(name="feedid")
	int feedId ;

	
	
	/**
	 * Gets the ko serial no.
	 *
	 * @return the koSerialNo
	 */
	public int getKoSerialNo() {
		return koSerialNo;
	}

	/**
	 * Sets the ko serial no.
	 *
	 * @param koSerialNo the koSerialNo to set
	 */
	public void setKoSerialNo(int koSerialNo) {
		this.koSerialNo = koSerialNo;
	}

	/**
	 * Gets the account ID.
	 *
	 * @return the accountID
	 */
	public int getAccountID() {
		return accountID;
	}

	/**
	 * Sets the account ID.
	 *
	 * @param accountID the accountID to set
	 */
	public void setAccountID(int accountID) {
		this.accountID = accountID;
	}

	/**
	 * Gets the serial number.
	 *
	 * @return the serialNumber
	 */
	public int getSerialNumber() {
		return serialNumber;
	}

	/**
	 * Sets the serial number.
	 *
	 * @param serialNumber the serialNumber to set
	 */
	private void setSerialNumber(int serialNumber) {
		this.serialNumber = serialNumber;
	}

	/**
	 * Gets the user ID.
	 *
	 * @return the userID
	 */
	public String getUserID() {
		return userID;
	}

	/**
	 * Sets the user ID.
	 *
	 * @param userID the userID to set
	 */
	public void setUserID(String userID) {
		this.userID = userID;
	}

	/**
	 * Gets the linked date.
	 *
	 * @return the linkedDate
	 */
	public Date getLinkedDate() {
		return linkedDate;
	}

	/**
	 * Sets the linked date.
	 *
	 * @param linkedDate the linkedDate to set
	 */
	public void setLinkedDate(Date linkedDate) {
		this.linkedDate = linkedDate;
	}

	/**
	 * Gets the feed id.
	 *
	 * @return the feedId
	 */
	public int getFeedId() {
		return feedId;
	}

	/**
	 * Sets the feed id.
	 *
	 * @param feedId the feedId to set
	 */
	public void setFeedId(int feedId) {
		this.feedId = feedId;
	}

	/**
	 * Hash code.
	 *
	 * @return the int
	 */
	@Override
	public int hashCode() {
	    return Objects.hash(getSerialNumber());
	}
	
	/**
	 * Adds the serial public.
	 *
	 * @param serialNumber the serial number
	 */
	public void addSerialPublic(int serialNumber) {
		this.serialNumber = serialNumber;
	}
	
	/**
	 * Equals.
	 *
	 * @param o the o
	 * @return true, if successful
	 */
	@Override
	public boolean equals(Object o) {
	    return (this.equals(o) || (o != null && this.getClass().equals(o.getClass())));
		}	

}
