package com.ikon.model;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The Class KOTags.
 */
@Entity
@Table(name = "ko_tags")
public class KOTags implements Serializable{
	
	/** The ko tag id. */
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="kotagid")
	int koTagId;
	
	/** The ko id. */
	@Column(name="koid")
	String koId;
	
	/** The ko single tags. */
	@Column(name="kosingletags")
	String koSingleTags;
	
	/** The ko bigram tags. */
	@Column(name="kobigramtags")
	String koBigramTags;
	
	/** The ko trigram tags. */
	@Column(name="kotrigramtags")
	String koTrigramTags;
	
	/**
	 * Gets the ko tag id.
	 *
	 * @return the koTagId
	 */
	public int getKoTagId() {
		return koTagId;
	}
	
	/**
	 * Sets the ko tag id.
	 *
	 * @param koTagId the new ko tag id
	 */
	private void setKoTagId(int koTagId) {
		this.koTagId=koTagId;
	}
	
	/**
	 * Gets the ko id.
	 *
	 * @return the koId
	 */
	public String getKoId() {
		return koId;
	}
	
	/**
	 * Sets the ko id.
	 *
	 * @param koId the koId to set
	 */
	public void setKoId(String koId) {
		this.koId = koId;
	}
	
	/**
	 * Gets the ko single tags.
	 *
	 * @return the koSingleTags
	 */
	public String getKoSingleTags() {
		return koSingleTags;
	}
	
	/**
	 * Sets the ko single tags.
	 *
	 * @param koSingleTags the koSingleTags to set
	 */
	public void setKoSingleTags(String koSingleTags) {
		this.koSingleTags = koSingleTags;
	}
	
	/**
	 * Gets the ko bigram tags.
	 *
	 * @return the koBigramTags
	 */
	public String getKoBigramTags() {
		return koBigramTags;
	}
	
	/**
	 * Sets the ko bigram tags.
	 *
	 * @param koBigramTags the koBigramTags to set
	 */
	public void setKoBigramTags(String koBigramTags) {
		this.koBigramTags = koBigramTags;
	}
	
	/**
	 * Gets the ko trigram tags.
	 *
	 * @return the koTrigramTags
	 */
	public String getKoTrigramTags() {
		return koTrigramTags;
	}
	
	/**
	 * Sets the ko trigram tags.
	 *
	 * @param koTrigramTags the koTrigramTags to set
	 */
	public void setKoTrigramTags(String koTrigramTags) {
		this.koTrigramTags = koTrigramTags;
	}
	
	/**
	 * Hash code.
	 *
	 * @return the int
	 */
	@Override
	public int hashCode() {
	    return Objects.hash(getKoTagId());
	}
	
	/**
	 * Equals.
	 *
	 * @param o the o
	 * @return true, if successful
	 */
	@Override
	public boolean equals(Object o) {
	    return (this.equals(o) || (o != null && this.getClass().equals(o.getClass())));
		}	
}
