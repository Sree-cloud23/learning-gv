package com.ikon.model;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The Class IncidentTags.
 */
@Entity
@Table(name = "incident_tags")
public class IncidentTags implements Serializable{

	/** The inc tag ID. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "inctagid")
	int incTagID;
	
	/** The ticket ID. */
	@Column(name = "ticketid")
	String ticketID;
	
	/** The inc single tags. */
	@Column(name = "incsingletags")
	String incSingleTags;
	
	/** The inc bigram tags. */
	@Column(name = "incbigramtags")
	String incBigramTags;
	
	/** The inc trigram tags. */
	@Column(name = "inctrigramtags")
	String incTrigramTags;

	/**
	 * Gets the inc tag ID.
	 *
	 * @return the incTagID
	 */
	public int getIncTagID() {
		return incTagID;
	}
	
	/**
	 * Sets the incTagID.
	 *
	 * @param incTagID the incTagID to set
	 */
	private void setIncTagID(int incTagID) {
		this.incTagID = incTagID;
	}

	/**
	 * Gets the ticket ID.
	 *
	 * @return the ticketID
	 */
	public String getTicketID() {
		return ticketID;
	}

	/**
	 * Sets the ticket ID.
	 *
	 * @param ticketID the ticketID to set
	 */
	public void setTicketID(String ticketID) {
		this.ticketID = ticketID;
	}

	/**
	 * Gets the inc single tags.
	 *
	 * @return the incSingleTags
	 */
	public String getIncSingleTags() {
		return incSingleTags;
	}

	/**
	 * Sets the inc single tags.
	 *
	 * @param incSingleTags the incSingleTags to set
	 */
	public void setIncSingleTags(String incSingleTags) {
		this.incSingleTags = incSingleTags;
	}

	/**
	 * Gets the inc bigram tags.
	 *
	 * @return the incBigramTags
	 */
	public String getIncBigramTags() {
		return incBigramTags;
	}

	/**
	 * Sets the inc bigram tags.
	 *
	 * @param incBigramTags the incBigramTags to set
	 */
	public void setIncBigramTags(String incBigramTags) {
		this.incBigramTags = incBigramTags;
	}

	/**
	 * Gets the inc trigram tags.
	 *
	 * @return the incTrigramTags
	 */
	public String getIncTrigramTags() {
		return incTrigramTags;
	}

	/**
	 * Sets the inc trigram tags.
	 *
	 * @param incTrigramTags the incTrigramTags to set
	 */
	public void setIncTrigramTags(String incTrigramTags) {
		this.incTrigramTags = incTrigramTags;
	}

	/**
	 * Hash code.
	 *
	 * @return the int
	 */
	@Override
	public int hashCode() {
		return Objects.hash(getIncTagID());
	}

	/**
	 * Equals.
	 *
	 * @param o the o
	 * @return true, if successful
	 */
	@Override
	public boolean equals(Object o) {
	    return (this.equals(o) || (o != null && this.getClass().equals(o.getClass())));
		}

}
