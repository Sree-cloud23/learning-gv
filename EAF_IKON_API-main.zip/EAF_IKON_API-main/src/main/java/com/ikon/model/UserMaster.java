package com.ikon.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * The Class UserMaster.
 */
@Entity
@Table(name = "user")
public class UserMaster implements Serializable{
	
	/** The id. */
	@Id @GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ID")
    private Long id;
	
	
	/** The User ID. */
	@Column(name="Name")
    private String userId;
		
    /** The name. */
    @Column(name="UserID")
    private String name;
	
    /** The Password. */
    @Column(name="Password")
    private String password;
	
    /** The email. */
    @Column(name="Email")
    private String email;
	
    /** The status. */
    @Column(name="Status")
    private String status;
    
    /** The attempts. */
    @Column(name="Attempts")
    private int attempts;
    
    /** The reset token. */
    @Column(name="Resettoken")
    private String resetToken;
    
    /** The created date. */
    @Column(name="Createddate")
    private Date createdDate;
    
    /** The created by. */
    @Column(name="Createdby")
    private String createdBy;
    
    /** The modified date. */
    @Column(name="Modifieddate")
    private Date modifiedDate;
    
    /** The modified by. */
    @Column(name="Modifiedby")
    private String modifiedBy;
    
    /** The isactive. */
    @Column(name="isactive")
    private Short isactive;
    
    @Column(name="isloggedin")
    private Short isloggedin;
    
    @Column(name="tokenid")
    private String tokenid;
    
    @Column(name="tokenexptime")
    private LocalDateTime tokenExpTime;
    
    public LocalDateTime getTokenExpTime() {
		return tokenExpTime;
	}

	public void setTokenExpTime(LocalDateTime tokenExpDate) {
		this.tokenExpTime = tokenExpDate;
	}

	/** The password confirm. */
    @Transient
    private String passwordConfirm;

	
    
	/**
	 * Gets the id.
	 *
	 * @return the iD
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param iD the iD to set
	 */
	private void setId(Long iD) {
		this.id = iD;
	}

	/**
	 * Gets the user ID.
	 *
	 * @return the user_ID
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * Sets the user ID.
	 *
	 * @param user_ID the user_ID to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the name.
	 *
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Gets the password.
	 *
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * Sets the password.
	 *
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * Gets the email.
	 *
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * Sets the email.
	 *
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Sets the status.
	 *
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Gets the attempts.
	 *
	 * @return the attempts
	 */
	public int getAttempts() {
		return attempts;
	}

	/**
	 * Sets the attempts.
	 *
	 * @param attempts the attempts to set
	 */
	public void setAttempts(int attempts) {
		this.attempts = attempts;
	}

	/**
	 * Gets the reset token.
	 *
	 * @return the resetToken
	 */
	public String getResetToken() {
		return resetToken;
	}

	/**
	 * Sets the reset token.
	 *
	 * @param resetToken the resetToken to set
	 */
	public void setResetToken(String resetToken) {
		this.resetToken = resetToken;
	}

	/**
	 * Gets the created date.
	 *
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * Sets the created date.
	 *
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * Gets the created by.
	 *
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * Sets the created by.
	 *
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * Gets the modified date.
	 *
	 * @return the modifiedDate
	 */
	public Date getModifiedDate() {
		return modifiedDate;
	}

	/**
	 * Sets the modified date.
	 *
	 * @param modifiedDate the modifiedDate to set
	 */
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	/**
	 * Gets the modified by.
	 *
	 * @return the modifiedBy
	 */
	public String getModifiedBy() {
		return modifiedBy;
	}

	/**
	 * Sets the modified by.
	 *
	 * @param modifiedBy the modifiedBy to set
	 */
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	/**
	 * Gets the password confirm.
	 *
	 * @return the passwordConfirm
	 */
	public String getPasswordConfirm() {
		return passwordConfirm;
	}

	/**
	 * Sets the password confirm.
	 *
	 * @param passwordConfirm the passwordConfirm to set
	 */
	public void setPasswordConfirm(String passwordConfirm) {
		this.passwordConfirm = passwordConfirm;
	}
	
	

	/**
	 * Gets the isactive.
	 *
	 * @return the isactive
	 */
	public Short getIsactive() {
		return isactive;
	}

	/**
	 * Sets the isactive.
	 *
	 * @param isactive the new isactive
	 */
	public void setIsactive(Short isactive) {
		this.isactive = isactive;
	}
	
	

	/**
	 * Gets the isloggedin.
	 *
	 * @return the isloggedin
	 */
	public Short getIsloggedin() {
		return isloggedin;
	}

	/**
	 * Sets the isloggedin.
	 *
	 * @param isloggedin the new isloggedin
	 */
	public void setIsloggedin(Short isloggedin) {
		this.isloggedin = isloggedin;
	}

	/**
	 * Gets the tokenid.
	 *
	 * @return the tokenid
	 */
	public String getTokenid() {
		return tokenid;
	}

	/**
	 * Sets the tokenid.
	 *
	 * @param tokenid the new tokenid
	 */
	public void setTokenid(String tokenid) {
		this.tokenid = tokenid;
	}

	/**
	 * Hash code.
	 *
	 * @return the int
	 */
	@Override
	public int hashCode() {
	    return Objects.hash(getId());
	}
	
	/**
	 * Equals.
	 *
	 * @param o the o
	 * @return true, if successful
	 */
	@Override
	public boolean equals(Object o) {
	    return (this.equals(o) || (o != null && this.getClass().equals(o.getClass())));
		}	   
}
