package com.ikon.model;

import javax.persistence.*;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

/**
 * The Class AccessControl.
 */
@Entity
@Table(name = "access_control")
public class AccessControl implements Serializable {

	/** The Access id. */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "Accessid")
	private Long AccessId;

	/** The profile id. */
	@Column(name = "Profileid")
	private Long profileId;

	/** The role id. */
	@Column(name = "Roleid")
	private Long roleId;

	/** The user id. */
	@Column(name = "Userid")
	private String userId;

	/** The account id. */
	@Column(name = "Accountid")
	private Long accountId;

	/** The status. */
	@Column(name = "Status")
	private String status;

	/** The created date. */
	@Column(name = "Createddate")
	private Date createdDate;

	/** The created by. */
	@Column(name = "Createdby")
	private String createdBy;

	/** The modified date. */
	@Column(name = "Modifieddate")
	private Date modifiedDate;

	/** The modified by. */
	@Column(name = "Modifiedby")
	private String modifiedBy;

	/**
	 * Gets the access id.
	 *
	 * @return the accessId
	 */
	public Long getAccessId() {
		return AccessId;
	}

	/**
	 * Sets the access id.
	 *
	 * @param accessId the accessId to set
	 */
	private void setAccessId(Long accessId) {
		AccessId = accessId;
	}

	/**
	 * Gets the profile id.
	 *
	 * @return the profileId
	 */
	public Long getProfileId() {
		return profileId;
	}

	/**
	 * Sets the profile id.
	 *
	 * @param profileId the profileId to set
	 */
	public void setProfileId(Long profileId) {
		this.profileId = profileId;
	}

	/**
	 * Gets the role id.
	 *
	 * @return the roleId
	 */
	public Long getRoleId() {
		return roleId;
	}

	/**
	 * Sets the role id.
	 *
	 * @param roleId the roleId to set
	 */
	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	/**
	 * Gets the user id.
	 *
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * Sets the user id.
	 *
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * Gets the account id.
	 *
	 * @return the accountId
	 */
	public Long getAccountId() {
		return accountId;
	}

	/**
	 * Sets the account id.
	 *
	 * @param accountId the accountId to set
	 */
	public void setAccountId(Long accountId) {
		this.accountId = accountId;
	}

	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Sets the status.
	 *
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Gets the created date.
	 *
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * Sets the created date.
	 *
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * Gets the created by.
	 *
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * Sets the created by.
	 *
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * Gets the modified date.
	 *
	 * @return the modifiedDate
	 */
	public Date getModifiedDate() {
		return modifiedDate;
	}

	/**
	 * Sets the modified date.
	 *
	 * @param modifiedDate the modifiedDate to set
	 */
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	/**
	 * Gets the modified by.
	 *
	 * @return the modifiedBy
	 */
	public String getModifiedBy() {
		return modifiedBy;
	}

	/**
	 * Sets the modified by.
	 *
	 * @param modifiedBy the modifiedBy to set
	 */
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	/**
	 * Hash code.
	 *
	 * @return the int
	 */
	@Override
	public int hashCode() {
		return Objects.hash(getAccessId());
	}

	/**
	 * Equals.
	 *
	 * @param o the o
	 * @return true, if successful
	 */
	@Override
	public boolean equals(Object o) {
		return this.equals(o) || (o != null && this.getClass().equals(o.getClass()));
	}

}
