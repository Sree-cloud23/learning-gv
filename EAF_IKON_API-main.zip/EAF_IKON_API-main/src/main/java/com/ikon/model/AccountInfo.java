package com.ikon.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The Class AccountInfo.
 */
@Entity
@Table(name = "account_info")
public class AccountInfo implements Serializable{

	/** The account id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Accountid")
	private int accountId;

	/** The Account name. */
	@Column(name = "Accountname")
	private String AccountName;

	/** The Schema name. */
	@Column(name = "Schemaname")
	private String SchemaName;

	/** The Account status. */
	@Column(name = "Accountstatus")
	private String AccountStatus;

	/** The Market unit. */
	@Column(name = "Marketunit")
	private String MarketUnit;

	/** The bu. */
	@Column(name = "bu")
	private String BU;

	/** The sbu. */
	@Column(name = "sbu")
	private String SBU;

	/** The Primary practice ID. */
	@Column(name = "Primarypracticeid")
	private int PrimaryPracticeID;

	/** The Created date. */
	@Column(name = "Createddate")
	private Date CreatedDate;

	/** The Created by. */
	@Column(name = "Createdby")
	private String CreatedBy;

	/** The Modified date. */
	@Column(name = "Modifieddate")
	private Date ModifiedDate;

	/** The Modified by. */
	@Column(name = "Modifiedby")
	private String ModifiedBy;

	/**
	 * Gets the account id.
	 *
	 * @return the accountId
	 */
	public int getAccountId() {
		return accountId;
	}

	/**
	 * Sets the account id.
	 *
	 * @param accountId the accountId to set
	 */
	private void setAccountId(int accountId) {
		this.accountId = accountId;
	}

	/**
	 * Gets the account name.
	 *
	 * @return the accountName
	 */
	public String getAccountName() {
		return AccountName;
	}

	/**
	 * Sets the account name.
	 *
	 * @param accountName the accountName to set
	 */
	public void setAccountName(String accountName) {
		AccountName = accountName;
	}

	/**
	 * Gets the schema name.
	 *
	 * @return the schemaName
	 */
	public String getSchemaName() {
		return SchemaName;
	}

	/**
	 * Sets the schema name.
	 *
	 * @param schemaName the schemaName to set
	 */
	public void setSchemaName(String schemaName) {
		SchemaName = schemaName;
	}

	/**
	 * Gets the account status.
	 *
	 * @return the accountStatus
	 */
	public String getAccountStatus() {
		return AccountStatus;
	}

	/**
	 * Sets the account status.
	 *
	 * @param accountStatus the accountStatus to set
	 */
	public void setAccountStatus(String accountStatus) {
		AccountStatus = accountStatus;
	}

	/**
	 * Gets the market unit.
	 *
	 * @return the marketUnit
	 */
	public String getMarketUnit() {
		return MarketUnit;
	}

	/**
	 * Sets the market unit.
	 *
	 * @param marketUnit the marketUnit to set
	 */
	public void setMarketUnit(String marketUnit) {
		MarketUnit = marketUnit;
	}

	/**
	 * Gets the bu.
	 *
	 * @return the bU
	 */
	public String getBU() {
		return BU;
	}

	/**
	 * Sets the bu.
	 *
	 * @param bU the bU to set
	 */
	public void setBU(String bU) {
		BU = bU;
	}

	/**
	 * Gets the sbu.
	 *
	 * @return the sBU
	 */
	public String getSBU() {
		return SBU;
	}

	/**
	 * Sets the sbu.
	 *
	 * @param sBU the sBU to set
	 */
	public void setSBU(String sBU) {
		SBU = sBU;
	}

	/**
	 * Gets the primary practice ID.
	 *
	 * @return the primaryPracticeID
	 */
	public int getPrimaryPracticeID() {
		return PrimaryPracticeID;
	}

	/**
	 * Sets the primary practice ID.
	 *
	 * @param primaryPracticeID the primaryPracticeID to set
	 */
	public void setPrimaryPracticeID(int primaryPracticeID) {
		PrimaryPracticeID = primaryPracticeID;
	}

	/**
	 * Gets the created date.
	 *
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return CreatedDate;
	}

	/**
	 * Sets the created date.
	 *
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		CreatedDate = createdDate;
	}

	/**
	 * Gets the created by.
	 *
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return CreatedBy;
	}

	/**
	 * Sets the created by.
	 *
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		CreatedBy = createdBy;
	}

	/**
	 * Gets the modified date.
	 *
	 * @return the modifiedDate
	 */
	public Date getModifiedDate() {
		return ModifiedDate;
	}

	/**
	 * Sets the modified date.
	 *
	 * @param modifiedDate the modifiedDate to set
	 */
	public void setModifiedDate(Date modifiedDate) {
		ModifiedDate = modifiedDate;
	}

	/**
	 * Gets the modified by.
	 *
	 * @return the modifiedBy
	 */
	public String getModifiedBy() {
		return ModifiedBy;
	}

	/**
	 * Sets the modified by.
	 *
	 * @param modifiedBy the modifiedBy to set
	 */
	public void setModifiedBy(String modifiedBy) {
		ModifiedBy = modifiedBy;
	}

	/**
	 * Hash code.
	 *
	 * @return the int
	 */
	@Override
	public int hashCode() {
		return Objects.hash(getAccountId());
	}

	/**
	 * Equals.
	 *
	 * @param o the o
	 * @return true, if successful
	 */
	@Override
	public boolean equals(Object o) {
		return this.equals(o) || (o != null && this.getClass().equals(o.getClass()));
	}

}
