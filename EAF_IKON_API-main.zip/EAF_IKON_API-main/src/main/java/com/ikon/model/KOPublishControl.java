package com.ikon.model;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The Class KOPublishControl.
 */
@Entity
@Table(name = "ko_publish_control")
public class KOPublishControl implements Serializable{

	/** The review ID. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Reviewid")
	Integer reviewID;

	/** The ko serial no. */
	@Column(name = "KOSerialno")
	Integer koSerialNo;

	/** The created date. */
	@Column(name = "Createddate")
	String createdDate;

	/** The created by. */
	@Column(name = "Createdby")
	String createdBy;

	/** The reviewed date. */
	@Column(name = "Revieweddate")
	String reviewedDate;

	/** The reviewed by. */
	@Column(name = "Reviewedby")
	String reviewedBy;

	/** The published date. */
	@Column(name = "Publisheddate")
	String publishedDate;

	/** The published by. */
	@Column(name = "Publishedby")
	String publishedBy;

	/** The reviewcount. */
	@Column(name = "Reviewcount")
	Integer reviewcount;

	/** The review comments. */
	@Column(name = "Reviewcomments")
	String reviewComments;

	/** The rework area. */
	@Column(name = "Reworkarea")
	String reworkArea;

	/** The action required. */
	@Column(name = "Actionrequired")
	String actionRequired;

	/**
	 * Gets the review ID.
	 *
	 * @return the reviewID
	 */
	public Integer getReviewID() {
		return reviewID;
	}

	/**
	 * Sets the review ID.
	 *
	 * @param reviewID the reviewID to set
	 */
	private void setReviewID(Integer reviewID) {
		this.reviewID = reviewID;
	}

	/**
	 * Gets the ko serial no.
	 *
	 * @return the koSerialNo
	 */
	public Integer getKoSerialNo() {
		return koSerialNo;
	}

	/**
	 * Sets the ko serial no.
	 *
	 * @param koSerialNo the koSerialNo to set
	 */
	public void setKoSerialNo(Integer koSerialNo) {
		this.koSerialNo = koSerialNo;
	}

	/**
	 * Gets the created date.
	 *
	 * @return the createdDate
	 */
	public String getCreatedDate() {
		return createdDate;
	}

	/**
	 * Sets the created date.
	 *
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * Gets the created by.
	 *
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * Sets the created by.
	 *
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * Gets the reviewed date.
	 *
	 * @return the reviewedDate
	 */
	public String getReviewedDate() {
		return reviewedDate;
	}

	/**
	 * Sets the reviewed date.
	 *
	 * @param reviewedDate the reviewedDate to set
	 */
	public void setReviewedDate(String reviewedDate) {
		this.reviewedDate = reviewedDate;
	}

	/**
	 * Gets the reviewed by.
	 *
	 * @return the reviewedBy
	 */
	public String getReviewedBy() {
		return reviewedBy;
	}

	/**
	 * Sets the reviewed by.
	 *
	 * @param reviewedBy the reviewedBy to set
	 */
	public void setReviewedBy(String reviewedBy) {
		this.reviewedBy = reviewedBy;
	}

	/**
	 * Gets the published date.
	 *
	 * @return the publishedDate
	 */
	public String getPublishedDate() {
		return publishedDate;
	}

	/**
	 * Sets the published date.
	 *
	 * @param publishedDate the publishedDate to set
	 */
	public void setPublishedDate(String publishedDate) {
		this.publishedDate = publishedDate;
	}

	/**
	 * Gets the published by.
	 *
	 * @return the publishedBy
	 */
	public String getPublishedBy() {
		return publishedBy;
	}

	/**
	 * Sets the published by.
	 *
	 * @param publishedBy the publishedBy to set
	 */
	public void setPublishedBy(String publishedBy) {
		this.publishedBy = publishedBy;
	}

	/**
	 * Gets the reviewcount.
	 *
	 * @return the reviewcount
	 */
	public Integer getReviewcount() {
		return reviewcount;
	}

	/**
	 * Sets the reviewcount.
	 *
	 * @param reviewcount the reviewcount to set
	 */
	public void setReviewcount(Integer reviewcount) {
		this.reviewcount = reviewcount;
	}

	/**
	 * Gets the review comments.
	 *
	 * @return the reviewComments
	 */
	public String getReviewComments() {
		return reviewComments;
	}

	/**
	 * Sets the review comments.
	 *
	 * @param reviewComments the reviewComments to set
	 */
	public void setReviewComments(String reviewComments) {
		this.reviewComments = reviewComments;
	}

	/**
	 * Gets the rework area.
	 *
	 * @return the reworkArea
	 */
	public String getReworkArea() {
		return reworkArea;
	}

	/**
	 * Sets the rework area.
	 *
	 * @param reworkArea the reworkArea to set
	 */
	public void setReworkArea(String reworkArea) {
		this.reworkArea = reworkArea;
	}

	/**
	 * Gets the action required.
	 *
	 * @return the actionRequired
	 */
	public String getActionRequired() {
		return actionRequired;
	}

	/**
	 * Sets the action required.
	 *
	 * @param actionRequired the actionRequired to set
	 */
	public void setActionRequired(String actionRequired) {
		this.actionRequired = actionRequired;
	}

	/**
	 * Hash code.
	 *
	 * @return the int
	 */
	@Override
	public int hashCode() {
		return Objects.hash(getReviewID());
	}

	/**
	 * Equals.
	 *
	 * @param o the o
	 * @return true, if successful
	 */
	@Override
	public boolean equals(Object o) {
	    return (this.equals(o) || (o != null && this.getClass().equals(o.getClass())));
		}

}
