package com.ikon.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The Class HelpDesk.
 */
@Entity
@Table(name = "query")
public class HelpDesk implements Serializable{
	
	/** The Query ID. */
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="QueryID")
	int QueryID;
	
	/** The User ID. */
	@Column(name="UserID")
	String UserID;
	
	/** The Account ID. */
	@Column(name="AccountID")
	int AccountID;
	
	/** The Subject. */
	@Column(name="Subject")
	String Subject;
	
	/** The Short description. */
	@Column(name="Shortdescription")
	String ShortDescription;
	
	/** The Description. */
	@Column(name="Description")
	String Description;
	
	/** The Query date. */
	@Column(name="Querydate")
	Date QueryDate;
	
	/** The request raised for. */
	@Column(name="Requestraisedfor")
	String requestRaisedFor;
	
	/** The area of concern. */
	@Column(name="Areaofconcern")
	String areaOfConcern;
	
	/**
	 * Gets the request raised for.
	 *
	 * @return the request raised for
	 */
	public String getRequestRaisedFor() {
		return requestRaisedFor;
	}

	/**
	 * Sets the request raised for.
	 *
	 * @param requestRaisedFor the new request raised for
	 */
	public void setRequestRaisedFor(String requestRaisedFor) {
		this.requestRaisedFor = requestRaisedFor;
	}

	/**
	 * Gets the area of concern.
	 *
	 * @return the area of concern
	 */
	public String getAreaOfConcern() {
		return areaOfConcern;
	}

	/**
	 * Sets the area of concern.
	 *
	 * @param areaOfConcern the new area of concern
	 */
	public void setAreaOfConcern(String areaOfConcern) {
		this.areaOfConcern = areaOfConcern;
	}

	/**
	 * Gets the query ID.
	 *
	 * @return the queryID
	 */
	public int getQueryID() {
		return QueryID;
	}

	/**
	 * Sets the query ID.
	 *
	 * @param queryID the queryID to set
	 */
	private void setQueryID(int queryID) {
		QueryID = queryID;
	}

	/**
	 * Gets the user ID.
	 *
	 * @return the userID
	 */
	public String getUserID() {
		return UserID;
	}

	/**
	 * Sets the user ID.
	 *
	 * @param userID the userID to set
	 */
	public void setUserID(String userID) {
		UserID = userID;
	}

	/**
	 * Gets the account ID.
	 *
	 * @return the accountID
	 */
	public int getAccountID() {
		return AccountID;
	}

	/**
	 * Sets the account ID.
	 *
	 * @param accountID the accountID to set
	 */
	public void setAccountID(int accountID) {
		AccountID = accountID;
	}

	/**
	 * Gets the subject.
	 *
	 * @return the subject
	 */
	public String getSubject() {
		return Subject;
	}

	/**
	 * Sets the subject.
	 *
	 * @param subject the subject to set
	 */
	public void setSubject(String subject) {
		Subject = subject;
	}

	/**
	 * Gets the short description.
	 *
	 * @return the shortDescription
	 */
	public String getShortDescription() {
		return ShortDescription;
	}

	/**
	 * Sets the short description.
	 *
	 * @param shortDescription the shortDescription to set
	 */
	public void setShortDescription(String shortDescription) {
		ShortDescription = shortDescription;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {
		return Description;
	}

	/**
	 * Sets the description.
	 *
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		Description = description;
	}

	/**
	 * Gets the query date.
	 *
	 * @return the queryDate
	 */
	public Date getQueryDate() {
		return QueryDate;
	}

	/**
	 * Sets the query date.
	 *
	 * @param queryDate the queryDate to set
	 */
	public void setQueryDate(Date queryDate) {
		QueryDate = queryDate;
	}

	/**
	 * Hash code.
	 *
	 * @return the int
	 */
	@Override
	public int hashCode() {
	    return Objects.hash(getQueryID());
	}
	
	/**
	 * Equals.
	 *
	 * @param o the o
	 * @return true, if successful
	 */
	@Override
	public boolean equals(Object o) {
	    return (this.equals(o) || (o != null && this.getClass().equals(o.getClass())));
		}

}
