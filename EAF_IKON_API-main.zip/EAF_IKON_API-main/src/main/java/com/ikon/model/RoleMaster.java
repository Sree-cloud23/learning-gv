package com.ikon.model;

import javax.persistence.*;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

/**
 * The Class RoleMaster.
 */
@Entity
@Table(name = "role_master")
public class RoleMaster implements Serializable{
    
    /** The role id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="Roleid")
    private Long roleId;

    /** The function id. */
    @Column(name="Functionid")
    private Long functionId;
    
    /** The rolecategory id. */
    @Column(name="Rolecategoryid")
    private Long rolecategoryId;
    
    /** The status. */
    @Column(name="Status")
    private String status;
    
    /** The created date. */
    @Column(name="Createddate")
    private Date createdDate;
    
    /** The created by. */
    @Column(name="Createdby")
    private String createdBy;
    
    /** The modified date. */
    @Column(name="Modifieddate")
    private Date modifiedDate;
    
    /** The modified by. */
    @Column(name="Modifiedby")
    private String modifiedBy;

	
	
	/**
	 * Gets the role id.
	 *
	 * @return the roleId
	 */
	public Long getRoleId() {
		return roleId;
	}

	/**
	 * Sets the role id.
	 *
	 * @param roleId the roleId to set
	 */
	private void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	/**
	 * Gets the function id.
	 *
	 * @return the functionId
	 */
	public Long getFunctionId() {
		return functionId;
	}

	/**
	 * Sets the function id.
	 *
	 * @param functionId the functionId to set
	 */
	public void setFunctionId(Long functionId) {
		this.functionId = functionId;
	}

	/**
	 * Gets the rolecategory id.
	 *
	 * @return the rolecategoryId
	 */
	public Long getRolecategoryId() {
		return rolecategoryId;
	}

	/**
	 * Sets the rolecategory id.
	 *
	 * @param rolecategoryId the rolecategoryId to set
	 */
	public void setRolecategoryId(Long rolecategoryId) {
		this.rolecategoryId = rolecategoryId;
	}

	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Sets the status.
	 *
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Gets the created date.
	 *
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * Sets the created date.
	 *
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * Gets the created by.
	 *
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * Sets the created by.
	 *
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * Gets the modified date.
	 *
	 * @return the modifiedDate
	 */
	public Date getModifiedDate() {
		return modifiedDate;
	}

	/**
	 * Sets the modified date.
	 *
	 * @param modifiedDate the modifiedDate to set
	 */
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	/**
	 * Gets the modified by.
	 *
	 * @return the modifiedBy
	 */
	public String getModifiedBy() {
		return modifiedBy;
	}

	/**
	 * Sets the modified by.
	 *
	 * @param modifiedBy the modifiedBy to set
	 */
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	/**
	 * Hash code.
	 *
	 * @return the int
	 */
	@Override
	public int hashCode() {
	    return Objects.hash(getRoleId());
	}
	
	/**
	 * Equals.
	 *
	 * @param o the o
	 * @return true, if successful
	 */
	@Override
	public boolean equals(Object o) {
	    return (this.equals(o) || (o != null && this.getClass().equals(o.getClass())));
		}	
}
