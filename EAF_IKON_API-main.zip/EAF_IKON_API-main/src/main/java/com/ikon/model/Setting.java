package com.ikon.model;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The Class Setting.
 */
@Entity
@Table(name = "settings")
public class Setting implements Serializable{
	
	/** The id. */
	@Id @GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="id")
    private Long id;
	
	/** The user id. */
	@Column(name="Userid")
    private String userId;
	
    /** The Default account ID. */
    @Column(name="Defaultaccountid")
    private int DefaultAccountID;
	
    /** The Color theme ID. */
    @Column(name="Colorthemeid")
    private String ColorThemeID;
	
    /** The Last query ID. */
    @Column(name="Lastqueryid")
    private String LastQueryID;
	
    /** The Default landing page. */
    @Column(name="Defaultlandingpage")
    private String DefaultLandingPage;

	
	
	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the id to set
	 */
	private void setId(Long id) {
		this.id = id;
	}

	/**
	 * Gets the user id.
	 *
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * Sets the user id.
	 *
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * Gets the default account ID.
	 *
	 * @return the defaultAccountID
	 */
	public int getDefaultAccountID() {
		return DefaultAccountID;
	}

	/**
	 * Sets the default account ID.
	 *
	 * @param defaultAccountID the defaultAccountID to set
	 */
	public void setDefaultAccountID(int defaultAccountID) {
		DefaultAccountID = defaultAccountID;
	}

	/**
	 * Gets the color theme ID.
	 *
	 * @return the colorThemeID
	 */
	public String getColorThemeID() {
		return ColorThemeID;
	}

	/**
	 * Sets the color theme ID.
	 *
	 * @param colorThemeID the colorThemeID to set
	 */
	public void setColorThemeID(String colorThemeID) {
		ColorThemeID = colorThemeID;
	}

	/**
	 * Gets the last query ID.
	 *
	 * @return the lastQueryID
	 */
	public String getLastQueryID() {
		return LastQueryID;
	}

	/**
	 * Sets the last query ID.
	 *
	 * @param lastQueryID the lastQueryID to set
	 */
	public void setLastQueryID(String lastQueryID) {
		LastQueryID = lastQueryID;
	}

	/**
	 * Gets the default landing page.
	 *
	 * @return the defaultLandingPage
	 */
	public String getDefaultLandingPage() {
		return DefaultLandingPage;
	}

	/**
	 * Sets the default landing page.
	 *
	 * @param defaultLandingPage the defaultLandingPage to set
	 */
	public void setDefaultLandingPage(String defaultLandingPage) {
		DefaultLandingPage = defaultLandingPage;
	}

	/**
	 * Hash code.
	 *
	 * @return the int
	 */
	@Override
	public int hashCode() {
	    return Objects.hash(getId());
	}
	
	/**
	 * Equals.
	 *
	 * @param o the o
	 * @return true, if successful
	 */
	@Override
	public boolean equals(Object o) {
	    return (this.equals(o) || (o != null && this.getClass().equals(o.getClass())));
		}	
 
}
