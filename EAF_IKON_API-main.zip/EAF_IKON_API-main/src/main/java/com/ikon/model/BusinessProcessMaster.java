package com.ikon.model;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The Class BusinessProcessMaster.
 */
@Entity
@Table(name = "business_process_master")
public class BusinessProcessMaster implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** The Application name. */
	@Column(name = "ApplicationName")
	String ApplicationName;
	
	/** The Bns pro L 1. */
	@Column(name = "BnsProL1")
	String BnsProL1;
	
	/** The Bns pro L 2. */
	@Column(name = "BnsProL2")
	String BnsProL2;
	
	/** The Bns pro L 3. */
	@Column(name = "BnsProL3")
	String BnsProL3;
	
	/** The id. */
	@Column(name = "ID")
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int id;
	
	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	
	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	private void setId(int id) {
		this.id = id;
	}
	
	/**
	 * Gets the application name.
	 *
	 * @return the application name
	 */
	public String getApplicationName() {
		return ApplicationName;
	}
	
	/**
	 * Sets the application name.
	 *
	 * @param applicationName the new application name
	 */
	public void setApplicationName(String applicationName) {
		ApplicationName = applicationName;
	}
	
	/**
	 * Gets the bns pro L 1.
	 *
	 * @return the bns pro L 1
	 */
	public String getBnsProL1() {
		return BnsProL1;
	}
	
	/**
	 * Sets the bns pro L 1.
	 *
	 * @param bnsProL1 the new bns pro L 1
	 */
	public void setBnsProL1(String bnsProL1) {
		BnsProL1 = bnsProL1;
	}
	
	/**
	 * Gets the bns pro L 2.
	 *
	 * @return the bns pro L 2
	 */
	public String getBnsProL2() {
		return BnsProL2;
	}
	
	/**
	 * Sets the bns pro L 2.
	 *
	 * @param bnsProL2 the new bns pro L 2
	 */
	public void setBnsProL2(String bnsProL2) {
		BnsProL2 = bnsProL2;
	}
	
	/**
	 * Gets the bns pro L 3.
	 *
	 * @return the bns pro L 3
	 */
	public String getBnsProL3() {
		return BnsProL3;
	}
	
	/**
	 * Sets the bns pro L 3.
	 *
	 * @param bnsProL3 the new bns pro L 3
	 */
	public void setBnsProL3(String bnsProL3) {
		BnsProL3 = bnsProL3;
	}
	
	/**
	 * 
	 * @return the String
	 */
	@Override
	public String toString() {
		return "BusinessProcessMaster [ApplicationName=" + ApplicationName + ", BnsProL1=" + BnsProL1 + ", BnsProL2="
				+ BnsProL2 + ", BnsProL3=" + BnsProL3 + ", id=" + id + "]";
	}
	
	/**
	 * Hash code.
	 *
	 * @return the int
	 */
	@Override
	public int hashCode() {
		return Objects.hash(getId());
	}

	/**
	 * Equals.
	 *
	 * @param o the o
	 * @return true, if successful
	 */
	@Override
	public boolean equals(Object o) {
	    return (this.equals(o) || (o != null && this.getClass().equals(o.getClass())));
		}
	
	
	

}
