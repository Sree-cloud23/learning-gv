package com.ikon.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.ikon.model.AccountInfo;
import com.ikon.repository.AccountInfoRepository;
import com.ikon.validator.IKONUtils;

// TODO: Auto-generated Javadoc
/**
 * The Class AccountInfoServiceImpl.
 */
@Service
public class AccountInfoServiceImpl implements AccountInfoService{
	
	    /** The account info repository. */
    	@Inject
    	private transient  AccountInfoRepository accountInfoRepository;
	    
	    /**
    	 * Find all.
    	 *
    	 * @return the list
    	 */
    	@Override
	    public List<AccountInfo> findAll() {
	    	return accountInfoRepository.findAll();
	    }

	/**
	 * Gets the account name by account id.
	 *
	 * @param accountId the account id
	 * @return the account name by account id
	 */
	@Override
	public AccountInfo getAccountNameByAccountId(String accountId) {
		List<AccountInfo> accountInfoList = accountInfoRepository.findAll();
    	for(AccountInfo accountInfo:accountInfoList){
    		if(accountId.equalsIgnoreCase(String.valueOf(accountInfo.getAccountId()))&& !IKONUtils.isNullOrEmpty(accountInfo.getAccountName())){
    			return accountInfo;
    		}
    	}
    	
		return new AccountInfo();
	}
	
	/**
	 * Gets the displaypage.
	 *
	 * @param accountID the account ID
	 * @return the displaypage
	 */
	public int getDisplaypage(int accountID) {
		
		int displayValue = Integer.parseInt(accountInfoRepository.findDisplayPage(accountID));
		return displayValue;
		
	}
	
	/**
	 * Gets the KO enabled status.
	 *
	 * @param accountID the account ID
	 * @return the KO enabled status
	 */
	public int getKOEnabledStatus(int accountID) {
		int koStatus = Integer.parseInt(accountInfoRepository.findKOEnabled(accountID));
		return koStatus;
	}


}
