package com.ikon.service;

import java.util.List;
import java.util.Set;

import com.ikon.dto.AgeingWorkinfoBean;
import com.ikon.dto.ComplianceBean;
import com.ikon.dto.DashboardBean;
import com.ikon.dto.KOMetricsBean;
import com.ikon.dto.MasterDataAttributeVO;
import com.ikon.model.TicketDataHistory;

/**
 * The Interface TMDashboardService.
 *
 * @author Capgemini
 */
public interface TMDashboardService {
	
	/**
	 * Find all.
	 *
	 * @return the list
	 */
	 List<TicketDataHistory> findAll();

	/**
	 * Gets the TM dashboard data.
	 *
	 * @param userId the user id
	 * @param accountId the account id
	 * @return the TM dashboard data
	 */
	List<DashboardBean> getTMDashboardData(String userId, String accountId);

	/**
	 * Gets the all TL inciedents dashboard data.
	 *
	 * @param masterDataAttributeVO the master data attribute VO
	 * @param assigneeNameLists the assignee name lists
	 * @return the all TL inciedents dashboard data
	 */
	List<DashboardBean> getAllTLInciedentsDashboardData(MasterDataAttributeVO masterDataAttributeVO, String assigneeNameLists);

	/**
	 * Gets the all TL run to zero data.
	 *
	 * @param masterDataAttributeVO the master data attribute VO
	 * @param assigneeNameLists the assignee name lists
	 * @return the all TL run to zero data
	 */
	List<DashboardBean> getAllTLRunToZeroData(MasterDataAttributeVO masterDataAttributeVO, String assigneeNameLists);

	/**
	 * Gets the all TL ko status data.
	 *
	 * @param masterDataAttributeVO the master data attribute VO
	 * @param assigneeNameLists the assignee name lists
	 * @return the all TL ko status data
	 */
	List<DashboardBean> getAllTLKoStatusData(MasterDataAttributeVO masterDataAttributeVO, String assigneeNameLists);

	/**
	 * Gets the KO inc link count TL.
	 *
	 * @param masterDataAttributeVO the master data attribute VO
	 * @param assigneeNameLists the assignee name lists
	 * @return the KO inc link count TL
	 */
	List<DashboardBean> getKOIncLinkCountTL(MasterDataAttributeVO masterDataAttributeVO, String assigneeNameLists);

	/**
	 * Gets the all assignee name.
	 *
	 * @param assignmentGrpLists the assignment grp lists
	 * @param appNameLists the app name lists
	 * @param userId the user id
	 * @return the all assignee name
	 */
	Set<String> getAllAssigneeName(Set<String> assignmentGrpLists, Set<String> appNameLists, String userId);

	/**
	 * Gets the leader board data.
	 *
	 * @param accountName the account name
	 * @return the leader board data
	 */
	List<DashboardBean> getLeaderBoardData(String accountName);

	/**
	 * Gets the top analyst data.
	 *
	 * @param accountName the account name
	 * @return the top analyst data
	 */
	List<DashboardBean> getTopAnalystData(String accountName);

	/**
	 * Gets the top reviewer data.
	 *
	 * @param accountName the account name
	 * @return the top reviewer data
	 */
	List<DashboardBean> getTopReviewerData(String accountName);

	/**
	 * Gets the top contributor data.
	 *
	 * @param accountName the account name
	 * @return the top contributor data
	 */
	List<DashboardBean> getTopContributorData(String accountName);

	/**
	 * Gets the mttr avg hours per mon.
	 *
	 * @param fromDate the from date
	 * @param toDate the to date
	 * @return the mttr avg hours per mon
	 */
	List<DashboardBean> getMttrAvgHoursPerMon(String fromDate, String toDate);
	
	/**
	 * Gets the mttr by priority.
	 *
	 * @param fromDate the from date
	 * @param toDate the to date
	 * @return the mttr by priority
	 */
	List<DashboardBean> getMttrByPriority(String fromDate, String toDate);
	
	/**
	 * Gets the mttr report.
	 *
	 * @param fromDate the from date
	 * @param toDate the to date
	 * @return the mttr report
	 */
	List<DashboardBean> getMttrReport(String fromDate, String toDate);
	
	/**
	 * Gets the mttr report by priority.
	 *
	 * @param fromDate the from date
	 * @param toDate the to date
	 * @return the mttr report by priority
	 */
	List<DashboardBean> getMttrReportByPriority(String fromDate, String toDate);

	/**
	 * Gets the compliance report.
	 *
	 * @param fromDate the from date
	 * @param toDate the to date
	 * @return the compliance report
	 */
	List<ComplianceBean> getComplianceReport(String fromDate, String toDate);
	
	/**
	 * Gets the KO metrics chart.
	 *
	 * @param masterDataAttributeVO the master data attribute VO
	 * @param freq 
	 * @return the KO metrics chart
	 */
	List<KOMetricsBean> getKOMetricsChart(MasterDataAttributeVO masterDataAttributeVO, String freq);

	/**
	 * Gets the ageing workinfo report.
	 *
	 * @param masterDataAttributeVO the master data attribute VO
	 * @return the ageing workinfo report
	 */
	List<AgeingWorkinfoBean> getAgeingWorkinfoReport(MasterDataAttributeVO masterDataAttributeVO);

	/**
	 * Gets the ageing workinfo report detail.
	 *
	 * @param masterDataAttributeVO the master data attribute VO
	 * @return the ageing workinfo report detail
	 */
	List<AgeingWorkinfoBean> getAgeingWorkinfoReportDetail(MasterDataAttributeVO masterDataAttributeVO);
}
