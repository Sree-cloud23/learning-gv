package com.ikon.service;

import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.ikon.dto.SettingBean;
import com.ikon.model.HelpDesk;
import com.ikon.model.Setting;

/**
 * The Interface HelpDeskService.
 */
public interface HelpDeskService  {

	/**
	 * Save.
	 *
	 * @param help the help
	 * @param request the request
	 * @param session the session
	 */
	void save(HelpDesk help, HttpServletRequest request,HttpSession session);
	
	/**
	 * Account access.
	 *
	 * @param userID the user ID
	 * @return the list
	 */
	List<SettingBean> accountAccess(String userID);

	/**
	 * Default account.
	 *
	 * @param userID the user ID
	 * @return the list
	 */
	List<SettingBean> defaultAccount(String userID);

	/**
	 * Landing page listing.
	 *
	 * @param userID the user ID
	 * @return the list
	 */
	List<SettingBean> landingPageListing(String userID);

	/**
	 * Default landing page.
	 *
	 * @param userID the user ID
	 * @param accid the accid
	 * @return the list
	 */
	List<SettingBean> defaultLandingPage(String userID,int accid);	

	/**
	 * Gets the statistic data.
	 *
	 * @param accountID the account ID
	 * @return the statistic data
	 */
	public SettingBean getStatisticData(int accountID);

	/**
	 * Settingacc save.
	 *
	 * @param settab the settab
	 * @param request the request
	 * @param session the session
	 */
	void settingacc_save(Setting settab, HttpServletRequest request, HttpSession session);

	/**
	 * Settinglanpage save.
	 *
	 * @param settab the settab
	 * @param request the request
	 * @param session the session
	 */
	void settinglanpage_save(Setting settab, HttpServletRequest request, HttpSession session);

	/**
	 * Helpdesk options listing.
	 *
	 * @param formheading the formheading
	 * @return the sets the
	 */
	Set<String> helpdeskOptionsListing(String formheading);


	/**
	 * Infomailsave.
	 *
	 * @param requesteremail the requesteremail
	 * @param recipientsto the recipientsto
	 * @param recipientscc the recipientscc
	 * @param subject the subject
	 * @param mailmsg the mailmsg
	 * @param accountid the accountid
	 */
	void infomailsave(String requesteremail, String recipientsto, String recipientscc, String subject, String mailmsg,
			int accountid);
	
	/**
	 * Gets the default account id.
	 *
	 * @param username the username
	 * @return the default account id
	 */
	 String getDefaultAccountId(String username);
}
