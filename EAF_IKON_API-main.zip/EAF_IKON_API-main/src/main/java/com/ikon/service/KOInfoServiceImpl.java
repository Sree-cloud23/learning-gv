package com.ikon.service;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.poi.hwpf.HWPFDocument;
import org.apache.poi.hwpf.extractor.WordExtractor;
import org.apache.poi.xwpf.extractor.XWPFWordExtractor;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;

/*import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;*/
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.ikon.dto.ComplianceBean;
import com.ikon.dto.KOInfoBean;
import com.ikon.dto.KOMetricsBean;
import com.ikon.dto.KOReviewerBean;
import com.ikon.dto.KoDataAttributeVO;
import com.ikon.dto.LandingScreenBean;
import com.ikon.dto.MasterDataAttributeVO;
import com.ikon.dto.SettingBean;
import com.ikon.dto.TicketDataAttributeVO;
import com.ikon.model.BusinessProcessMaster;
import com.ikon.model.KOInfo;
import com.ikon.model.KOPublishControl;
import com.ikon.model.Setting;
import com.ikon.repository.KOInfoRepository;
import com.ikon.repository.KOPublishControlRepository;
import com.ikon.repository.SettingRepository;
import com.ikon.rest.web.models.Authentication;
import com.ikon.rest.web.models.SecurityContext;
import com.ikon.rest.web.models.SecurityContextHolder;
import com.ikon.validator.IKONUtils;

import lombok.extern.slf4j.Slf4j;

/**
 * The Class KOInfoServiceImpl.
 */
@SuppressWarnings({ "deprecation", "unchecked", "rawtypes" })
@Service
@Slf4j
public class KOInfoServiceImpl implements KOInfoService {

	/** The Constant FILE_PATH. */
	private static final String FILE_PATH = "D:\\bkm\\IKON2_SRC\\IKON\\src\\main\\webapp\\resources\\uploadedFiles\\";

	/** The Constant ACC_ID_STRING. */
	private static final String ACC_ID_STRING = "accid";

	/** The Constant ASSGN_GRP_STRING. */
	private static final String ASSGN_GRP_STRING = "assgngrp";

	/** The Constant FRM_DATE_STRING. */
	private static final String FRM_DATE_STRING = "frmdate";

	/** The Constant TO_DATE_STRING. */
	private static final String TO_DATE_STRING = "todate";

	/** The Constant GROUP_STRING. */
	private static final String GROUP_STRING = "group";

	/** The Constant ASSIGNMENT_GROUP_STRING. */
	private static final String ASSIGNMENT_GROUP_STRING = "assignmentGroup";

	/** The Constant FREQ_STRING. */
	private static final String FREQ_STRING = "freq";

	/** The Constant U_STRING. */
	private static final String USER_ID_STRING = "userId";

	/** The Constant KO_ID_STRING. */
	private static final String KO_ID_STRING = "koId";

	/** The Constant TOWER_STRING. */
	private static final String TOWER_STRING = "tower";

	/** The Constant CLUSTER_STRING. */
	private static final String CLUSTER_STRING = "cluster";

	/** The Constant SYMPTOMS. */
	private static final String SYMPTOMS = "symptoms";

	/** The Constant REVIEW CMNTS. */
	private static final String REVIEW_CMNTS = "reviewComments";

	/** The Constant ATT NAME. */
	private static final String ATT_NAME = "attachmentname";

	/** The Constant TICKET_ID. */
	private static final String TICKET_ID = "ticketid";

	/** The Constant REWORK_COMPLETE. */
	private static final String REWORK_COMPLETE = "reworkComplete";

	/** The Constant ATT_NUM. */
	private static final String ATT_NUM = "attachmentnumber";

	/** The Constant PUB_STAT. */
	private static final String PUB_STAT = "publistatus";

	/** The Constant SEARCH_ID. */
	private static final String SEARCH_ID = "searchid";

	/** The Constant APP_NAME. */
	private static final String APP_NAME = "applicationName";

	/** The Constant ANSWER. */
	private static final String ANSWER = "answer";

	/** The Constant CATALINA_HOME. */
	private static final String CATALINA_HOME = "catalina.home";

	/** The Constant ATT_DATAFIX. */
	private static final String ATT_DATAFIX = "attachmentdatafix";

	/** The Constant KOID. */
	private static final String KOID = "koID";

	/** The Constant RESOLUTION. */
	private static final String RESOLUTION = "resolution";

	/** The Constant WEBAPP_KODOC. */
	private static final String WEBAPP_KODOC = "\\webapps\\KOdocuments\\";

	/** The Constant REVIEWED_BY. */
	private static final String REVIEWED_BY = "reviewedBy";

	/** The Constant SHORT_DESC. */
	private static final String SHORT_DESC = "shortDescription";

	/** The Constant LONG_DESC. */
	private static final String LONG_DESC = "longDescription";

	/** The Constant ATT_PATH. */
	private static final String ATT_PATH = "attachmentpath";

	/** The Constant FUN_ASSIGN_APPROVER. */
	private static final String FUN_ASSIGN_APPROVER = "select * from fun_assign_approver()";

	/** The Constant FILE. */
	private static final String FILE = "file";

	/** The Constant CREATED_BY. */
	private static final String CREATED_BY = "createdby";

	/** The Constant PUBLICATION_STATUS. */
	private static final String PUBLICATION_STATUS = "publicationStatus";

	/** The Constant APPS_NAME_STRING. */
	private static final String APPS_NAME_STRING = "appsname";

	/** The Constant CREATEDBY. */
	private static final String CREATEDBY = "createdBy";

	/** The Constant Account Id. */
	private static final String ACCOUNT_ID = "accountId";

	/** The Constant FIFTEEN. */
	private static final int FIFTEEN = 15;

	/** The entity manager. */
	@PersistenceContext
	EntityManager entityManager;

	/** The email service. */
	@Inject
	private transient EmailService emailService;

	/** The ko publish control repository. */
	@Inject
	private transient KOPublishControlRepository koPublishControlRepository;

	/** The ko info repository. */
	@Inject
	private transient KOInfoRepository koInfoRepository;

	/** The access control service. */
	@Inject
	private transient AccessControlService accessControlService;

	/** The help service. */
	@Inject
	private transient HelpDeskService helpService;

	/** The setting repository. */
	@Inject
	private transient SettingRepository settingRepository;
	
	/** The Constant log. */
	//private static final log log = LogManager.getlog(KOInfoServiceImpl.class);

	/**
	 * Populate inc appdetails.
	 *
	 * @param linkedincident the linkedincident
	 * @param moduleName the module name
	 * @return the KO info bean
	 */
	@Override
	@Transactional
	public KOInfoBean populateIncAppdetails(final String linkedincident, final String moduleName) {

		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String loginusrname = auth.getName();
		int accid = 0;
		List<KOInfoBean> IncAppdetBeanList = null;
		Session session = entityManager.unwrap(Session.class);
		Query query = session.createSQLQuery("select * from fun_user_after_login(:userId)")
				.setResultTransformer(Transformers.aliasToBean(LandingScreenBean.class));
		query.setParameter(USER_ID_STRING, loginusrname);
		List<LandingScreenBean> accessControlBeanList = query.list();
		if (Objects.nonNull(accessControlBeanList) && accessControlBeanList.size() > 0) {
			accid = accessControlBeanList.get(0).getDefaultAccountID();
		}
		query = session.createSQLQuery("select * from fun_ko_ticket_search(:linkedincident, :accid, :moduleName)")
				.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
		query.setParameter("linkedincident", linkedincident);
		query.setParameter(ACC_ID_STRING, accid);
		query.setParameter("moduleName", moduleName);
		IncAppdetBeanList = query.list();

		if (Objects.nonNull(IncAppdetBeanList) && IncAppdetBeanList.size() > 0) {
			return IncAppdetBeanList.get(0);
		} else {
			return null;
		}
	}

	/**
	 * Kolistview SP.
	 *
	 * @param KoAttrVo the ko attr vo
	 * @return the list
	 */
	@Override
	@Transactional
	public List<KOInfoBean> kolistviewSP(KoDataAttributeVO KoAttrVo) {
		List<KOInfoBean> KOInfoBeanList = null;
		Session session = entityManager.unwrap(Session.class);
		Query query = session.createSQLQuery(
				"select * from fun_ko_list_view(:accid,:koid, :createdBy, :appsname, :assgngrp, :publicationstatus, :koType)")
				.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
		query.setString(ACC_ID_STRING, KoAttrVo.getMasterDtAttrVo().getAccId());
		query.setString("koid", KoAttrVo.getKoDtAttr().getKoId());
		query.setString(CREATEDBY, KoAttrVo.getKoDtAttr().getCreatedBy());
		query.setString(APPS_NAME_STRING, KoAttrVo.getMasterDtAttrVo().getAppName());
		query.setString(ASSGN_GRP_STRING,  KoAttrVo.getMasterDtAttrVo().getAssignmentGroup());
		query.setString("publicationstatus", KoAttrVo.getKoDtAttr().getPublicationStatus());
		query.setInteger("koType", Objects.isNull(KoAttrVo.getKoDtAttr().getKoType()) ? 0 : KoAttrVo.getKoDtAttr().getKoType());
		KOInfoBeanList = query.list();
		return KOInfoBeanList;

	}

	/**
	 * Kopubgraph SP.
	 *
	 * @param KoAttrVo the ko attr vo
	 * @return the list
	 */

	@Override
	@Transactional
	public List<KOInfoBean> kopubgraphSP(KoDataAttributeVO KoAttrVo) {
		List<KOInfoBean> kopubgraphList = null;
		Session session = entityManager.unwrap(Session.class);
		Query query = session.createSQLQuery(
				"select * from fun_ko_publish_graph(:accid,:frmdate, :todate,:tower,:cc, :cluster,:appsname,:assgngrp,:freq,:group,:userId)")
				.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
		query.setString(ACC_ID_STRING, KoAttrVo.getMasterDtAttrVo().getAccId());
		query.setString(FRM_DATE_STRING, KoAttrVo.getMasterDtAttrVo().getFromDate());
		query.setString(TO_DATE_STRING, KoAttrVo.getMasterDtAttrVo().getToDate());
		query.setString(TOWER_STRING, KoAttrVo.getMasterDtAttrVo().getTower());
		query.setString("cc", KoAttrVo.getMasterDtAttrVo().getCc());
		query.setString(CLUSTER_STRING, KoAttrVo.getMasterDtAttrVo().getCluster());
		query.setString(APPS_NAME_STRING, KoAttrVo.getMasterDtAttrVo().getAppName());
		query.setString(ASSGN_GRP_STRING, KoAttrVo.getMasterDtAttrVo().getAssignmentGroup());
		query.setString(FREQ_STRING, KoAttrVo.getFreq());
		query.setString(GROUP_STRING, KoAttrVo.getGroup());
		query.setString(USER_ID_STRING, KoAttrVo.getMasterDtAttrVo().getUserId());

		kopubgraphList = query.list();
		return kopubgraphList;

	}

	/**
	 * Ko created graph SP.
	 *
	 * @param KoAttrVo the ko attr vo
	 * @return the list
	 */

	@Override
	@Transactional
	public List<KOInfoBean> koCreatedGraphSP(KoDataAttributeVO KoAttrVo) {

		List<KOInfoBean> kocreatedgraphList = null;
		Session session = entityManager.unwrap(Session.class);
		Query query = session.createSQLQuery(
				"select * from fun_ko_created_graph(:accid,:frmdate, :todate,:tower,:cc, :cluster,:appsname,:assgngrp,:freq,:group,:userId)")
				.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
		query.setString(ACC_ID_STRING, KoAttrVo.getMasterDtAttrVo().getAccId());
		query.setString(FRM_DATE_STRING, KoAttrVo.getMasterDtAttrVo().getFromDate());
		query.setString(TO_DATE_STRING, KoAttrVo.getMasterDtAttrVo().getToDate());
		query.setString(TOWER_STRING, KoAttrVo.getMasterDtAttrVo().getTower());
		query.setString("cc", KoAttrVo.getMasterDtAttrVo().getCc());
		query.setString(CLUSTER_STRING, KoAttrVo.getMasterDtAttrVo().getCluster());
		query.setString(APPS_NAME_STRING, KoAttrVo.getMasterDtAttrVo().getAppName());
		query.setString(ASSGN_GRP_STRING, KoAttrVo.getMasterDtAttrVo().getAssignmentGroup());
		query.setString(FREQ_STRING, KoAttrVo.getFreq());
		query.setString(GROUP_STRING, KoAttrVo.getGroup());
		query.setString(USER_ID_STRING, KoAttrVo.getMasterDtAttrVo().getUserId());

		kocreatedgraphList = query.list();
		return kocreatedgraphList;

	}

	/**
	 * Ko usage graph SP.
	 *
	 * @param KoAttrVo the ko attr vo
	 * @return the list
	 */
	@Override
	@Transactional
	public List<KOInfoBean> koUsageGraphSP(KoDataAttributeVO KoAttrVo) {

		List<KOInfoBean> kousagegraphList = null;
		Session session = entityManager.unwrap(Session.class);
		Query query = session.createSQLQuery(
				"select * from fun_ko_linked_graph(:accid,:frmdate, :todate,:tower,:cc, :cluster,:appsname,:assgngrp,:freq,:group,:userId)")
				.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
		query.setString(ACC_ID_STRING, KoAttrVo.getMasterDtAttrVo().getAccId());
		query.setString(FRM_DATE_STRING, KoAttrVo.getMasterDtAttrVo().getFromDate());
		query.setString(TO_DATE_STRING, KoAttrVo.getMasterDtAttrVo().getToDate());
		query.setString(TOWER_STRING, KoAttrVo.getMasterDtAttrVo().getTower());
		query.setString("cc", KoAttrVo.getMasterDtAttrVo().getCc());
		query.setString(CLUSTER_STRING, KoAttrVo.getMasterDtAttrVo().getCluster());
		query.setString(APPS_NAME_STRING, KoAttrVo.getMasterDtAttrVo().getAppName());
		query.setString(ASSGN_GRP_STRING, KoAttrVo.getMasterDtAttrVo().getAssignmentGroup());
		query.setString(FREQ_STRING, KoAttrVo.getFreq());
		query.setString(GROUP_STRING, KoAttrVo.getGroup());
		query.setString(USER_ID_STRING, KoAttrVo.getMasterDtAttrVo().getUserId());

		kousagegraphList = query.list();

		return kousagegraphList;
	}

	/**
	 * Ko linkage graph SP.
	 *
	 * @param KoAttrVo the ko attr vo
	 * @return the list
	 */

	@Override
	@Transactional
	public List<KOInfoBean> koLinkageGraphSP(KoDataAttributeVO KoAttrVo) {

		List<KOInfoBean> kolinkagegraphList = null;
		Session session = entityManager.unwrap(Session.class);
		Query query = session.createSQLQuery(
				"select * from fun_inc_vs_ko_link_graph(:accid,:frmdate, :todate,:tower,:cc, :cluster,:appsname,:assgngrp,:freq,:group,:userId)")
				.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
		query.setString(ACC_ID_STRING, KoAttrVo.getMasterDtAttrVo().getAccId());
		query.setString(FRM_DATE_STRING, KoAttrVo.getMasterDtAttrVo().getFromDate());
		query.setString(TO_DATE_STRING, KoAttrVo.getMasterDtAttrVo().getToDate());
		query.setString(TOWER_STRING, KoAttrVo.getMasterDtAttrVo().getTower());
		query.setString("cc", KoAttrVo.getMasterDtAttrVo().getCc());
		query.setString(CLUSTER_STRING, KoAttrVo.getMasterDtAttrVo().getCluster());
		query.setString(APPS_NAME_STRING, KoAttrVo.getMasterDtAttrVo().getAppName());
		query.setString(ASSGN_GRP_STRING, KoAttrVo.getMasterDtAttrVo().getAssignmentGroup());
		query.setString(FREQ_STRING, KoAttrVo.getFreq());
		query.setString(GROUP_STRING, KoAttrVo.getGroup());
		query.setString(USER_ID_STRING, KoAttrVo.getMasterDtAttrVo().getUserId());

		kolinkagegraphList = query.list();
		return kolinkagegraphList;

	}

	/**
	 * Show all related K os.
	 *
	 * @param ticketID the ticket ID
	 * @return the list
	 */
	@Override
	@Transactional
	public List<KOInfoBean> showAllRelatedKOs(String ticketID) {
		List<KOInfoBean> KOInfoBeanList = null;
		Session session = entityManager.unwrap(Session.class);
		Query query = session.createSQLQuery("select * from fun_ticket_related_ko(:ticketID)")
				.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
		query.setParameter("ticketID", ticketID);
		KOInfoBeanList = query.list();
		return KOInfoBeanList;

	}

	/**
	 * Gets the default account id.
	 *
	 * @return the default account id
	 */
	private String getDefaultAccountId() {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String loginusrname = auth.getName();
		String accountId = "1";
		Setting settingInfo = settingRepository.findByUserId(loginusrname);
		if (Objects.nonNull(settingInfo)) {
			accountId = Integer.toString(settingInfo.getDefaultAccountID());
		}
		return accountId;
	}

	/**
	 * Sendemail.
	 *
	 * @param submitter     the submitter
	 * @param submittername the submittername
	 * @param approver      the approver
	 * @param approvername  the approvername
	 * @param koid          the koid
	 * @param accid         the accid
	 * @return the string
	 */
	/*
	 * public String sendemail(String submitter, String submittername, String
	 * approver, String approvername, String koid, String accid) { SimpleMailMessage
	 * passwordResetEmail = new SimpleMailMessage();
	 * passwordResetEmail.setFrom(submitter); passwordResetEmail.setTo(approver);
	 * String Subjectdata = "IKON-2: KO " + koid + " submit for your approval from "
	 * + submittername; passwordResetEmail.setSubject(Subjectdata);
	 * 
	 * String mailcontent = ("Hello " + approvername +
	 * ",\n You have recevied new KO(" + koid +
	 * ") for review.Please review and approve it. \n "
	 * 
	 * + "\n Regards,\n" + "IKON-2 Team.");
	 * 
	 * passwordResetEmail.setText(mailcontent);
	 * 
	 * try { emailService.sendEmail(passwordResetEmail); } catch (MailException e) {
	 * String mailmsg = mailcontent.replaceAll("\n", "<br/>");
	 * helpService.infomailsave(submitter, approver, "", Subjectdata, mailmsg,
	 * Integer.parseInt(accid)); } return null; }
	 */

	/**
	 * Sendreworkemail.
	 *
	 * @param approver      the approver
	 * @param approvername  the approvername
	 * @param submitter     the submitter
	 * @param submittername the submittername
	 * @param koid          the koid
	 * @param accid         the accid
	 * @return the string
	 */
	/*
	 * public String sendreworkemail(String approver, String approvername, String
	 * submitter, String submittername, String koid, String accid) {
	 * SimpleMailMessage passwordResetEmail = new SimpleMailMessage();
	 * passwordResetEmail.setFrom(approver); passwordResetEmail.setTo(submitter);
	 * String subjectdata = ("IKON-2: KO " + koid +
	 * " submitted for your rework from " + approvername);
	 * passwordResetEmail.setSubject(subjectdata);
	 * 
	 * String msgtext = ("Hello " + submittername + ",\n You have recevied KO(" +
	 * koid + ") for rework.Please rework and submit it.\n "
	 * 
	 * + "\n Regards,\n" + "IKON-2 Team.");
	 * 
	 * passwordResetEmail.setText(msgtext);
	 * 
	 * try { emailService.sendEmail(passwordResetEmail); } catch (MailException e) {
	 * String mailmsg = msgtext.replaceAll("\n", "<br/>");
	 * helpService.infomailsave(approver, submitter, "", subjectdata, mailmsg,
	 * Integer.parseInt(accid)); } return null; }
	 */

	/**
	 * Insert KO detail.
	 *
	 * @param koInfoBean the ko info bean
	 * @param files      the files
	 * @return the list
	 * @throws IllegalAccessException the illegal access exception
	 */
	@Override
	@Transactional
	public List<KOInfoBean> insertKODetail(KOInfoBean koInfoBean, @RequestParam(FILE) MultipartFile[] files)
			throws IllegalAccessException {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String loggedInUserName = auth.getName();
		String createActionValue = koInfoBean.getKoStage();
		String createActionId = createActionValue.equalsIgnoreCase("Indraft") ? "1" : "2";
		String accountName = getAccountName();
		if (StringUtils.isEmpty(koInfoBean.getTicketsearchbox()) || StringUtils.isEmpty(koInfoBean.getApplicationName())
				|| StringUtils.isEmpty(koInfoBean.getAssignmentGroup())
				|| StringUtils.isEmpty(koInfoBean.getShortDescription())) {
			throw new IllegalAccessException();
		}
		List<KOInfoBean> KOInfoBeanList = null;
		Session session = entityManager.unwrap(Session.class);
		Query query = session.createSQLQuery("select * from fun_create_ko(:shortDescription, :applicationName, :assignmentGroup, "
				+ ":longDescription, :symptoms, :resolution, :answer, :symptoms, :answer, :resolution,:attachmentdatafix,:attachmentnumber,:attachmentname ,:attachmentpath,:pubstatus,:userid,:ticketid,:accid,:createactionid,:genericKoID)")
				.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
		query.setParameter(SHORT_DESC, koInfoBean.getShortDescription());
		query.setParameter(APP_NAME, koInfoBean.getApplicationName());
		query.setParameter(ASSIGNMENT_GROUP_STRING, koInfoBean.getAssignmentGroup());
		query.setParameter(LONG_DESC, koInfoBean.getLongDescription());
		query.setParameter(SYMPTOMS, koInfoBean.getSymptoms());
		query.setParameter(RESOLUTION, koInfoBean.getResolution());
		query.setParameter(ANSWER, koInfoBean.getAnswer());
		query.setParameter("pubstatus", koInfoBean.getKoStage());
		query.setParameter("userid", loggedInUserName);
		query.setParameter(TICKET_ID, koInfoBean.getTicketsearchbox());
		query.setParameter(ACC_ID_STRING, getDefaultAccountId());
		query.setParameter("createactionid", createActionId);
		StringBuffer text = new StringBuffer();
		StringBuffer attachmentFileName = new StringBuffer();
		String attachmentPath = "";
		Path fname;
		int nooffiles = 0;
		if (Objects.nonNull(files) && files.length > 0) {
			String rootPath = System.getProperty(CATALINA_HOME);
			File dir = new File(rootPath + WEBAPP_KODOC + accountName + File.separator);
			if (!dir.exists())
				dir.mkdirs();
			attachmentPath = dir.toString();
			List<String> names = uploadFiles(files);
			for (String fpath : names) {
				text.append(readUploadFile(fpath));

				Path path = Paths.get(fpath);
				fname = path.getFileName();
				path.toAbsolutePath();
				if (Objects.nonNull(attachmentFileName) && !attachmentFileName.toString().equalsIgnoreCase("")) {
					attachmentFileName.append(strConcat("|" , fname.toString()));
				} else {
					attachmentFileName.setLength(0);
					attachmentFileName.append(fname.toString());
				}
				nooffiles++;
			}
		}

		query.setParameter(ATT_DATAFIX, text.toString());
		query.setParameter(ATT_NUM, nooffiles);
		query.setParameter(ATT_NAME, attachmentFileName.toString());
		query.setParameter(ATT_PATH, attachmentPath);
		query.setParameter("genericKoID", koInfoBean.getGenericKoID());
		KOInfoBeanList = query.list();
		return KOInfoBeanList;
	}

	/**
	 * Gets the account name.
	 *
	 * @return the account name
	 */
	private String getAccountName() {
		SecurityContext sc = SecurityContextHolder.getContext();
		Authentication auth = sc.getAuthentication();
		List<SettingBean> sbList = helpService.accountAccess(auth.getName());
		return Objects.nonNull(sbList) && sbList.size() > 0 && Objects.nonNull(sbList.get(0)) && Objects.nonNull(sbList.get(0).getAccountName())
				? sbList.get(0).getAccountName()
				: "Unknown";
	}

	/**
	 * Sendmailtoreviewer.
	 *
	 * @param var_ko          the var ko
	 * @param createactionval the createactionval
	 */
	@Override
	@Transactional
	public void sendmailtoreviewer(String var_ko, String createactionval) {
		if (createactionval.equalsIgnoreCase("ReviewSubmit")) {
			List<KOInfoBean> approverbeanList = null;
			Session session = entityManager.unwrap(Session.class);
			Query query1 = session.createSQLQuery("select * from fun_assign_approver_koId(:koId)")
					.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));

			query1.setParameter(KO_ID_STRING, var_ko);
			approverbeanList = query1.list();
			String approverusrid = null;
			String Submitteremail = null;
			String approveremail = null;
			String Submitterusrid = null;

			if (Objects.nonNull(approverbeanList) && !approverbeanList.isEmpty()) {
				for (KOInfoBean ko : approverbeanList) {
					approverusrid = ko.getApproverUserID();
					Submitteremail = ko.getCreaterEmail();
					approveremail = ko.getApproverEmail();
					Submitterusrid = ko.getCreatedBy();
				}

				/*
				 * if (Objects.nonNull(Submitteremail) && Objects.nonNull(approveremail) &&
				 * !Submitteremail.trim().equals("") && !approveremail.trim().equals(""))
				 * sendemail(Submitteremail, Submitterusrid, approveremail, approverusrid,
				 * var_ko, getDefaultAccountId());
				 */
			}

		}
	}

	/**
	 * Insert review comment.
	 *
	 * @param koInfoBean the ko info bean
	 * @return the list
	 */
	@Override
	@Transactional
	public List<KOInfoBean> insertReviewComment(KOInfoBean koInfoBean) {

		Session session = entityManager.unwrap(Session.class);
		Query query = session.createSQLQuery("select 1 as return from fun_ko_insert_review(:koID, :createdDate, :CreatedBy, :reviewedDate, :reviewedBy, :publishedDate, :publishedBy, :newReviewComments, :newReworkArea, :newActionRequired)");
				//.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));

		query.setString(KOID, koInfoBean.getKoID());
		query.setDate("createdDate", koInfoBean.getCreatedDate());
		query.setString("CreatedBy", koInfoBean.getCreatedBy());
		query.setDate("reviewedDate", koInfoBean.getReviewedDate());
		query.setString(REVIEWED_BY, koInfoBean.getReviewedBy());
		query.setDate("publishedDate", koInfoBean.getPublishedDate());
		query.setString("publishedBy", koInfoBean.getPublishedBy());
		query.setString("newReviewComments", koInfoBean.getNewReviewComment());
		query.setString("newReworkArea", koInfoBean.getNewReworkArea());
		query.setInteger("newActionRequired", koInfoBean.getNewActionRequired());
		query.list();
		return new ArrayList<KOInfoBean>();
	}

	/**
	 * Delete review comment.
	 *
	 * @param reviewID the review ID
	 * @return the list
	 */
	@Override
	@Transactional
	public List<KOInfoBean> deleteReviewComment(int reviewID) {
		Session session = entityManager.unwrap(Session.class);
		Query query = session.createSQLQuery("select 1 as return from fun_ko_delete_review(:reviewID)");
				//.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
		query.setInteger("reviewID", reviewID);
		query.list();
		return new ArrayList<KOInfoBean>();
	}

	/**
	 * Edits the KO detail.
	 *
	 * @param koId the ko id
	 * @return the list
	 */
	@Override
	@Transactional
	public List<KOInfoBean> editKODetail(String koId) {
		List<KOInfoBean> KOInfoBeanList = null;
		Session session = entityManager.unwrap(Session.class);
		Query query = session.createSQLQuery("select * from fun_retrive_ko_data(:koID)")
				.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
		query.setString(KOID, koId);
		KOInfoBeanList = query.list();
		return KOInfoBeanList;

	}

	/**
	 * Retrieve review comments.
	 *
	 * @param koId the ko id
	 * @return the list
	 */
	@Override
	@Transactional
	public List<KOInfoBean> retrieveReviewComments(String koId) {
		List<KOInfoBean> KOInfoBeanList = null;
		Session session = entityManager.unwrap(Session.class);
		Query query = session.createSQLQuery("select * from fun_retrieve_review_comments(:koID)")
				.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
		query.setString(KOID, koId);
		KOInfoBeanList = query.list();
		return KOInfoBeanList;

	}

	/**
	 * Upload file.
	 *
	 * @param files the files
	 * @return the list
	 */
	public List<String> uploadFiles(MultipartFile[] files) {

		List<String> name = new ArrayList<String>();
		String accountName = getAccountName();
		String rootPath = System.getProperty(CATALINA_HOME);
		File dir = new File(rootPath + WEBAPP_KODOC + accountName + File.separator);
		for (MultipartFile file : files) {
			if (!dir.exists())
				dir.mkdirs();
			try {
				if (Objects.nonNull(file.getOriginalFilename()) && !file.getOriginalFilename().equalsIgnoreCase("")) {
					Path copyLocation = Paths
							.get(dir + File.separator + StringUtils.cleanPath(file.getOriginalFilename()));
					Files.copy(file.getInputStream(), copyLocation, StandardCopyOption.REPLACE_EXISTING);
					name.add(copyLocation.toString());
				}
			} catch (IOException e) {
				log.error(e.getMessage());
			}
		}
		return name;
	}

	/**
	 * Read doc file.
	 *
	 * @param fileName the file name
	 * @return the string
	 */
	private String readDocFile(String fileName) {
		String text = null;
		try (InputStream is = Files.newInputStream(Paths.get(fileName))) {
			HWPFDocument doc = new HWPFDocument(is);
			WordExtractor we = new WordExtractor(doc);
			text = we.getText();
			is.close();
		} catch (IOException e) {
			log.error(e.getMessage());
		}
		return text;
	}

	/**
	 * Read docx file.
	 *
	 * @param fileName the file name
	 * @return the string
	 */
	public static String readDocxFile(String fileName) {
		String text = null;
		try (InputStream is = Files.newInputStream(Paths.get(fileName))) {
			XWPFDocument document = new XWPFDocument(is);
			XWPFWordExtractor extract = new XWPFWordExtractor(document);
			text = extract.getText();
			is.close();
		} catch (IOException e) {
			log.error(e.getMessage());
		}
		return text;
	}

	/**
	 * Read pdf file.
	 *
	 * @param fileName the file name
	 * @return the string
	 */
	private String readPdfFile(String fileName) {
		String text = null;
		File file = new File(fileName);		
		try(PDDocument document = PDDocument.load(file);) {
			PDFTextStripper pdfStripper = new PDFTextStripper();
			text = pdfStripper.getText(document).trim();
		} catch (IOException e) {
			log.error(e.getMessage());
		}
		return text;
	}

	/**
	 * Read upload file.
	 *
	 * @param filePath the file path
	 * @return the string
	 */
	private String readUploadFile(String filePath) {
		String fileContent = null;
		File file = new File(filePath);
		String fileName = file.getName();
		if (fileName.substring(fileName.lastIndexOf('.') + 1).equalsIgnoreCase("Doc")) {
			fileContent = readDocFile(filePath);
		} else if (fileName.substring(fileName.lastIndexOf('.') + 1).equalsIgnoreCase("Docx")) {
			fileContent = readDocxFile(filePath);
		} else if (fileName.substring(fileName.lastIndexOf('.') + 1).equalsIgnoreCase("pdf")) {
			fileContent = readPdfFile(filePath);
		} else {
			fileContent = "";
		}
		return fileContent;
	}

	/**
	 * Gets the all created by names.
	 *
	 * @param userId    the user id
	 * @param accountId the account id
	 * @return the all created by names
	 */
	@Override
	public Set<String> getAllCreatedByNames(String userId, String accountId) {
		List<KOPublishControl> koPublishControlBeanList = koPublishControlRepository.findAll();
		Set<String> createdByList = new TreeSet<String>();
		for (KOPublishControl koPublishControl : koPublishControlBeanList) {
			if (!StringUtils.isEmpty(koPublishControl.getCreatedBy())) {
				createdByList.add(koPublishControl.getCreatedBy());
			}
		}
		return createdByList;
	}

	/**
	 * Gets the all publication status.
	 *
	 * @param koInfoBean the ko info bean
	 * @return the all publication status
	 */
	@Override
	public Set<String> getAllPublicationStatus(KOInfoBean koInfoBean) {
		List<KOInfo> koInfoBeanList = koInfoRepository.findAll();
		Set<String> publicationStatusList = new HashSet<String>();
		for (KOInfo koInfoData : koInfoBeanList) {
			if (!StringUtils.isEmpty(koInfoData.getPublicationStatus())) {
				publicationStatusList.add(koInfoData.getPublicationStatus());
			}
		}
		return publicationStatusList;
	}

	/**
	 * Update KO detail.
	 *
	 * @param koInfoBean the ko info bean
	 * @param files      the files
	 * @param userId     the user id
	 * @return the string
	 */
	@Override
	@Transactional
	public String updateKODetail(KOInfoBean koInfoBean, @RequestParam(FILE) MultipartFile[] files, String userId)
			{
		Session session = entityManager.unwrap(Session.class);
		String PubStsid = null;
		String PubStsval = koInfoBean.getPublicationStatus();
		PubStsid = getPubStsId(PubStsval);

		Query query = session
				.createSQLQuery("select 1 as return from fun_update_ko(:koId, :shortDescription, :applicationName, :assignmentGroup, "
						+ ":longDescription, :symptoms, :resolution, :cause, :symptoms, :answer, :resolution,:attachmentdatafix,:attachmentnumber,:attachmentname ,:attachmentpath,:reviewedBy,:reviewedDate,:publishedBy,:publishedDate,:userId,:publicationStatus,:modifiedBy,:ticketid,:actionid)");
				//.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));

		query.setString(KO_ID_STRING, koInfoBean.getKoID());
		query.setString(SHORT_DESC, koInfoBean.getShortDescription());
		query.setString(APP_NAME, koInfoBean.getApplicationName());
		query.setString(ASSIGNMENT_GROUP_STRING, koInfoBean.getAssignmentGroup());
		query.setString(LONG_DESC, koInfoBean.getLongDescription());
		query.setString(SYMPTOMS, koInfoBean.getSymptoms());
		query.setString(RESOLUTION, koInfoBean.getResolution());
		query.setString("cause", koInfoBean.getCause());
		query.setString(SYMPTOMS, koInfoBean.getSymptoms());
		query.setString(ANSWER, koInfoBean.getAnswer());
		query.setString(RESOLUTION, koInfoBean.getResolution());
		query.setString(REVIEWED_BY, koInfoBean.getReviewedBy());
		query.setDate("reviewedDate", koInfoBean.getReviewedDate());
		query.setString("publishedBy", koInfoBean.getPublishedBy());
		query.setDate("publishedDate", koInfoBean.getPublishedDate());
		query.setString(USER_ID_STRING, userId);
		query.setString(PUBLICATION_STATUS, koInfoBean.getPublicationStatus());
		query.setString("modifiedBy", userId);
		query.setString(TICKET_ID, koInfoBean.getTicketID());
		query.setString("actionid", PubStsid);
		StringBuffer text = new StringBuffer();
		StringBuffer Att_fname = new StringBuffer();
		Path fname;
		int nooffiles = 0;
		System.getProperty(CATALINA_HOME);
		File dir = new File(FILE_PATH);
		if (!dir.exists())
			dir.mkdirs();
		List<String> names = uploadFiles(files);

		for (String fpath : names) {
			text.append(readUploadFile(fpath));

			Path path = Paths.get(fpath);
			fname = path.getFileName();
			path.toAbsolutePath();
			if (Objects.nonNull(Att_fname) && !Att_fname.toString().equalsIgnoreCase("")) {
				Att_fname.append(strConcat("|" , fname.toString()));
			} else {
				Att_fname.setLength(0);
				Att_fname.append(fname.toString());
			}
			nooffiles++;
		}
		query.setString(ATT_DATAFIX, text.toString());
		query.setInteger(ATT_NUM, nooffiles);
		query.setString(ATT_NAME, Att_fname.toString());
		query.setString(ATT_PATH, dir.toString());
		query.list();
		switch (PubStsval.toLowerCase(Locale.getDefault())) {
		case "reviewsubmit":
			reviewSubmitKO(session, koInfoBean);
			break;
		case "approved":
			approvedKO(session, koInfoBean);
			break;
		case "reworksubmit":
			reworkKO(session, koInfoBean);
			break;
		default:
			break;
		}

		return "";
	}

	/**
	 * Gets the pub sts id.
	 *
	 * @param pubStsval the pub stsval
	 * @return the pub sts id
	 */
	private String getPubStsId(String pubStsval) {
		switch (pubStsval.toLowerCase(Locale.getDefault())) {
		case "indraft":
			return "1";
		case "reviewsubmit":
			return "2";
		case "inreview":
			return "3";
		case "reworksubmit":
			return "4";
		case "inrework":
			return "5";
		case "approved":
			return "6";
		default:
			return "7";
		}
	}

	/**
	 * Rework KO.
	 *
	 * @param session the session
	 * @param koInfoBean the ko info bean
	 */
	private void reworkKO(Session session, KOInfoBean koInfoBean) {

		List<KOInfoBean> approverbeanList = null;
		Query query1 = session.createSQLQuery("select * from fun_submit_for_rework(:koId)")
				.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
		query1.setString(KO_ID_STRING, koInfoBean.getKoID());
		approverbeanList = query1.list();
		if (Objects.nonNull(approverbeanList) && !approverbeanList.isEmpty()) {
			String approverusrid = null;
			String Submitteremail = null;
			String approveremail = null;
			String Submitterusrid = null;
			for (KOInfoBean ko : approverbeanList) {
				Submitterusrid = ko.getCreatedBy();
				Submitteremail = ko.getCreaterEmail();
				approverusrid = ko.getApproverUserID();
				approveremail = ko.getApproverEmail();
			}
			/*
			 * if (Objects.nonNull(Submitteremail) && Objects.nonNull(approveremail) &&
			 * !Submitteremail.trim().equals("") && !approveremail.trim().equals(""))
			 * sendreworkemail(approveremail, approverusrid, Submitteremail, Submitterusrid,
			 * koInfoBean.getKoID(), getDefaultAccountId());
			 */

		}
		List<KOInfoBean> approverbeanList1 = null;

		Query query11 = session.createSQLQuery(FUN_ASSIGN_APPROVER)
				.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
		approverbeanList1 = query11.list();

		if (Objects.nonNull(approverbeanList1) && !approverbeanList1.isEmpty()) {
			String approverusrid_re = null;
			String Submitteremail_re = null;
			String koid_re = null;
			String approveremail_re = null;
			String Submitterusrid_re = null;
			for (KOInfoBean ko : approverbeanList1) {
				approverusrid_re = ko.getApproverUserID();
				Submitteremail_re = ko.getCreaterEmail();
				koid_re = ko.getKoID();
				approveremail_re = ko.getApproverEmail();
				Submitterusrid_re = ko.getCreatedBy();
			}
			/*
			 * if (Objects.nonNull(Submitteremail_re) && Objects.nonNull(approveremail_re)
			 * && !Submitteremail_re.trim().equals("") &&
			 * !approveremail_re.trim().equals("")) sendemail(Submitteremail_re,
			 * Submitterusrid_re, approveremail_re, approverusrid_re, koid_re,
			 * getDefaultAccountId());
			 */
		}

	}

	/**
	 * Approved KO.
	 *
	 * @param session the session
	 * @param koInfoBean the ko info bean
	 */
	private void approvedKO(Session session, KOInfoBean koInfoBean) {

		List<KOInfoBean> approverbeanList = null;
		Query query1 = session.createSQLQuery("select * from fun_update_approver_status(:koId)")
				.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
		query1.setString(KO_ID_STRING, koInfoBean.getKoID());
		approverbeanList = query1.list();
		if (Objects.nonNull(approverbeanList) && !approverbeanList.isEmpty()) {
			KOInfoBean ko = approverbeanList.get(approverbeanList.size() - 1);
			String approverusrid = ko.getApproverUserID();
			String Submitteremail = ko.getCreaterEmail();
			String approveremail = ko.getApproverEmail();
			String Submitterusrid = ko.getCreatedBy();

			/*
			 * if (Objects.nonNull(Submitteremail) && Objects.nonNull(approveremail) &&
			 * !Submitteremail.trim().equals("") && !approveremail.trim().equals(""))
			 * sendapprovedemail(Submitteremail, Submitterusrid, approveremail,
			 * approverusrid, koInfoBean.getKoID(), getDefaultAccountId());
			 */
		}

		List<KOInfoBean> approverbeanList1 = null;
		Query query11 = session.createSQLQuery(FUN_ASSIGN_APPROVER)
				.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
		approverbeanList1 = query11.list();
		if (Objects.nonNull(approverbeanList1) && !approverbeanList1.isEmpty()) {
			KOInfoBean ko = approverbeanList1.get(approverbeanList1.size() - 1);
			String approverusrid_re = ko.getApproverUserID();
			String Submitteremail_re = ko.getCreaterEmail();
			String koid_re = ko.getKoID();
			String approveremail_re = ko.getApproverEmail();
			String Submitterusrid_re = ko.getCreatedBy();

			/*
			 * if (!StringUtils.isEmpty(koid_re) && (Objects.nonNull(Submitteremail_re) &&
			 * Objects.nonNull(approveremail_re) && !Submitteremail_re.trim().equals("") &&
			 * !approveremail_re.trim().equals(""))) { sendemail(Submitteremail_re,
			 * Submitterusrid_re, approveremail_re, approverusrid_re, koid_re,
			 * getDefaultAccountId());
			 */
			//}
		}

	}

	/**
	 * Review submit KO.
	 *
	 * @param session the session
	 * @param koInfoBean the ko info bean
	 */
	private void reviewSubmitKO(Session session, KOInfoBean koInfoBean) {

		List<KOInfoBean> approverbeanList = null;
		if (!StringUtils.isEmpty(koInfoBean.getReviewedBy())) {
			assignAndEmailReviewer(koInfoBean.getKoID(), koInfoBean.getReviewedBy());
		} else {
			Query query1 = session.createSQLQuery("select * from fun_assign_approver_koId(:koId)")
					.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
			query1.setString(KO_ID_STRING, koInfoBean.getKoID());
			approverbeanList = query1.list();

			String approverusrid = null;
			String Submitteremail = null;
			String approveremail = null;
			String Submitterusrid = null;

			if (Objects.nonNull(approverbeanList) && !approverbeanList.isEmpty()) {
				for (KOInfoBean ko : approverbeanList) {
					approverusrid = ko.getApproverUserID();
					Submitteremail = ko.getCreaterEmail();
					approveremail = ko.getApproverEmail();
					Submitterusrid = ko.getCreatedBy();
				}
				/*
				 * if (Objects.nonNull(Submitteremail) && Objects.nonNull(approveremail) &&
				 * !Submitteremail.trim().equals("") && !approveremail.trim().equals(""))
				 * sendemail(Submitteremail, Submitterusrid, approveremail, approverusrid,
				 * koInfoBean.getKoID(), getDefaultAccountId());
				 */
			}
		}

	}

	/**
	 * Update review comment.
	 *
	 * @param reviewId the review id
	 * @param checkVal the check val
	 * @return the string
	 */
	@Override
	@Transactional
	public String updateReviewComment(String reviewId, int checkVal) {
		Session session = entityManager.unwrap(Session.class);
		Query query = session.createSQLQuery("select 1 as return from fun_ko_update_review(:reviewID, :newActionRequired)");
				//.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));

		query.setString("reviewID", reviewId);
		query.setInteger("newActionRequired", checkVal);
		query.list();

		return "";
	}

	/**
	 * Ko approval cycle list SP.
	 *
	 * @param koDtAttrVO the ko dt attr VO
	 * @return the list
	 */

	@Override
	@Transactional
	public List<KOInfoBean> koApprovalCycleListSP(KoDataAttributeVO koDtAttrVO) {

		List<KOInfoBean> KOInfoBeanList = null;

		Session session = entityManager.unwrap(Session.class);
		Query query = session.createSQLQuery(
				"select * from fun_ko_approver_cycle(:accountID,:publicationStatus, :assignmentGroup, :applicationName, :createdBy, :reviewedBy, :reviewComments,:reworkComplete,:fromDate,:toDate)")
				.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
		query.setInteger("accountID", Integer.parseInt(IKONUtils.isNullOrEmpty( koDtAttrVO.getMasterDtAttrVo().getAccId()) ? "0": koDtAttrVO.getMasterDtAttrVo().getAccId()));
		query.setString(PUBLICATION_STATUS, koDtAttrVO.getKoDtAttr().getPublicationStatus());
		query.setString(ASSIGNMENT_GROUP_STRING, koDtAttrVO.getMasterDtAttrVo().getAssignmentGroup());
		query.setString(APP_NAME, koDtAttrVO.getMasterDtAttrVo().getAppName());
		query.setString(CREATEDBY, koDtAttrVO.getKoDtAttr().getCreatedBy());
		query.setString(REVIEWED_BY, koDtAttrVO.getKoDtAttr().getReviewedBy());
		query.setString("fromDate", koDtAttrVO.getMasterDtAttrVo().getFromDate());
		query.setString("toDate", koDtAttrVO.getMasterDtAttrVo().getToDate());
		if (!IKONUtils.isNullOrEmpty(koDtAttrVO.getKoDtAttr().getReviewComments())) {
			query.setInteger(REVIEW_CMNTS, Integer.parseInt(IKONUtils.isNullOrEmpty(koDtAttrVO.getKoDtAttr().getReviewComments())?"0":koDtAttrVO.getKoDtAttr().getReviewComments()));
		} else {
			query.setInteger(REVIEW_CMNTS, 3);
		}
		if (!IKONUtils.isNullOrEmpty(koDtAttrVO.getKoDtAttr().getReworkComplete())) {
			query.setInteger(REWORK_COMPLETE, Integer.parseInt(IKONUtils.isNullOrEmpty(koDtAttrVO.getKoDtAttr().getReworkComplete())?"0":koDtAttrVO.getKoDtAttr().getReworkComplete()));
		} else {
			query.setInteger(REWORK_COMPLETE, 3);
		}
		KOInfoBeanList = query.list();
		return KOInfoBeanList;

	}

	/**
	 * Gets the all reviewed by names.
	 *
	 * @param userId    the user id
	 * @param accountId the account id
	 * @return the all reviewed by names
	 */
	@Override
	public Set<String> getAllReviewedByNames(String userId, String accountId) {
		List<KOPublishControl> koPublishControlBeanList = koPublishControlRepository.findAll();
		Set<String> createdByList = new HashSet<String>();
		for (KOPublishControl koPublishControl : koPublishControlBeanList) {
			if (!StringUtils.isEmpty(koPublishControl.getReviewedBy())) {
				createdByList.add(koPublishControl.getReviewedBy());
			}
		}
		return createdByList;
	}

	/**
	 * Sendapprovedemail.
	 *
	 * @param submitter     the submitter
	 * @param submittername the submittername
	 * @param approver      the approver
	 * @param approvername  the approvername
	 * @param koid          the koid
	 * @param accid         the accid
	 * @return the string
	 */
	/*
	 * public String sendapprovedemail(String submitter, String submittername,
	 * String approver, String approvername, String koid, String accid) {// Email
	 * message SimpleMailMessage passwordResetEmail = new SimpleMailMessage();
	 * passwordResetEmail.setFrom(approver); passwordResetEmail.setTo(submitter);
	 * String subjectdata = "IKON-2: KO " + koid + " got approved by " +
	 * approvername; passwordResetEmail.setSubject(subjectdata);
	 * 
	 * String msgdata = ("Hello " + submittername + ",\n Your KO (" + koid +
	 * ") got approved by " + approvername + ". \n "
	 * 
	 * + "\n Regards,\n" + "IKON-2 Team.");
	 * 
	 * passwordResetEmail.setText(msgdata);
	 * 
	 * try { emailService.sendEmail(passwordResetEmail); } catch (RuntimeException
	 * e) { String mailmsg = msgdata.replaceAll("\n", "<br/>");
	 * helpService.infomailsave(approver, submitter, "", subjectdata, mailmsg,
	 * Integer.parseInt(accid)); } return null; }
	 */
	/**
	 * Koavaldist SP.
	 *
	 * @param masterDataAttributeVO the master data attribute VO
	 * @return the list
	 */
	@Override
	@Transactional
	public List<KOInfoBean> koavaldistSP(MasterDataAttributeVO masterDataAttributeVO) {

		List<KOInfoBean> koavaldistList = null;
		Session session = entityManager.unwrap(Session.class);
		Query query = session.createSQLQuery(
				"select * from fun_ko_publish_graph_tower(:accid,:frmdate,:todate,:tower,:CC,:cluster,:appsname,:assgngrp,:userId)")
				.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
		query.setString(ACC_ID_STRING, masterDataAttributeVO.getAccId());
		query.setString(FRM_DATE_STRING, masterDataAttributeVO.getFromDate());
		query.setString(TO_DATE_STRING, masterDataAttributeVO.getToDate());
		query.setString(ASSGN_GRP_STRING, masterDataAttributeVO.getAssignmentGroup());
		query.setString(APPS_NAME_STRING, masterDataAttributeVO.getAppName());
		query.setString(TOWER_STRING, masterDataAttributeVO.getTower());
		query.setString("CC", masterDataAttributeVO.getCc());
		query.setString(CLUSTER_STRING, masterDataAttributeVO.getCluster());
		query.setString(USER_ID_STRING, masterDataAttributeVO.getUserId());
		koavaldistList = query.list();
		return koavaldistList;
	}

	/**
	 * Inclinked.
	 *
	 * @param masterDataAttributeVO the master data attribute VO
	 * @return the list
	 */
	@Override
	@Transactional
	public List<KOInfoBean> inclinked(MasterDataAttributeVO masterDataAttributeVO) {
		List<KOInfoBean> incvskogrpList = null;

		Session session = entityManager.unwrap(Session.class);
		Query query = session.createSQLQuery(
				"select * from fun_incident_linked_distribution_graph(:accid,:frmdate,:todate,:tower,:CC,:cluster,:appsname,:assgngrp,:userId)")
				.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
		query.setString(ACC_ID_STRING, masterDataAttributeVO.getAccId());
		query.setString(FRM_DATE_STRING, masterDataAttributeVO.getFromDate());
		query.setString(TO_DATE_STRING, masterDataAttributeVO.getToDate());
		query.setString(ASSGN_GRP_STRING, masterDataAttributeVO.getAssignmentGroup());
		query.setString(APPS_NAME_STRING, masterDataAttributeVO.getAppName());
		query.setString(TOWER_STRING, masterDataAttributeVO.getTower());
		query.setString("CC", masterDataAttributeVO.getCc());
		query.setString(CLUSTER_STRING, masterDataAttributeVO.getCluster());
		query.setString(USER_ID_STRING, masterDataAttributeVO.getUserId());
		
		incvskogrpList = query.list();
		return incvskogrpList;
	}

	/**
	 * Ko usage report SP.
	 *
	 * @param masterDataAttributeVO the master data attribute VO
	 * @param koType the ko type
	 * @return the list
	 */
	@Override
	@Transactional
	public List<KOInfoBean> koUsageReportSP(MasterDataAttributeVO masterDataAttributeVO, Integer koType) {
		List<KOInfoBean> KOInfoBeanList = null;

		Session session = entityManager.unwrap(Session.class);
		Query query = session.createSQLQuery(
				"select * from fun_top_ko_usage_report(:accountID,:fromDate, :toDate,:tower,:CC,:Cluster,:appname, :assignmentGroup, :koType)")
				.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
		query.setString("accountID", masterDataAttributeVO.getAccId());
		query.setString("fromDate", masterDataAttributeVO.getFromDate());
		query.setString("toDate", masterDataAttributeVO.getToDate());
		query.setString(TOWER_STRING, masterDataAttributeVO.getTower());
		query.setString("CC", masterDataAttributeVO.getCc());
		query.setString("Cluster", masterDataAttributeVO.getCluster());
		query.setString("appname", masterDataAttributeVO.getAppName());
		query.setString(ASSIGNMENT_GROUP_STRING, masterDataAttributeVO.getAssignmentGroup());
		query.setInteger("koType", Objects.isNull(koType)?0:koType);

		KOInfoBeanList = query.list();
		return KOInfoBeanList;
	}

	/**
	 * Linkvsnotlinked.
	 *
	 * @param masterDataAttributeVO the master data attribute VO
	 * @return the list
	 */
	@Override
	@Transactional
	public List<KOInfoBean> linkvsnotlinked(MasterDataAttributeVO masterDataAttributeVO) {
		List<KOInfoBean> linkvsnotlinkList = null;
		Session session = entityManager.unwrap(Session.class);
		Query query = session.createSQLQuery(
				"select * from fun_published_ko_link_vs_unlink_graph(:accid,:frmdate,:todate,:tower,:CC,:cluster,:appsname,:assgngrp,:usrid)")
				.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
		query.setString(ACC_ID_STRING, masterDataAttributeVO.getAccId());
		query.setString(FRM_DATE_STRING, masterDataAttributeVO.getFromDate());
		query.setString(TO_DATE_STRING, masterDataAttributeVO.getToDate());
		query.setString(ASSGN_GRP_STRING, masterDataAttributeVO.getAssignmentGroup());
		query.setString(APPS_NAME_STRING, masterDataAttributeVO.getAppName());
		query.setString(TOWER_STRING, masterDataAttributeVO.getTower());
		query.setString("CC", masterDataAttributeVO.getCc());
		query.setString(CLUSTER_STRING, masterDataAttributeVO.getCluster());
		query.setString("usrid", masterDataAttributeVO.getUserId());
		
		
		linkvsnotlinkList = query.list();

		return linkvsnotlinkList;
	}

	/**
	 * Simple ticket search.
	 *
	 * @param tktDtAttrVO the tkt dt attr VO
	 * @return the list
	 */
	@Override
	@Transactional
	public List<KOInfoBean> simpleTicketSearch(TicketDataAttributeVO tktDtAttrVO) {
		List<KOInfoBean> simplesearchkolistList = null;

		Session session = entityManager.unwrap(Session.class);
		Query query = session.createSQLQuery(
				"select * from fun_simple_ticket_search(:searchString,:searchid,:appsname,:assignname,:publistatus,:createdby)")
				.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
		query.setString("searchString", tktDtAttrVO.getSearchDtAttrVo().getSearch());
		query.setString(SEARCH_ID, tktDtAttrVO.getSearchDtAttrVo().getSearchid());
		query.setString(APPS_NAME_STRING, tktDtAttrVO.getMasterDtAttrVo().getAppName());
		query.setString("assignname", tktDtAttrVO.getMasterDtAttrVo().getAssignmentGroup());
		query.setString(PUB_STAT, tktDtAttrVO.getKoDtAttr().getKopublished());
		query.setString(CREATED_BY, tktDtAttrVO.getKoDtAttr().getCreatedBy());
		simplesearchkolistList = query.list();
		return simplesearchkolistList;
	}

	/**
	 * Simple KO search.
	 *
	 * @param tktDtAttrVO the tkt dt attr VO
	 * @return the list
	 */
	@Override
	@Transactional
	public List<KOInfoBean> simpleKOSearch(TicketDataAttributeVO tktDtAttrVO) {
		List<KOInfoBean> simplesearchkolistList = null;

		Session session = entityManager.unwrap(Session.class);
		Query query = session.createSQLQuery(
				"select * from fun_simple_ko_search(:searchString,:searchid,:appsname,:assignname,:publistatus,:createdby)")
				.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
		query.setString("searchString", tktDtAttrVO.getSearchDtAttrVo().getSearch());
		query.setString(SEARCH_ID, tktDtAttrVO.getSearchDtAttrVo().getSearchid());
		query.setString(APPS_NAME_STRING, tktDtAttrVO.getMasterDtAttrVo().getAppName());
		query.setString("assignname", tktDtAttrVO.getMasterDtAttrVo().getAssignmentGroup());
		query.setString(PUB_STAT, tktDtAttrVO.getKoDtAttr().getKopublished());
		query.setString(CREATED_BY, tktDtAttrVO.getKoDtAttr().getCreatedBy());
		simplesearchkolistList = query.list();
		return simplesearchkolistList;
	}

	/**
	 * Gets the KO reviewers by assignment group.
	 *
	 * @param masterDataAttributeVO the master data attribute VO
	 * @param createKo the create ko
	 * @return the KO reviewers by assignment group
	 */
	@Override
	@Transactional
	public List<KOReviewerBean> getKOReviewersByAssignmentGroup(MasterDataAttributeVO masterDataAttributeVO,
			Integer createKo) {
		List<KOReviewerBean> koReviewersList = null;
		Session session = entityManager.unwrap(Session.class);
		Query query = session.createSQLQuery("select * from fun_retreive_asgngrp_user(:asgngrp,:accid,:userId, :createKo)")
				.setResultTransformer(Transformers.aliasToBean(KOReviewerBean.class));
		query.setString("asgngrp", masterDataAttributeVO.getAppName()); //appNames are passed thought its mentioned assigment group here
		query.setString(ACC_ID_STRING, masterDataAttributeVO.getAccId());
		query.setString(USER_ID_STRING, masterDataAttributeVO.getUserId());
		query.setInteger("createKo", Objects.isNull(createKo) ? 0 : createKo);
		koReviewersList = query.list();
		return koReviewersList;
	}

	/**
	 * Assign and email reviewer.
	 *
	 * @param var_ko         the var ko
	 * @param approverUserID the approver user ID
	 */
	@Override
	@Transactional
	public void assignAndEmailReviewer(String var_ko, String approverUserID) {
		List<KOInfoBean> approverbeanList = null;
		Session session = entityManager.unwrap(Session.class);
		Query query1 = session.createSQLQuery("select * from fun_assign_reviewer(:koId,:approverUserID)")
				.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
		query1.setString(KO_ID_STRING, var_ko);
		query1.setString("approverUserID", approverUserID);
		approverbeanList = query1.list();

		if (Objects.nonNull(approverbeanList) && !approverbeanList.isEmpty()) {
			KOInfoBean koBean = approverbeanList.get(0);
			if (Objects.nonNull(koBean)) {
				String submittedBy = koBean.getCreatedBy();
				String submitterEmailId = koBean.getCreaterEmail();
				String approverID = koBean.getApproverUserID();
				String approverEmailId = koBean.getApproverEmail();
				/*
				 * if (!StringUtils.isEmpty(submitterEmailId) &&
				 * !StringUtils.isEmpty(approverEmailId)) { sendemail(submitterEmailId,
				 * submittedBy, approverEmailId, approverID, var_ko, getDefaultAccountId());
				 */
				//}
			}
		}

	}

	/**
	 * Mttrchrt.
	 *
	 * @param masterDataAttributeVO the master data attribute VO
	 * @return the list
	 */
	@Override
	@Transactional
	public List<KOInfoBean> mttrchrt(MasterDataAttributeVO masterDataAttributeVO) {
		List<KOInfoBean> mttrchrtList = null;
		Session session = entityManager.unwrap(Session.class);
		Query query = session
				.createSQLQuery(
						"select * from fun_mttr_all_incidents_chart(:accid,:frmdate,:todate,:tower,:CC,:cluster,:assgngrp)")
				.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
		query.setString(ACC_ID_STRING, masterDataAttributeVO.getAccId());
		query.setString(FRM_DATE_STRING, masterDataAttributeVO.getFromDate());
		query.setString(TO_DATE_STRING, masterDataAttributeVO.getToDate());
		query.setString(ASSGN_GRP_STRING, masterDataAttributeVO.getAssignmentGroup());
		query.setString(TOWER_STRING, masterDataAttributeVO.getTower());
		query.setString("CC", masterDataAttributeVO.getCc());
		query.setString(CLUSTER_STRING, masterDataAttributeVO.getCluster());

		mttrchrtList = query.list();
		return mttrchrtList;
	}

	/**
	 * Update generic KO detail.
	 *
	 * @param koInfoBean the ko info bean
	 * @param files the files
	 * @param userId the user id
	 * @return the string
	 */
	@Override
	@Transactional
	public String updateGenericKODetail(KOInfoBean koInfoBean, @RequestParam(FILE) MultipartFile[] files, String userId)
			{
		Session session = entityManager.unwrap(Session.class);
		String accountName = getAccountName();
		String PubStsid = null;
		String PubStsval = koInfoBean.getPublicationStatus();
		PubStsid = getPubStsId(PubStsval);

		Query query = session.createSQLQuery(
				"select 1 as return from fun_update_generic_ko(:koId, :shortDescription, :applicationName, :assignmentGroup, "
						+ ":longDescription, :symptoms, :resolution, :cause, :symptoms, :answer, :resolution,:attachmentdatafix,:attachmentnumber,:attachmentname ,:attachmentpath,:reviewedBy,:reviewedDate,:publishedBy,:publishedDate,:userId,:publicationStatus,:modifiedBy,:ticketid,:actionid,:level1,:level2,:level3)");
				//.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));

		query.setString(KO_ID_STRING, koInfoBean.getKoID());
		query.setString(SHORT_DESC, koInfoBean.getShortDescription());
		query.setString(APP_NAME, koInfoBean.getApplicationName());
		query.setString(ASSIGNMENT_GROUP_STRING, koInfoBean.getAssignmentGroup());
		query.setString(LONG_DESC, koInfoBean.getLongDescription());
		query.setString(SYMPTOMS, koInfoBean.getSymptoms());
		query.setString(RESOLUTION, koInfoBean.getResolution());
		query.setString("cause", koInfoBean.getCause());
		query.setString(SYMPTOMS, koInfoBean.getSymptoms());
		query.setString(ANSWER, koInfoBean.getAnswer());
		query.setString(RESOLUTION, koInfoBean.getResolution());
		query.setString(REVIEWED_BY, koInfoBean.getReviewedBy());
		query.setDate("reviewedDate", koInfoBean.getReviewedDate());
		query.setString("publishedBy", koInfoBean.getPublishedBy());
		query.setDate("publishedDate", koInfoBean.getPublishedDate());
		query.setString(USER_ID_STRING, userId);
		query.setString(PUBLICATION_STATUS, koInfoBean.getPublicationStatus());
		query.setString("modifiedBy", userId);
		query.setString(TICKET_ID, null);
		query.setString("actionid", PubStsid);
		StringBuffer text = new StringBuffer();
		StringBuffer Att_fname = new StringBuffer();
		int nooffiles = 0;
		String rootPath = System.getProperty(CATALINA_HOME);
		File dir = new File(rootPath + WEBAPP_KODOC + accountName + File.separator);
		if (!dir.exists())
			dir.mkdirs();
		List<String> names = uploadModuleNamedFiles(files, koInfoBean);
		for (String fpath : names) {
			text.append(readUploadFile(fpath));
			Path path = Paths.get(fpath);
			Path fname = path.getFileName();
			path.toAbsolutePath();
			if (Objects.nonNull(Att_fname) && !Att_fname.toString().equalsIgnoreCase("")) {
				Att_fname.append(strConcat("|" , fname.toString()));
			} else
				Att_fname.append(fname.toString());
			nooffiles++;
		}

		query.setString(ATT_DATAFIX, text.toString());
		query.setInteger(ATT_NUM, nooffiles);
		query.setString(ATT_NAME, Att_fname.toString());
		query.setString(ATT_PATH, dir.toString());
		query.setString("level1", koInfoBean.getBnsProL1());
		query.setString("level2", koInfoBean.getBnsProL2());
		query.setString("level3", koInfoBean.getBnsProL3());
		query.list();
		switch (PubStsval.toLowerCase(Locale.getDefault())) {
		case "reviewsubmit":
			reviewSubmitKOGen(session, koInfoBean);
			break;
		case "approved":
			approvedKOGen(session, koInfoBean);
			break;
		case "reworksubmit":
			reworkKOGen(session, koInfoBean);
			break;

		default:
			break;
		}

		return "";
	}

	/**
	 * Rework KO gen.
	 *
	 * @param session the session
	 * @param koInfoBean the ko info bean
	 */
	private void reworkKOGen(Session session, KOInfoBean koInfoBean) {
		List<KOInfoBean> approverbeanList = null;

		Query query1 = session.createSQLQuery("select * from fun_submit_for_rework(:koId)")
				.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
		query1.setString(KO_ID_STRING, koInfoBean.getKoID());
		approverbeanList = query1.list();
		if (Objects.nonNull(approverbeanList) && !approverbeanList.isEmpty()) {
			String approverusrid = null;
			String Submitteremail = null;
			String approveremail = null;
			String Submitterusrid = null;

			for (KOInfoBean ko : approverbeanList) {
				Submitterusrid = ko.getCreatedBy();
				Submitteremail = ko.getCreaterEmail();
				approverusrid = ko.getApproverUserID();
				approveremail = ko.getApproverEmail();
			}

			/*
			 * if (!Submitteremail.equals("") && !approveremail.equals("") &&
			 * Objects.nonNull(Submitteremail) && Objects.nonNull(approveremail))
			 * sendreworkemail(approveremail, approverusrid, Submitteremail, Submitterusrid,
			 * koInfoBean.getKoID(), getDefaultAccountId());
			 */

		}
		List<KOInfoBean> approverbeanList1 = null;
		Query query11 = session.createSQLQuery(FUN_ASSIGN_APPROVER)
				.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
		approverbeanList1 = query11.list();
		if (Objects.nonNull(approverbeanList1) && !approverbeanList1.isEmpty()) {
			String approverusrid_re = null;
			String Submitteremail_re = null;
			String koid_re = null;
			String approveremail_re = null;
			String Submitterusrid_re = null;

			for (KOInfoBean ko : approverbeanList1) {
				approverusrid_re = ko.getApproverUserID();
				Submitteremail_re = ko.getCreaterEmail();
				koid_re = ko.getKoID();
				approveremail_re = ko.getApproverEmail();
				Submitterusrid_re = ko.getCreatedBy();
			}
			/*
			 * if ((!StringUtils.isEmpty(koid_re)) && (!Submitteremail_re.equals("") &&
			 * !approveremail_re.equals("") && Objects.nonNull(Submitteremail_re) &&
			 * Objects.nonNull(approveremail_re))) sendemail(Submitteremail_re,
			 * Submitterusrid_re, approveremail_re, approverusrid_re, koid_re,
			 * getDefaultAccountId());
			 */
		}
	}

	/**
	 * Approved KO gen.
	 *
	 * @param session the session
	 * @param koInfoBean the ko info bean
	 */
	private void approvedKOGen(Session session, KOInfoBean koInfoBean) {
		List<KOInfoBean> approverbeanList = null;
		Query query1 = session.createSQLQuery("select * from fun_update_approver_status(:koId)")
				.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
		query1.setString(KO_ID_STRING, koInfoBean.getKoID());
		approverbeanList = query1.list();
		if (Objects.nonNull(approverbeanList) && !approverbeanList.isEmpty()) {
			String approverusrid = null;
			String Submitteremail = null;
			String approveremail = null;
			String Submitterusrid = null;
			for (KOInfoBean ko : approverbeanList) {
				approverusrid = ko.getApproverUserID();
				Submitteremail = ko.getCreaterEmail();
				approveremail = ko.getApproverEmail();
				Submitterusrid = ko.getCreatedBy();
			}
			/*
			 * if (!Submitteremail.equals("") && !approveremail.equals("") &&
			 * Objects.nonNull(Submitteremail) && Objects.nonNull(approveremail))
			 * sendapprovedemail(Submitteremail, Submitterusrid, approveremail,
			 * approverusrid, koInfoBean.getKoID(), getDefaultAccountId());
			 */
		}

		List<KOInfoBean> approverbeanList1 = null;
		Query query11 = session.createSQLQuery(FUN_ASSIGN_APPROVER)
				.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
		approverbeanList1 = query11.list();
		if (Objects.nonNull(approverbeanList1) && !approverbeanList1.isEmpty()) {
			String approverusrid_re = null;
			String Submitteremail_re = null;
			String koid_re = null;
			String approveremail_re = null;
			String Submitterusrid_re = null;

			for (KOInfoBean ko : approverbeanList1) {
				approverusrid_re = ko.getApproverUserID();
				Submitteremail_re = ko.getCreaterEmail();
				koid_re = ko.getKoID();
				approveremail_re = ko.getApproverEmail();
				Submitterusrid_re = ko.getCreatedBy();
			}

			/*
			 * if ((!StringUtils.isEmpty(koid_re)) && (!Submitteremail_re.equals("") &&
			 * !approveremail_re.equals("") && Objects.nonNull(Submitteremail_re) &&
			 * Objects.nonNull(approveremail_re))) sendemail(Submitteremail_re,
			 * Submitterusrid_re, approveremail_re, approverusrid_re, koid_re,
			 * getDefaultAccountId());
			 */
		}
	}

	/**
	 * Review submit KO gen.
	 *
	 * @param session the session
	 * @param koInfoBean the ko info bean
	 */
	private void reviewSubmitKOGen(Session session, KOInfoBean koInfoBean) {
		if (!StringUtils.isEmpty(koInfoBean.getReviewedBy())) {
			assignAndEmailReviewer(koInfoBean.getKoID(), koInfoBean.getReviewedBy());
		} else {
			sendmailtoreviewer(koInfoBean.getKoID(), "reviewsubmit");
		}
	}

	/**
	 * Find modules andlevels.
	 *
	 * @param loginusrname the loginusrname
	 * @return the list
	 */
	@Override
	@Transactional
	public List<BusinessProcessMaster> findModulesAndlevels(String loginusrname) {
		List<BusinessProcessMaster> moduleLevelList = null;
		Session session = entityManager.unwrap(Session.class);
		Query query = session.createSQLQuery("select * from fun_fetch_application(:userId)")
				.setResultTransformer(Transformers.aliasToBean(BusinessProcessMaster.class));
		query.setString(USER_ID_STRING, loginusrname);

		moduleLevelList = query.list();
		return moduleLevelList;
	}

	/**
	 * Upload file.
	 *
	 * @param files the files
	 * @param koInfoBean the ko info bean
	 * @return the List
	 */
	@Override
	public List<String> uploadModuleNamedFiles(MultipartFile[] files, KOInfoBean koInfoBean) {

		List<String> name = new ArrayList<String>();
		String accountName = getAccountName();
		String rootPath = System.getProperty(CATALINA_HOME);
		File dir = new File(rootPath + WEBAPP_KODOC + accountName + File.separator);

		String domainName = "CAP_SAP";
		String moduleName = koInfoBean.getApplicationName();
		moduleName = moduleName.replaceAll("/", "").trim();
		moduleName = moduleName.replaceAll("-", "").trim();
		moduleName = moduleName.replaceAll("  ", "").trim();

		String level3Name = koInfoBean.getBnsProL3();
		level3Name = level3Name.replaceAll("[^a-zA-Z]", "").trim();

		String shortDescName = koInfoBean.getShortDescription();
		String shortdescUpdated = "";

		if (shortDescName.length() > FIFTEEN) {
			shortdescUpdated = shortDescName.substring(0, 15);
		} else {
			shortdescUpdated = shortDescName;
		}

		for (MultipartFile file : files) {
			if (!dir.exists())
				dir.mkdirs();
			try {

				String extensionname = file.getOriginalFilename()
						.substring(file.getOriginalFilename().lastIndexOf(".") + 1);
				String originalFilename = file.getOriginalFilename();
				originalFilename = String.join("_", domainName, moduleName, level3Name, shortdescUpdated);

				String fileName = String.join(".",originalFilename,extensionname);
				fileName = fileName.replaceAll(" ", "_");

				String fileCheck = strConcat(originalFilename , ".");
				fileCheck = fileCheck.replaceAll(" ", "_");

				if (Objects.nonNull(fileName) && !fileName.equalsIgnoreCase("") && !fileName.equalsIgnoreCase(fileCheck)) {
					Path copyLocation = Paths.get(dir + File.separator + StringUtils.cleanPath(fileName));
					Files.copy(file.getInputStream(), copyLocation, StandardCopyOption.REPLACE_EXISTING);
					name.add(copyLocation.toString());
				}
			} catch (IOException e) {
				log.error(e.getMessage());
			}
		}
		return name;
	}

	/**
	 * Generic KO search.
	 *
	 * @param tktDtAttrVO the tkt dt attr VO
	 * @return the list
	 */
	@Override
	@Transactional
	public List<KOInfoBean> genericKOSearch(TicketDataAttributeVO tktDtAttrVO) {
		List<KOInfoBean> simplesearchkolistList = null;

		Session session = entityManager.unwrap(Session.class);
		Query query = session
				.createSQLQuery(
						"select * from fun_simple_generic_ko_search(:searchString,:searchid,:appsname,:publistatus,:createdby)")
				.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
		query.setString("searchString", tktDtAttrVO.getSearchDtAttrVo().getSearch());
		query.setString(SEARCH_ID, tktDtAttrVO.getSearchDtAttrVo().getSearchid());
		query.setString(APPS_NAME_STRING, tktDtAttrVO.getMasterDtAttrVo().getAppName());
		query.setString(PUB_STAT, tktDtAttrVO.getKoDtAttr().getKopublished());
		query.setString(CREATED_BY, tktDtAttrVO.getKoDtAttr().getCreatedBy());		
		simplesearchkolistList = query.list();
		return simplesearchkolistList;
	}

	/**
	 * Ko staus update.
	 *
	 * @return the list
	 */
	@Override
	@Transactional
	public List<KOInfoBean> koStausUpdate() {
		List<KOInfoBean> simplesearchkolistList = null;
		Session session = entityManager.unwrap(Session.class);
		Query query = session.createSQLQuery("CALL sp_update_ko_status()")
				.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
		simplesearchkolistList = query.list();
		return simplesearchkolistList;
	}

	/**
	 * Generic ko approval cycle list SP.
	 *
	 * @param koDtAttrVO the ko dt attr VO
	 * @return the list
	 */
	@Override
	@Transactional
	public List<KOInfoBean> genericKoApprovalCycleListSP(KoDataAttributeVO koDtAttrVO) {
		List<KOInfoBean> KOInfoBeanList = null;
		Session session = entityManager.unwrap(Session.class);
		Query query = session.createSQLQuery(
				"select * from fun_generic_ko_approver_cycle(:accountID,:publicationStatus, :assignmentGroup, :applicationName, :createdBy, :reviewedBy, :reviewComments,:reworkComplete,:fromDate,:toDate,:level1,:level2,:level3,:userId)")
				.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
		query.setString("accountID", koDtAttrVO.getMasterDtAttrVo().getAccId());
		query.setString(PUBLICATION_STATUS, koDtAttrVO.getKoDtAttr().getPublicationStatus());
		query.setString(ASSIGNMENT_GROUP_STRING, koDtAttrVO.getMasterDtAttrVo().getAssignmentGroup());
		query.setString(APP_NAME, koDtAttrVO.getMasterDtAttrVo().getAppName());
		query.setString(CREATEDBY, koDtAttrVO.getKoDtAttr().getCreatedBy());
		query.setString(REVIEWED_BY, koDtAttrVO.getKoDtAttr().getReviewedBy());
		query.setString("fromDate", koDtAttrVO.getMasterDtAttrVo().getFromDate());
		query.setString("toDate", koDtAttrVO.getMasterDtAttrVo().getToDate());
		if (!IKONUtils.isNullOrEmpty(koDtAttrVO.getKoDtAttr().getReviewComments())) {
			query.setString(REVIEW_CMNTS, koDtAttrVO.getKoDtAttr().getReviewComments());
		} else {
			query.setString(REVIEW_CMNTS, "3");
		}
		if (!IKONUtils.isNullOrEmpty(koDtAttrVO.getKoDtAttr().getReworkComplete())) {
			query.setString(REWORK_COMPLETE, koDtAttrVO.getKoDtAttr().getReworkComplete());
		} else {
			query.setString(REWORK_COMPLETE, "3");
		}

		query.setString("level1", koDtAttrVO.getMasterDtAttrVo().getLevel1());
		query.setString("level2", koDtAttrVO.getMasterDtAttrVo().getLevel2());
		query.setString("level3", koDtAttrVO.getMasterDtAttrVo().getLevel3());
		query.setString(USER_ID_STRING, koDtAttrVO.getMasterDtAttrVo().getUserId());

		KOInfoBeanList = query.list();
		return KOInfoBeanList;

	}

	/**
	 * Insert generic KO detail.
	 *
	 * @param koInfoBean the ko info bean
	 * @param files the files
	 * @return the list
	 * @throws IllegalAccessException the illegal access exception
	 */
	@Override
	@Transactional
	public List<KOInfoBean> insertGenericKODetail(KOInfoBean koInfoBean, @RequestParam(FILE) MultipartFile[] files)
			throws IllegalAccessException {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String loggedInUserName = auth.getName();
		String createActionValue = koInfoBean.getKoStage();
		String createActionId = createActionValue.equalsIgnoreCase("Indraft") ? "1" : "2";
		String accountName = getAccountName();
		if (((Objects.isNull(koInfoBean.getApplicationName()) || koInfoBean.getApplicationName().equalsIgnoreCase(""))
				|| (Objects.isNull(koInfoBean.getShortDescription())
						|| koInfoBean.getShortDescription().equalsIgnoreCase("")))) {
			throw new IllegalAccessException();
		}
		List<KOInfoBean> KOInfoBeanList = null;
		Session session = entityManager.unwrap(Session.class);
		Query query = session
				.createSQLQuery("select * from fun_create_generic_ko(:shortDescription,:applicationName,:assignmentGroup, "
						+ ":longDescription,:symptoms,:resolution,:answer,:symptoms,:answer,:resolution,:attachmentdatafix,:attachmentnumber,:attachmentname ,:attachmentpath,:pubstatus,:userid,:ticketid,:accid,:createactionid,:level1,:level2,:level3)")
				.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));

		query.setString(SHORT_DESC, koInfoBean.getShortDescription());
		query.setString(APP_NAME, koInfoBean.getApplicationName());
		query.setString(ASSIGNMENT_GROUP_STRING, koInfoBean.getAssignmentGroup());
		query.setString(LONG_DESC, koInfoBean.getLongDescription());
		query.setString(SYMPTOMS, koInfoBean.getSymptoms());
		query.setString(RESOLUTION, koInfoBean.getResolution());
		query.setString(ANSWER, koInfoBean.getAnswer());
		query.setString("pubstatus", koInfoBean.getKoStage());
		query.setString("userid", loggedInUserName);
		query.setString(TICKET_ID, koInfoBean.getTicketsearchbox());
		query.setString("accid", String.valueOf(koInfoBean.getAccountID()));
		query.setString("createactionid", createActionId);
		StringBuffer text = new StringBuffer();
		StringBuffer attachmentFileName = new StringBuffer();
		String attachmentPath = "";
		int nooffiles = 0;

		if (Objects.nonNull(files) && files.length > 0) {
			String rootPath = System.getProperty(CATALINA_HOME);
			File dir = new File(rootPath + WEBAPP_KODOC + accountName + File.separator);
			if (!dir.exists())
				dir.mkdirs();
			attachmentPath = dir.toString();
			List<String> names = uploadModuleNamedFiles(files, koInfoBean);

			for (String fpath : names) {
				text.append(readUploadFile(fpath));
				Path path = Paths.get(fpath);
				Path fname = path.getFileName();
				// path.toAbsolutePath();
				if (Objects.nonNull(attachmentFileName) && !attachmentFileName.toString().equalsIgnoreCase("")) {
					attachmentFileName.append(strConcat("|" , fname.toString()));
				} else
					attachmentFileName.append(fname.toString());
				nooffiles++;
			}
		}

		query.setString(ATT_DATAFIX, text.toString());
		query.setInteger(ATT_NUM, nooffiles);
		query.setString(ATT_NAME, attachmentFileName.toString());
		query.setString(ATT_PATH, attachmentPath);
		query.setString("level1", koInfoBean.getBnsProL1());
		query.setString("level2", koInfoBean.getBnsProL2());
		query.setString("level3", koInfoBean.getBnsProL3());

		KOInfoBeanList = query.list();
		return KOInfoBeanList;
	}

	/**
	 * Retrieve GS review comments.
	 *
	 * @param koId the ko id
	 * @return the list
	 */
	@Override
	@Transactional
	public List<KOInfoBean> retrieveGSReviewComments(String koId) {
		List<KOInfoBean> KOInfoBeanList = null;
		Session session = entityManager.unwrap(Session.class);
		Query query = session.createSQLQuery("select * from fun_retrieve_generic_ko_review_comments(:koID)")
				.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
		query.setParameter(KOID, koId);
		KOInfoBeanList = query.list();
		return KOInfoBeanList;

	}

	/**
	 * Edits the generic KO detail.
	 *
	 * @param koId the ko id
	 * @param accountId the account id
	 * @return the list
	 */
	@Override
	@Transactional
	public List<KOInfoBean> editGenericKODetail(String koId, String accountId) {

		List<KOInfoBean> KOInfoBeanList = null;
		Session session = entityManager.unwrap(Session.class);
		Query query = session.createSQLQuery("select * from fun_retrive_generic_ko_data(:koID, :accountId)")
				.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
		query.setParameter(KOID, koId);
		query.setParameter(ACCOUNT_ID, accountId);
		KOInfoBeanList = query.list();
		return KOInfoBeanList;
	}

	
	/**
	 * Kousagechrt.
	 *
	 * @param masterDataAttributeVO the master data attribute VO
	 * @return the list
	 */
	@Override
	@Transactional
	public List<KOInfoBean> kousagechrt(MasterDataAttributeVO masterDataAttributeVO) {

		List<KOInfoBean> kousagegraphList = null;
		Session session = entityManager.unwrap(Session.class);

		Query query = session
				.createSQLQuery(
						"select * from fun_ko_usage_chart(:accid,:frmdate,:todate,:tower,:CC,:cluster,:appsname,:assgngrp)")
				.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
		query.setString(ACC_ID_STRING, masterDataAttributeVO.getAccId());
		query.setString(FRM_DATE_STRING, masterDataAttributeVO.getFromDate());
		query.setString(TO_DATE_STRING, masterDataAttributeVO.getToDate());
		query.setString(ASSGN_GRP_STRING, masterDataAttributeVO.getAssignmentGroup());
		query.setString(APPS_NAME_STRING, masterDataAttributeVO.getAppName());
		query.setString(TOWER_STRING, masterDataAttributeVO.getTower());
		query.setString("CC", masterDataAttributeVO.getCc());
		query.setString(CLUSTER_STRING, masterDataAttributeVO.getCluster());
		

		kousagegraphList = query.list();
		return kousagegraphList;
	}
	
	/**
	 * Str concat.
	 *
	 * @param string1 the string 1
	 * @param string2 the string 2
	 * @return string
	 */
	@Override
	public String strConcat(String string1, String string2) {
		StringBuffer strBuff = new  StringBuffer(string1);
		strBuff.append(string2);
		return strBuff.toString();
	}
	
	/**
	 * 
	 * @param accountId the account id
	 * @return the KOInfoBean list
	 */
	@Override
	@Transactional
	public List<KOInfoBean> getAllKos(String accountId) {
		List<KOInfoBean> koInfoBeanList = new ArrayList<KOInfoBean>();
		Session session = entityManager.unwrap(Session.class);
		Query query = session.createSQLQuery("select * from fun_ko_info(:accid)")
				.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
		query.setParameter(ACC_ID_STRING,accountId);
		koInfoBeanList = query.list();
		return koInfoBeanList;
	}

	/**
	 *
	 */
	@Override
	@Transactional
	public List<ComplianceBean> compliancechart(MasterDataAttributeVO masterDataAttributeVO) {
		List<ComplianceBean> compliancechartList = null;
		Session session = entityManager.unwrap(Session.class);

		Query query = session
				.createSQLQuery(
						"select * from fun_compliance_chart2(:accid,:frmdate,:todate,:tower,:CC,:cluster,:appsname,:assgngrp)")
				.setResultTransformer(Transformers.aliasToBean(ComplianceBean.class));
		query.setString(ACC_ID_STRING, masterDataAttributeVO.getAccId());
		query.setString(FRM_DATE_STRING, masterDataAttributeVO.getFromDate());
		query.setString(TO_DATE_STRING, masterDataAttributeVO.getToDate());
		query.setString(ASSGN_GRP_STRING, masterDataAttributeVO.getAssignmentGroup());
		query.setString(APPS_NAME_STRING, masterDataAttributeVO.getAppName());
		query.setString(TOWER_STRING, masterDataAttributeVO.getTower());
		query.setString("CC", masterDataAttributeVO.getCc());
		query.setString(CLUSTER_STRING, masterDataAttributeVO.getCluster());
		

		compliancechartList = query.list();
		return compliancechartList;
	}
	/**
	 * @param fromdate todate
	 * @return the KOInfoBean list
	 */
	@Override
	@Transactional
	public List<KOInfoBean> koCreationRepo(String frmDate, String todate) {
		List<KOInfoBean> koCreationList = null;
		Session session = entityManager.unwrap(Session.class);
		Query query = session
				.createSQLQuery(
						"select * from fun_ko_created_report(:frmdate,:todate)")
				.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
		query.setString(FRM_DATE_STRING, frmDate);
		query.setString(TO_DATE_STRING, todate);
		koCreationList = query.list();
		return koCreationList;
	}

	/**
	 * @param fromdate todate
	 * @return the KOInfoBean list
	 */
	@Override
	@Transactional
	public List<KOMetricsBean> koMetricsRepo(String frmDate, String todate) {
		List<KOMetricsBean> koMetricsist = null;
		Session session = entityManager.unwrap(Session.class);
		Query query = session
				.createSQLQuery(
						"select * from fun_ko_metrics_report_test(:frmdate,:todate)")
				.setResultTransformer(Transformers.aliasToBean(KOMetricsBean.class));
		query.setString(FRM_DATE_STRING, frmDate);
		query.setString(TO_DATE_STRING, todate);
		koMetricsist = query.list();
		return koMetricsist;
	}	
}