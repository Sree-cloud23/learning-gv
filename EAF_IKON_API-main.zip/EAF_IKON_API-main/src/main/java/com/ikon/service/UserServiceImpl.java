package com.ikon.service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ikon.dto.AccessControlBean;
import com.ikon.dto.LandingScreenBean;
import com.ikon.dto.UserBean;
import com.ikon.model.UserMaster;
import com.ikon.repository.UserRepository;

/**
 * The Class UserServiceImpl.
 */
@SuppressWarnings("deprecation")
@Service
public class UserServiceImpl implements UserService {
	
    /** The user repository. */
	@Inject
    private transient UserRepository userRepository;
    
    /** The entity manager. */
    @PersistenceContext
    EntityManager entityManager;
    
    /**
     * Save reset.
     *
     * @param user the user
     */
    @Override
    public void saveReset(UserMaster user) {
    	UserMaster userMaster = userRepository.findById(user.getId()).orElse(null);    	
    	userMaster.setResetToken(user.getResetToken());
    	userRepository.save(userMaster);
    }
    
    /**
     * Save change pwd.
     *
     * @param user the user
     */
    @Override
    public void saveChangePwd(UserMaster user) {
		UserMaster userMaster = userRepository.findById(user.getId()).orElse(null);
    	userMaster.setResetToken(user.getResetToken()); 
    	userMaster.setPassword(user.getPassword());
    	userMaster.setAttempts(0);
    	userMaster.setStatus("Active");
    	userRepository.save(userMaster);
    } 
    
    /**
     * Update attempts.
     *
     * @param user the user
     */
    @Override
	public void updateAttempts(String user) {
    	final int maxAttempts=2;
		UserMaster userMaster = userRepository.findByName(user);
		userMaster.setAttempts(userMaster.getAttempts() + 1);
		if (Objects.equals(userMaster.getAttempts(), maxAttempts)) {
			userMaster.setStatus("Locked");
		} 
		userRepository.save(userMaster);
	}
    
    /**
     * Check attempts.
     *
     * @param user the user
     * @return the int
     */
    @Override
    public int checkAttempts(String user) {
    	UserMaster userMaster = userRepository.findByName(user);
    	return userMaster.getAttempts();
    	    	
    }
    
    /**
     * Reset attempts.
     *
     * @param user the user
     */
    @Override
    public void resetAttempts(String user) {
    	UserMaster userMaster = userRepository.findByName(user);
    	userMaster.setAttempts(0);
    	userRepository.save(userMaster);    	
    }

    /**
     * Find by username.
     *
     * @param username the username
     * @return the user master
     */
    @Override
    public UserMaster findByUsername(String username) {
        return userRepository.findByName(username);
    }
    
    /**
     * Find user by email.
     *
     * @param email the email
     * @return the optional
     */
    @Override
    public Optional<UserMaster> findUserByEmail(String email) {
		return userRepository.findByEmail(email);
	}

	/**
	 * Find user by reset token.
	 *
	 * @param resetToken the reset token
	 * @return the optional
	 */
	@Override
	public Optional<UserMaster> findUserByResetToken(String resetToken) {
		return userRepository.findByResetToken(resetToken);
	}
	
	/**
	 * Gets the user detail.
	 *
	 * @param userId the user id
	 * @return the user detail
	 */
	@Override
	@Transactional
	public LandingScreenBean getUserDetail(String userId) {
		List<LandingScreenBean> accessControlBeanList = null;
		Session session = entityManager.unwrap( Session.class );
			Query query = session.createSQLQuery("select * from fun_user_after_login(:userId)").setResultTransformer(Transformers.aliasToBean(LandingScreenBean.class));
			query.setParameter("userId", userId);
			accessControlBeanList = query.list();
			if(Objects.nonNull(accessControlBeanList) && accessControlBeanList.size()>0){
				return accessControlBeanList.get(0);			
			} 
			return new LandingScreenBean();
	}
	
	
	/**
	 * Insert user login.
	 *
	 * @param userID the user ID
	 * @param accountID the account ID
	 * @param errorMessage the error message
	 * @return the string
	 */
	@Override
	@Transactional
	public String insertUserLogin(String userID,String accountID,String errorMessage) {
		Session session = entityManager.unwrap( Session.class );
		
			Query query = session.createSQLQuery("select 1 as return from fun_insert_user_login(:userID, :accountID,:errorMessage)");
					//.setResultTransformer(Transformers.aliasToBean(TicketDataBean.class));
	
			query.setString("userID", userID);
			query.setString("accountID", accountID);
			query.setString("errorMessage", errorMessage);
	
			query.list(); 	
			return "";
	}

	/**
	 * Gets the details byuserid.
	 *
	 * @param user the user
	 * @return the details byuserid
	 */
	@Override
	@Transactional
	public UserMaster getdetailsByuserid(String user) {
		
		UserMaster userBeanList = null;
		
		//userBeanList = userRepository.getDetailsByUserName(user);
		userBeanList = userRepository.findByName(user);
		if (Objects.nonNull(userBeanList)) {
			return userBeanList;
		}
		return null;

	}

	/**
	 * Gets the user logged indetail.
	 *
	 * @param fromDate the from date
	 * @param toDate the to date
	 * @return the user logged indetail
	 */
	@Override
	@Transactional
	public List<UserBean> getUserLoggedIndetail(String fromDate, String toDate) {
		List<UserBean> userLoggedInData = null;
		Session session = entityManager.unwrap( Session.class );
			Query query = session.createSQLQuery("select * from fun_user_login_report(:fromDate, :toDate)")
					.setResultTransformer(Transformers.aliasToBean(UserBean.class));
			query.setParameter("fromDate", fromDate);
			query.setParameter("toDate", toDate);
			userLoggedInData = query.list();
			return userLoggedInData;
	}
	
	
	/**
	 * 
	 * @param accountID
	 * @return User Bean
	 */
	@Override
	@Transactional
	public UserBean getUserAccountType(String accountID) {
		List<UserBean> accType = null;
		Session session = entityManager.unwrap( Session.class );
		Query query = session.createSQLQuery("select * from fun_check_acc_type(:accountID)")
				.setResultTransformer(Transformers.aliasToBean(UserBean.class));
		query.setString("accountID", accountID);
		
		accType = query.list();
		if(Objects.nonNull(accType) && accType.size()>0){
			return accType.get(0);			
		} else {
			new AccessControlBean();
		}
		return new UserBean();
	}
}
