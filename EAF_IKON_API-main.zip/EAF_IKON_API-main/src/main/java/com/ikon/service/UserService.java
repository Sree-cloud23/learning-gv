package com.ikon.service;

import java.util.List;
import java.util.Optional;

import com.ikon.dto.LandingScreenBean;
import com.ikon.dto.UserBean;
import com.ikon.model.UserMaster;

/**
 * The Interface UserService.
 */
public interface UserService {
	
	/**
	 * Find user by email.
	 *
	 * @param email_ID the email ID
	 * @return the optional
	 */
	public Optional<UserMaster> findUserByEmail(String email_ID);

	/**
	 * Find user by reset token.
	 *
	 * @param resetToken the reset token
	 * @return the optional
	 */
	public Optional<UserMaster> findUserByResetToken(String resetToken);

	/**
	 * Gets the user detail.
	 *
	 * @param userId the user id
	 * @return the user detail
	 */
	public LandingScreenBean getUserDetail(String userId);

	/**
	 * Find by username.
	 *
	 * @param username the username
	 * @return the user master
	 */
	public UserMaster findByUsername(String username);

	/**
	 * Save reset.
	 *
	 * @param user the user
	 */
	void saveReset(UserMaster user);

	/**
	 * Save change pwd.
	 *
	 * @param user the user
	 */
	void saveChangePwd(UserMaster user);

	/**
	 * Update attempts.
	 *
	 * @param user the user
	 */
	void updateAttempts(String user);

	/**
	 * Reset attempts.
	 *
	 * @param user the user
	 */
	void resetAttempts(String user);

	/**
	 * Check attempts.
	 *
	 * @param user the user
	 * @return the int
	 */
	int checkAttempts(String user);

	/**
	 * Gets the details byuserid.
	 *
	 * @param user the user
	 * @return the details byuserid
	 */
	public UserMaster getdetailsByuserid(String user);

	/**
	 * Insert user login.
	 *
	 * @param userID the user ID
	 * @param accountID the account ID
	 * @param errorMessage the error message
	 * @return the string
	 */
	String insertUserLogin(String userID, String accountID, String errorMessage);

	/**
	 * Gets the user logged indetail.
	 *
	 * @param fromDate the from date
	 * @param toDate the to date
	 * @return the user logged indetail
	 */
	List<UserBean> getUserLoggedIndetail(String fromDate, String toDate);

	/**
	 * Gets the user account type.
	 *
	 * @param accountID the account ID
	 * @return the user account type
	 */
	UserBean getUserAccountType(String accountID);

}
