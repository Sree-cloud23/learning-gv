package com.ikon.service;

import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.orm.jpa.EntityManagerFactoryInfo;
/*import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;*/
import org.springframework.stereotype.Service;

import com.ikon.dto.KOInfoBean;
import com.ikon.rest.web.models.Authentication;
import com.ikon.rest.web.models.PostgresTicketDataBean;
import com.ikon.rest.web.models.SecurityContextHolder;
import com.ikon.rest.web.models.TicketDataDTO;
import com.ikon.rest.web.models.WorkNoteDTO;

import lombok.extern.slf4j.Slf4j;

@Service
@Transactional
@Slf4j
public class MLDBProcess {

	/** The Constant log. */
	//private  final log log = LogManager.getlog(MLDBProcess.class);

	@PersistenceContext(unitName = "multiEntityManager")
	private  EntityManager entityManager;
	
	
	private  Connection getPostgresDbConnection() {
		Connection dbcon = null;

		/*ClassLoader loader = Thread.currentThread().getContextClassLoader();
		Properties properties = new Properties();
		try (InputStream resourceStream = loader.getResourceAsStream("application.properties")) {
			properties.load(resourceStream);
		} catch (IOException e) {
			log.error(e);
		}

		String conUrl = properties.getProperty("postgresconnectionurl");
		String username = properties.getProperty("postgresusername");
		String password = properties.getProperty("postgrespassword");*/

		try {
			//dbcon = DriverManager.getConnection(conUrl, username, password);
			//Session session = entityManager.unwrap( Session.class );
			//dbcon = entityManager.getEntityManagerFactory().getc
					EntityManagerFactoryInfo info = (EntityManagerFactoryInfo) entityManager.getEntityManagerFactory();
		    dbcon = info.getDataSource().getConnection();
			log.info("You are now connected to the postgres server");
		} catch (SQLException e) {
			log.error(e.getMessage());
		}

		return dbcon;
	}

	public  void insertIncToPostgres(final TicketDataDTO ticketDataDTO) {

		final String description = ticketDataDTO.getDescription(); // Notes
		final String summary = ticketDataDTO.getShortDescription(); // getSummary
		final String comments = ticketDataDTO.getResolutionNote();

		// String worknotes = ticketDataDTO.getWorkNotes(); // getAdditional_Comments
		final List<WorkNoteDTO> workNotes = ticketDataDTO.getWorkNotes();
		final StringBuilder workNote = new StringBuilder();
		if (workNotes != null) {
			for (final WorkNoteDTO workNoteDto : workNotes) {
				workNote.append(workNoteDto.getValue());
				workNote.append(" ");
			}
		}
		final String incidentText = description + " " + summary + " " + comments + " " + workNote.toString();
		final String descSum = description + " " + summary;

		final PostgresTicketDataBean mbdbean = new PostgresTicketDataBean();
		mbdbean.setIncident_id(ticketDataDTO.getNumber()); // Incident ID
		mbdbean.setApp_Name(checkNull(ticketDataDTO.getApplicationName()));
		mbdbean.setAssigned_Group(ticketDataDTO.getAssignmentGroup());
		mbdbean.setStatus(ticketDataDTO.getState()); // getStatus
		mbdbean.setInc_text(incidentText);
		mbdbean.setSummary(descSum);
		
		final PostgresTicketDataBean postgresTicketDataBean = findTicketInTicketDataHistoryPostgres(
				ticketDataDTO.getNumber());
		
		if (postgresTicketDataBean == null) {
			pushTicketToTicketDataInterPostgres(mbdbean);
		} else {
			if ((postgresTicketDataBean.getIncident_id().equalsIgnoreCase(mbdbean.getIncident_id()))
					&& ((!postgresTicketDataBean.getInc_text().equalsIgnoreCase(mbdbean.getInc_text()))
							|| (!postgresTicketDataBean.getApp_Name().equalsIgnoreCase(mbdbean.getApp_Name()))
							|| (!postgresTicketDataBean.getAssigned_Group().equalsIgnoreCase(mbdbean.getAssigned_Group()))
							|| (!postgresTicketDataBean.getStatus().equalsIgnoreCase(mbdbean.getStatus()))
							|| (!postgresTicketDataBean.getSummary().equalsIgnoreCase(mbdbean.getSummary())))) {

				pushTicketToTicketDataInterPostgres(mbdbean);
			} else {
				pushTicketToTicketDataHistoryPostgres(mbdbean);
			}
		}

	}

	private  void pushTicketToTicketDataInterPostgres(final PostgresTicketDataBean ticketBean) {

		final StringBuffer sqlQuery = new StringBuffer(
				"INSERT INTO ticket_data_inter_mongo(\"Incident_id\",\"App_Name\",\"Assigned_Group\",\"Status\",\"Inc_text\",\"Summary\")");
		sqlQuery.append(" VALUES(?,?,?,?,?,?)");
		sqlQuery.append(" ON CONFLICT (\"Incident_id\") DO UPDATE");
		sqlQuery.append(
				" SET \"Incident_id\"=?,\"App_Name\"=?,\"Assigned_Group\"=?,\"Status\"=?,\"Inc_text\"=?,\"Summary\"=?");

		try (Connection dbcon = getPostgresDbConnection();
				PreparedStatement prepareStatement = dbcon.prepareStatement(sqlQuery.toString(),
						Statement.RETURN_GENERATED_KEYS)) {
			prepareStatement.setString(1, ticketBean.getIncident_id());
			prepareStatement.setString(2, ticketBean.getApp_Name());
			prepareStatement.setString(3, ticketBean.getAssigned_Group());
			prepareStatement.setString(4, ticketBean.getStatus());
			prepareStatement.setString(5, ticketBean.getInc_text());
			prepareStatement.setString(6, ticketBean.getSummary());

			prepareStatement.setString(7, ticketBean.getIncident_id());
			prepareStatement.setString(8, ticketBean.getApp_Name());
			prepareStatement.setString(9, ticketBean.getAssigned_Group());
			prepareStatement.setString(10, ticketBean.getStatus());
			prepareStatement.setString(11, ticketBean.getInc_text());
			prepareStatement.setString(12, ticketBean.getSummary());

			int rowsAffected = prepareStatement.executeUpdate();

			if (rowsAffected > 0) {
				log.info("Ticket inserted successfully into postgres into ticket_data_inter: "
						+ ticketBean.getIncident_id());
			}
		} catch (SQLException ex) {
			log.error(ex.getMessage());
		}

	}

	private  void pushTicketToTicketDataHistoryPostgres(final PostgresTicketDataBean ticketBean) {

		final StringBuffer sqlQuery = new StringBuffer(
				"INSERT INTO ticket_data_history_mongo(\"Incident_id\",\"App_Name\",\"Assigned_Group\",\"Status\",\"Inc_text\",\"Summary\")");
		sqlQuery.append(" VALUES(?,?,?,?,?,?)");
		sqlQuery.append(" ON CONFLICT (\"Incident_id\") DO UPDATE");
		sqlQuery.append(
				" SET \"Incident_id\"=?,\"App_Name\"=?,\"Assigned_Group\"=?,\"Status\"=?,\"Inc_text\"=?,\"Summary\"=?");

		try (Connection dbcon = getPostgresDbConnection();
				PreparedStatement prepareStatement = dbcon.prepareStatement(sqlQuery.toString(),
						Statement.RETURN_GENERATED_KEYS)) {
			prepareStatement.setString(1, ticketBean.getIncident_id());
			prepareStatement.setString(2, checkNull(ticketBean.getApp_Name()));
			prepareStatement.setString(3, ticketBean.getAssigned_Group());
			prepareStatement.setString(4, ticketBean.getStatus());
			prepareStatement.setString(5, ticketBean.getInc_text());
			prepareStatement.setString(6, ticketBean.getSummary());

			prepareStatement.setString(7, ticketBean.getIncident_id());
			prepareStatement.setString(8, checkNull(ticketBean.getApp_Name()));
			prepareStatement.setString(9, ticketBean.getAssigned_Group());
			prepareStatement.setString(10, ticketBean.getStatus());
			prepareStatement.setString(11, ticketBean.getInc_text());
			prepareStatement.setString(12, ticketBean.getSummary());

			int rowsAffected = prepareStatement.executeUpdate();

			if (rowsAffected > 0) {
				log.info("Ticket updated successfully into postgres into ticket_data_history: "
						+ ticketBean.getIncident_id());
			}
		} catch (SQLException ex) {
			log.error(ex.getMessage());
		}

	}

	/**
	 * Insert data into postgres.
	 * 
	 * @param koInfoBean    the ko info bean
	 * @param defaultAcctId the default acct id
	 * @param koId          the ko id
	 * @param getKoStage    the get ko stage
	 * @throws UnsupportedEncodingException
	 */
	public  void insertDataIntoPostgres(KOInfoBean koInfoBean, String defaultAcctId, String koId,
			String getKoStage ,String userName) throws UnsupportedEncodingException {

		String incident_id;
		try {

			List<String> getvalue_inter = findKoInKoDetailInterPostgres(koId);

			if ((Objects.nonNull(koInfoBean.getTicketsearchbox())
					&& !koInfoBean.getTicketsearchbox().trim().equalsIgnoreCase("")))
				incident_id = koInfoBean.getTicketsearchbox();
			else
				incident_id = koInfoBean.getTicketID();

			List<String> getvalue_ticket = findTicketInIncKoLinkPostgres(incident_id);

			if (Objects.nonNull(getKoStage) && getKoStage.equalsIgnoreCase("ticketview")) {
				if (getvalue_ticket.size() > 0) {
					updatelinkkoInPostgres(koInfoBean, defaultAcctId, koId, getKoStage,userName);
					return;
				} else {
					insertIncKoLinkInPostgres(koInfoBean, defaultAcctId, koId, getKoStage,userName);
					return;
				}
			}

			if (getvalue_inter.size() > 0) {
				updatekoInPostgres(koInfoBean, defaultAcctId, koId, getKoStage,userName);
				return;

			} else {
				insertkoInPostgres(koInfoBean, defaultAcctId, koId, getKoStage);
				if(koInfoBean.getTicketID() != null && !"".equals(koInfoBean.getTicketID().trim())) {
					insertIncKoLinkInPostgres(koInfoBean, defaultAcctId, koId, getKoStage,userName);
				}

			}

			if (Objects.nonNull(koInfoBean.getGenericKoID()) && !koInfoBean.getGenericKoID().equalsIgnoreCase("null")
					&& koInfoBean.getGenericKoID().startsWith("GS")) {

				insertCloneKoInPostgres(koInfoBean, koId);
			}

		} catch (Exception e) {
			log.error(e.getMessage());
		}
	}

	private  void insertCloneKoInPostgres(KOInfoBean koInfoBean, String koId) {

		String genericKoId = koInfoBean.getGenericKoID();

		Date todaysDate = new Date();
		DateFormat df2 = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss", Locale.getDefault());

		String date = df2.format(todaysDate);

		final StringBuffer sqlQuery = new StringBuffer(
				"INSERT INTO generic_account_ko_mapping_mongo(\"generic_id\",\"acc_ko_id\",\"link_date\")");
		sqlQuery.append(" VALUES(?,?,?)");
		sqlQuery.append(" ON CONFLICT (\"generic_id\") DO UPDATE");
		sqlQuery.append(" SET \"generic_id\"=?,\"acc_ko_id\"=?,\"link_date\"=?");

		try (Connection dbcon = getPostgresDbConnection();
				PreparedStatement prepareStatement = dbcon.prepareStatement(sqlQuery.toString(),
						Statement.RETURN_GENERATED_KEYS)) {
			prepareStatement.setString(1, genericKoId);
			prepareStatement.setString(2, koId);
			prepareStatement.setString(3, date);

			prepareStatement.setString(4, genericKoId);
			prepareStatement.setString(5, koId);
			prepareStatement.setString(6, date);

			int rowsAffected = prepareStatement.executeUpdate();

			if (rowsAffected > 0) {
				log.info("Generic id inserted/updated successfully into postgres: " + genericKoId);
			}
		} catch (SQLException ex) {
			log.error(ex.getMessage());
		}

	}

	private  void insertkoInPostgres(KOInfoBean koInfoBean, String defaultAcctId, String koId,
			String getKoStage) {

		String shortdescription = koInfoBean.getShortDescription();
		String longdescription = koInfoBean.getLongDescription();
		String symptoms = koInfoBean.getSymptoms();
		String resolution = koInfoBean.getResolution();

		String ko_text = shortdescription + " " + longdescription + " " + symptoms + " " + resolution;
		String summary = shortdescription + " " + longdescription;
	String publicationStatus="";
		
		if(StringUtils.isNumeric(getKoStage))
		{
		if (getKoStage.equalsIgnoreCase("1")) {
			publicationStatus = "1";
		} else if (getKoStage.equalsIgnoreCase("2")) {
			publicationStatus = "2";
		} else {
			publicationStatus = koInfoBean.getPublicationStatus();
		}
		}
		else {
			if(getKoStage.equalsIgnoreCase("draft"))
				publicationStatus = "1";
			if(getKoStage.equalsIgnoreCase("published"))
				publicationStatus = "6";
			
		}
		final StringBuffer sqlQuery = new StringBuffer(
				"INSERT INTO ko_detail_inter_mongo(\"Ko_id\",\"Ko_text\",\"Summary\",\"App_name\",\"Ticket_group\",\"Ko_status\",\"Publication_status\")");
		sqlQuery.append(" VALUES(?,?,?,?,?,?,?)");

		try (Connection dbcon = getPostgresDbConnection();
				PreparedStatement prepareStatement = dbcon.prepareStatement(sqlQuery.toString(),
						Statement.RETURN_GENERATED_KEYS)) {
			prepareStatement.setString(1, koId);
			prepareStatement.setString(2, ko_text);
			prepareStatement.setString(3, summary);
			prepareStatement.setString(4, koInfoBean.getApplicationName());
			prepareStatement.setString(5, koInfoBean.getAssignmentGroup());
			prepareStatement.setString(6, "1");
			prepareStatement.setString(7, publicationStatus);

			int rowsAffected = prepareStatement.executeUpdate();

			if (rowsAffected > 0) {
				log.info("KO inserted successfully into postgres: " + koId);
			}
		} catch (SQLException ex) {
			log.error(ex.getMessage());
		}

	}

	private  void updatekoInPostgres(KOInfoBean koInfoBean, String defaultAcctId, String koId,
			String getKoStage,String userName) {
		
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss", Locale.getDefault());
		Date date = new Date();

		String shortdescription = koInfoBean.getShortDescription();
		String longdescription = koInfoBean.getLongDescription();
		String symptoms = koInfoBean.getSymptoms();
		String resolution = koInfoBean.getResolution();

		String ko_text = shortdescription + " " + longdescription + " " + symptoms + " " + resolution;
		String summary = shortdescription + " " + longdescription;
		
		String publicationStatus=null;
		if(!StringUtils.isNumeric(koInfoBean.getPublicationStatus())) {
			if(getKoStage.equalsIgnoreCase("draft"))
				publicationStatus = "1";
			if(getKoStage.equalsIgnoreCase("published"))
				publicationStatus = "6";
		}
		else {
			publicationStatus=koInfoBean.getPublicationStatus();
		}

		StringBuffer sqlQuery = new StringBuffer(
				"update ko_detail_inter_mongo set \"Ko_text\"=?,\"Summary\"=?,\"App_name\"=?,\"Ticket_group\"=?,\"Publication_status\"=?,\"Ko_status\"=?,\"modifieddate\"=?,\"modifiedby\"=?");
		sqlQuery.append(" where \"Ko_id\"=?");

		try (Connection dbcon = getPostgresDbConnection();
				PreparedStatement prepareStatement = dbcon.prepareStatement(sqlQuery.toString(),
						Statement.RETURN_GENERATED_KEYS)) {
			prepareStatement.setString(1, ko_text);
			prepareStatement.setString(2, summary);
			prepareStatement.setString(3, koInfoBean.getApplicationName());
			prepareStatement.setString(4, koInfoBean.getAssignmentGroup());
			prepareStatement.setString(5, publicationStatus);
			prepareStatement.setString(6, "1");
			prepareStatement.setString(7, dateFormat.format(date));
			prepareStatement.setString(8,userName);
			prepareStatement.setString(9, koId);

			int rowsAffected = prepareStatement.executeUpdate();

			if (rowsAffected > 0) {
				log.info("Existing KO successfully updated into postgres: " + koId);
			}
		} catch (SQLException ex) {
			log.error(ex.getMessage());
		}
	}

	private  void insertIncKoLinkInPostgres(KOInfoBean koInfoBean, String defaultAcctId, String koId,
			String getKoStage,String userName) {

		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String loginusrname = auth.getName();
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss", Locale.getDefault());
		Date date = new Date();
		String incident_id;

		if ((Objects.nonNull(koInfoBean.getTicketsearchbox())
				&& !koInfoBean.getTicketsearchbox().trim().equalsIgnoreCase("")))
			incident_id = koInfoBean.getTicketsearchbox();
		else
			incident_id = koInfoBean.getTicketID();

		final StringBuffer sqlQuery = new StringBuffer(
				"INSERT INTO incident_ko_link_mongo(\"incident_id\",\"ko_id\",\"User_Id\",\"link_date\",\"arch_flag\",\"createddate\",\"createdby\")");
		sqlQuery.append(" VALUES(?,?,?,?,?)");

		try (Connection dbcon = getPostgresDbConnection();
				PreparedStatement prepareStatement = dbcon.prepareStatement(sqlQuery.toString(),
						Statement.RETURN_GENERATED_KEYS)) {
			prepareStatement.setString(1, incident_id);
			prepareStatement.setString(2, koId);
			prepareStatement.setString(3, userName);
			prepareStatement.setString(4, dateFormat.format(date));
			prepareStatement.setString(5, "null");
			prepareStatement.setString(6, dateFormat.format(date));
			prepareStatement.setString(7, userName);

			int rowsAffected = prepareStatement.executeUpdate();

			if (rowsAffected > 0) {
				log.info("Ticket linked successfully into postgres: " + incident_id);
			}
		} catch (SQLException ex) {
			log.error(ex.getMessage());
		}

	}

	private  void updatelinkkoInPostgres(KOInfoBean koInfoBean, String defaultAcctId, String koId,
			String getKoStage, String userName) {

		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String loginusrname = auth.getName();
		String incident_id;

		if ((Objects.nonNull(koInfoBean.getTicketsearchbox())
				&& !koInfoBean.getTicketsearchbox().trim().equalsIgnoreCase("")))
			incident_id = koInfoBean.getTicketsearchbox();
		else
			incident_id = koInfoBean.getTicketID();

		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss", Locale.getDefault());
		Date date = new Date();

		StringBuffer sqlQuery = new StringBuffer(
				"update incident_ko_link_mongo set \"ko_id\"=?,\"User_Id\"=?,\"link_date\"=?,\"modifieddate\"=?,\"modifiedby\"=?");
		sqlQuery.append(" where \"incident_id\"=?");

		try (Connection dbcon = getPostgresDbConnection();
				PreparedStatement prepareStatement = dbcon.prepareStatement(sqlQuery.toString(),
						Statement.RETURN_GENERATED_KEYS)) {
			prepareStatement.setString(1, koId);
			prepareStatement.setString(2, userName);
			prepareStatement.setString(3, dateFormat.format(date));
			prepareStatement.setString(4, incident_id);
			prepareStatement.setString(5, dateFormat.format(date));
			prepareStatement.setString(6, userName);
			prepareStatement.setString(7, incident_id);

			int rowsAffected = prepareStatement.executeUpdate();

			if (rowsAffected > 0) {
				log.info("Existing Ticket linked successfully into postgres: " + incident_id);
			}
		} catch (SQLException ex) {
			log.error(ex.getMessage());
		}
	}

	private  List<String> findKoInKoDetailInterPostgres(final String koId) {
		List<String> koList = new ArrayList<>();
		final StringBuffer sqlQuery = new StringBuffer("select \"Ko_id\" from ko_detail_inter_mongo where \"Ko_id\"=?");
		try (Connection dbcon = getPostgresDbConnection();
				PreparedStatement prepareStatement = dbcon.prepareStatement(sqlQuery.toString(),
						Statement.RETURN_GENERATED_KEYS)) {
			prepareStatement.setString(1, koId);
			ResultSet resultSet = prepareStatement.executeQuery();
			while (resultSet.next()) {
				String dbKoId = resultSet.getString(1);
				koList.add(dbKoId);
			}
			log.info("List of KO's found in db: " + koList.size());
		} catch (SQLException ex) {
			log.error(ex.getMessage());
		}
		return koList;
	}

	private  List<String> findTicketInIncKoLinkPostgres(final String incidentId) {
		List<String> incList = new ArrayList<>();
		final StringBuffer sqlQuery = new StringBuffer(
				"select \"incident_id\" from incident_ko_link_mongo where \"incident_id\"=?");
		try (Connection dbcon = getPostgresDbConnection();
				PreparedStatement prepareStatement = dbcon.prepareStatement(sqlQuery.toString(),
						Statement.RETURN_GENERATED_KEYS)) {
			prepareStatement.setString(1, incidentId);

			ResultSet resultSet = prepareStatement.executeQuery();
			while (resultSet.next()) {
				String dbIncId = resultSet.getString(1);
				incList.add(dbIncId);
			}
			log.info("List of Incidents found in db: " + incList.size());
		} catch (SQLException ex) {
			log.error(ex.getMessage());
		}
		return incList;
	}

	private  PostgresTicketDataBean findTicketInTicketDataHistoryPostgres(final String incidentId) {

		PostgresTicketDataBean postgresTicketBean = null;

		final StringBuffer sqlQuery = new StringBuffer(
				"select \"Incident_id\",\"Assigned_Group\",\"App_Name\",\"Status\",\"Summary\",\"Inc_text\" from ticket_data_history_mongo where \"Incident_id\"=?");
		try (Connection dbcon = getPostgresDbConnection();
				PreparedStatement prepareStatement = dbcon.prepareStatement(sqlQuery.toString(),
						Statement.RETURN_GENERATED_KEYS)) {
			prepareStatement.setString(1, incidentId);

			ResultSet resultSet = prepareStatement.executeQuery();
			while (resultSet.next()) {
				postgresTicketBean = new PostgresTicketDataBean();
				postgresTicketBean.setIncident_id(resultSet.getString(1));
				postgresTicketBean.setAssigned_Group(resultSet.getString(2));
				postgresTicketBean.setApp_Name(resultSet.getString(3));
				postgresTicketBean.setStatus(resultSet.getString(4));
				postgresTicketBean.setSummary(resultSet.getString(5));
				postgresTicketBean.setInc_text(resultSet.getString(6));
			}

		} catch (SQLException ex) {
			log.error(ex.getMessage());
		}
		if (postgresTicketBean == null) {
			log.info("Ticket does not exist in ticket data history with ticketid: " + incidentId);
			return null;
		} else {
			return postgresTicketBean;
		}
	}

	/**
	 * Insert generic data.
	 *
	 * @param koInfoBean the ko info bean
	 * @throws UnsupportedEncodingException
	 */
	public  void insertGenericData(KOInfoBean koInfoBean) throws UnsupportedEncodingException {
		insertGenericKo(koInfoBean);
	}

	/**
	 * Update generic data.
	 *
	 * @param koInfoBean the ko info bean
	 * @param getKoStage the get ko stage
	 * @throws UnsupportedEncodingException
	 */
	public  void updateGenericData(KOInfoBean koInfoBean, String getKoStage) throws UnsupportedEncodingException {

		List<String> getvalue_inter = findKoInKoDetailInterPostgres(koInfoBean.getKoID());

		if (getvalue_inter.size() > 0) {
			updateGenericKo(koInfoBean, getKoStage);
			return;
		} else {
			insertGenericKo(koInfoBean);
		}

	}

	private  void insertGenericKo(KOInfoBean koInfo) {

		String koId = koInfo.getKoID();
		String appName = koInfo.getApplicationName();
		String koText = koInfo.getShortDescription() + " " + koInfo.getLongDescription() + " " + koInfo.getSymptoms()
				+ " " + koInfo.getResolution();
		String publicationStatus = koInfo.getKoStage();
		String summary = koInfo.getShortDescription() + " " + koInfo.getLongDescription();
		String ticketGroup = " ";
		Integer bplId = koInfo.getBusinessProcessLevelid();
		//String koType = "Generic";
		Integer koStatus = 1;

		final StringBuffer sqlQuery = new StringBuffer(
				"INSERT INTO ko_detail_inter_mongo(\"Ko_id\",\"Ko_text\",\"Summary\",\"App_name\",\"Ticket_group\",\"Ko_status\",\"Publication_status\",\"Bpl_id\")");
		sqlQuery.append(" VALUES(?,?,?,?,?,?,?,?)");

		try (Connection dbcon = getPostgresDbConnection();
				PreparedStatement prepareStatement = dbcon.prepareStatement(sqlQuery.toString(),
						Statement.RETURN_GENERATED_KEYS)) {
			prepareStatement.setString(1, koId);
			prepareStatement.setString(2, koText);
			prepareStatement.setString(3, summary);
			prepareStatement.setString(4, appName);
			prepareStatement.setString(5, ticketGroup);
			prepareStatement.setString(6, koStatus.toString());
			prepareStatement.setString(7, publicationStatus);
			prepareStatement.setInt(8, bplId);
		//	prepareStatement.setString(9, koType);

			int rowsAffected = prepareStatement.executeUpdate();

			if (rowsAffected > 0) {
				log.info("Generic KO inserted successfully into postgres: " + koId);
			}
		} catch (SQLException ex) {
			log.error(ex.getMessage());
		}
	}

	private  void updateGenericKo(KOInfoBean koInfo, String getKoStage) {

		String koId = koInfo.getKoID();
		String appName = koInfo.getApplicationName();
		String koText = koInfo.getShortDescription() + " " + koInfo.getLongDescription() + " " + koInfo.getSymptoms()
				+ " " + koInfo.getResolution();
		String publicationStatus = getKoStage;
		String summary = koInfo.getShortDescription() + " " + koInfo.getLongDescription();
		String ticketGroup = " ";
		Integer bplId = koInfo.getBusinessProcessLevelid();
		//String koType = "Generic";
		Integer koStatus = 1;

		StringBuffer sqlQuery = new StringBuffer(
				"update ko_detail_inter_mongo set \"Ko_text\"=?,\"Summary\"=?,\"App_name\"=?,\"Ticket_group\"=?,\"Publication_status\"=?,\"Ko_status\"=?,\"Bpl_id\"=?");
		sqlQuery.append(" where \"Ko_id\"=?");

		try (Connection dbcon = getPostgresDbConnection();
				PreparedStatement prepareStatement = dbcon.prepareStatement(sqlQuery.toString(),
						Statement.RETURN_GENERATED_KEYS)) {
			prepareStatement.setString(1, koText);
			prepareStatement.setString(2, summary);
			prepareStatement.setString(3, appName);
			prepareStatement.setString(4, ticketGroup);
			prepareStatement.setString(5, publicationStatus);
			prepareStatement.setString(6, koStatus.toString());
			prepareStatement.setString(7, bplId.toString());
			//prepareStatement.setString(8, koType);
			prepareStatement.setString(9, koId);

			int rowsAffected = prepareStatement.executeUpdate();

			if (rowsAffected > 0) {
				log.info("Existing Generic KO successfully updated into postgres: " + koId);
			}
		} catch (SQLException ex) {
			log.error(ex.getMessage());
		}

	}

	/**
	 * check Null.
	 *
	 * @param obj the obj
	 * @return Object obj
	 */
	private  String checkNull(String obj) {
		return Objects.nonNull(obj) ? obj : "";
	}

}
