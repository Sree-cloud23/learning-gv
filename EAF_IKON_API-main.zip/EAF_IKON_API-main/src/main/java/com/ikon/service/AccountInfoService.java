package com.ikon.service;

import java.util.List;

import com.ikon.model.AccountInfo;

// TODO: Auto-generated Javadoc
/**
 * The Interface AccountInfoService.
 */
public interface AccountInfoService {
	  
  	/**
  	 * Find all.
  	 *
  	 * @return the list
  	 */
  	public List<AccountInfo> findAll();
	  
  	/**
  	 * Gets the account name by account id.
  	 *
  	 * @param accountId the account id
  	 * @return the account name by account id
  	 */
  	public AccountInfo getAccountNameByAccountId(String accountId);
  	
  	/**
	   * Gets the displaypage.
	   *
	   * @param accountID the account ID
	   * @return the displaypage
	   */
	  public int getDisplaypage(int accountID);
  	 
  	/**
	   * Gets the KO enabled status.
	   *
	   * @param accountID the account ID
	   * @return the KO enabled status
	   */
	  public int getKOEnabledStatus(int accountID);
}
