package com.ikon.service;

import java.util.List;

import com.ikon.model.RoleMaster;

/**
 * The Interface RoleMasterService.
 */
public interface RoleMasterService {
    
    /**
     * Find all.
     *
     * @return the list
     */
    public List<RoleMaster> findAll();
}
