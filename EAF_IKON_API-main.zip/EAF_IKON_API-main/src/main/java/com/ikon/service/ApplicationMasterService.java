package com.ikon.service;

import java.util.List;
import java.util.Set;

import com.ikon.model.ApplicationMaster;

/**
 * The Interface ApplicationMasterService.
 */
public interface ApplicationMasterService {
    
    /**
     * Find all.
     *
     * @return the list
     */
    public List<ApplicationMaster> findAll();

	/**
	 * Gets the all application name.
	 *
	 * @param userId the user id
	 * @param accountId the account id
	 * @return the all application name
	 */
	Set<String> getAllApplicationName(String userId, String accountId);
	
	/**
	 * Gets the all assignment group.
	 *
	 * @param userId the user id
	 * @param accountId the account id
	 * @return the all assignment group
	 */
	Set<String> getAllAssignmentGroup(String userId, String accountId);
	
	/**
	 * Gets the all tower.
	 *
	 * @param userId the user id
	 * @param accountId the account id
	 * @return the all tower
	 */
	Set<String> getAllTower(String userId, String accountId);
	
	/**
	 * Gets the all CC.
	 *
	 * @param userId the user id
	 * @param accountId the account id
	 * @return the all CC
	 */
	Set<String> getAllCC(String userId, String accountId);
	
	/**
	 * Gets the all cluster.
	 *
	 * @param userId the user id
	 * @param accountId the account id
	 * @return the all cluster
	 */
	Set<String> getAllCluster(String userId, String accountId);

	/**
	 * Gets the filters data.
	 *
	 * @param defaultAccountId the default account id
	 * @param userId the user id
	 * @return the filters data
	 */
	public List<ApplicationMaster> getFiltersData(String defaultAccountId, String userId);
}
