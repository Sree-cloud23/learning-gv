package com.ikon.service;
import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.ikon.model.RoleMaster;
import com.ikon.repository.RoleMasterRepository;

/**
 * The Class RoleMasterServiceImpl.
 */
@Service
public class RoleMasterServiceImpl implements RoleMasterService {
	
    /** The role master repository. */
    @Inject
    private transient  RoleMasterRepository roleMasterRepository;
    
    /**
     * Find all.
     *
     * @return the list
     */
    @Override
    public List<RoleMaster> findAll() {
    	return roleMasterRepository.findAll();
    }
	
}
