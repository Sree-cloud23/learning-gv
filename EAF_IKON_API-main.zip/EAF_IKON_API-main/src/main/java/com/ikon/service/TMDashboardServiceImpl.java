package com.ikon.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Service;

import com.ikon.dto.AgeingWorkinfoBean;
import com.ikon.dto.ComplianceBean;
import com.ikon.dto.DashboardBean;
import com.ikon.dto.KOMetricsBean;
import com.ikon.dto.MasterDataAttributeVO;
import com.ikon.model.TicketDataHistory;
import com.ikon.model.UserAccountApplicationMapping;
import com.ikon.repository.AccountInfoRepository;
import com.ikon.repository.TicketDataHistoryRepository;
import com.ikon.repository.UserAccountAppRepository;
import com.ikon.validator.IKONUtils;

/**
 * The Class TMDashboardServiceImpl.
 */
@Service
public class TMDashboardServiceImpl implements TMDashboardService {

	/** The entity manager. */
	@PersistenceContext
	private  EntityManager entityManager;
	
	/** The ticket data history repository. */
	@Inject
	public transient TicketDataHistoryRepository ticketDataHistoryRepository;
	 
 	/** The Constant USER_ID_STRING. */
 	private static final String USER_ID_STRING = "userId";

 	/** The Constant ACCOUNT_NAME_STRING. */
 	private static final String ACCOUNT_NAME_STRING = "accountName";

 	/** The Constant ASSIGNMENT_GROUP_STRING. */
 	private static final String ASSIGNMENT_GROUP_STRING = "assignmentGroup";

 	/** The Constant APPLICATION_NAME_STRING. */
 	private static final String APPLICATION_NAME_STRING = "applicationName";

 	/** The Constant ASSIGNEE_NAME_STRING. */
 	private static final String ASSIGNEE_NAME_STRING = "assigneeName";

 	/** The Constant FROM_DATE_STRING. */
 	private static final String FROM_DATE_STRING = "fromDate";

 	/** The Constant TO_DATE_STRING. */
 	private static final String TO_DATE_STRING = "toDate";

	/**
	 * Find all.
	 *
	 * @return the list
	 */
	@Override
	public List<TicketDataHistory> findAll() {
		return ticketDataHistoryRepository.findAll();
	}

	/** The user account app repository. */
	@Inject
	public transient UserAccountAppRepository userAccountAppRepository;
	
	/** The account info repository. */
	@Inject
	public transient AccountInfoRepository accountInfoRepository;

	/** The access control service. */
	@Inject
	public transient AccessControlService accessControlService;

	/** The account info service. */
	@Inject
	public transient AccountInfoService accountInfoService;

	/**
	 * Gets the TM dashboard data.
	 *
	 * @param userId the user id
	 * @param accountId the account id
	 * @return the TM dashboard data
	 */
	@Override
	@Transactional
	public List<DashboardBean> getTMDashboardData(String userId, String accountId) {
		List<DashboardBean> ticketDataBeanList = null;
		Session session =entityManager.unwrap( Session.class );
			Query query = session.createSQLQuery("select * from fun_dashboard_view(:userId,:accountId)")
					.setResultTransformer(Transformers.aliasToBean(DashboardBean.class));
			query.setParameter(USER_ID_STRING, userId);
			query.setParameter("accountId", accountId);
			ticketDataBeanList = query.list();
		return ticketDataBeanList;
	}

	/**
	 * Gets the all TL inciedents dashboard data.
	 *
	 * @param masterDataAttributeVO the master data attribute VO
	 * @param assigneeNameLists the assignee name lists
	 * @return the all TL inciedents dashboard data
	 */
	@Override
	@Transactional
	public List<DashboardBean> getAllTLInciedentsDashboardData(MasterDataAttributeVO masterDataAttributeVO, String assigneeNameLists) {
		List<DashboardBean> allOpenIncidents = null;
		Session session = entityManager.unwrap( Session.class );
			Query query = session
					.createSQLQuery(
							"select * from fun_tl_total_incidents_dashboard(:userId,:accountName,:assignmentGroup,:applicationName,:assigneeName)")
					.setResultTransformer(Transformers.aliasToBean(DashboardBean.class));
			query.setString(USER_ID_STRING, masterDataAttributeVO.getUserId());
			query.setString(ACCOUNT_NAME_STRING, masterDataAttributeVO.getAccountName());
			query.setString(ASSIGNMENT_GROUP_STRING, masterDataAttributeVO.getAssignmentGroup());
			query.setString(APPLICATION_NAME_STRING, masterDataAttributeVO.getAppName());
			query.setString(ASSIGNEE_NAME_STRING, assigneeNameLists);
			allOpenIncidents = query.list();
			return allOpenIncidents;
	}

	/**
	 * Gets the all TL run to zero data.
	 *
	 * @param masterDataAttributeVO the master data attribute VO
	 * @param assigneeNameLists the assignee name lists
	 * @return the all TL run to zero data
	 */
	@Override
	@Transactional
	public List<DashboardBean> getAllTLRunToZeroData(MasterDataAttributeVO masterDataAttributeVO, String assigneeNameLists) {

		List<DashboardBean> allrunToZeroData = null;
		Session session = entityManager.unwrap( Session.class );
			Query query = session
					.createSQLQuery(
							"select * from fun_tl_runto_zero_dashboard(:userId,:accountName,:assignmentGroup,:applicationName,:assigneeName)")
					.setResultTransformer(Transformers.aliasToBean(DashboardBean.class));
			query.setString(USER_ID_STRING, masterDataAttributeVO.getUserId());
			query.setString(ACCOUNT_NAME_STRING, masterDataAttributeVO.getAccountName());
			query.setString(ASSIGNMENT_GROUP_STRING, masterDataAttributeVO.getAssignmentGroup());
			query.setString(APPLICATION_NAME_STRING, masterDataAttributeVO.getAppName());
			query.setString(ASSIGNEE_NAME_STRING, assigneeNameLists);
			allrunToZeroData = query.list();
			return allrunToZeroData;
	}

	/**
	 * Gets the all TL ko status data.
	 *
	 * @param masterDataAttributeVO the master data attribute VO
	 * @param assigneeNameLists the assignee name lists
	 * @return the all TL ko status data
	 */
	@Override
	@Transactional
	public List<DashboardBean> getAllTLKoStatusData(MasterDataAttributeVO masterDataAttributeVO, String assigneeNameLists) {

		List<DashboardBean> allkoStatusList = null;
		Session session=entityManager.unwrap( Session.class );
			Query query = session
					.createSQLQuery(
							"select * from fun_tl_ko_status_dashboard(:userId,:accountName,:assignmentGroup,:applicationName,:assigneeName)")
					.setResultTransformer(Transformers.aliasToBean(DashboardBean.class));
			query.setString(USER_ID_STRING, masterDataAttributeVO.getUserId());
			query.setString(ACCOUNT_NAME_STRING, masterDataAttributeVO.getAccountName());
			query.setString(ASSIGNMENT_GROUP_STRING, masterDataAttributeVO.getAssignmentGroup());
			query.setString(APPLICATION_NAME_STRING, masterDataAttributeVO.getAppName());
			query.setString(ASSIGNEE_NAME_STRING, assigneeNameLists);
			allkoStatusList = query.list();

			return allkoStatusList;
	}

	/**
	 * Gets the all assignee name.
	 *
	 * @param assGroupp the ass groupp
	 * @param appNamess the app namess
	 * @param userId the user id
	 * @return the all assignee name
	 */
	@Override
	public Set<String> getAllAssigneeName(Set<String> assGroupp, Set<String> appNamess, String userId) {
		List<UserAccountApplicationMapping> userAccAppDataBeanList = userAccountAppRepository.findAll();
		Set<String> assigneeNameList = new HashSet<String>();
		userAccAppDataBeanList.forEach(assname-> {
			Set<String> assGroup = new TreeSet<String>(String.CASE_INSENSITIVE_ORDER);
			assGroup = assGroupp;
			Set<String> appNames = new TreeSet<String>(String.CASE_INSENSITIVE_ORDER);
			appNames = appNamess;
			if (assGroup.contains(String.valueOf(assname.getAssignmentGroup()))
					&& appNames.contains(String.valueOf(assname.getApplicationName()))
					&& !IKONUtils.isNullOrEmpty(assname.getAssigneeName())) {
				assigneeNameList.add(assname.getAssigneeName());
			}
		});
		return assigneeNameList;

	}

	/**
	 * Gets the leader board data.
	 *
	 * @param accountName the account name
	 * @return the leader board data
	 */
	@Override
	@Transactional
	public List<DashboardBean> getLeaderBoardData(String accountName) {
		List<DashboardBean> leaderBoardDataBeanList = null;
		Session session = entityManager.unwrap( Session.class );
			Query query = session
					.createSQLQuery("select * from fun_leaderboard(:accountName)")
					.setResultTransformer(Transformers.aliasToBean(DashboardBean.class));
			query.setParameter(ACCOUNT_NAME_STRING, accountName);
			
			leaderBoardDataBeanList = query.list();
			 return leaderBoardDataBeanList;
	}

	/**
	 * Gets the top analyst data.
	 *
	 * @param accountName the account name
	 * @return the top analyst data
	 */
	@Override
	@Transactional
	public List<DashboardBean> getTopAnalystData(String accountName) {
		List<DashboardBean> topAnalystData = null;
		Session session = entityManager.unwrap( Session.class );
			Query query = session
					.createSQLQuery("select * from fun_top_analyst(:accountName)")
					.setResultTransformer(Transformers.aliasToBean(DashboardBean.class));

			query.setParameter(ACCOUNT_NAME_STRING, accountName);
			
			topAnalystData = query.list();
			 return topAnalystData;
	}

	/**
	 * Gets the top reviewer data.
	 *
	 * @param accountName the account name
	 * @return the top reviewer data
	 */
	@Override
	@Transactional
	public List<DashboardBean> getTopReviewerData(String accountName) {
		List<DashboardBean> topReviewerData = null;
		Session session = entityManager.unwrap( Session.class );
			Query query = session.createSQLQuery(
							"select * from fun_top_reviewer(:accountName)")
					.setResultTransformer(Transformers.aliasToBean(DashboardBean.class));

			query.setParameter(ACCOUNT_NAME_STRING, accountName);
			
			topReviewerData = query.list();
			return topReviewerData;
	}

	/**
	 * Gets the top contributor data.
	 *
	 * @param accountName the account name
	 * @return the top contributor data
	 */
	@Override
	@Transactional
	public List<DashboardBean> getTopContributorData(String accountName) {
		List<DashboardBean> topContributorData = null;
		Session session= entityManager.unwrap( Session.class );
			Query query = session
					.createSQLQuery(
							"select * from fun_top_contributor(:accountName)")
					.setResultTransformer(Transformers.aliasToBean(DashboardBean.class));

			query.setParameter(ACCOUNT_NAME_STRING, accountName);
			
			topContributorData = query.list();
			return topContributorData;
	}

	/**
	 * Gets the KO inc link count TL.
	 *
	 * @param masterDataAttributeVO the master data attribute VO
	 * @param assigneeNameLists the assignee name lists
	 * @return the KO inc link count TL
	 */
	@Override
	@Transactional
	public List<DashboardBean> getKOIncLinkCountTL(MasterDataAttributeVO masterDataAttributeVO, String assigneeNameLists) {
		List<DashboardBean> koIncLinkCount = null;
		Session session = entityManager.unwrap( Session.class );
			Query query = session
					.createSQLQuery(
							"select * from fun_tl_ko_linked_count(:userId,:accountName,:assignmentGroup,:applicationName,:assigneeName)")
					.setResultTransformer(Transformers.aliasToBean(DashboardBean.class));
			query.setString(USER_ID_STRING, masterDataAttributeVO.getUserId());
			query.setString(ACCOUNT_NAME_STRING, masterDataAttributeVO.getAccountName());
			query.setString(ASSIGNMENT_GROUP_STRING, masterDataAttributeVO.getAssignmentGroup());
			query.setString(APPLICATION_NAME_STRING, masterDataAttributeVO.getAppName());
			query.setString(ASSIGNEE_NAME_STRING, assigneeNameLists);
			koIncLinkCount = query.list();
			return koIncLinkCount;
	}
	
	
	/**
	 * Gets the mttr avg hours per mon.
	 *
	 * @param fromDate the from date
	 * @param toDate the to date
	 * @return the mttr avg hours per mon
	 */
	@Override
	@Transactional
	public List<DashboardBean> getMttrAvgHoursPerMon(String fromDate, String toDate) {
		List<DashboardBean> mttrAvgHrs = null;
		Session session = entityManager.unwrap( Session.class );
			Query query = session.createSQLQuery("select * from fun_mttr_all_incidents(:fromDate, :toDate)")
					.setResultTransformer(Transformers.aliasToBean(DashboardBean.class));
			query.setParameter(FROM_DATE_STRING, fromDate);
			query.setParameter(TO_DATE_STRING, toDate);
			mttrAvgHrs = query.list();
			session.clear();
		return mttrAvgHrs;
	}

	/**
	 * Gets the mttr by priority.
	 *
	 * @param fromDate the from date
	 * @param toDate the to date
	 * @return the mttr by priority
	 */
	@Override
	@Transactional
	public List<DashboardBean> getMttrByPriority(String fromDate, String toDate) {
		List<DashboardBean> mttrByPriority = null;
		Session session = entityManager.unwrap( Session.class );
			Query query = session.createSQLQuery("select * from fun_mttr_priority(:fromDate, :toDate)")
					.setResultTransformer(Transformers.aliasToBean(DashboardBean.class));
			query.setParameter(FROM_DATE_STRING, fromDate);
			query.setParameter(TO_DATE_STRING, toDate);
			mttrByPriority = query.list();
		return mttrByPriority;
	}

	/**
	 * Gets the mttr report.
	 *
	 * @param fromDate the from date
	 * @param toDate the to date
	 * @return the mttr report
	 */
	@Override
	@Transactional
	public List<DashboardBean> getMttrReport(String fromDate, String toDate) {
		List<DashboardBean> mttrAvgHrs = null;
		Session session = entityManager.unwrap( Session.class );
			Query query = session.createSQLQuery("select * from fun_mttr_all_incidents_report(:fromDate, :toDate)")
					.setResultTransformer(Transformers.aliasToBean(DashboardBean.class));
			query.setParameter(FROM_DATE_STRING, fromDate);
			query.setParameter(TO_DATE_STRING, toDate);
			mttrAvgHrs = query.list();
			session.clear();
		return mttrAvgHrs;
	}

	/**
	 * Gets the MTTR report by priority.
	 *
	 * @param fromDate the from date
	 * @param toDate the to date
	 * @return the mttr report by priority
	 */
	@Override
	@Transactional
	public List<DashboardBean> getMttrReportByPriority(String fromDate, String toDate) {
		List<DashboardBean> mttrByPriority = null;
		Session session = entityManager.unwrap( Session.class );
			Query query = session.createSQLQuery("select * from fun_mttr_priority_report(:fromDate, :toDate)")
					.setResultTransformer(Transformers.aliasToBean(DashboardBean.class));
			query.setParameter(FROM_DATE_STRING, fromDate);
			query.setParameter(TO_DATE_STRING, toDate);
			mttrByPriority = query.list();
			session.clear();
		return mttrByPriority;
	}

	/**
	 * 
	 * @param fromDate
	 * @param toDate
	 * @return
	 */
	@Override
	@Transactional
	public List<ComplianceBean> getComplianceReport(String fromDate, String toDate) {
		List<ComplianceBean> complianceList = new ArrayList<ComplianceBean>();
		Session session = entityManager.unwrap( Session.class );
		Query query = session.createSQLQuery("select * from fun_compliance_report_new(:fromDate, :toDate)")
				.setResultTransformer(Transformers.aliasToBean(ComplianceBean.class));
		query.setParameter(FROM_DATE_STRING, fromDate);
		query.setParameter(TO_DATE_STRING, toDate);
		complianceList = query.list();
		return complianceList;
	}

	@Override
	@Transactional
	public List<KOMetricsBean> getKOMetricsChart(MasterDataAttributeVO masterDataAttributeVO, String freq) {
		List<KOMetricsBean> koMetricsList = new ArrayList<KOMetricsBean>();
		Session session = entityManager.unwrap( Session.class );
		Query query = session.createSQLQuery("select * from fun_ko_metrics_chart(:accid,:frmdate, :todate,:tower,:cc, :cluster,:appsname,:assgngrp,:freq,:userId)")
				.setResultTransformer(Transformers.aliasToBean(KOMetricsBean.class));
		query.setString("accid", masterDataAttributeVO.getAccId());
		query.setString("frmdate", masterDataAttributeVO.getFromDate());
		query.setString("todate", masterDataAttributeVO.getToDate());
		query.setString("tower", masterDataAttributeVO.getTower());
		query.setString("cc", masterDataAttributeVO.getCc());
		query.setString("cluster", masterDataAttributeVO.getCluster());
		query.setString("appsname", masterDataAttributeVO.getAppName());
		query.setString("assgngrp", masterDataAttributeVO.getAssignmentGroup());
		query.setString("freq", freq);
		query.setString("userId", masterDataAttributeVO.getUserId());
		koMetricsList = query.list();
		return koMetricsList;
	}

	/**
	 * Gets the ageing workinfo report.
	 *
	 * @param masterDataAttributeVO the master data attribute VO
	 * @return the ageing workinfo report
	 */
	@Override
	@Transactional
	public List<AgeingWorkinfoBean> getAgeingWorkinfoReport(MasterDataAttributeVO masterDataAttributeVO) {
		List<AgeingWorkinfoBean> ageingList = new ArrayList<AgeingWorkinfoBean>();
		Session session = entityManager.unwrap( Session.class );
		Query query = session.createSQLQuery("SELECT * from fun_ageing_workinfo_report(:frmdate, :todate);")
				.setResultTransformer(Transformers.aliasToBean(AgeingWorkinfoBean.class));
		query.setString("frmdate", masterDataAttributeVO.getFromDate());
		query.setString("todate", masterDataAttributeVO.getToDate());
		ageingList = query.list();
		return ageingList;
	}

	/**
	 * Gets the ageing workinfo report detail.
	 *
	 * @param masterDataAttributeVO the master data attribute VO
	 * @return the ageing workinfo report detail
	 */
	@Override
	@Transactional
	public List<AgeingWorkinfoBean> getAgeingWorkinfoReportDetail(MasterDataAttributeVO masterDataAttributeVO) {
		List<AgeingWorkinfoBean> ageingDetailList = new ArrayList<AgeingWorkinfoBean>();
		Session session = entityManager.unwrap( Session.class );
		Query query = session.createSQLQuery("SELECT * from fun_ageing_workinfo_report_detail(:tower,:cc, :cluster,:frmdate, :todate);")
				.setResultTransformer(Transformers.aliasToBean(AgeingWorkinfoBean.class));
		query.setString("tower", masterDataAttributeVO.getTower());
		query.setString("cc", masterDataAttributeVO.getCc());
		query.setString("cluster", masterDataAttributeVO.getCluster());
		query.setString("frmdate", masterDataAttributeVO.getFromDate());
		query.setString("todate", masterDataAttributeVO.getToDate());
		
		ageingDetailList = query.list();
		return ageingDetailList;
	}
	
}
