
package com.ikon.service;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;
import org.springframework.web.multipart.MultipartFile;
import com.ikon.dto.ComplianceBean;
import com.ikon.dto.KOInfoBean;
import com.ikon.dto.KOMetricsBean;
import com.ikon.dto.KOReviewerBean;
import com.ikon.dto.KoDataAttributeVO;
import com.ikon.dto.MasterDataAttributeVO;
import com.ikon.dto.TicketDataAttributeVO;
import com.ikon.model.BusinessProcessMaster;
import com.ikon.model.KOInfo;

/**
 * The Interface KOInfoService.
 */
public interface KOInfoService {

	/**
	 * Kolistview SP.
	 *
	 * @param KoAttrVo the ko attr vo
	 * @return the list
	 */
	List<KOInfoBean> kolistviewSP(KoDataAttributeVO KoAttrVo);

	/**
	 * Kopubgraph SP.
	 *
	 * @param KoAttrVo the ko attr vo
	 * @return the list
	 */
	List<KOInfoBean> kopubgraphSP(KoDataAttributeVO KoAttrVo);

	/**
	 * Show all related K os.
	 *
	 * @param ticketID the ticket ID
	 * @return the list
	 */
	List<KOInfoBean> showAllRelatedKOs(String ticketID);

	/**
	 * Gets the all created by names.
	 *
	 * @param userId    the user id
	 * @param accountId the account id
	 * @return the all created by names
	 */
	public Set<String> getAllCreatedByNames(String userId, String accountId);

	/**
	 * Gets the all publication status.
	 *
	 * @param koInfoBean the ko info bean
	 * @return the all publication status
	 */
	public Set<String> getAllPublicationStatus(KOInfoBean koInfoBean);

	/**
	 * Insert KO detail.
	 *
	 * @param koInfoBean the ko info bean
	 * @param files      the files
	 * @return the list
	 * @throws IllegalAccessException the illegal access exception
	 */
	List<KOInfoBean> insertKODetail(KOInfoBean koInfoBean, MultipartFile[] files)
			throws IllegalAccessException;

	/**
	 * Edits the KO detail.
	 *
	 * @param koId the ko id
	 * @return the list
	 */
	List<KOInfoBean> editKODetail(String koId);

	/**
	 * Update KO detail.
	 *
	 * @param koInfoBean the ko info bean
	 * @param files      the files
	 * @param userId     the user id
	 * @return the string
	 */
	String updateKODetail(KOInfoBean koInfoBean, MultipartFile[] files, String userId);

	/**
	 * Populate inc appdetails.
	 *
	 * @param linkedincident the linkedincident
	 * @param moduleName the module name
	 * @return the KO info bean
	 */
	KOInfoBean populateIncAppdetails(final String linkedincident, final String moduleName);

	/**
	 * Retrieve review comments.
	 *
	 * @param koId the ko id
	 * @return the list
	 */
	List<KOInfoBean> retrieveReviewComments(String koId);

	/**
	 * Insert review comment.
	 *
	 * @param koInfoBean the ko info bean
	 * @return the list
	 */
	List<KOInfoBean> insertReviewComment(KOInfoBean koInfoBean);

	/**
	 * Delete review comment.
	 *
	 * @param reviewID the review ID
	 * @return the list
	 */
	List<KOInfoBean> deleteReviewComment(int reviewID);

	/**
	 * Update review comment.
	 *
	 * @param reviewId the review id
	 * @param checkVal the check val
	 * @return the string
	 */
	String updateReviewComment(String reviewId, int checkVal);
	
	/**
	 * Gets the all reviewed by names.
	 *
	 * @param userId    the user id
	 * @param accountId the account id
	 * @return the all reviewed by names
	 */
	public Set<String> getAllReviewedByNames(String userId, String accountId);

	/**
	 * Ko approval cycle list SP.
	 *
	 * @param koDtAttrVO the ko dt attr VO
	 * @return the list
	 */
	List<KOInfoBean> koApprovalCycleListSP(KoDataAttributeVO koDtAttrVO);

	/**
	 * Ko created graph SP.
	 *
	 * @param KoAttrVo the ko attr vo
	 * @return the list
	 */
	List<KOInfoBean> koCreatedGraphSP(KoDataAttributeVO KoAttrVo);

	/**
	 * Ko usage graph SP.
	 *
	 * @param KoAttrVo the ko attr vo
	 * @return the list
	 */
	List<KOInfoBean> koUsageGraphSP(KoDataAttributeVO KoAttrVo);

	/**
	 * Ko linkage graph SP.
	 *
	 * @param KoAttrVo the ko attr vo
	 * @return the list
	 */
	List<KOInfoBean> koLinkageGraphSP(KoDataAttributeVO KoAttrVo);

	/**
	 * Koavaldist SP.
	 *
	 * @param masterDataAttributeVO the master data attribute VO
	 * @return the list
	 */
	List<KOInfoBean> koavaldistSP(MasterDataAttributeVO masterDataAttributeVO);

	/**
	 * Inclinked.
	 * Incidents linked to KOs distribution chart
	 *
	 * @param masterDataAttributeVO the master data attribute VO
	 * @return the list
	 */
	List<KOInfoBean> inclinked(MasterDataAttributeVO masterDataAttributeVO);

	/**
	 * Sendmailtoreviewer.
	 *
	 * @param var_ko          the var ko
	 * @param createactionval the createactionval
	 */
	void sendmailtoreviewer(String var_ko, String createactionval);

	/**
	 * Ko usage report SP.
	 * for ko_usage report
	 *
	 * @param masterDataAttributeVO the master data attribute VO
	 * @param integer the integer
	 * @return the list
	 */
	List<KOInfoBean> koUsageReportSP(MasterDataAttributeVO masterDataAttributeVO, Integer integer);

	/**
	 * Linkvsnotlinked.
	 * KO Linked vs Not Linked (Overall) chart
	 *
	 * @param masterDataAttributeVO the master data attribute VO
	 * @return the list
	 */
	List<KOInfoBean> linkvsnotlinked(MasterDataAttributeVO masterDataAttributeVO);

	/**
	 * Simple ticket search.
	 *
	 * @param tktDtAttrVO the tkt dt attr VO
	 * @return the list
	 */
	List<KOInfoBean> simpleTicketSearch(TicketDataAttributeVO tktDtAttrVO);

	/**
	 * Simple KO search.
	 *
	 * @param tktDtAttrVO the tkt dt attr VO
	 * @return the list
	 */
	List<KOInfoBean> simpleKOSearch(TicketDataAttributeVO tktDtAttrVO);

	/**
	 * Gets the KO reviewers by assignment group.
	 *
	 * @param masterDataAttributeVO the master data attribute VO
	 * @param i the i
	 * @return the KO reviewers by assignment group
	 */
	List<KOReviewerBean> getKOReviewersByAssignmentGroup(MasterDataAttributeVO masterDataAttributeVO, Integer i);

	/**
	 * Assign and email reviewer.
	 *
	 * @param var_ko         the var ko
	 * @param approverUserID the approver user ID
	 */
	void assignAndEmailReviewer(String var_ko, String approverUserID);

	/**
	 * Mttrchrt.
	 *
	 * @param masterDataAttributeVO the master data attribute VO
	 * @return the list
	 */
	List<KOInfoBean> mttrchrt(MasterDataAttributeVO masterDataAttributeVO);

	/**
	 * Update KO detail.
	 *
	 * @param koInfoBean the ko info bean
	 * @param files      the files
	 * @param userId     the user id
	 * @return the string
	 */
	String updateGenericKODetail(KOInfoBean koInfoBean, MultipartFile[] files, String userId);

	/**
	 * Find modules andlevels.
	 *
	 * @param loginusrname the loginusrname
	 * @return the list
	 */
	List<BusinessProcessMaster> findModulesAndlevels(String loginusrname);

	/**
	 * Upload file.
	 *
	 * @param files the files
	 * @param koInfoBean the ko info bean
	 * @return the list
	 */
	List<String> uploadModuleNamedFiles(MultipartFile[] files, KOInfoBean koInfoBean);

	/**
	 * Generic KO search.
	 *
	 * @param tktDtAttrVO the tkt dt attr VO
	 * @return the list
	 */
	List<KOInfoBean> genericKOSearch(TicketDataAttributeVO tktDtAttrVO);

	/**
	 * Ko staus update.
	 *
	 * @return the list
	 */
	List<KOInfoBean> koStausUpdate();

	/**
	 * Generic ko approval cycle list SP.
	 *
	 * @param koDtAttrVO the ko dt attr VO
	 * @return the list
	 */
	List<KOInfoBean> genericKoApprovalCycleListSP(KoDataAttributeVO koDtAttrVO);

	/**
	 * Insert generic KO detail.
	 *
	 * @param koInfoBean the ko info bean
	 * @param files the files
	 * @return the list
	 * @throws IllegalAccessException the illegal access exception
	 */
	List<KOInfoBean> insertGenericKODetail(KOInfoBean koInfoBean, MultipartFile[] files)
			throws IllegalAccessException;

	/**
	 * Retrieve GS review comments.
	 *
	 * @param koId the ko id
	 * @return the list
	 */
	List<KOInfoBean> retrieveGSReviewComments(String koId);

	/**
	 * Edits the generic KO detail.
	 *
	 * @param koId the ko id
	 * @param accountId the account id
	 * @return the list
	 */
	List<KOInfoBean> editGenericKODetail(String koId, String accountId);

	/**
	 * Kousagechrt.
	 *
	 * @param masterDataAttributeVO the master data attribute VO
	 * @return the list
	 */
	List<KOInfoBean> kousagechrt(MasterDataAttributeVO masterDataAttributeVO);

	/**
	 * Str concat.
	 *
	 * @param string1 the string 1
	 * @param string2 the string 2
	 * @return the string
	 */
	String strConcat(String string1, String string2);

	/**
	 * @param accountId the account id
	 * @return the List
	 */
	List<KOInfoBean> getAllKos(String accountId);
	
	/**
	 * Kousagechrt.
	 *
	 * @param masterDataAttributeVO the master data attribute VO
	 * @return the list
	 */
	List<ComplianceBean> compliancechart(MasterDataAttributeVO masterDataAttributeVO);
	/**
	 * koCreationRepo.
	 *
	 * @param fromdate and todate
	 * @return the list
	 */
	List<KOInfoBean> koCreationRepo(String frmDate, String todate);
	/**
	 * koMetricsRepo.
	 *
	 * @param fromdate and todate
	 * @return the list
	 */
	List<KOMetricsBean> koMetricsRepo(String frmDate, String todate);
}
