package com.ikon.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.inject.Inject;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.ikon.model.Role;
import com.ikon.repository.RoleRepository;

/**
 * The Class RoleServiceImpl.
 */
@Service
public class RoleServiceImpl implements RoleService {

	/** The role repository. */
	@Inject
	private transient RoleRepository roleRepository;

	/**
	 * Save.
	 *
	 * @param role the role
	 */
	@Override
	public void save(Role role) {
		roleRepository.save(role);

	}

	/**
	 * Find all.
	 *
	 * @return the list
	 */
	@Override
	@Transactional
	public List<Role> findAll() {

		List<Role> roleList = roleRepository.findAll();
		return roleList;
	}

	/**
	 * Find by id.
	 *
	 * @param id the id
	 * @return the role
	 */
	@Override
	public Role findById(Long id) {

		return roleRepository.findById(id).orElse(null);
	}

	/**
	 * Gets the all role names.
	 *
	 * @return the all role names
	 */
	@Override
	public List<String> getAllRoleNames() {
		List<Role> roleList = roleRepository.findAll();
		List<String> roleStrList = new ArrayList<>();
		for (Role role : roleList) {
			roleStrList.add(role.getRoleCategoryName());
		}
		return roleStrList;
	}

	/**
	 * Find role by role name.
	 *
	 * @param roleName the role name
	 * @return the role
	 */
	@Override
	public Role findRoleByRoleName(String roleName) {
		List<Role> roleList = roleRepository.findAll();
		if (Objects.nonNull(roleList)) {
			for (Role role : roleList) {
				if (Objects.nonNull(role) &&Objects.nonNull(role.getRoleCategoryName())
						&& role.getRoleCategoryName().equalsIgnoreCase(roleName)) {
					return role;
				}
			}
		}
		return new Role();
	}

}
