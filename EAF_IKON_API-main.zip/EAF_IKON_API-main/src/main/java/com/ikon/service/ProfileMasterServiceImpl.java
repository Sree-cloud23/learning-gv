package com.ikon.service;
import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.ikon.model.ProfileMaster;
import com.ikon.repository.ProfileMasterRepository;

/**
 * The Class ProfileMasterServiceImpl.
 */
@Service
public class ProfileMasterServiceImpl implements ProfileMasterService {
	
    /** The profile master repository. */
    @Inject
    private transient ProfileMasterRepository profileMasterRepository;
    
    /**
     * Find all.
     *
     * @return the list
     */
    @Override
    public List<ProfileMaster> findAll() {
    	return profileMasterRepository.findAll();
    }

	/**
	 * Find by id.
	 *
	 * @param id the id
	 * @return the profile master
	 */
	@Override
	public ProfileMaster findById(Long id) {
		return profileMasterRepository.findById(id).orElse(null);
	}
	
}
