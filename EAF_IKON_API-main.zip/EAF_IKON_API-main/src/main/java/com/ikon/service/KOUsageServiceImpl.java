package com.ikon.service;

import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ikon.dto.KOInfoBean;
import com.ikon.dto.MasterDataAttributeVO;
import com.ikon.model.KOUsage;
import com.ikon.repository.KOUsageRepository;

import lombok.extern.slf4j.Slf4j;

/**
 * The Class KOUsageServiceImpl.
 */
@Service
@Slf4j
public class KOUsageServiceImpl implements KOUsageService
{
	/** The entity manager. */
	@PersistenceContext
	private EntityManager entityManager;
	
	/** The k O usage repository. */
	@Inject
	private transient KOUsageRepository kOUsageRepository;
	
	
	/** The Constant LOGGER. */
 	//private static final Logger LOGGER = LogManager.getLogger(KOUsageServiceImpl.class);
	
	/**
	 * Find all.
	 *
	 * @return the list
	 */
	@Override
	public List<KOUsage> findAll() {
		List<KOUsage> automatinTrackingList = kOUsageRepository.findAll();
		return automatinTrackingList;
	}
	
	/**
	 * G KO creation report.
	 *
	 * @param masterDataAttributeVO the master data attribute VO
	 * @return the list
	 */
	@Override
	@Transactional
	public List<KOInfoBean> gKOCreationReport(MasterDataAttributeVO masterDataAttributeVO) {
		List<KOInfoBean> koCreationList = null;

		try {
			Session session = entityManager.unwrap(Session.class);
			Query query = session.createSQLQuery("select * from fun_ko_creation_report(:accountId, :fromDate, :toDate, :BnsProL1, :BnsProL2, :BnsProL3, :appName )")
					.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
			query.setString("accountId", masterDataAttributeVO.getAccId());
			query.setString("fromDate", masterDataAttributeVO.getFromDate());
			query.setString("toDate", masterDataAttributeVO.getToDate());
			query.setString("BnsProL1", masterDataAttributeVO.getLevel1());
			query.setString("BnsProL2", masterDataAttributeVO.getLevel2());
			query.setString("BnsProL3", masterDataAttributeVO.getLevel3());
			query.setString("appName", masterDataAttributeVO.getAppName());
			
			koCreationList = query.list();
			session.clear();
		} catch (HibernateException e) {
			log.error(e.getMessage());
		}
		return koCreationList;
	}
	
	/**
	 * G KO clone report.
	 *
	 * @param masterDataAttributeVO the master data attribute VO
	 * @return the list
	 */
	@Override
	@Transactional
	public List<KOInfoBean> gKOCloneReport(MasterDataAttributeVO masterDataAttributeVO) {
		List<KOInfoBean> koCreationList = null;

		try {
			Session session = entityManager.unwrap(Session.class);
			Query query = session.createSQLQuery("select * from fun_ko_cloned_report(:accountId, :fromDate, :toDate, :BnsProL1, :BnsProL2, :BnsProL3, :appName )")
					.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
			query.setString("accountId", masterDataAttributeVO.getAccId());
			query.setString("fromDate", masterDataAttributeVO.getFromDate());
			query.setString("toDate", masterDataAttributeVO.getToDate());
			query.setString("BnsProL1", masterDataAttributeVO.getLevel1());
			query.setString("BnsProL2", masterDataAttributeVO.getLevel2());
			query.setString("BnsProL3", masterDataAttributeVO.getLevel3());
			query.setString("appName", masterDataAttributeVO.getAppName());
			
			koCreationList = query.list();
			session.clear();
		} catch (HibernateException e) {
			log.error(e.getMessage());
		}
		return koCreationList;
	}
	
	/**
	 * Gtop performance report.
	 *
	 * @param masterDataAttributeVO the master data attribute VO
	 * @return the list
	 */
	@Override
	@Transactional
	public List<KOInfoBean> gtopPerformanceReport(MasterDataAttributeVO masterDataAttributeVO) {
		List<KOInfoBean> koCreationList = null;

		try {
			Session session = entityManager.unwrap(Session.class);
			Query query = session.createSQLQuery("select * from fun_top_performance_ko_report(:accountId, :fromDate, :toDate, :BnsProL1, :BnsProL2, :BnsProL3, :appName )")
					.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
			query.setString("accountId", masterDataAttributeVO.getAccId());
			query.setString("fromDate", masterDataAttributeVO.getFromDate());
			query.setString("toDate", masterDataAttributeVO.getToDate());
			query.setString("BnsProL1", masterDataAttributeVO.getLevel1());
			query.setString("BnsProL2", masterDataAttributeVO.getLevel2());
			query.setString("BnsProL3", masterDataAttributeVO.getLevel3());
			query.setString("appName", masterDataAttributeVO.getAppName());
			
			koCreationList = query.list();
			session.clear();
		} catch (HibernateException e) {
			log.error(e.getMessage());
		}
		return koCreationList;
	}

}
        
    