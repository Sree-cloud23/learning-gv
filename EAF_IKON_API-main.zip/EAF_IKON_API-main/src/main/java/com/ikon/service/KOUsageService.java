package com.ikon.service;

import java.util.List;

import com.ikon.dto.KOInfoBean;
import com.ikon.dto.MasterDataAttributeVO;
import com.ikon.model.KOUsage;

// TODO: Auto-generated Javadoc
/**
 * The Interface KOUsageService.
 */
public interface KOUsageService 
{
	
	/**
	 * Find all.
	 *
	 * @return the list
	 */
	public List<KOUsage> findAll();
	
	/**
	 * G KO creation report.
	 *
	 * @param masterDataAttributeVO the master data attribute VO
	 * @return the list
	 */
	List<KOInfoBean> gKOCreationReport(MasterDataAttributeVO masterDataAttributeVO);


	/**
	 * G KO clone report.
	 *
	 * @param masterDataAttributeVO the master data attribute VO
	 * @return the list
	 */
	List<KOInfoBean> gKOCloneReport(MasterDataAttributeVO masterDataAttributeVO);


	/**
	 * Gtop performance report.
	 *
	 * @param masterDataAttributeVO the master data attribute VO
	 * @return the list
	 */
	List<KOInfoBean> gtopPerformanceReport(MasterDataAttributeVO masterDataAttributeVO);


}
