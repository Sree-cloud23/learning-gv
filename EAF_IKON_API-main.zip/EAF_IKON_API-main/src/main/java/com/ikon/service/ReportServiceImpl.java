package com.ikon.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ikon.dto.ReportBean;
import com.ikon.dto.ReportDataAttributeVO;

/**
 * The Class ReportServiceImpl.
 */
@SuppressWarnings("deprecation")
@Service
public class ReportServiceImpl implements ReportService {

	/** The entity manager. */
	@PersistenceContext
	private EntityManager entityManager;

	/** The Constant ACCOUNT_ID. */
	private static final String ACCOUNT_ID = "accountId";

	/**
	 * Update favorite report.
	 *
	 * @param reportDataAttributeVO the report data attribute VO
	 * @return the string
	 */
	@Override
	@Transactional
	public String updateFavoriteReport(ReportDataAttributeVO reportDataAttributeVO) {

		javax.persistence.Query qry = entityManager
				.createNativeQuery("select 1 as return from fun_update_favourite(:accountId, :userId, :reportId, :isFavoriteReport)");
		qry.setParameter(ACCOUNT_ID, reportDataAttributeVO.getAccountId());

		Session session = entityManager.unwrap(Session.class);
		Query query = session
				.createSQLQuery("select 1 as return from fun_update_favourite(:accountId, :userId, :reportId, :isFavoriteReport)");
				//.setResultTransformer(Transformers.aliasToBean(ReportBean.class));

		query.setParameter(ACCOUNT_ID, reportDataAttributeVO.getAccountId());
		query.setParameter("userId", reportDataAttributeVO.getUserId());
		query.setParameter("reportId", reportDataAttributeVO.getReportId());
		query.setParameter("isFavoriteReport", reportDataAttributeVO.getIsFavoriteReport());

		query.list();
		return "";
	}

	/**
	 * Insert report usage.
	 *
	 * @param reportDataAttributeVO the report data attribute VO
	 * @return the string
	 */
	@Override
	@Transactional
	public String insertReportUsage(ReportDataAttributeVO reportDataAttributeVO) {
		Session session = entityManager.unwrap(Session.class);
		Query query = session.createSQLQuery("select 1 as return from fun_insert_report_usage(:accountId, :userId, :reportId, :actionId)");
				//.setResultTransformer(Transformers.aliasToBean(ReportBean.class));

		query.setString(ACCOUNT_ID, reportDataAttributeVO.getAccountId());
		query.setString("userId", reportDataAttributeVO.getUserId());
		query.setString("reportId", reportDataAttributeVO.getReportId());
		query.setString("actionId", reportDataAttributeVO.getIsFavoriteReport());

		query.list();
		return "";
	}

	/**
	 * Gets the report list view.
	 *
	 * @param accountID the account ID
	 * @param userID    the user ID
	 * @return the report list view
	 */
	@Override
	@Transactional
	public List<ReportBean> getReportListView(String accountID, String userID) {

		List<ReportBean> reportBeanList = null;
		Session session = entityManager.unwrap(Session.class);
		Query query = session.createSQLQuery("select * from fun_reports_list(:accountID,:userID)")
				.setResultTransformer(Transformers.aliasToBean(ReportBean.class));
		query.setString("accountID", accountID);
		query.setString("userID", userID);

		reportBeanList = query.list();
		return reportBeanList;

	}

	/**
	 * Update favorite chart.
	 *
	 * @param reportDataAttributeVO the report data attribute VO
	 * @return the string
	 */
	@Override
	@Transactional
	public String updateFavoriteChart(ReportDataAttributeVO reportDataAttributeVO) {

		javax.persistence.Query qry = entityManager
				.createNativeQuery("select 1 as return from fun_update_favourite(:accountId, :userId, :reportId, :isFavoriteChart)");
		qry.setParameter(ACCOUNT_ID, reportDataAttributeVO.getAccountId());

		Session session = entityManager.unwrap(Session.class);

		Query query = session
				.createSQLQuery("select 1 as return from fun_update_favourite(:accountId, :userId, :reportId, :isFavoriteChart)");
				//.setResultTransformer(Transformers.aliasToBean(ReportBean.class));

		query.setParameter(ACCOUNT_ID, reportDataAttributeVO.getAccountId());
		query.setParameter("userId", reportDataAttributeVO.getUserId());
		query.setParameter("chartId", reportDataAttributeVO.getReportId());
		query.setParameter("isFavoriteReport", reportDataAttributeVO.getIsFavoriteReport());

		query.list();
		return "";
	}

}
