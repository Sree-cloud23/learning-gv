package com.ikon.service;



/**
 * The Interface EmailService.
 */
public interface EmailService {
	
	/**
	 * Send email.
	 *
	 * @param email the email
	 */
	public void sendEmail(Object email)  throws Exception;
}
