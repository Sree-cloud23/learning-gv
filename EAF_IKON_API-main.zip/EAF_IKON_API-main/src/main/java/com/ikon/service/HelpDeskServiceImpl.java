package com.ikon.service;

import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;
/*import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;*/
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ikon.dto.SettingBean;
import com.ikon.model.AccountInfo;
import com.ikon.model.HelpDesk;
import com.ikon.model.Setting;
import com.ikon.model.UserMaster;
import com.ikon.repository.AccountInfoRepository;
import com.ikon.repository.SettingRepository;
import com.ikon.repository.UserRepository;
import com.ikon.rest.web.models.Authentication;
import com.ikon.rest.web.models.SecurityContextHolder;

/**
 * The Class HelpDeskServiceImpl.
 */
@SuppressWarnings("deprecation")
@Service
public class HelpDeskServiceImpl implements HelpDeskService {

	/** The entity manager. */
	@PersistenceContext
	private EntityManager entityManager;

	/** The user repository. */
	@Inject
	private transient UserRepository userRepository;

	/** The setting repository. */
	@Inject
	private transient SettingRepository settingRepository;

	/** The account info repository. */
	@Inject
	private transient AccountInfoRepository accountInfoRepository;

	/** The em. */
	//@Inject
	//EntityManager em;
	
	/**  The Constact UNCHECKED_STRING. */
	private static final String UNCHECKED_STRING = "unchecked"; 
	
	/**  The Constant DEF_ACCID_STRING. */
	private static final String DEF_ACCID_STRING = "def_acc_id";

	/**  The Constant USER_ID_STRING. */
	private static final String USER_ID_STRING = "userID";
	
	/**
	 * Save.
	 *
	 * @param help the help
	 * @param request the request
	 * @param session the session
	 */
	@Override
	public void save(HelpDesk help, HttpServletRequest request, HttpSession session) {
		AccountInfo accountinfo = new AccountInfo();
		Setting userSetting = new Setting();
		String requesteremail = request.getParameter("requesteremail");
		UserMaster user = userRepository.findByEmail(requesteremail).orElse(null);
		if (Objects.nonNull(user)) {
			userSetting = settingRepository.findByUserId(user.getName());
			if (!Objects.isNull(userSetting)) {
				accountinfo = accountInfoRepository.findByAccountId(userSetting.getDefaultAccountID());
				help.setUserID(user.getName());
				help.setAccountID(userSetting.getDefaultAccountID());
			}
		} else {
			help.setUserID("Guest");
			help.setAccountID(3);
			accountinfo = accountInfoRepository.findByAccountId(3);
		}
		session.setAttribute("accountid", userSetting.getDefaultAccountID());
		session.setAttribute("accountname", accountinfo.getAccountName());
		if (Objects.isNull(session.getAttribute("accountname"))) {
			session.setAttribute("accountname", accountinfo.getAccountName());
		}
	}

	/**
	 * Account access.
	 *
	 * @param userID the user ID
	 * @return the list
	 */
	@Override
	@Transactional
	public List<SettingBean> accountAccess(String userID) {
		List<SettingBean> SettingBeanList = null;
			Session session = entityManager.unwrap( Session.class );
		Query query = session.createSQLQuery("select * from fun_retreive_user_accounts(:userID)")
				.setResultTransformer(Transformers.aliasToBean(SettingBean.class));
		query.setString(USER_ID_STRING, userID);
		SettingBeanList = query.getResultList();
		return SettingBeanList;
	}

	/**
	 * Default account.
	 *
	 * @param userID the user ID
	 * @return the list
	 */
	@Override
	@Transactional
	public List<SettingBean> defaultAccount(String userID) {
		List<SettingBean> SettingBeanList_def_acc = null;
		Session session = entityManager.unwrap( Session.class );
		Query query_def_acc = session.createSQLQuery("select * from fun_default_account(:userID)")
				.setResultTransformer(Transformers.aliasToBean(SettingBean.class));
		query_def_acc.setString(USER_ID_STRING, userID);
		SettingBeanList_def_acc = query_def_acc.getResultList();
		return SettingBeanList_def_acc;
	}

	/**
	 * Landing page listing.
	 *
	 * @param userID the user ID
	 * @return the list
	 */
	@Override
	@Transactional
	public List<SettingBean> landingPageListing(String userID) {
		List<SettingBean> SettingBeanList_lan_page = null;
		Session session = entityManager.unwrap( Session.class );
			Query query_lan_page = session.createSQLQuery("select * from fun_retreive_landing_pages(:userID)")
					.setResultTransformer(Transformers.aliasToBean(SettingBean.class));
			query_lan_page.setString(USER_ID_STRING, userID);
			SettingBeanList_lan_page = query_lan_page.getResultList();
		return SettingBeanList_lan_page;
	}

	/**
	 * Default landing page.
	 *
	 * @param userID the user ID
	 * @param accid the accid
	 * @return the list
	 */
	@Override
	@Transactional
	public List<SettingBean> defaultLandingPage(String userID, int accid) {
		List<SettingBean> SettingBeanList_lan_page = null;
		Session session = entityManager.unwrap( Session.class );
			Query query_def_lan_page = session.createSQLQuery("select * from fun_default_landing_page(:userID,:def_acc_id)")
					.setResultTransformer(Transformers.aliasToBean(SettingBean.class));
			query_def_lan_page.setString(USER_ID_STRING, userID);
			query_def_lan_page.setInteger(DEF_ACCID_STRING, accid);
			SettingBeanList_lan_page = query_def_lan_page.getResultList();
		return SettingBeanList_lan_page;
	}

	/**
	 * Settingacc save.
	 *
	 * @param settab the settab
	 * @param request the request
	 * @param session the session
	 */
	@Override
	@Transactional
	public void settingacc_save(Setting settab, HttpServletRequest request, HttpSession session) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String userID = auth.getName();
		String defaultAccount = request.getParameter("defaultAccount");
		Session session1 = entityManager.unwrap( Session.class );
			Query query_def_acc = session1.createSQLQuery("select 1 as return from fun_update_user_default_account(:userID,:def_acc_id)");
					//.setResultTransformer(Transformers.aliasToBean(SettingBean.class));
			query_def_acc.setParameter(USER_ID_STRING, userID);
			query_def_acc.setParameter(DEF_ACCID_STRING, defaultAccount);
			query_def_acc.list();
		
	}

	/**
	 * Settinglanpage save.
	 *
	 * @param settab the settab
	 * @param request the request
	 * @param session the session
	 */
	@Override
	@Transactional
	public void settinglanpage_save(Setting settab, HttpServletRequest request, HttpSession session) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String userID = auth.getName();
		String defaultAccount = request.getParameter("defaultAccount");
		String defaultPage = request.getParameter("defaultPage");
		Session session2 = entityManager.unwrap( Session.class );
			Query query_def_lan_page = session2
					.createSQLQuery("select 1 as return from fun_update_user_landing_page (:userID,:def_acc_id,:def_lan_page)");
					//.setResultTransformer(Transformers.aliasToBean(SettingBean.class));
			query_def_lan_page.setParameter(USER_ID_STRING, userID);
			query_def_lan_page.setParameter(DEF_ACCID_STRING, defaultAccount);
			query_def_lan_page.setParameter("def_lan_page", defaultPage);
			query_def_lan_page.list();
		
	}

	/**
	 * Gets the statistic data.
	 *
	 * @param accountID the account ID
	 * @return the statistic data
	 */
	@Override
	@Transactional
	public SettingBean getStatisticData(int accountID) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String userID = auth.getName();
		List<SettingBean> SettingBeanList_stat_data = null;
		Session session = entityManager.unwrap( Session.class );
			Query query = session.createSQLQuery("select * from fun_user_profile(:userID,:accountID)")
					.setResultTransformer(Transformers.aliasToBean(SettingBean.class));
			query.setParameter(USER_ID_STRING, userID);
			query.setParameter("accountID", accountID);
			SettingBeanList_stat_data = query.list();
			if (Objects.nonNull(SettingBeanList_stat_data) && SettingBeanList_stat_data.size() > 0) {
				return SettingBeanList_stat_data.get(0);
	
			}		
		return new SettingBean();
	}

	/**
	 * Helpdesk options listing.
	 *
	 * @param formheading the formheading
	 * @return the sets the
	 */
	@Override
	@Transactional
	public Set<String> helpdeskOptionsListing(String formheading) {
		List<SettingBean> HelpdeskOptList = null;
		Set<String> HelpdeskOptionsList = new HashSet<String>();
		Session session = entityManager.unwrap( Session.class );
			Query query_lan_page = session.createSQLQuery("select * from fun_retrieve_helpdesk_options(:formheading)")
					.setResultTransformer(Transformers.aliasToBean(SettingBean.class));
			query_lan_page.setParameter("formheading", formheading);
			HelpdeskOptList = query_lan_page.getResultList();
	
			for (SettingBean HDoptions : HelpdeskOptList) {
				HelpdeskOptionsList.add(HDoptions.getHelpDeskOptions());
			}
		return HelpdeskOptionsList;
	}

	/**
	 * Infomailsave.
	 *
	 * @param requesteremail the requesteremail
	 * @param recipientsto the recipientsto
	 * @param recipientscc the recipientscc
	 * @param subject the subject
	 * @param mailmsg the mailmsg
	 * @param accountid the accountid
	 */
	@Override
	@Transactional
	public void infomailsave(String requesteremail, String recipientsto, String recipientscc, String subject,
			String mailmsg, int accountid) {
		Session session = entityManager.unwrap(Session.class);
		Query query_mailinfo = session.createSQLQuery(
				"select 1 as return from fun_insert_mailing_info(:def_acc_id,:requesteremail,:recipientsto,:recipientscc,:subject,:mailmsg,:attno,:attpath)");
				//.setResultTransformer(Transformers.aliasToBean(SettingBean.class));
		query_mailinfo.setInteger(DEF_ACCID_STRING, accountid);
		query_mailinfo.setString("requesteremail", requesteremail);
		query_mailinfo.setString("recipientsto", recipientsto);
		query_mailinfo.setString("recipientscc", recipientscc);
		query_mailinfo.setString("subject", subject);
		query_mailinfo.setString("mailmsg", mailmsg);
		query_mailinfo.setString("attno", "0");
		query_mailinfo.setString("attpath", null);
		query_mailinfo.list();
		
	}

	/**
	 * Gets the default account id.
	 *
	 * @param username the username
	 * @return the default account id
	 */
	@Override
	public String getDefaultAccountId(String username) {
		
		String accountId = "1";
		Setting settingInfo =  settingRepository.findByUserId(username);
		if(Objects.nonNull(settingInfo))
		{
			accountId = Integer.toString(settingInfo.getDefaultAccountID());
    	} 
		return accountId;
	}
	
}
