package com.ikon.service;

import java.util.List;

import com.ikon.model.AccessControl;

/**
 * The Interface AccessControlService.
 */
public interface AccessControlService {
    
    /**
     * Find all.
     *
     * @return the list
     */
    public List<AccessControl> findAll();
    
    /**
     * Gets the access detail by user id.
     *
     * @param userId the user id
     * @return the access detail by user id
     */
    public AccessControl getAccessDetailByUserId(String userId);
}
