package com.ikon.service;

import java.util.List;

import com.ikon.model.Role;

/**
 * The Interface RoleService.
 */
public interface RoleService {
	
	/**
	 * Save.
	 *
	 * @param role the role
	 */
	void save(Role role);
   
   /**
    * Find all.
    *
    * @return the list
    */
   List<Role> findAll();
   
   /**
    * Find by id.
    *
    * @param id the id
    * @return the role
    */
   Role findById(Long id);
   
   /**
    * Gets the all role names.
    *
    * @return the all role names
    */
   List<String> getAllRoleNames();
   
   /**
    * Find role by role name.
    *
    * @param roleName the role name
    * @return the role
    */
   Role findRoleByRoleName(String roleName);
}
