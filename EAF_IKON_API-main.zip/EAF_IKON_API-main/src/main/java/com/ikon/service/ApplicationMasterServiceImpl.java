package com.ikon.service;

import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Service;

import com.ikon.model.ApplicationMaster;
import com.ikon.repository.ApplicationMasterRepository;
import com.ikon.validator.IKONUtils;

/**
 * The Class ApplicationMasterServiceImpl.
 */
@SuppressWarnings("deprecation")
@Service
public class ApplicationMasterServiceImpl implements ApplicationMasterService {
	
    /** The entity manager. */
    @PersistenceContext
    private  EntityManager entityManager;
	
    /** The application master repository. */
    @Inject
    private transient ApplicationMasterRepository applicationMasterRepository;

    /**
     * Find all.
     *
     * @return the list
     */
    @Override
    public List<ApplicationMaster> findAll() {
    	return applicationMasterRepository.findAll();
    }

	/**
	 * Gets the all application name.
	 *
	 * @param userId the user id
	 * @param accountId the account id
	 * @return the all application name
	 */
	@Override
	public Set<String> getAllApplicationName(String userId, String accountId) {
		List<ApplicationMaster> applicationMasterList = applicationMasterRepository.findAll();
		Set<String> applicationNameList = new TreeSet<String>();
		for (ApplicationMaster appMaster : applicationMasterList) {
			if(!IKONUtils.isNullOrEmpty(accountId) && appMaster.getAccountId().equals(Long.parseLong(accountId))){
				applicationNameList.add(appMaster.getAppName());
			}
		}
		return applicationNameList;
	}
	
	/**
	 * Gets the all assignment group.
	 *
	 * @param userId the user id
	 * @param accountId the account id
	 * @return the all assignment group
	 */
	@Override
	public Set<String> getAllAssignmentGroup(String userId, String accountId) {
		List<ApplicationMaster> applicationMasterList = applicationMasterRepository.findAll();
		Set<String> assignmentGroupList = new TreeSet<String>();
		for (ApplicationMaster appMaster : applicationMasterList) {
			if(!IKONUtils.isNullOrEmpty(accountId) && appMaster.getAccountId().equals(Long.parseLong(accountId))){
				assignmentGroupList.add(appMaster.getAssignmentGroup());
			}
		}
		return assignmentGroupList;
	}
	
	
	/**
	 * Gets the all tower.
	 *
	 * @param userId the user id
	 * @param accountId the account id
	 * @return the all tower
	 */
	@Override
	public Set<String> getAllTower(String userId, String accountId) {
		List<ApplicationMaster> applicationMasterList = applicationMasterRepository.findAll();
		Set<String> towerList = new TreeSet<String>();
		for (ApplicationMaster appMaster : applicationMasterList) {
			if(!IKONUtils.isNullOrEmpty(accountId) && appMaster.getAccountId().equals(Long.parseLong(accountId))
				&& Objects.nonNull(appMaster.getTower()) && !appMaster.getTower().trim().equalsIgnoreCase("")) {
					towerList.add(appMaster.getTower());
			}
		}
		return towerList;
	}
	
	/**
	 * Gets the all CC.
	 *
	 * @param userId the user id
	 * @param accountId the account id
	 * @return the all CC
	 */
	@Override
	public Set<String> getAllCC(String userId, String accountId) {
		List<ApplicationMaster> applicationMasterList = applicationMasterRepository.findAll();
		Set<String> ccList = new TreeSet<String>();
		for (ApplicationMaster appMaster : applicationMasterList) {
			if(!IKONUtils.isNullOrEmpty(accountId) && appMaster.getAccountId().equals(Long.parseLong(accountId))
				&& Objects.nonNull(appMaster.getCc()) && !appMaster.getCc().trim().equalsIgnoreCase("")) {
					ccList.add(appMaster.getCc());
			}
		}
		return ccList;
	}
	
	/**
	 * Gets the all cluster.
	 *
	 * @param userId the user id
	 * @param accountId the account id
	 * @return the all cluster
	 */
	@Override
	public Set<String> getAllCluster(String userId, String accountId) {
		List<ApplicationMaster> applicationMasterList = applicationMasterRepository.findAll();
		Set<String> clusterList = new TreeSet<String>();
		for (ApplicationMaster appMaster : applicationMasterList) {
			if(!IKONUtils.isNullOrEmpty(accountId) && appMaster.getAccountId().equals(Long.parseLong(accountId))
				&& !Objects.isNull(appMaster.getCluster())&& !appMaster.getCluster().trim().equalsIgnoreCase("")) {
					clusterList.add(appMaster.getCluster());
			}
		}
		return clusterList;
	}

	/**
	 * Gets the filters data.
	 *
	 * @param defaultAccountId the default account id
	 * @param userId the user id
	 * @return the filters data
	 */
	@Override
	@Transactional
	public List<ApplicationMaster> getFiltersData(String defaultAccountId, String userId) {
		List<ApplicationMaster> filtersList = null;
		Session session = entityManager.unwrap( Session.class );
		Query query = session.createSQLQuery("select * from fun_user_master_data_mapping(:accId,:userId)")
				.setResultTransformer(Transformers.aliasToBean(ApplicationMaster.class));
		query.setParameter("accId", defaultAccountId);
		query.setParameter("userId", userId);
		filtersList = query.list();
		return filtersList;
	} 
}
