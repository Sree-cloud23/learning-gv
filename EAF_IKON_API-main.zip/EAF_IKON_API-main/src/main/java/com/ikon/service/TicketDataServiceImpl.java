package com.ikon.service;

import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ikon.dto.KOInfoBean;
import com.ikon.dto.TicketDataAttributeVO;
import com.ikon.dto.TicketDataBean;
import com.ikon.model.AccountInfo;
import com.ikon.model.KOUsage;
import com.ikon.model.TicketData;
import com.ikon.model.UserAccountApplicationMapping;
import com.ikon.repository.AccountInfoRepository;
import com.ikon.repository.KOInfoRepository;
import com.ikon.repository.KOUsageRepository;
import com.ikon.repository.TicketDataRepository;
import com.ikon.repository.UserAccountAppRepository;
import com.ikon.validator.IKONUtils;

/**
 * The Class TicketDataServiceImpl.
 */
@SuppressWarnings("deprecation")
@Service
public class TicketDataServiceImpl implements TicketDataService {

	/** The entity manager. */
	@PersistenceContext
	private EntityManager entityManager;
	
	/** The ko info service. */
	@Inject
	private transient KOInfoService koInfoService;

	/** The ticket data repository. */
	@Inject
	private transient TicketDataRepository ticketDataRepository;

	/** The account info repository. */
	@Inject
	private transient AccountInfoRepository accountInfoRepository;

	/** The user account app repository. */
	@Inject
	private transient UserAccountAppRepository userAccountAppRepository;

	/** The k O info repository. */
	@Inject
	private transient KOInfoRepository kOInfoRepository;

	/** The k O usage repository. */
	@Inject
	private transient KOUsageRepository kOUsageRepository;
	
	/**  The constant ticketID. */
	private static final String TICKET_ID_STRING="ticketID";

	/**
	 * Find all.
	 *
	 * @return the list
	 */
	@Override
	public List<TicketData> findAll() {
		return ticketDataRepository.findAll();
	}

	/**
	 * Gets the all ticket data.
	 *
	 * @param tktDtAttrVO the tkt dt attr VO
	 * @return the all ticket data
	 */
	@Override
	@Transactional
	public List<TicketDataBean> getAllTicketData(TicketDataAttributeVO tktDtAttrVO) {
		List<TicketDataBean> ticketDataBeanList = null;
		Session session = entityManager.unwrap( Session.class );
		Query query = session.createSQLQuery(
				"select * from  fun_ticket_list_view(:userId,:searchType,:applicationName,:assignmentGroup,:serviceType,:status,:priority,:koValue,:assigneeName,:fromDate,:toDate)")
				.setResultTransformer(Transformers.aliasToBean(TicketDataBean.class));
		query.setString("userId", tktDtAttrVO.getMasterDtAttrVo().getUserId());
		query.setInteger("searchType", Integer.parseInt(IKONUtils.isNullOrEmpty(tktDtAttrVO.getSearchType()) ? "0":tktDtAttrVO.getSearchType()));
		query.setString("applicationName", tktDtAttrVO.getMasterDtAttrVo().getAppName());
		query.setString("assignmentGroup", tktDtAttrVO.getMasterDtAttrVo().getAssignmentGroup());
		query.setString("serviceType", tktDtAttrVO.getServiceType());
		query.setString("status", tktDtAttrVO.getStatus());
		query.setString("priority", tktDtAttrVO.getPriority());
		query.setInteger("koValue", Integer.parseInt(IKONUtils.isNullOrEmpty(tktDtAttrVO.getKoValue()) ? "0":tktDtAttrVO.getKoValue()));
		query.setString("assigneeName", tktDtAttrVO.getAssigneeName());
		query.setString("fromDate", tktDtAttrVO.getMasterDtAttrVo().getFromDate());
		query.setString("toDate", tktDtAttrVO.getMasterDtAttrVo().getToDate());
		ticketDataBeanList = query.list();
		return ticketDataBeanList;
	}

	/**
	 * Gets the ticket data.
	 *
	 * @param ticketId the ticket id
	 * @return the ticket data
	 */
	@Override
	@Transactional
	public List<TicketDataBean> getTicketData(String ticketId) {
		List<TicketDataBean> ticketDataBeanList = null;
		Session session = entityManager.unwrap( Session.class );
		Query query = session.createSQLQuery("select * from fun_single_ticket_view(:ticketID)")
				.setResultTransformer(Transformers.aliasToBean(TicketDataBean.class));
		query.setString(TICKET_ID_STRING, ticketId);
		ticketDataBeanList = query.list();
		return ticketDataBeanList;
	}

	/**
	 * Gets the incident tags.
	 *
	 * @param ticketId the ticket id
	 * @return the incident tags
	 */
	@Override
	@Transactional
	public List<TicketDataBean> getIncidentTags(String ticketId) {
		List<TicketDataBean> ticketDataBeanList = null;
		Session session = entityManager.unwrap( Session.class );
		Query query = session.createSQLQuery("select * from fun_incident_tags(:ticketID)")
				.setResultTransformer(Transformers.aliasToBean(TicketDataBean.class));
		query.setParameter(TICKET_ID_STRING, ticketId);
		ticketDataBeanList = query.list();
		return ticketDataBeanList;
	}

	/**
	 * Gets the similar incident list.
	 *
	 * @param ticketId the ticket id
	 * @return the similar incident list
	 */
	@Override
	@Transactional
	public List<TicketDataBean> getSimilarIncidentList(String ticketId) {
		List<TicketDataBean> ticketDataBeanList = null;
		Session session = entityManager.unwrap( Session.class );
		Query query = session.createSQLQuery("select * from fun_similar_incident_view(:ticketID)")
				.setResultTransformer(Transformers.aliasToBean(TicketDataBean.class));
		query.setParameter(TICKET_ID_STRING, ticketId);
		ticketDataBeanList = query.list();
		return ticketDataBeanList;
	}

	/**
	 * Gets the incidenttags list.
	 *
	 * @param ticketId the ticket id
	 * @return the incidenttags list
	 */
	@Override
	@Transactional
	public List<TicketDataBean> getincidenttagsList(String ticketId) {
		List<TicketDataBean> getincidenttagsList = null;
		Session session = entityManager.unwrap( Session.class );
		Query query = session.createSQLQuery("select * from fun_incident_tags(:ticketID)")
				.setResultTransformer(Transformers.aliasToBean(TicketDataBean.class));
		query.setParameter(TICKET_ID_STRING, ticketId);
		getincidenttagsList = query.list();
		return getincidenttagsList;
	}

	/**
	 * Gets the kotagsincident list.
	 *
	 * @param KOID the koid
	 * @return the kotagsincident list
	 */
	@Override
	@Transactional
	public List<TicketDataBean> getkotagsincidentList(String KOID) {
		List<TicketDataBean> getkotagsincidentList = null;
		Session session = entityManager.unwrap( Session.class );
		Query query = session.createSQLQuery("select * from fun_ko_tags(:KOID)")
				.setResultTransformer(Transformers.aliasToBean(TicketDataBean.class));
		query.setString("KOID", KOID);
		getkotagsincidentList = query.list();
		return getkotagsincidentList;
	}

	/**
	 * Gets the ticket tracking list.
	 *
	 * @param ticketId the ticket id
	 * @return the ticket tracking list
	 */
	@Override
	@Transactional
	public List<TicketDataBean> getTicketTrackingList(String ticketId) {
		List<TicketDataBean> ticketDataBeanList = null;
		Session session = entityManager.unwrap( Session.class );
		Query query = session.createSQLQuery("select * from fun_tracking_incident(:ticketID)")
				.setResultTransformer(Transformers.aliasToBean(TicketDataBean.class));
		query.setParameter(TICKET_ID_STRING, ticketId);
		ticketDataBeanList = query.list();
		return ticketDataBeanList;
	}

	/**
	 * Gets the all application name.
	 *
	 * @param userId    the user id
	 * @param accountId the account id
	 * @return the all application name
	 */

	@Override
	public Set<String> getAllApplicationName(String userId, String accountId) {
		List<UserAccountApplicationMapping> appMapping = userAccountAppRepository.findAll();
		Set<String> applicationNameList = new HashSet<String>();
		for (UserAccountApplicationMapping app : appMapping) {
			if (accountId.equalsIgnoreCase(String.valueOf(app.getAccountID()))
					&& userId.equalsIgnoreCase(String.valueOf(app.getUserID()))
					&& !IKONUtils.isNullOrEmpty(app.getApplicationName())) {
				applicationNameList.add(app.getApplicationName());
			}
		}
		return applicationNameList;
	}

	/**
	 * Gets the all assignment group.
	 *
	 * @param userId    the user id
	 * @param accountId the account id
	 * @return the all assignment group
	 */
	@Override
	public Set<String> getAllAssignmentGroup(String userId, String accountId) {
		List<UserAccountApplicationMapping> ticketDataBeanList = userAccountAppRepository.findAll();
		Set<String> assignmentGroupList = new HashSet<String>();
		for (UserAccountApplicationMapping ass : ticketDataBeanList) {
			if (accountId.equalsIgnoreCase(String.valueOf(ass.getAccountID()))
					&& userId.equalsIgnoreCase(String.valueOf(ass.getUserID()))
					&& !IKONUtils.isNullOrEmpty(ass.getApplicationName())) {
				assignmentGroupList.add(ass.getAssignmentGroup());
			}
		}
		return assignmentGroupList;
	}

	/**
	 * Gets the all ticket type.
	 *
	 * @param userId    the user id
	 * @param accountId the account id
	 * @return the all ticket type
	 */

	@Override
	public Set<String> getAllTicketType(String userId, String accountId) {
		List<TicketData> ticketDataBeanList = ticketDataRepository.findAll();
		Set<String> ticketTypeList = new HashSet<String>();
		for (TicketData ticketData : ticketDataBeanList) {
			if (accountId.equalsIgnoreCase(ticketData.getAccountID())
					&& !IKONUtils.isNullOrEmpty(ticketData.getServiceType())) {
				ticketTypeList.add(ticketData.getServiceType());
			}
		}
		return ticketTypeList;
	}

	/**
	 * Gets the all priority.
	 *
	 * @param userId    the user id
	 * @param accountId the account id
	 * @return the all priority
	 */
	@Override
	public Set<String> getAllPriority(String userId, String accountId) {
		List<TicketData> ticketDataBeanList = ticketDataRepository.findAll();
		Set<String> priorityList = new HashSet<String>();
		for (TicketData ticketData : ticketDataBeanList) {
			if (accountId.equalsIgnoreCase(ticketData.getAccountID())
					&& !IKONUtils.isNullOrEmpty(ticketData.getPriority())) {
				priorityList.add(ticketData.getPriority());
			}
		}
		return priorityList;
	}

	/**
	 * Gets the all status.
	 *
	 * @param userId    the user id
	 * @param accountId the account id
	 * @return the all status
	 */
	@Override
	public Set<String> getAllStatus(String userId, String accountId) {
		List<TicketData> ticketDataBeanList = ticketDataRepository.findAll();
		Set<String> statusList = new HashSet<String>();
		for (TicketData ticketData : ticketDataBeanList) {
			if (accountId.equalsIgnoreCase(ticketData.getAccountID())
					&& !IKONUtils.isNullOrEmpty(ticketData.getStatus())) {
				statusList.add(ticketData.getStatus());
			}
		}
		return statusList;
	}

	/**
	 * Gets the assignment group by application name.
	 *
	 * @param applicationName the application name
	 * @return the assignment group by application name
	 */
	@Override
	public String getAssignmentGroupByApplicationName(String applicationName) {
		List<TicketData> appMasterList = ticketDataRepository.findAll();
		for (TicketData appMaster : appMasterList) {
			if (!IKONUtils.isNullOrEmpty(applicationName)
					&& applicationName.equalsIgnoreCase(appMaster.getApplicationName())) {
				return appMaster.getAssignmentGroup();
			}
		}
		return "";
	}

	/**
	 * Gets the account name by account id.
	 *
	 * @param accountId the account id
	 * @return the account name by account id
	 */
	@Override
	public String getAccountNameByAccountId(int accountId) {
		AccountInfo accountInfo = accountInfoRepository.findByAccountId(accountId);
		String accountName = "";
		if (!Objects.isNull(accountInfo) && Objects.equals(accountInfo.getAccountId(), accountId)) {
			accountName = accountInfo.getAccountName();
		}
		return accountName;
	}

	/**
	 * Insert KO for resolution.
	 *
	 * @param ticketDataAttributeVO the ticket data attribute VO
	 * @param isResolutionExists the is resolution exists
	 * @return the string
	 */
	@Override
	@Transactional
	public String insertKOForResolution(TicketDataAttributeVO ticketDataAttributeVO,
			String isResolutionExists) {
		Session session = entityManager.unwrap( Session.class );
		Query query = session.createSQLQuery(
				"select 1 as return from fun_selected_ko_for_resolution(:ticketID, :koID, :userID, :accountID,:reuseractionid, :KocreatoractionID)");
				//.setResultTransformer(Transformers.aliasToBean(TicketDataBean.class));

		query.setParameter(TICKET_ID_STRING, ticketDataAttributeVO.getTicketId());
		query.setParameter("koID", ticketDataAttributeVO.getKoDtAttr().getKoId());
		query.setParameter("userID", ticketDataAttributeVO.getMasterDtAttrVo().getUserId());
		query.setParameter("accountID", ticketDataAttributeVO.getMasterDtAttrVo().getAccId());
		if (!IKONUtils.isNullOrEmpty(isResolutionExists) && isResolutionExists.equalsIgnoreCase("yes")) {
			query.setParameter("reuseractionid", "30");
			query.setParameter("KocreatoractionID", "29");
		} else {
			query.setParameter("reuseractionid", "10");
			query.setParameter("KocreatoractionID", "8");
		}
		query.list();
		return "";
	}

	/**
	 * Gets the all KO inc count.
	 *
	 * @param koUsageList the ko usage list
	 * @param koInfoList  the ko info list
	 * @param koId        the ko id
	 * @return the all KO inc count
	 */
	@Override
	public Long getAllKOIncCount(List<KOUsage> koUsageList, List<KOInfoBean> koInfoList, String koId) {
		int koSerialNo = 0;
		Long totalCnt = 0L;
		for (KOInfoBean koInfo : koInfoList) {
			if (koId.equalsIgnoreCase(koInfo.getKoID())) {
				koSerialNo = koInfo.getKOSerialNo();
			}
		}
		for (KOUsage koUsage : koUsageList) {
			if (!Objects.isNull(koUsage) && Objects.equals(koUsage.getKoSerialNo(), koSerialNo)) {
				totalCnt++;
			}
		}
		return totalCnt;
	}

	/**
	 * Gets the no of inc linked for KO.
	 *
	 * @param koId the ko id
	 * @param accountId the account id
	 * @return the no of inc linked for KO
	 */
	@Override
	public Long getNoOfIncLinkedForKO(String koId,String accountId) {
		int koSerialNo = 0;
		Long totalCnt = 0L;
		List<KOInfoBean> koInfoList = koInfoService.getAllKos(accountId);
		for (KOInfoBean koInfo : koInfoList) {
			if (koId.equalsIgnoreCase(koInfo.getKoID())) {
				koSerialNo = koInfo.getKOSerialNo();
			}
		}
		List<KOUsage> koUsageList = kOUsageRepository.findAll();
		for (KOUsage koUsage : koUsageList) {
			if (!Objects.isNull(koUsage) && Objects.equals(koUsage.getKoSerialNo(), koSerialNo)) {
				totalCnt++;
			}
		}
		return totalCnt;
	}

	/**
	 * Gets the all assignee name.
	 *
	 * @param accountId the account id
	 * @return the all assignee name
	 */
	@Override
	public Set<String> getAllAssigneeName(String accountId) {
		List<TicketData> ticketDataBeanList = ticketDataRepository.findAll();
		Set<String> assigneeNameList = new HashSet<String>();
		for (TicketData ticketData : ticketDataBeanList) {
			if (accountId.equalsIgnoreCase(ticketData.getAccountID())
					&& !IKONUtils.isNullOrEmpty(ticketData.getAssigneeName().trim())) {
				assigneeNameList.add(ticketData.getAssigneeName());
			}
		}
		return assigneeNameList;
	}

	/**
	 * Gets the subject matter specialist.
	 *
	 * @param ticketId the ticket id
	 * @return the subject matter specialist
	 */
	@Override
	@Transactional
	public TicketDataBean getSubjectMatterSpecialist(String ticketId) {
		List<TicketDataBean> ticketDataBeanList = null;
		Session session = entityManager.unwrap( Session.class );
		Query query = session.createSQLQuery("select * from fun_similar_sme(:ticketID)")
				.setResultTransformer(Transformers.aliasToBean(TicketDataBean.class));
		query.setParameter(TICKET_ID_STRING, ticketId);
		ticketDataBeanList = query.list();
		String subjectMatterSpecialist = "";
		String ticketCount = "";
		if (Objects.nonNull(ticketDataBeanList) && ticketDataBeanList.size() > 0) {
			subjectMatterSpecialist = ticketDataBeanList.get(0).getAssigneeName();
			if (Objects.nonNull(ticketDataBeanList.get(0).getTicketCount())) {
				ticketCount = String.valueOf(ticketDataBeanList.get(0).getTicketCount());
			}
		}

		TicketDataBean ticketDataBean = new TicketDataBean();
		ticketDataBean.setSubjectMatterSpecialist(subjectMatterSpecialist);
		ticketDataBean.setTicketCount(ticketCount);
		
		return ticketDataBean;
	}

	/**
	 * Gets the inc missing ko data.
	 *
	 * @param tktDtAttrVO the tkt dt attr VO
	 * @param isSearchByResolvedDate the is search by resolved date
	 * @return the inc missing ko data
	 */
	@Override
	@Transactional
	public List<TicketDataBean> getIncMissingKoData(TicketDataAttributeVO tktDtAttrVO, String isSearchByResolvedDate) {
		List<TicketDataBean> ticketDataBeanList = null;
		Session session = entityManager.unwrap( Session.class );
		Query query = session.createSQLQuery(
				"select * from fun_inc_missing_ko(:userId,:isSerachByResolvedDate,:fromDate,:toDate,:applicationName,:assignmentGroup,:serviceType,:assigneeName,:tower,:cc,:cluster)")
				.setResultTransformer(Transformers.aliasToBean(TicketDataBean.class));
		query.setString("userId", tktDtAttrVO.getMasterDtAttrVo().getAccId());
		if (Objects.isNull(isSearchByResolvedDate))
			query.setString("isSerachByResolvedDate", "0");
		else
			query.setString("isSerachByResolvedDate", isSearchByResolvedDate);
		query.setString("fromDate", tktDtAttrVO.getMasterDtAttrVo().getFromDate());
		query.setString("toDate", tktDtAttrVO.getMasterDtAttrVo().getToDate());
		query.setString("applicationName", tktDtAttrVO.getMasterDtAttrVo().getAppName());
		query.setString("assignmentGroup", tktDtAttrVO.getMasterDtAttrVo().getAssignmentGroup());
		query.setString("serviceType", tktDtAttrVO.getServiceType());
		query.setString("assigneeName", tktDtAttrVO.getAssigneeName());
		query.setString("tower", tktDtAttrVO.getMasterDtAttrVo().getTower());
		query.setString("cc", tktDtAttrVO.getMasterDtAttrVo().getCc());
		query.setString("cluster", tktDtAttrVO.getMasterDtAttrVo().getCluster());

		ticketDataBeanList = query.list();
		return ticketDataBeanList;
	}

	/**
	 * Checks if is ticket exists.
	 *
	 * @param ticketId the ticket id
	 * @return true, if is ticket exists
	 */
	@Override
	public boolean isTicketExists(String ticketId) {
		Long count = (Long) ticketDataRepository.isTicketExists(ticketId);
		return ((count.equals(0L)) ? false : true);
	}

	/**
	 * Gets the start time of last feed.
	 *
	 * @return the start time of last feed
	 */
	@Override
	@Transactional
	public List<TicketDataBean> getStartTimeOfLastFeed() {

		List<TicketDataBean> ticketDataBeanList = null;
		Session session = entityManager.unwrap( Session.class );
		Query query = session.createSQLQuery("select * from fun_lasttime_feed()")
				.setResultTransformer(Transformers.aliasToBean(TicketDataBean.class));
		ticketDataBeanList = query.list();

		return ticketDataBeanList;

	}

	/**
	 * Gets the ticket serial number.
	 *
	 * @param ticketID the ticket ID
	 * @return the ticket serial number
	 */
	@Override
	public Long getTicketSerialNumber(String ticketID) {
		return ticketDataRepository.getTicketData(ticketID);
	}
	
	@Override
	@Transactional
	public List<TicketDataBean> getLinkedTickets(String koID, String accountId) {
		

		List<TicketDataBean> ticketDataBeanList = null;
		Session session = entityManager.unwrap( Session.class );
		Query query = session.createSQLQuery("select * from fun_ko_linked_tickets(:koId,:accountId)")
				.setResultTransformer(Transformers.aliasToBean(TicketDataBean.class));
		query.setString("koId", koID);
		query.setString("accountId", accountId);
		ticketDataBeanList = query.list();
		
		return ticketDataBeanList;
	}

}
