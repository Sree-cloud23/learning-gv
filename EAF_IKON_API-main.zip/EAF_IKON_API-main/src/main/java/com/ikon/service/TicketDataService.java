package com.ikon.service;

import java.util.List;
import java.util.Set;

import com.ikon.dto.KOInfoBean;
import com.ikon.dto.TicketDataAttributeVO;
import com.ikon.dto.TicketDataBean;
import com.ikon.model.KOInfo;
import com.ikon.model.KOUsage;
import com.ikon.model.TicketData;

/**
 * The Interface TicketDataService.
 */
public interface TicketDataService {

	/**
	 * Find all.
	 *
	 * @return the list
	 */
	public List<TicketData> findAll();

	/**
	 * Gets the all ticket data.
	 *
	 * @param tktDtAttrVO the tkt dt attr VO
	 * @return the all ticket data
	 */
	List<TicketDataBean> getAllTicketData(TicketDataAttributeVO tktDtAttrVO);

	/**
	 * Gets the ticket data.
	 *
	 * @param ticketId the ticket id
	 * @return the ticket data
	 */
	List<TicketDataBean> getTicketData(String ticketId);

	/**
	 * Gets the incident tags.
	 *
	 * @param ticketId the ticket id
	 * @return the incident tags
	 */
	List<TicketDataBean> getIncidentTags(String ticketId);

	/**
	 * Gets the all application name.
	 *
	 * @param userId    the user id
	 * @param accountId the account id
	 * @return the all application name
	 */
	Set<String> getAllApplicationName(String userId, String accountId);

	/**
	 * Gets the all assignment group.
	 *
	 * @param userId    the user id
	 * @param accountId the account id
	 * @return the all assignment group
	 */
	Set<String> getAllAssignmentGroup(String userId, String accountId);

	/**
	 * Gets the all ticket type.
	 *
	 * @param userId    the user id
	 * @param accountId the account id
	 * @return the all ticket type
	 */
	Set<String> getAllTicketType(String userId, String accountId);

	/**
	 * Gets the all priority.
	 *
	 * @param userId    the user id
	 * @param accountId the account id
	 * @return the all priority
	 */
	Set<String> getAllPriority(String userId, String accountId);

	/**
	 * Gets the all status.
	 *
	 * @param userId    the user id
	 * @param accountId the account id
	 * @return the all status
	 */
	Set<String> getAllStatus(String userId, String accountId);

	/**
	 * Gets the similar incident list.
	 *
	 * @param ticketId the ticket id
	 * @return the similar incident list
	 */
	List<TicketDataBean> getSimilarIncidentList(String ticketId);

	/**
	 * Gets the ticket tracking list.
	 *
	 * @param ticketId the ticket id
	 * @return the ticket tracking list
	 */
	List<TicketDataBean> getTicketTrackingList(String ticketId);

	/**
	 * Gets the incidenttags list.
	 *
	 * @param ticketId the ticket id
	 * @return the incidenttags list
	 */
	List<TicketDataBean> getincidenttagsList(String ticketId);

	/**
	 * Gets the kotagsincident list.
	 *
	 * @param ticketId the ticket id
	 * @return the kotagsincident list
	 */
	List<TicketDataBean> getkotagsincidentList(String ticketId);

	/**
	 * Gets the assignment group by application name.
	 *
	 * @param applicationName the application name
	 * @return the assignment group by application name
	 */
	String getAssignmentGroupByApplicationName(String applicationName);

	/**
	 * Gets the account name by account id.
	 *
	 * @param accountId the account id
	 * @return the account name by account id
	 */
	String getAccountNameByAccountId(int accountId);

	/**
	 * Insert KO for resolution.
	 *
	 * @param ticketDataAttributeVO the ticket data attribute VO
	 * @param isResolutionExists the is resolution exists
	 * @return the string
	 */
	String insertKOForResolution(TicketDataAttributeVO ticketDataAttributeVO,
			String isResolutionExists);

	/**
	 * Gets the all KO inc count.
	 *
	 * @param koUsageList the ko usage list
	 * @param koInfoList  the ko info list
	 * @param koId        the ko id
	 * @return the all KO inc count
	 */
	Long getAllKOIncCount(List<KOUsage> koUsageList, List<KOInfoBean> koInfoList, String koId);

	/**
	 * Gets the no of inc linked for KO.
	 *
	 * @param koId the ko id
	 * @param accountId the account id
	 * @return the no of inc linked for KO
	 */
	Long getNoOfIncLinkedForKO(String koId, String accountId);

	/**
	 * Gets the all assignee name.
	 *
	 * @param accountId the account id
	 * @return the all assignee name
	 */
	Set<String> getAllAssigneeName(String accountId);

	/**
	 * Gets the subject matter specialist.
	 *
	 * @param ticketId the ticket id
	 * @return the subject matter specialist
	 */
	TicketDataBean getSubjectMatterSpecialist(String ticketId);

	/**
	 * Gets the inc missing ko data.
	 *
	 * @param tktDtAttrVO the tkt dt attr VO
	 * @param isSearchByResolvedDate the is search by resolved date
	 * @return the inc missing ko data
	 */
	List<TicketDataBean> getIncMissingKoData(TicketDataAttributeVO tktDtAttrVO, String isSearchByResolvedDate);

	/**
	 * Checks if is ticket exists.
	 *
	 * @param ticketId the ticket id
	 * @return true, if is ticket exists
	 */
	public boolean isTicketExists(String ticketId);

	/**
	 * Gets the start time of last feed.
	 *
	 * @return the start time of last feed
	 */
	List<TicketDataBean> getStartTimeOfLastFeed();

	/**
	 * Gets the ticket serial number.
	 *
	 * @param ticketID the ticket ID
	 * @return the ticket serial number
	 */
	public Long getTicketSerialNumber(String ticketID);

	/**
	 * Gets the linked tickets.
	 *
	 * @param koID the ko ID
	 * @param accountId the account id
	 * @return the linked tickets
	 */
	public List<TicketDataBean> getLinkedTickets(String koID, String accountId);
}
