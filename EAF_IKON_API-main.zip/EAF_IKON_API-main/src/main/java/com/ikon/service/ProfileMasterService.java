package com.ikon.service;

import java.util.List;
import com.ikon.model.ProfileMaster;

/**
 * The Interface ProfileMasterService.
 */
public interface ProfileMasterService {
    
    /**
     * Find all.
     *
     * @return the list
     */
    public List<ProfileMaster> findAll();
    
    /**
     * Find by id.
     *
     * @param id the id
     * @return the profile master
     */
    ProfileMaster findById(Long id);
}
