package com.ikon.service;

import java.util.List;

import com.ikon.dto.ReportBean;
import com.ikon.dto.ReportDataAttributeVO;

/**
 * The Interface ReportService.
 */
public interface ReportService {
    
	/**
	 * Update favorite report.
	 *
	 * @param reportDataAttributeVO the report data attribute VO
	 * @return the string
	 */
	String updateFavoriteReport(ReportDataAttributeVO reportDataAttributeVO);
	
	/**
	 * Gets the report list view.
	 *
	 * @param accountId the account id
	 * @param userId the user id
	 * @return the report list view
	 */
	List<ReportBean> getReportListView(String accountId, String userId);
	
	/**
	 * Insert report usage.
	 *
	 * @param reportDataAttributeVO the report data attribute VO
	 * @return the string
	 */
	String insertReportUsage(ReportDataAttributeVO reportDataAttributeVO);
	
	/**
	 * Update favorite chart.
	 *
	 * @param reportDataAttributeVO the report data attribute VO
	 * @return the string
	 */
	String updateFavoriteChart(ReportDataAttributeVO reportDataAttributeVO);
	
}
