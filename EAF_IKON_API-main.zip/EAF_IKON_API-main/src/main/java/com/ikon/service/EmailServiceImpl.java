package com.ikon.service;

import javax.inject.Inject;


import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

/**
 * The Class EmailServiceImpl.
 */
@Service("emailService")
public class EmailServiceImpl implements EmailService {

	@Override
	public void sendEmail(Object email) throws Exception {
		// TODO Auto-generated method stub
		
	}

	/** The mail sender. *//*
							 * @Inject private transient JavaMailSender mailSender;
							 */

	/**
	 * Send email.
	 *
	 * @param email the email
	 */
	/*
	 * @Override
	 * 
	 * @Async public void sendEmail(SimpleMailMessage email) throws MailException {
	 * // mailSender.send(email); }
	 */
}
