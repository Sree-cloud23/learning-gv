package com.ikon.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.ikon.model.AccessControl;
import com.ikon.repository.AccessControlRepository;

/**
 * The Class AccessControlServiceImpl.
 */
@Service
public class AccessControlServiceImpl implements AccessControlService {

	/** The access control repository. */
	@Inject
	private transient  AccessControlRepository accessControlRepository;

	/**
	 * Find all.
	 *
	 * @return the list
	 */
	@Override
	public List<AccessControl> findAll() {
		return accessControlRepository.findAll();
	}

	/**
	 * Gets the access detail by user id.
	 *
	 * @param userId the user id
	 * @return the access detail by user id
	 */
	@Override
	public AccessControl getAccessDetailByUserId(String userId) {
		List<AccessControl> accessControlList = accessControlRepository.getAccessControlDetailsByUserName(userId);
		for (AccessControl accessControl : accessControlList) {
			if (accessControl.getUserId().equalsIgnoreCase(userId)) {
				return accessControl;
			}
		}
		return new AccessControl();
	}

}
