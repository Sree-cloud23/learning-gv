package com.ikon.rooca2;

import java.util.Date;

import org.springframework.stereotype.Component;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;

/**
 * The Class JWTTokenGenerator.
 */
@Component
public class JWTTokenGenerator {
	
	/**
	 * Generate token.
	 *
	 * @param username the username
	 * @return the string
	 */
	public String generateToken(String username) {
		Algorithm algorithm = Algorithm.HMAC256("rooca2");
		String token = JWT.create()
						.withIssuer("Ikon2")
						.withSubject("Authentication token")
						.withClaim("preferred_username", username)
						.withIssuedAt(new Date())
						.sign(algorithm);
		return token;
	}
}
