package com.ikon.rooca2;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
/*import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;*/
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.view.RedirectView;

import com.ikon.model.UserMaster;
import com.ikon.repository.UserRepository;

import lombok.extern.slf4j.Slf4j;

/**
 * The Class Rooca2AuthenticationController.
 */
@CrossOrigin(origins = "*")
@RestController
@Slf4j
public class Rooca2AuthenticationController {

	/** The user repo. */
	@Autowired
	private UserRepository userRepo;

	/** The env */
	@Autowired
	private Environment env;

	/** The Constant log. */
	//private static final log log = LogManager.getlog(Rooca2AuthenticationController.class);
	
	/**
	 * Gets the user token.
	 *
	 * @param token the token
	 * @return the user token
	 */
	@GetMapping(value = "/roocaauth/{token}")
	public Map<String, String> getUserToken(@PathVariable String token) {
		String name = null;
		final LocalDateTime now = LocalDateTime.now();
		Map<String, String> map = new ConcurrentHashMap<>();
		UserMaster user = userRepo.findByTokenidAndIsloggedin(token, (short) 1);
		if (user != null) {
			if (now.isBefore(user.getTokenExpTime())) {
				name = user.getUserId();
				final String time = env.getProperty("rooca.session.time.limit");
				if (time != null) {
					user.setTokenExpTime(now.plusMinutes(Long.parseLong(time)));
				}
			} else {
				user.setTokenExpTime(null);
			}
			userRepo.save(user);
		}
		map.put("ikon2UserName", name);
		return map;
	}

	/**
	 * Logout.
	 *
	 * @param request  the request
	 * @param response the response
	 * @return the redirect view
	 */
	@PostMapping(value = "/logout")
	public RedirectView logout(HttpServletRequest request, HttpServletResponse response) {
		return null;

		/*
		 * Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		 * log.info("Inside logout method to clear login status"); if (auth != null) {
		 * String username = auth.getName(); UserMaster userMaster =
		 * userRepo.findByName(username); userMaster.setIsloggedin((short) 0);
		 * userMaster.setTokenExpTime(null); userMaster.setTokenid(null);
		 * userRepo.save(userMaster); log.info("Cleared login status of " + username);
		 * new SecurityContextLogoutHandler().logout(request, response, auth); }
		 * SecurityContextHolder.getContext().setAuthentication(null);
		 * log.info("Redirecting to Ikon 2 Login page"); StringBuffer url =
		 * request.getRequestURL(); log.info("Request from url: " + url.toString());
		 * 
		 * // sprint may deployment start String loginUrl = ""; String logoutRequestFrom
		 * = env.getProperty("ikon2.logout.url.request.from"); if
		 * (url.toString().contains(logoutRequestFrom)) { loginUrl =
		 * env.getProperty("ikon2.login.internal.url"); } else { loginUrl =
		 * env.getProperty("ikon2.login.external.url"); } // sprint may deployment end
		 * 
		 * RedirectView redirectView = new RedirectView();
		 * redirectView.setUrl(loginUrl); return redirectView;
		 */
	}

}