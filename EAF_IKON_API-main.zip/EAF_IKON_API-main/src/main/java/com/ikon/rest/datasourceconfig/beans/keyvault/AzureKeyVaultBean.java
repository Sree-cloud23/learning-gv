package com.ikon.rest.datasourceconfig.beans.keyvault;

import lombok.Getter;
import lombok.Setter;

/**
 * The Azure Key Vault Bean CLass
 */
@Getter
@Setter
public class AzureKeyVaultBean {

	 /**
     * The Azure ClientId Field
     */
    private String clientId;

    /**
     * The Azure TenantId Field
     */
    private String tenantId;

    /**
     * The Azure Client Key Field
     */
    private String clientKey;

    /**
     * The Azure Vault Url Field
     */
    private String url;
	
	
	
}
