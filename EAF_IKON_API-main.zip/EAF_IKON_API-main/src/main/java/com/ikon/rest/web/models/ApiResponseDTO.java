package com.ikon.rest.web.models;

/**
 * The Class ApiResponseDTO.
 */
public class ApiResponseDTO {
	
	/** Status */
	private boolean status;
	
	/** Message */
	private String message;

	/**
	 * Gets the status
	 * @return boolean
	 */
	public boolean isStatus() {
		return status;
	}

	/**
	 * Sets the status
	 * @param status
	 */
	public void setStatus(final boolean status) {
		this.status = status;
	}

	/**
	 * gets the message
	 * @return String
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * sets the message
	 * @param message
	 */
	public void setMessage(final String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "ApiResponseDTO [status=" + status + ", message=" + message + "]";
	}

}
