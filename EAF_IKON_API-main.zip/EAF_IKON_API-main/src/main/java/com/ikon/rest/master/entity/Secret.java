package com.ikon.rest.master.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;


/**
 * entity object to map tenant account information
 */
@Entity
@Table(name = "account_secrets")
@Getter
@Setter
@EqualsAndHashCode
public class Secret implements Serializable{/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/** The Id. */
    @Id
    @Column(name = "id")
    private Integer id;

	/**
	 * Account Id
	 */
    @Column(name = "accountid")
    private String accountId;


    @Column(name = "type")
    private String type;

    /**
     * The Connection CLass Name
     */
    @Column(name = "name")
    private String name;

    @JsonBackReference
    @ManyToOne
    @JoinColumn(name = "accountid", referencedColumnName = "accountid", insertable = false, updatable = false)
    private Tenant tenant;
	
	
} 
