package com.ikon.rest.web.models.dashboard;

import java.math.BigDecimal;
import java.math.BigInteger;

/**
 * The Class AgeingWorkinfoDTO.
 */
public class AgeingWorkinfoDTO {
	
	/** The applicationname. */
	private String applicationname;
	
	/** The assignmentgroup. */
	private String assignmentgroup;
	
	/** The total ticket count. */
	private BigInteger totalTicketCount;
	
	/** The inc update count. */
	private BigInteger incUpdateCount;
	
	/** The inc update perc. */
	private BigDecimal incUpdatePerc;
	
	/** The incident id. */
	//Ageing workinfo detail
	private String incidentId;
	
	/** The summary. */
	private String summary;
	
	/** The assignee. */
	private String assignee;
	
	/** The reported date. */
	private String reportedDate;
	
	/** The priority. */
	private String priority;
	
	/** The status. */
	private String status;
	
	/** The modified date. */
	private String modifiedDate;
	
	/** The ageing. */
	private String ageing;
	
	/** The modified by. */
	private String modifiedBy;
	
	/** The service type. */
	private String serviceType;
	
	/** The sys id. */
	private String sysId;
	
	/**
	 * Gets the application name.
	 *
	 * @return the application name
	 */
	public String getApplicationName() {
		return applicationname;
	}
	
	/**
	 * Sets the application name.
	 *
	 * @param applicationName the new application name
	 */
	public void setApplicationName(String applicationName) {
		this.applicationname = applicationName;
	}
	
	/**
	 * Gets the assignment group.
	 *
	 * @return the assignment group
	 */
	public String getAssignmentGroup() {
		return assignmentgroup;
	}
	
	/**
	 * Sets the assignment group.
	 *
	 * @param assignmentGroup the new assignment group
	 */
	public void setAssignmentGroup(String assignmentGroup) {
		this.assignmentgroup = assignmentGroup;
	}
	
	/**
	 * Gets the total ticket count.
	 *
	 * @return the total ticket count
	 */
	public BigInteger getTotalTicketCount() {
		return totalTicketCount;
	}
	
	/**
	 * Sets the total ticket count.
	 *
	 * @param totalTicketCount the new total ticket count
	 */
	public void setTotalTicketCount(BigInteger totalTicketCount) {
		this.totalTicketCount = totalTicketCount;
	}
	
	/**
	 * Gets the inc update count.
	 *
	 * @return the inc update count
	 */
	public BigInteger getIncUpdateCount() {
		return incUpdateCount;
	}
	
	/**
	 * Sets the inc update count.
	 *
	 * @param incUpdateCount the new inc update count
	 */
	public void setIncUpdateCount(BigInteger incUpdateCount) {
		this.incUpdateCount = incUpdateCount;
	}
	
	/**
	 * Gets the inc update perc.
	 *
	 * @return the inc update perc
	 */
	public BigDecimal getIncUpdatePerc() {
		return incUpdatePerc;
	}
	
	/**
	 * Sets the inc update perc.
	 *
	 * @param incUpdatePerc the new inc update perc
	 */
	public void setIncUpdatePerc(BigDecimal incUpdatePerc) {
		this.incUpdatePerc = incUpdatePerc;
	}
	
	/**
	 * Gets the applicationname.
	 *
	 * @return the applicationname
	 */
	public String getApplicationname() {
		return applicationname;
	}
	
	/**
	 * Sets the applicationname.
	 *
	 * @param applicationname the new applicationname
	 */
	public void setApplicationname(String applicationname) {
		this.applicationname = applicationname;
	}
	
	/**
	 * Gets the assignmentgroup.
	 *
	 * @return the assignmentgroup
	 */
	public String getAssignmentgroup() {
		return assignmentgroup;
	}
	
	/**
	 * Sets the assignmentgroup.
	 *
	 * @param assignmentgroup the new assignmentgroup
	 */
	public void setAssignmentgroup(String assignmentgroup) {
		this.assignmentgroup = assignmentgroup;
	}
	
	/**
	 * Gets the incident id.
	 *
	 * @return the incident id
	 */
	public String getIncidentId() {
		return incidentId;
	}
	
	/**
	 * Sets the incident id.
	 *
	 * @param incidentId the new incident id
	 */
	public void setIncidentId(String incidentId) {
		this.incidentId = incidentId;
	}
	
	/**
	 * Gets the summary.
	 *
	 * @return the summary
	 */
	public String getSummary() {
		return summary;
	}
	
	/**
	 * Sets the summary.
	 *
	 * @param summary the new summary
	 */
	public void setSummary(String summary) {
		this.summary = summary;
	}
	
	/**
	 * Gets the assignee.
	 *
	 * @return the assignee
	 */
	public String getAssignee() {
		return assignee;
	}
	
	/**
	 * Sets the assignee.
	 *
	 * @param assignee the new assignee
	 */
	public void setAssignee(String assignee) {
		this.assignee = assignee;
	}
	
	/**
	 * Gets the reported date.
	 *
	 * @return the reported date
	 */
	public String getReportedDate() {
		return reportedDate;
	}
	
	/**
	 * Sets the reported date.
	 *
	 * @param reportedDate the new reported date
	 */
	public void setReportedDate(String reportedDate) {
		this.reportedDate = reportedDate;
	}
	
	/**
	 * Gets the priority.
	 *
	 * @return the priority
	 */
	public String getPriority() {
		return priority;
	}
	
	/**
	 * Sets the priority.
	 *
	 * @param priority the new priority
	 */
	public void setPriority(String priority) {
		this.priority = priority;
	}
	
	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	
	/**
	 * Sets the status.
	 *
	 * @param status the new status
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	
	/**
	 * Gets the modified date.
	 *
	 * @return the modified date
	 */
	public String getModifiedDate() {
		return modifiedDate;
	}
	
	/**
	 * Sets the modified date.
	 *
	 * @param modifiedDate the new modified date
	 */
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	
	/**
	 * Gets the ageing.
	 *
	 * @return the ageing
	 */
	public String getAgeing() {
		return ageing;
	}
	
	/**
	 * Sets the ageing.
	 *
	 * @param ageing the new ageing
	 */
	public void setAgeing(String ageing) {
		this.ageing = ageing;
	}
	
	/**
	 * Gets the modified by.
	 *
	 * @return the modified by
	 */
	public String getModifiedBy() {
		return modifiedBy;
	}
	
	/**
	 * Sets the modified by.
	 *
	 * @param modifiedBy the new modified by
	 */
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	
	/**
	 * Gets the service type.
	 *
	 * @return the service type
	 */
	public String getServiceType() {
		return serviceType;
	}
	
	/**
	 * Sets the service type.
	 *
	 * @param serviceType the new service type
	 */
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	
	/**
	 * Gets the sys id.
	 *
	 * @return the sys id
	 */
	public String getSysId() {
		return sysId;
	}
	
	/**
	 * Sets the sys id.
	 *
	 * @param sysId the new sys id
	 */
	public void setSysId(String sysId) {
		this.sysId = sysId;
	}
	
	/**
	 * To string.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return "AgeingWorkinfoDTO [applicationname=" + applicationname + ", assignmentgroup=" + assignmentgroup
				+ ", totalTicketCount=" + totalTicketCount + ", incUpdateCount=" + incUpdateCount + ", incUpdatePerc="
				+ incUpdatePerc + ", incidentId=" + incidentId + ", summary=" + summary + ", assignee=" + assignee
				+ ", reportedDate=" + reportedDate + ", priority=" + priority + ", status=" + status + ", modifiedDate="
				+ modifiedDate + ", ageing=" + ageing + ", modifiedBy=" + modifiedBy + ", serviceType=" + serviceType
				+ ", sysId=" + sysId + "]";
	}
	
	
	
	
	

}
