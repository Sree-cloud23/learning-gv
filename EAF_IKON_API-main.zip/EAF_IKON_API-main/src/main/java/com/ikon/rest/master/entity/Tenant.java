package com.ikon.rest.master.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


/**
 * entity object to map tenant account information
 */
@Entity
@Table(name = "account_mapping")
@Getter
@Setter
@EqualsAndHashCode
@ToString
public class Tenant implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Tenant Id
	 */

	@Column(name = "tenantid")
	private String tenantId;

	/**
	 * Account Id
	 */
	@Id
	@Column(name = "accountid")
	private String accountId;

	/**
	 * Active Status field
	 */
	@Column(name = "active")
	private boolean active;

	/**
	 * Tenant Connection Config
	 */
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "accountid", referencedColumnName = "accountid", insertable = false, updatable = false)
	private ConnectionConfig connectionConfig;

	/**
	 * Tenant Properties
	 */
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "accountid", referencedColumnName = "accountid", insertable = false, updatable = false)
	private ApplicationProperties applicationProperties;

	/**
	 * List of secrets
	 */
	@OneToMany(cascade=CascadeType.ALL, mappedBy= "tenant")
	@LazyCollection(LazyCollectionOption.FALSE)
	private List<Secret> secrets;
	
}
