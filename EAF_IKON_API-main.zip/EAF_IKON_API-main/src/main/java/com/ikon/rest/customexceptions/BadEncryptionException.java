package com.ikon.rest.customexceptions;

public class BadEncryptionException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Constructor to initialize exception object
	 * 
	 * @param message
	 */
	public BadEncryptionException(final String message) {
		super(message);
	}

}
