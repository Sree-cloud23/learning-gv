package com.ikon.rest.web.models.dashboard;

import java.math.BigInteger;
import java.util.Date;

public class RunToZeroDTO {

	 /** The Serial number. */
    private Integer SerialNumber;
	
    /** The ticket ID. */
    private String ticketID;
    
    /** The summary. */
    private String summary;
    
    /** The application name. */
    private String applicationName;
    
    /** The assignment group. */
    private String assignmentGroup;
    
    /** The assignee name. */
    private String assigneeName;    
    
    /** The status. */
    private String status;
    
    /** The service type. */
    private String serviceType;
    
    /** The urgency. */
    private String urgency;
    
    /** The priority. */
    private String priority;
    
  private String impact;
    
    /** The reported date. */
    private Date reportedDate;
    
    /** The work notes. */
    private String workNotes;
    
    /** The Last modified by. */
    private String LastModifiedBy;
    
    /** The last modified date. */
    private Date lastModifiedDate;
    
    /** The resolved date. */
    private Date resolvedDate;
    
    /** The relev perc. */
    private String relevPerc;
    
    /** The usage perc. */
    private String usagePerc;
    
    /**ticketLinkedCount*/
    private BigInteger ticketLinkedCount;
    
    
    private String sysId;

	public Integer getSerialNumber() {
		return SerialNumber;
	}

	public void setSerialNumber(Integer serialNumber) {
		SerialNumber = serialNumber;
	}

	public String getTicketID() {
		return ticketID;
	}

	public void setTicketID(String ticketID) {
		this.ticketID = ticketID;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public String getApplicationName() {
		return applicationName;
	}

	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}

	public String getAssignmentGroup() {
		return assignmentGroup;
	}

	public void setAssignmentGroup(String assignmentGroup) {
		this.assignmentGroup = assignmentGroup;
	}

	public String getAssigneeName() {
		return assigneeName;
	}

	public void setAssigneeName(String assigneeName) {
		this.assigneeName = assigneeName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public String getUrgency() {
		return urgency;
	}

	public void setUrgency(String urgency) {
		this.urgency = urgency;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getImpact() {
		return impact;
	}

	public void setImpact(String impact) {
		this.impact = impact;
	}

	public Date getReportedDate() {
		return reportedDate;
	}

	public void setReportedDate(Date reportedDate) {
		this.reportedDate = reportedDate;
	}

	public String getWorkNotes() {
		return workNotes;
	}

	public void setWorkNotes(String workNotes) {
		this.workNotes = workNotes;
	}

	public String getLastModifiedBy() {
		return LastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		LastModifiedBy = lastModifiedBy;
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(Date lastModifiedDate) {

		this.lastModifiedDate = lastModifiedDate;
	}

	public Date getResolvedDate() {
		return resolvedDate;
	}

	public void setResolvedDate(Date resolvedDate) {
		this.resolvedDate = resolvedDate;
	}

	public String getRelevPerc() {
		return relevPerc;
	}

	public void setRelevPerc(String relevPerc) {
		this.relevPerc = relevPerc;
	}

	public String getUsagePerc() {
		return usagePerc;
	}

	public void setUsagePerc(String usagePerc) {
		this.usagePerc = usagePerc;
	}

	public BigInteger getTicketLinkedCount() {
		return ticketLinkedCount;
	}

	public void setTicketLinkedCount(BigInteger ticketLinkedCount) {
		this.ticketLinkedCount = ticketLinkedCount;
	}

	public String getSysId() {
		return sysId;
	}

	
	public void setSysId(String sysId) {
		this.sysId = sysId;
	}
	
	
    
    
    
}
