package com.ikon.rest.web.models.dashboard;

/**
 * The Class IncMissingKODTO.
 */
public class IncMissingKODTO {
	
	/** The ticket id. */
	private String ticketId;
	
	/** The summary. */
	private String summary;
	
	/** The ticket type. */
	private String ticketType;
	
	/** The application name. */
	private String applicationName;
	
	/** The assignment group. */
	private String assignmentGroup;
	
	/** The assignee. */
	private String assignee;
	
	/** The status. */
	private String status;
	
	/** The month. */
	private String month;
	
	/** The inc linked. */
	private String incLinked;
	
	/** The inc resolved. */
	private String incResolved;
	
	private String sysId;

	/**
	 * Gets the ticket id.
	 *
	 * @return the ticket id
	 */
	public String getTicketId() {
		return ticketId;
	}

	/**
	 * Sets the ticket id.
	 *
	 * @param ticketId the new ticket id
	 */
	public void setTicketId(String ticketId) {
		this.ticketId = ticketId;
	}

	/**
	 * Gets the summary.
	 *
	 * @return the summary
	 */
	public String getSummary() {
		return summary;
	}

	/**
	 * Sets the summary.
	 *
	 * @param summary the new summary
	 */
	public void setSummary(String summary) {
		this.summary = summary;
	}

	/**
	 * Gets the ticket type.
	 *
	 * @return the ticket type
	 */
	public String getTicketType() {
		return ticketType;
	}

	/**
	 * Sets the ticket type.
	 *
	 * @param ticketType the new ticket type
	 */
	public void setTicketType(String ticketType) {
		this.ticketType = ticketType;
	}

	/**
	 * Gets the application name.
	 *
	 * @return the application name
	 */
	public String getApplicationName() {
		return applicationName;
	}

	/**
	 * Sets the application name.
	 *
	 * @param applicationName the new application name
	 */
	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}

	/**
	 * Gets the assignment group.
	 *
	 * @return the assignment group
	 */
	public String getAssignmentGroup() {
		return assignmentGroup;
	}

	/**
	 * Sets the assignment group.
	 *
	 * @param assignmentGroup the new assignment group
	 */
	public void setAssignmentGroup(String assignmentGroup) {
		this.assignmentGroup = assignmentGroup;
	}

	/**
	 * Gets the assignee.
	 *
	 * @return the assignee
	 */
	public String getAssignee() {
		return assignee;
	}

	/**
	 * Sets the assignee.
	 *
	 * @param assignee the new assignee
	 */
	public void setAssignee(String assignee) {
		this.assignee = assignee;
	}

	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Sets the status.
	 *
	 * @param status the new status
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Gets the inc linked.
	 *
	 * @return the inc linked
	 */
	public String getIncLinked() {
		return incLinked;
	}

	/**
	 * Sets the inc linked.
	 *
	 * @param incLinked the new inc linked
	 */
	public void setIncLinked(String incLinked) {
		this.incLinked = incLinked;
	}

	/**
	 * Gets the inc resolved.
	 *
	 * @return the inc resolved
	 */
	public String getIncResolved() {
		return incResolved;
	}

	/**
	 * Sets the inc resolved.
	 *
	 * @param incResolved the new inc resolved
	 */
	public void setIncResolved(String incResolved) {
		this.incResolved = incResolved;
	}

	/**
	 * Gets the month.
	 *
	 * @return the month
	 */
	public String getMonth() {
		return month;
	}

	/**
	 * Sets the month.
	 *
	 * @param month the new month
	 */
	public void setMonth(String month) {
		this.month = month;
	}
	

	public String getSysId() {
		return sysId;
	}

	public void setSysId(String sysId) {
		this.sysId = sysId;
	}

	/**
	 * To string.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return "IncMissingKODTO [ticketId=" + ticketId + ", summary=" + summary + ", ticketType=" + ticketType
				+ ", applicationName=" + applicationName + ", assignmentGroup=" + assignmentGroup + ", assignee="
				+ assignee + ", status=" + status + ", month=" + month + ", incLinked=" + incLinked + ", incResolved="
				+ incResolved + "]";
	}
	
	

}
