package com.ikon.rest.master.entity;


import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * entity object to map tenant account information
 */
@Entity
@Table(name = "connection_config")
@Getter
@Setter
@EqualsAndHashCode
public class ConnectionConfig implements Serializable{/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
     * Account Id
     */
    @Id
    @Column(name = "accountid")
    private String accountId;


    @Column(name = "url")
    private String url;

    /**
     * The Connection CLass Name
     */
    @Column(name = "classname")
    private String className;

    /**
     * The Pool Sizes
     */
    @Column(name = "poolsizes")
    private String poolSizes;

    /**
     * The Pool Sizes
     */
    @Column(name = "username")
    private String userName;

    /**
     * The Pool Sizes
     */
    @Column(name = "password")
    private String password;
	
}
