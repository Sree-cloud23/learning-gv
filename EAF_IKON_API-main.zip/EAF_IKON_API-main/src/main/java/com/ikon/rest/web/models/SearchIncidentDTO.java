package com.ikon.rest.web.models;

public class SearchIncidentDTO {

	  /** The koid. */
	  private String koid;
	  
	 /** The application name. */
	  private String applicationName;
	  
	  /** The assignment group. */
	  private String assignmentGroup;
	  
	  /** The cause code level. */
	  private String causeCode;

	  /**
	   * 
	   * @return
	   */
	public String getApplicationName() {
		return applicationName;
	}

	/**
	 * 
	 * @param applicationName
	 */
	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}

	/**
	 * 
	 * @return
	 */
	public String getAssignmentGroup() {
		return assignmentGroup;
	}

	/**
	 * 
	 * @param assignmentGroup
	 */
	public void setAssignmentGroup(String assignmentGroup) {
		this.assignmentGroup = assignmentGroup;
	}

	/**
	 * 
	 * @return
	 */
	public String getCauseCode() {
		return causeCode;
	}

	/**
	 * 
	 * @param causeCode
	 */
	public void setCauseCode(String causeCode) {
		this.causeCode = causeCode;
	}

	/**
	 * 
	 * @return
	 */
	public String getKoid() {
		return koid;
	}

	/**
	 * 
	 * @param koid
	 */
	public void setKoid(String koid) {
		this.koid = koid;
	}
	
	
	
	  
	  
	  
}
