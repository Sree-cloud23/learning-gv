package com.ikon.rest.web.models.dashboard;

public class ComplianceDTO {
	
	/** The inc resolved. */
	private String incResolved;
	
	/** The sr resolved. */
	private String srResolved;
	
	/** The total resolved. */
	private String totalResolved;
	
	/** The ko created. */
	private String koCreated;
	
	/** The ko linked. */
	private String koLinked;
	
	/** The res vs linked. */
	private String resVsLinked;
	
	/** The assignment group. */
	private String assignmentGroup;
	
	/** The application Name. */
	private String applicationName;
	
	/** The Months Name. */
	private String month;

	public String getIncResolved() {
		return incResolved;
	}

	public void setIncResolved(String incResolved) {
		this.incResolved = incResolved;
	}

	public String getSrResolved() {
		return srResolved;
	}

	public void setSrResolved(String srResolved) {
		this.srResolved = srResolved;
	}

	public String getTotalResolved() {
		return totalResolved;
	}

	public void setTotalResolved(String totalResolved) {
		this.totalResolved = totalResolved;
	}

	public String getKoCreated() {
		return koCreated;
	}

	public void setKoCreated(String koCreated) {
		this.koCreated = koCreated;
	}

	public String getKoLinked() {
		return koLinked;
	}

	public void setKoLinked(String koLinked) {
		this.koLinked = koLinked;
	}

	public String getResVsLinked() {
		return resVsLinked;
	}

	public void setResVsLinked(String resVsLinked) {
		this.resVsLinked = resVsLinked;
	}

	public String getAssignmentGroup() {
		return assignmentGroup;
	}

	public void setAssignmentGroup(String assignmentGroup) {
		this.assignmentGroup = assignmentGroup;
	}

	public String getApplicationName() {
		return applicationName;
	}

	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}

	public String getMonths() {
		return month;
	}

	public void setMonths(String months) {
		this.month = months;
	}

	@Override
	public String toString() {
		return "ComplianceDTO [incResolved=" + incResolved + ", srResolved=" + srResolved + ", totalResolved="
				+ totalResolved + ", koCreated=" + koCreated + ", koLinked=" + koLinked + ", resVsLinked=" + resVsLinked
				+ ", assignmentGroup=" + assignmentGroup + ", applicationName=" + applicationName + ", months=" + month
				+ "]";
	}

	
	
}
