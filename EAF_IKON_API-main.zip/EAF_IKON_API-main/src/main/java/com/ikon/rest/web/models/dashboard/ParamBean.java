package com.ikon.rest.web.models.dashboard;

import java.util.List;

import com.ikon.rest.web.models.MultilingualKOStatusDTO;

public class ParamBean {

	List<MultilingualKOStatusDTO> reportChartType;
	
	List<MultilingualKOStatusDTO> reportName;
	
	List<MultilingualKOStatusDTO> chartName;
	
	List<MultilingualKOStatusDTO> frequency;
	
	List<MultilingualKOStatusDTO> koStatus;

	public List<MultilingualKOStatusDTO> getReportChartType() {
		return reportChartType;
	}

	public void setReportChartType(List<MultilingualKOStatusDTO> reportChartType) {
		this.reportChartType = reportChartType;
	}

	public List<MultilingualKOStatusDTO> getReportName() {
		return reportName;
	}

	public void setReportName(List<MultilingualKOStatusDTO> reportName) {
		this.reportName = reportName;
	}

	public List<MultilingualKOStatusDTO> getChartName() {
		return chartName;
	}

	public void setChartName(List<MultilingualKOStatusDTO> chartName) {
		this.chartName = chartName;
	}

	public List<MultilingualKOStatusDTO> getFrequency() {
		return frequency;
	}

	public void setFrequency(List<MultilingualKOStatusDTO> frequency) {
		this.frequency = frequency;
	}

	public List<MultilingualKOStatusDTO> getKoStatus() {
		return koStatus;
	}

	public void setKoStatus(List<MultilingualKOStatusDTO> koStatus) {
		this.koStatus = koStatus;
	}
	
	
	
}
