package com.ikon.rest.datasourceconfig.beans.keyvault;

import lombok.Getter;
import lombok.Setter;

/**
 * The AWS Key Vault Bean Class
 */
@Getter
@Setter
public class AWSKeyVaultBean {


    /**
     * The URL field
     */
    private String url;

    /**
     * The token field
     */
    private String token;

	
}
