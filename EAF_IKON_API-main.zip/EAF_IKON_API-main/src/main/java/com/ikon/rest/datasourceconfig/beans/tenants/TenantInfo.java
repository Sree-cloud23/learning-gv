package com.ikon.rest.datasourceconfig.beans.tenants;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Tenant Info Class
 *
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class TenantInfo {

	/**
	 * The AccountID
	 */
	private String accountId;
	/**
	 * The KoPrefix
	 */
	private String koPrefix;
	/**
	 * The KoStartingNumber
	 */
	private String koStartingNumber;
	/**
	 * The AttachmentBase
	 */
	private String attachmentBase;
	/**
	 * The accountName
	 */
	private String accountName;
	/**
	 * The attachmentTypeBases
	 */
	private String attachmentTypeBases;
	/**
	 * The staticToken
	 */
	private String staticToken;
	/**
	 * The updateKbToDL
	 */
	private String updateKbToDl;

}
