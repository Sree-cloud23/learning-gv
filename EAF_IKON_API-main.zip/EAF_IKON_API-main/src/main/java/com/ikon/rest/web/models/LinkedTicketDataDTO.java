package com.ikon.rest.web.models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

/**
 * The LinkedTicketDataDTO Class
 *
 */
@AllArgsConstructor
@NoArgsConstructor
@Getter
public class LinkedTicketDataDTO {

	/** The ticket ID. */
    private String ticketID;
    
    /** The resolution note. */
    private String resolutionNote;
    
    /** The summary. */
    private String summary;
    
    /** The notes. */
    private String notes;
    
    /** The category. */
    private String category;
    
    /** The relev perc. */
    private String relevPerc;
    
    /** The usage perc. */
    private String usagePerc;
}
