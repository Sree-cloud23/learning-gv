package com.ikon.rest.customexceptions;

public class InvalidTenantException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Constructor to initialize exception object
	 * 
	 * @param message
	 */
	public InvalidTenantException(final String message) {
		super(message);
	}
}
