package com.ikon.rest.web.models;

/**
 * The Class DLkbLink.
 */
public class DLkbLink {
	
	/** The sys id. */
	private String sys_id;
	
	/** The kb article. */
	private String kb_article;
	
	/** The created by. */
	private String created_by;
	
	/** The incident type. */
	private String incident_type;
	
	/**
	 * Gets the sys id.
	 *
	 * @return the sys id
	 */
	public String getSys_id() {
		return sys_id;
	}
	
	/**
	 * Sets the sys id.
	 *
	 * @param sys_id the new sys id
	 */
	public void setSys_id(String sys_id) {
		this.sys_id = sys_id;
	}
	
	/**
	 * Gets the kb article.
	 *
	 * @return the kb article
	 */
	public String getKb_article() {
		return kb_article;
	}
	
	/**
	 * Sets the kb article.
	 *
	 * @param kb_article the new kb article
	 */
	public void setKb_article(String kb_article) {
		this.kb_article = kb_article;
	}
	
	/**
	 * Gets the created by.
	 *
	 * @return the created by
	 */
	public String getCreated_by() {
		return created_by;
	}
	
	/**
	 * Sets the created by.
	 *
	 * @param created_by the new created by
	 */
	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}
	
	
	/**
	 *Get Incident type 	
	 */
	public String getIncident_type() {
		return incident_type;
	}

	/**
	 * 
	 * @param incident_type
	 * Sets the incident_type.
	 */
	public void setIncident_type(String incident_type) {
		this.incident_type = incident_type;
	}
	
	

	
	/**
	 * To string.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return "DLkbLink [sys_id=" + sys_id + ", kb_article=" + kb_article + ", created_by=" + created_by
				+ ", incident_type=" + incident_type + "]";
	}



	/**
	 * Instantiates a new d lkb link.
	 *
	 * @param sys_id the sys id
	 * @param kb_article the kb article
	 * @param created_by the created by
	 * @param incident_type the incident_type
	 */
	public DLkbLink(String sys_id, String kb_article, String created_by, String incident_type) {
		super();
		this.sys_id = sys_id;
		this.kb_article = kb_article;
		this.created_by = created_by;
		this.incident_type = incident_type;
	}


}
