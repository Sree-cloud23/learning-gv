package com.ikon.rest.service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.google.gson.JsonObject;
import com.ikon.dto.KOInfoBean;
import com.ikon.dto.TicketDataBean;
import com.ikon.model.KOArtifacts;
import com.ikon.model.KOInfo;
import com.ikon.repository.KOArtifactsRepository;
import com.ikon.repository.KOInfoRepository;
import com.ikon.rest.datasourceconfig.tenants.TenantContextHolder;
import com.ikon.rest.web.models.AttachmentDTO;
import com.ikon.rest.web.models.IncidentRelatedKODTO;
import com.ikon.rest.web.models.KODetailsDTO;
import com.ikon.rest.web.models.KOInfoDTO;
import com.ikon.rest.web.models.KOReviewCommnetsDTO;
import com.ikon.rest.web.models.MultilingualKOStatusDTO;
import com.ikon.rest.web.models.TicketDataDTO;
import com.ikon.rest.web.models.UserDTO;
import com.ikon.rest.web.models.WorkNoteDTO;

import lombok.extern.slf4j.Slf4j;


/**
 * The Class KOInfoServiceImplRest.
 */
@SuppressWarnings("deprecation")
@Service
@Slf4j
public class KOInfoServiceImplRest implements KOInfoServiceRest {

	/** The entity manager. */
	@PersistenceContext(unitName = "multiEntityManager")
	private EntityManager entityManager;
	
	/** The Constant log. */
	//private static final log log = LogManager.getlog(KOInfoServiceImplRest.class);
	
	/** The k O artifacts repository. */
	@Autowired
	private transient KOArtifactsRepository kOArtifactsRepository;
	
	/** The k O info repository. */
	@Autowired
	private transient KOInfoRepository kOInfoRepository;
	
	/** The attach type bases. */
//	@Value("${ikon2.attachmentTypeBases}")
	//private String attachTypeBases;
	
	/** The attach base. */
//	@Value("${ikon2.attachmentBase}")
//	private String attachBase;
	
	/** The account name. */
//	@Value("${ikon2.accountName}")
//	private String accountName;
	
	/** The tower */
	@Value("${KO.tower}")
	private String koTower;
	
	/** The Environment. */
	@Autowired
	private Environment env;
	
	/** The Constant ACCOUNT_ID. */
	private static final String ACCOUNT_ID = "1";


	/**
	 * Insert ticket detail.
	 *
	 * @param ticketDataDTO the ticket data DTO
	 * @return the int
	 */
	@Override
	@Transactional
	public int insertTicketDetail(TicketDataDTO ticketDataDTO){

		// to insert data to staging table
		int executeResult = 0;
		Session session = entityManager.unwrap( Session.class );

		StringBuffer query = new StringBuffer();
		query.append("insert into ticket_data_inter")
		.append("(\"accountid\",\"ticketid\",\"summary\",\"notes\",\"applicationname\",\"assignmentgroup\",\"assigneename\",\"status\",\"closeddate\",\"closedby\",\"resolutionnote\",\"servicetype\",\"company\",\"category\",")
		.append("\"subcategory\",\"urgency\",\"priority\",\"impact\",\"reporteddate\",\"worknotes\",\"lastmodifiedby\",\"lastmodifieddate\",\"resolveddate\",\"openedby\",\"location\",\"causecode1\",\"causecode2\",\"causecode3\",")
		.append("\"causecode4\",\"causecode5\",\"breachexception\",\"breachreason\",\"environment\",\"estimatedresolutiondate\",\"incidentassociationtype\",\"supportcompany\",\"apptier\",\"nexttargetdate\",\"operationalcategorizationtier1\",\"operationalcategorizationtier2\",\"operationalcategorizationtier3\",")
		.append("\"productcategorizationtier1\",\"productcategorizationtier2\",\"productcategorizationtier3\",\"slmstatus\",\"supportorganization\",\"processrelevancy\",\"statusreason\",\"contacttype\",\"resolutioncategory\",\"callerid\",\"closecode\",\"duedate\",\"reassignmentcount\",\"breachtime\",\"inccause\",\"sys_id\")")
		.append(" values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
		.append(" on conflict (\"ticketid\") do update set accountid=excluded.accountid,\"ticketid\"=?,\"summary\"=?,\"notes\"=?,\"applicationname\"=?,\"assignmentgroup\"=?,\"assigneename\"=?,\"status\"=?,\"closeddate\"=?,"
						+ "\"closedby\"=?,\"resolutionnote\"=?,\"servicetype\"=?,\"company\"=?,\"category\"=?,\"subcategory\"=?,\"urgency\"=?,\"priority\"=?,\"impact\"=?,\"reporteddate\"=?,"
						+ "\"worknotes\"=?,\"lastmodifiedby\"=?,\"lastmodifieddate\"=?,\"resolveddate\"=?,\"openedby\"=?,\"location\"=?,\"causecode1\"=?,\"causecode2\"=?,"
						+ "\"causecode3\"=?,\"causecode4\"=?,\"causecode5\"=?,\"breachexception\"=?,\"breachreason\"=?,\"environment\"=?,\"estimatedresolutiondate\"=?,"
						+ "\"incidentassociationtype\"=?,\"supportcompany\"=?,\"apptier\"=?,")
		.append("\"nexttargetdate\"=?,\"operationalcategorizationtier1\"=?,\"operationalcategorizationtier2\"=?,\"operationalcategorizationtier3\"=?,")
		.append("\"productcategorizationtier1\"=?,\"productcategorizationtier2\"=?,\"productcategorizationtier3\"=?,\"slmstatus\"=?,\"supportorganization\"=?,")
		.append("\"processrelevancy\"=?,\"statusreason\"=?,\"contacttype\"=?,\"resolutioncategory\"=?,\"callerid\"=?,\"closecode\"=?,\"duedate\"=?,\"reassignmentcount\"=?,"
						+ "\"breachtime\"=?,\"inccause\"=?,\"sys_id\"=?");
			
			Query query1 = session.createSQLQuery(query.toString()).setResultTransformer(Transformers.aliasToBean(TicketDataDTO.class));

			setTicketDataInterQueryParams(query1,ticketDataDTO);
			executeResult = query1.executeUpdate();
		return executeResult;
	}

	/**
	 * Sets the ticket data inter query params.
	 *
	 * @param query1 the query 1
	 * @param ticketDataDTO the ticket data DTO
	 */
	private void setTicketDataInterQueryParams(Query query1, TicketDataDTO ticketDataDTO) {
		
		log.info("Opened date: "+ticketDataDTO.getOpenedDate());
		log.info("Due date: "+ticketDataDTO.getDueDate());
		log.info("Last Modified date: "+ticketDataDTO.getLastModifiedDate());
		log.info("Resolved date: "+ticketDataDTO.getResolvedAt());
		log.info("Closed date: "+ticketDataDTO.getClosedAt());
		
		query1.setParameter(1, 1); //Account Id is an integer
		query1.setParameter(2, ticketDataDTO.getNumber());
		query1.setParameter(3, ticketDataDTO.getShortDescription());
		query1.setParameter(4, ticketDataDTO.getDescription());
		query1.setParameter(5, checkNull(ticketDataDTO.getApplicationName()));
		query1.setParameter(6, ticketDataDTO.getAssignmentGroup());
		query1.setParameter(7, ticketDataDTO.getAssignedTo());
		query1.setParameter(8, ticketDataDTO.getState());
		query1.setTimestamp(9, ticketDataDTO.getClosedAt());// Closed At
		query1.setParameter(10, ticketDataDTO.getClosedBy());
		query1.setParameter(11, ticketDataDTO.getResolutionNote());
		query1.setParameter(12, ticketDataDTO.getServiceType());
		query1.setParameter(13, ticketDataDTO.getCompany());
		query1.setParameter(14, ticketDataDTO.getCategory());
		query1.setParameter(15, ticketDataDTO.getSubCategory());
		query1.setParameter(16, ticketDataDTO.getUrgency());
		query1.setParameter(17, ticketDataDTO.getPriority());
		query1.setParameter(18, ticketDataDTO.getImpact());
		query1.setTimestamp(19, ticketDataDTO.getOpenedDate()); // Reported Date
		
		//query1.setParameter(20, ticketDataDTO.getWorkNotes()); // Additional Comments
		
		List<WorkNoteDTO> workNotes = ticketDataDTO.getWorkNotes();
		StringBuilder workNote = new StringBuilder();
		if(workNotes != null) {
			for(WorkNoteDTO workNoteDto: workNotes) {
				workNote.append(workNoteDto.getValue());
				workNote.append(" ");
			}
		}
		
		query1.setParameter(20, workNote.toString()); // Additional Comments
		
		query1.setParameter(21, ticketDataDTO.getLastModifiedBy());
		query1.setTimestamp(22, ticketDataDTO.getLastModifiedDate());
		query1.setTimestamp(23, ticketDataDTO.getResolvedAt());
		query1.setParameter(24, ticketDataDTO.getOpenedBy());
		query1.setParameter(25, ticketDataDTO.getLocation());
		query1.setParameter(26, ticketDataDTO.getCauseCodeLevel1());
		query1.setParameter(27, ticketDataDTO.getCauseCodeLevel2());
		query1.setParameter(28, ticketDataDTO.getCauseCodeLevel3());
		query1.setParameter(29, null); // getCauseCodeLevel4
		query1.setParameter(30, null); // getCauseCodeLevel5
		query1.setParameter(31, null); // Breach Exception
		query1.setParameter(32, null); // Breach Reason
		query1.setParameter(33, null); // Environment
		query1.setTimestamp(34, ticketDataDTO.getDueDate());
		query1.setParameter(35, null); // Associate Type
		query1.setParameter(36, null); // getSupportCompany
		query1.setParameter(37, null); // getAppTier
		query1.setTimestamp(38, null); // getNextTargetDate
		query1.setParameter(39, null); // getOperationalCategorizationTier1
		query1.setParameter(40, null); // getOperationalCategorizationTier2
		query1.setParameter(41, null); // getOperationalCategorizationTier3
		query1.setParameter(42, null); // getProductCategorizationTier1
		query1.setParameter(43, null); // getProductCategorizationTier2
		query1.setParameter(44, null); // getProductCategorizationTier3
		query1.setParameter(45, null); // getSLMStatus
		query1.setParameter(46, null); // getSupportOrganization
		query1.setParameter(47, 1);
		query1.setParameter(48, null); // getStatusReason
		query1.setParameter(49, null); // getContactType
		query1.setParameter(50, ticketDataDTO.getResolutionCategory());
		query1.setParameter(51, ticketDataDTO.getCallerId());
		query1.setParameter(52, null); // closeDate
		query1.setTimestamp(53, ticketDataDTO.getDueDate());
		query1.setParameter(54, null); // getReassignmentCount
		query1.setTimestamp(55, null); // getBreachTime
		query1.setParameter(56, null); // getINCCause
		query1.setParameter(57, ticketDataDTO.getSys_id());
		
		//query1.setParameter(57, 1); //Account Id is an integer
		query1.setParameter(58, ticketDataDTO.getNumber());
		query1.setParameter(59, ticketDataDTO.getShortDescription());
		query1.setParameter(60, ticketDataDTO.getDescription());
		query1.setParameter(61, checkNull(ticketDataDTO.getApplicationName()));
		query1.setParameter(62, ticketDataDTO.getAssignmentGroup());
		query1.setParameter(63, ticketDataDTO.getAssignedTo());
		query1.setParameter(64, ticketDataDTO.getState());
		query1.setTimestamp(65, ticketDataDTO.getClosedAt());// Closed At
		query1.setParameter(66, ticketDataDTO.getClosedBy());
		query1.setParameter(67, ticketDataDTO.getResolutionNote());
		query1.setParameter(68, ticketDataDTO.getServiceType());
		query1.setParameter(69, ticketDataDTO.getCompany());
		query1.setParameter(70, ticketDataDTO.getCategory());
		query1.setParameter(71, ticketDataDTO.getSubCategory());
		query1.setParameter(72, ticketDataDTO.getUrgency());
		query1.setParameter(73, ticketDataDTO.getPriority());
		query1.setParameter(74, ticketDataDTO.getImpact());
		query1.setTimestamp(75, ticketDataDTO.getOpenedDate()); // Reported Date
	
		//query1.setParameter(20, ticketDataDTO.getWorkNotes()); // Additional Comments
		query1.setParameter(76, workNote.toString()); // Additional Comments
		
		query1.setParameter(77, ticketDataDTO.getLastModifiedBy());
		query1.setTimestamp(78, ticketDataDTO.getLastModifiedDate());
		query1.setTimestamp(79, ticketDataDTO.getResolvedAt());
		query1.setParameter(80, ticketDataDTO.getOpenedBy());
		query1.setParameter(81, ticketDataDTO.getLocation());
		query1.setParameter(82, ticketDataDTO.getCauseCodeLevel1());
		query1.setParameter(83, ticketDataDTO.getCauseCodeLevel2());
		query1.setParameter(84, ticketDataDTO.getCauseCodeLevel3());
		query1.setParameter(85, null); // getCauseCodeLevel4
		query1.setParameter(86, null); // getCauseCodeLevel5
		query1.setParameter(87, null); // Breach Exception
		query1.setParameter(88, null); // Breach Reason
		query1.setParameter(89, null); // Environment
		query1.setTimestamp(90, ticketDataDTO.getDueDate());
		query1.setParameter(91, null); // Associate Type
		query1.setParameter(92, null); // getSupportCompany
		query1.setParameter(93, null); // getAppTier
		query1.setTimestamp(94, null); // getNextTargetDate
		query1.setParameter(95, null); // getOperationalCategorizationTier1
		query1.setParameter(96, null); // getOperationalCategorizationTier2
		query1.setParameter(97, null); // getOperationalCategorizationTier3
		query1.setParameter(98, null); // getProductCategorizationTier1
		query1.setParameter(99, null); // getProductCategorizationTier2
		query1.setParameter(100, null); // getProductCategorizationTier3
		query1.setParameter(101, null); // getSLMStatus
		query1.setParameter(102, null); // getSupportOrganization
		query1.setParameter(103, 1);
		query1.setParameter(104, null); // getStatusReason
		query1.setParameter(105, null); // getContactType
		query1.setParameter(106, ticketDataDTO.getResolutionCategory());
		query1.setParameter(107, ticketDataDTO.getCallerId());
		query1.setParameter(108, null); // closeDate
		query1.setTimestamp(109, ticketDataDTO.getDueDate());
		query1.setParameter(110, null); // getReassignmentCount
		query1.setTimestamp(111, null); // getBreachTime
		query1.setParameter(112, null); // getINCCause
		query1.setParameter(113, ticketDataDTO.getSys_id());
		
	}

	/**
	 * Run stored procedure with no param.
	 */
	@Override
	@Transactional
	public void runStoredProcedureWithNoParam() {
		try {
			
//			StoredProcedureQuery query = entityManager.createStoredProcedureQuery("sp_ticket_data_insert");
//          query.registerStoredProcedureParameter(1, Long.class, ParameterMode.INOUT);
//          query.registerStoredProcedureParameter(2, Long.class, ParameterMode.INOUT);
//          query.execute();
            
			Session session = entityManager.unwrap(Session.class);
	        Query query = session.createSQLQuery("select * from fun_ticket_data_insert()");
	        query.list();

		} catch (HibernateException e) {
			log.error("Error Occurred in fun_ticket_data_insert(): "+e);
		}

	}
	
	/**
	 * Gets the tower for KO.
	 *
	 * @param groupName the group name
	 * @return the tower for KO
	 */
	@Override
	public String getTowerForKO(String groupName) {
		String tower = koTower;
		try {
			List<String> towerList = entityManager
					.createNativeQuery("select distinct tower from application_master where Assignmentgroup = :grp")
					.setParameter("grp", groupName).getResultList();
			if(towerList.isEmpty()) {
				tower=koTower;
			}
			else {
				tower=towerList.get(0);
			}
		} catch (HibernateException e) {
			log.error("Error Occurred in : "+e);
		}
		return tower;
	}

	/**
	 * Push KO.
	 *
	 * @param koInfoBean the ko info bean
	 */
	@Override
	@Transactional
	public void pushKO(KOInfoBean koInfoBean) {
//		try {
//			StoredProcedureQuery query = entityManager.createStoredProcedureQuery("sp_push_ko");
//			int createActionId = koInfoBean.getKoStage().equalsIgnoreCase("draft") ? 1 : 2;
//			
//			query.registerStoredProcedureParameter(1, String.class, ParameterMode.IN);
//			query.registerStoredProcedureParameter(2, String.class, ParameterMode.IN);
//			query.registerStoredProcedureParameter(3, String.class, ParameterMode.IN);
//			query.registerStoredProcedureParameter(4, String.class, ParameterMode.IN);
//			query.registerStoredProcedureParameter(5, String.class, ParameterMode.IN);
//			query.registerStoredProcedureParameter(6, String.class, ParameterMode.IN);
//			query.registerStoredProcedureParameter(7, String.class, ParameterMode.IN);
//			query.registerStoredProcedureParameter(8, String.class, ParameterMode.IN);
//			query.registerStoredProcedureParameter(9, String.class, ParameterMode.IN);
//			query.registerStoredProcedureParameter(10, String.class, ParameterMode.IN);
//			query.registerStoredProcedureParameter(11, String.class, ParameterMode.IN);
//			query.registerStoredProcedureParameter(12, String.class, ParameterMode.IN);
//			query.registerStoredProcedureParameter(13, Integer.class, ParameterMode.IN);
//			query.registerStoredProcedureParameter(14, String.class, ParameterMode.IN);
//			query.registerStoredProcedureParameter(15, String.class, ParameterMode.IN);
//			query.registerStoredProcedureParameter(16, String.class, ParameterMode.IN);
//			query.registerStoredProcedureParameter(17, String.class, ParameterMode.IN);
//			query.registerStoredProcedureParameter(18, String.class, ParameterMode.IN);
//			query.registerStoredProcedureParameter(19, Integer.class, ParameterMode.IN);
//			query.registerStoredProcedureParameter(20, Integer.class, ParameterMode.IN);
//			query.registerStoredProcedureParameter(21, Timestamp.class, ParameterMode.IN);
//			query.registerStoredProcedureParameter(22, String.class, ParameterMode.IN);
//			query.registerStoredProcedureParameter(23, Timestamp.class, ParameterMode.IN);
//			query.registerStoredProcedureParameter(24, String.class, ParameterMode.IN);
//			
//			query.setParameter(1, checkNull(koInfoBean.getKoID()));
//			query.setParameter(2, checkNull(koInfoBean.getShortDescription()));
//			query.setParameter(3, checkNull(koInfoBean.getApplicationName()));
//			query.setParameter(4, checkNull(koInfoBean.getAssignmentGroup()));
//			query.setParameter(5, checkNull(koInfoBean.getLongDescription()));
//			query.setParameter(6, checkNull(koInfoBean.getSymptoms()));
//			query.setParameter(7, checkNull(koInfoBean.getResolution()));
//			query.setParameter(8, checkNull(koInfoBean.getCause()));
//			query.setParameter(9, checkNull(koInfoBean.getQuestion()));
//			query.setParameter(10, checkNull(koInfoBean.getAnswer()));
//			query.setParameter(11, checkNull(koInfoBean.getTechnotes()));
//			query.setParameter(12, checkNull(koInfoBean.getAttachmentDocumentName()));
//			query.setParameter(13, checkNullInteger(koInfoBean.getAttachmentNumber()));
//			query.setParameter(14, checkNull(koInfoBean.getAttachmentName()));
//			query.setParameter(15, checkNull(koInfoBean.getAttachmentPath()));
//			query.setParameter(16, checkNull(koInfoBean.getKoStage()));
//			query.setParameter(17, checkNull(koInfoBean.getPublishedBy()));
//			query.setParameter(18, checkNull(koInfoBean.getTicketID()));
//			query.setParameter(19, 1);
//			query.setParameter(20, createActionId);
//			query.setParameter(21, checkNull(koInfoBean.getCreatedDate()));
//			query.setParameter(22, checkNull(koInfoBean.getCreatedBy()));
//			query.setParameter(23, checkNull(koInfoBean.getModifiedDate()));
//			query.setParameter(24, checkNull(koInfoBean.getModifiedBy()));
//			
//			query.execute();
//		}catch (PersistenceException ex) {
//			log.error(ex);
//		}
		
		try {
		Session session=entityManager.unwrap(Session.class);
		
		   int createActionId =
		  koInfoBean.getKoStage().equalsIgnoreCase("draft") ? 1 : 2;
		  
		  Query query = session.createSQLQuery("select 1 as pushKo from fun_push_ko(:koId,:shortDescription,"
		  		+ ":applicatioName,"
		  		+ ":assignmentGroup,"
		  		+ ":longDescription,"
		  		+ ":symptoms,"
		  		+ ":resolution,"
		  		+ ":cause,"
		  		+ ":question,"
		  		+ ":answer,"
		  		+ ":techNotes,"
		  		+ ":attachmentDataFix,"
		  		+ ":attachmentNumber,"
		  		+ ":attachmentName,"
		  		+ ":attachmentPath,"
		  		+ ":publicationStatus,"
		  		+ ":userId,"
		  		+ ":ticketId,"
		  		+ ":accountId,"
		  		+ ":actionId,"
		  		+ ":createdDate,"
		  		+ ":createdBy,"
		  		+ ":modifiedDate,"
		  		+ ":modifiedBy)");
			query.setParameter("koId", checkNull(koInfoBean.getKoID()));
			query.setParameter("shortDescription",checkNull(koInfoBean.getShortDescription()));
			query.setParameter("applicatioName", checkNull(koInfoBean.getApplicationName()));
			query.setParameter("assignmentGroup", checkNull(koInfoBean.getAssignmentGroup()));
			query.setParameter("longDescription",checkNull( koInfoBean.getLongDescription()));
			query.setParameter("symptoms", checkNull(koInfoBean.getSymptoms()));
			query.setParameter("resolution", checkNull(koInfoBean.getResolution()));
			query.setParameter("cause", checkNull(koInfoBean.getCause()));
			query.setParameter("question", checkNull(koInfoBean.getQuestion()));
			query.setParameter("answer", checkNull(koInfoBean.getAnswer()));
			query.setParameter("techNotes", checkNull(koInfoBean.getTechnotes()));
			query.setParameter("attachmentDataFix",checkNull(koInfoBean.getAttachmentDocumentName()));
			query.setParameter("attachmentNumber",checkNullInteger( koInfoBean.getAttachmentNumber()));
			query.setParameter("attachmentName", checkNull(koInfoBean.getAttachmentName()));
			query.setParameter("attachmentPath", checkNull(koInfoBean.getAttachmentPath()));
			query.setParameter("publicationStatus", checkNull(koInfoBean.getKoStage()));
			query.setParameter("userId", checkNull(koInfoBean.getPublishedBy()));
			query.setParameter("ticketId", checkNull(koInfoBean.getTicketID()));
			query.setParameter("accountId", 1);
			query.setParameter("actionId", createActionId);
			query.setParameter("createdDate", checkNull(koInfoBean.getCreatedDate()));
			query.setParameter("createdBy", checkNull(koInfoBean.getCreatedBy()));
			query.setParameter("modifiedDate", checkNull(koInfoBean.getModifiedDate()));
			query.setParameter("modifiedBy", checkNull(koInfoBean.getModifiedBy()));
			 query.list();
	}catch (PersistenceException ex) {
		log.error("Error occurred while pushing ko : "+ex);
	}
	}
	
	/**
	 * Creates the user.
	 *
	 * @param userDTO the user DTO
	 */
	@Override
	@Transactional
	public void createUser(UserDTO userDTO) {
//		try {
//			StoredProcedureQuery query = entityManager.createStoredProcedureQuery("sp_push_user");
//			query.registerStoredProcedureParameter(1, String.class, ParameterMode.IN);
//			query.registerStoredProcedureParameter(2, String.class, ParameterMode.IN);
//			query.registerStoredProcedureParameter(3, String.class, ParameterMode.IN);
//			query.registerStoredProcedureParameter(4, String.class, ParameterMode.IN);
//			query.setParameter(1, Objects.nonNull(userDTO.getUserId())?userDTO.getUserId():"");
//			query.setParameter(2, Objects.nonNull(userDTO.getName())?userDTO.getName():"");
//			query.setParameter(3, Objects.nonNull(userDTO.getEmail())?userDTO.getEmail():"");
//			query.setParameter(4, Objects.nonNull(userDTO.getAssignmentGroup())? userDTO.getAssignmentGroup():"");
//			query.execute();	
//		}catch (PersistenceException ex) {
//			log.error(ex);
//		}
		
		try {
		Session session = entityManager.unwrap(Session.class);
        Query<?> query = session.createSQLQuery("select 1 as userDetails from fun_push_user(:userid,:name,:email,:assignmentgroup)");
        query.setString("userid", Objects.nonNull(userDTO.getUserId())?userDTO.getUserId():"");
        query.setString("name", Objects.nonNull(userDTO.getName())?userDTO.getName():"");
        query.setString("email", Objects.nonNull(userDTO.getEmail())?userDTO.getEmail():"");
        query.setString("assignmentgroup", Objects.nonNull(userDTO.getAssignmentGroup())? userDTO.getAssignmentGroup():"");
        query.list();
       
    }catch (PersistenceException ex) {
        log.error("Error occurred while creating user : "+ex);
    }
	}
	
	/**
	 * check Null.
	 *
	 * @param obj the obj
	 * @return Object obj
	 */
	private Object checkNull(Object obj) {
		return Objects.nonNull(obj)?obj:"";
	}
	
	/**
	 * check Null.
	 *
	 * @param obj the obj
	 * @return Object obj
	 */
	private Object checkNullInteger(Object obj) {
		return Objects.nonNull(obj)?obj:0;
	}

	/**
	 * Gets the attachment list.
	 *
	 * @param serialNumber the serial number
	 * @return the attachment list
	 */
	@Override
	@Transactional
	public List<AttachmentDTO> getAttachmentList(int serialNumber) {
		final List<AttachmentDTO> attachmentList = new ArrayList<AttachmentDTO>();
		Optional<KOArtifacts> koArt = kOArtifactsRepository.findById(serialNumber);
		
			// Validation for KO Artifacts presence
			if (koArt.isPresent() && StringUtils.hasLength(koArt.get().getAttachmentName())) {
				
				// Retrive Unique KO Attachment names
				Set<String> idNameSet = getAttachNameSet(koArt.get().getAttachmentName());
				// Convert attachment data into list
				String[] idNameArray;
				for (String idName : idNameSet) {
					try {
					idNameArray = idName.split("\\/|\\\\");
					attachmentList.add(new AttachmentDTO(idNameArray[1], idNameArray[0],
							idName.substring(idName.lastIndexOf('.') + 1, idName.length())));
					}catch (ArrayIndexOutOfBoundsException e) {
						log.error(e.getMessage());
					}
				}
			}
		
		return attachmentList;
	}

	/**
	 * Gets the attach name set.
	 *
	 * @param string the string
	 * @return the attach name set
	 */
	private Set<String> getAttachNameSet(String string) {
		return StringUtils.hasLength(string) ? new HashSet<String>(Arrays.asList(string.split("\\|"))) : new HashSet<String>();
	}

	/**
	 * Gets the attach type base.
	 *
	 * @param type the type
	 * @return the attach type base
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@Override
	public String getAttachTypeBase(String type) throws IOException {
		String attachTypeBase = "";
		//Get Type folder base
		Map<Object, Object> typeBaseMap = Arrays.stream(TenantContextHolder.getTenantContextHolder()
                .getAttachmentTypeBases().split(","))
			      .map(base -> base.split("="))
			      .collect(Collectors.toMap(base -> base[0], base -> base[1]));
		
		if(typeBaseMap.containsKey(type)) {
			attachTypeBase = typeBaseMap.get(type).toString();
		}else {
			throw new IOException("Attachment Type not found");
		}
		return attachTypeBase;
	}

	/**
	 * Gets the attach name.
	 *
	 * @param attachTypeId the attach type id
	 * @param attachID the attach ID
	 * @return the attach name
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@Override
	@Transactional
	public String getAttachName(String attachTypeId, String attachID) throws IOException {
		String attachName = "";
		
		// Retrive the file and attachment id from DB using attachment path (koid should
		// be present in attachment path)
		final KOInfo koInfo = getKOInfoArtifacts(attachTypeId);
		Optional<KOArtifacts> koArt = kOArtifactsRepository.findById(koInfo.getKoSerialNo());
		if(koArt.isPresent() && StringUtils.hasLength(koArt.get().getAttachmentName())) {
			Set<String> set = getAttachNameSet(koArt.get().getAttachmentName());
			for(String s : set) {
				if(attachID.equals(s.split("\\/|\\\\")[0])) {
					attachName = s.split("\\/|\\\\")[1];
				}
			}
		}else {
			throw new IOException("KO Artifact : "+attachTypeId+" is not found in DB or empty");
		}
		return attachName;
	}

	/**
	 * Gets the KO info artifacts.
	 *
	 * @param koid the koid
	 * @return the KO info artifacts
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@Override
	@Transactional
	public KOInfo getKOInfoArtifacts(String koid) throws IOException {
		final KOInfo koInfo = kOInfoRepository.findByKoID(koid);
		if (Objects.isNull(koInfo)) {
			throw new IOException("KO id : " + koid + " is not present in DB");
		}
		return koInfo;
	}

	/**
	 * Save KO artifacts.
	 *
	 * @param koid the koid
	 * @param attachmentId the attachment id
	 * @param fileName the file name
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@Override
	@Transactional
	public void saveKOArtifacts(String koid, String attachmentId, String fileName) throws IOException {

		final KOInfo koInfo = getKOInfoArtifacts(koid);
		Optional<KOArtifacts> koArt = kOArtifactsRepository.findById(koInfo.getKoSerialNo());
		if (koArt.isPresent()) {

			// Updating existing KO artifact record
			KOArtifacts koArtifacts = koArt.get();
			// Removing duplicate attach id - file Names
			Set<String> set = getAttachNameSet(koArt.get().getAttachmentName());
			set.add(attachmentId + File.separator + fileName);

			koArtifacts.setAttachmentPath(koid);
			koArtifacts.setAttachmentName(String.join("|", set));
			kOArtifactsRepository.save(koArtifacts);
		} else {

			// Adding a new record in KO artifact
			KOArtifacts koArticatsNew = new KOArtifacts(koInfo.getKoSerialNo(),
					attachmentId + File.separator + fileName, koid);
			kOArtifactsRepository.save(koArticatsNew);
		}
		
	}
	/**
	 * Kolistview SP.
	 *
	 * @param KoAttrVo the ko attr vo
	 * @return the list
	 */
	@Override
	@Transactional
	public List<KOInfoBean> getKOList(String roleType) {
		List<KOInfoBean> KOInfoBeanList = null;
		Session session = entityManager.unwrap(Session.class);
		Query query = session.createSQLQuery(
				"select * from fun_get_all_kos(:roleType)")
				.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
		query.setParameter("roleType", roleType);
		KOInfoBeanList = query.list();
		return KOInfoBeanList;
	}

	/**
	 * @param ticketID
	 * @return
	 */
	@Override
	@Transactional
	public List<TicketDataBean> getTicketDetail(String ticketID) {
		List<TicketDataBean> incBeanList = null;
		Session session = entityManager.unwrap(Session.class);
		Query query  = session.createSQLQuery("select * from fun_get_ticket_ko_by_ticketid(:number)")
				.setResultTransformer(Transformers.aliasToBean(TicketDataBean.class));
		query.setParameter("number", ticketID);
		incBeanList = query.list();
		return incBeanList;
	}
	
	/**
	 * Create KO.
	 * @param koInfoBean
	 */
	@Override
	@Transactional
	public List<KOInfoBean> createKO(KOInfoBean koInfoBean, String userName) {
		
		String koPrefix = TenantContextHolder.getTenantContextHolder().getKoPrefix();
		String koStartingNumber=TenantContextHolder.getTenantContextHolder().getKoStartingNumber();
		String createActionValue = koInfoBean.getKoStage();
		String createActionId = createActionValue.equalsIgnoreCase("1") ? "1" : "2";		
		List<KOInfoBean> koInfoBeanList = null;
		Session session = entityManager.unwrap(Session.class);
		Query query  = session.createSQLQuery("select * from fun_create_ko_without_ticketid(:shortDescription, :applicationName, :assignmentGroup,:causeCode,"
				+ ":longDescription, :symptoms, :answer, :resolution,:attachmentdatafix,:attachmentnumber,:attachmentname ,"
				+ ":attachmentpath,:pubstatus,:ticketid,:accid,:createactionid,:userid,:koprefix,:koStartingNumber)")
				.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
		query.setString("shortDescription", koInfoBean.getShortDescription());
		query.setString("applicationName", koInfoBean.getApplicationName());
		query.setString("assignmentGroup", koInfoBean.getAssignmentGroup());
		query.setString("causeCode", koInfoBean.getCauseCode());
		query.setString("longDescription", koInfoBean.getLongDescription());
		query.setString("symptoms", koInfoBean.getSymptoms());
		query.setString("answer", koInfoBean.getAnswer());
		query.setString("resolution", koInfoBean.getResolution());
		query.setString("attachmentdatafix","");
		query.setInteger("attachmentnumber", 0);
		query.setString("attachmentname","");
		query.setString("attachmentpath","");	
		query.setString("pubstatus", koInfoBean.getPublicationStatus());
		query.setString("ticketid", koInfoBean.getTicketID());
		query.setString("accid", ACCOUNT_ID);
		query.setString("createactionid", createActionId);
		query.setString("userid",userName);
		query.setString("koprefix",koPrefix);
		query.setString("koStartingNumber", koStartingNumber);	
			
		koInfoBeanList=query.list();
		
		return koInfoBeanList;
	}
	
	/**
	 * @param type
	 * @return
	 */
	@Override
	@Transactional
	public List<MultilingualKOStatusDTO> getAllKOStatus(String field) {
		List<MultilingualKOStatusDTO> statusList = null;
		Session session = entityManager.unwrap(Session.class);
		Query query = session.createSQLQuery("select * from fun_get_publication_status(:field)")
				.setResultTransformer(Transformers.aliasToBean(MultilingualKOStatusDTO.class));
		query.setString("field", field);
		statusList = query.list();
		return statusList;
	}
	/**
	 * @param koId
	 * @return
	 */
	@Override
	@Transactional
	public List<KOInfoBean> getKODetail(String koId) {
		List<KOInfoBean> koBeanList = null;
		Session session = entityManager.unwrap(Session.class);
		Query query  = session.createSQLQuery("select * from fun_retrive_ko_data_new(:koId)")
				.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
		query.setParameter("koId", koId);
		koBeanList = query.list();
		return koBeanList;
	}
	/**
	 * Retrieve review comments.
	 *
	 * @param koId the ko id
	 * @return the list
	 */
	@Override
	@Transactional
	public List<KOReviewCommnetsDTO> retrieveReviewComments(String koId) {
		List<KOReviewCommnetsDTO> KOInfoBeanList = null;
		Session session = entityManager.unwrap(Session.class);
		Query query = session.createSQLQuery("select * from fun_retrieve_review_comments_new(:koID)")
				.setResultTransformer(Transformers.aliasToBean(KOReviewCommnetsDTO.class));
		query.setString("koID", koId);
		KOInfoBeanList = query.list();
		return KOInfoBeanList;

	}

	/**
	 *Delete KO
	 * @param koId the ko id
	 * @return the list
	 */
	@Override
	@Transactional
	public String deleteKO(String koId,String userName) {
		Session session = entityManager.unwrap(Session.class);
		Query query  = session.createSQLQuery("select 1 as return from fun_delete_ko(:koId,:userName)");
				//.setResultTransformer(Transformers.aliasToBean(KOInfoBean.class));
		query.setParameter("koId", koId);
		query.setString("userName", userName);
		query.list();
		return "";
		
	}
	
      /**
	 * Update KO
	 * @param koInfo
	 * @param userName
	 * @return
	 */
	@Override
	@Transactional
	public List<KOInfoBean> updateKO(KOInfoBean koInfo, String userName) {
		List<KOInfoBean> koList = null;
		Session session = entityManager.unwrap(Session.class);
		Query query  = session.createSQLQuery("select * from fun_update_ko_new(:koid,:shortDescription,:applicationName,:assignmentGroup,"
				+ ":longDescription,:symptoms,:resolution,:answer,:reviewedBy,:publishedBy,"
				+ ":pubstatus,:modifiedBy,:ticketid,:createactionid,:revieweddate,:publisheddate)")
				.setResultTransformer(Transformers.aliasToBean(KODetailsDTO.class));
		query.setString("koid", koInfo.getKoID());
		query.setString("shortDescription", koInfo.getShortDescription());
		query.setString("applicationName", koInfo.getApplicationName());
		query.setString("assignmentGroup", koInfo.getAssignmentGroup());
		query.setString("longDescription", koInfo.getLongDescription());
		query.setString("symptoms", koInfo.getSymptoms());
		query.setString("resolution", koInfo.getResolution());
		query.setString("answer", koInfo.getAnswer());	
		query.setString("reviewedBy", koInfo.getReviewedBy());
		query.setString("publishedBy", koInfo.getPublishedBy());
		query.setString("pubstatus", koInfo.getKoStage());
		query.setString("modifiedBy", userName);
		query.setString("ticketid", koInfo.getTicketID());	
		query.setString("createactionid",koInfo.getPublicationStatus());
		query.setDate("revieweddate", koInfo.getReviewedDate());	
		query.setDate("publisheddate",koInfo.getPublishedDate());

		koList=query.list();		
		return koList;
	}

	/**
	 * Insert Review Comments
	 * @param koDTO
	 * @param reviewDTO
	 */
	@Override
	@Transactional
	public void insertReviewComments(KODetailsDTO koDTO,KOReviewCommnetsDTO reviewDTO) {
		Session session = entityManager.unwrap(Session.class);
		Query query = session.createSQLQuery("select 1 as return from fun_ko_insert_review(:koID, :createdDate, :CreatedBy, :reviewedDate, :reviewedBy, :publishedDate, :publishedBy, :reviewComments, :reworkArea, :actionRequired)");
		query.setString("koID", koDTO.getSolutionnumber());
		query.setDate("createdDate", koDTO.getCreatedDate());
		query.setString("CreatedBy", koDTO.getCreatedBy());
		query.setDate("reviewedDate", koDTO.getReviewedDate());
		query.setString("reviewedBy", koDTO.getReviewedBy());
		query.setDate("publishedDate", koDTO.getPublishedDate());
		query.setString("publishedBy", koDTO.getPublishedBy());
		query.setString("reviewComments", reviewDTO.getReviewComments());
		query.setString("reworkArea", reviewDTO.getReworkArea());
		query.setInteger("actionRequired", reviewDTO.getActionRequired());
		query.list();	
	}

	/**
	 * Update Review Comments
	 * @param koDTO
	 * @param reviewDTO
	 */
	@Override
	@Transactional
	public void updateReviewComments(KOReviewCommnetsDTO reviewDTO) {		
		Session session = entityManager.unwrap(Session.class);
		Query query = session.createSQLQuery("select 1 as return from fun_ko_new_update_review(:reviewId, :reviewComments, :reworkArea, :actionRequired)");
		query.setInteger("reviewId", reviewDTO.getReviewID());
		query.setString("reviewComments", reviewDTO.getReviewComments());
		query.setString("reworkArea", reviewDTO.getReworkArea());
		query.setInteger("actionRequired", reviewDTO.getActionRequired());
		query.list();
	}

	/**
	 * Delete attachment.
	 * @param attachedList
	 * @param koserialno
	 */
	@Override
	public void deleteAttachment(String attachedList,int koserialno) {
		kOArtifactsRepository.deleteAttachment(attachedList, koserialno);
	}

	/**
	 * Get KOArtifacts.
	 * @param koserialno
	 * @return
	 */
	@Override
	public KOArtifacts getArtifact(int koserialno) {
		KOArtifacts data=kOArtifactsRepository.findByKoSerialNo(koserialno);
		return data;
	}

	/**
	 * 
	 * @param type
	 * @param fileStr
	 * @param koid
	 * @param fileName
	 * @param attachmentId*/
	@Override
	public ResponseEntity<Object> pushAttachmentExtract(String type, String fileStr, String koid, String fileName, String attachmentId) {
		log.info("Start : pushAttachment");
		long start = System.currentTimeMillis();
		JsonObject json = new JsonObject();
		
		try {
			if (StringUtils.hasLength(fileName) && StringUtils.hasLength(fileStr) && StringUtils.hasLength(koid)
					&& StringUtils.hasLength(attachmentId) && StringUtils.hasLength(type)) {

				String attachTypeBase = getAttachTypeBase(type);
				

				String basePath = String.join(File.separator, TenantContextHolder.getTenantContextHolder().getAttachmentBase(), TenantContextHolder.getTenantContextHolder().getAccountName(), attachTypeBase, koid,
						attachmentId);
				// Creation of attachment id folder
				File f = new File(basePath);
				if (!f.exists()) {
					f.mkdirs();
				}
				// Save File content in the reporsitory
				Path copyLocation = Paths.get(basePath + File.separator + fileName);
				byte[] data = Base64.getDecoder().decode(fileStr.getBytes());
				Files.write(copyLocation, data);
				log.info("File is saved successfully : " + copyLocation.toString());

				// Save file data in KO Artifacts
				saveKOArtifacts(koid,attachmentId,fileName);

			} else {
				throw new IOException("File content is empty or null");
			}

			json.addProperty("statusCode", "200");
			json.addProperty("statusMessage", "Record has been saved in database sucessfully");
			log.info("Time taken (ms) : " + (System.currentTimeMillis() - start));
			log.info("End : pushAttachment");
			return new ResponseEntity<>(json.toString(), HttpStatus.OK);

		} catch (IOException | HibernateException | ArrayIndexOutOfBoundsException e) {
			log.error(e+" Error : "+ e.getMessage());
			log.info("Time taken (ms) : " + (System.currentTimeMillis() - start));
			json.addProperty("statusCode", "400");
			json.addProperty("statusMessage", "Error occurred while processing the data");
			log.info("End : pushAttachment");
			return new ResponseEntity<>(json.toString(), HttpStatus.BAD_REQUEST);
		}

		
	}
	

	@Override
	@Transactional
	public KOInfoDTO validateKO(String accId,String koId, String ticketId) {
		Session session=entityManager.unwrap(Session.class);
		List<KOInfoDTO> infoList=new ArrayList<>();
		Query query=session.createSQLQuery("select * from fun_ciap_validate_ko_test(:accId,:ticketId,:koId)")
				.setResultTransformer(Transformers.aliasToBean(KOInfoDTO.class));
		query.setInteger("accId",Integer.parseInt(accId));
		query.setString("ticketId", ticketId);
		query.setString("koId", koId);
		infoList=query.list();
		return infoList.get(0);
	}

	@Override
	@Transactional
	public List<IncidentRelatedKODTO> getRelatedKOs(String ticketId) {
		Session session=entityManager.unwrap(Session.class);
		List<IncidentRelatedKODTO> koList=new ArrayList<>();
		Query query=session.createSQLQuery("select * from fun_ciap_ticket_related_ko(:ticketId)")
				.setResultTransformer(Transformers.aliasToBean(IncidentRelatedKODTO.class));
		query.setString("ticketId", ticketId);	
		koList=query.list();
		return koList;
	}
	
	@Override
	@Transactional
	public List<TicketDataDTO> getIncidentKOrelevancy(String number) {
		List<TicketDataDTO> ticketDataDTO = null;
		Session session = entityManager.unwrap(Session.class);
		Query query = session.createSQLQuery("select * from fun_get_relevancy(:incident)")
				.setResultTransformer(Transformers.aliasToBean(TicketDataDTO.class));
		query.setString("incident", number);
		ticketDataDTO=query.list();
		if(Objects.nonNull(ticketDataDTO)) {
			return ticketDataDTO;
		}
		
		return new ArrayList<TicketDataDTO>();
	}
	
	
	/**
	 * Gets the k oby attach ID.
	 *
	 * @param attachID the attach ID
	 * @return the k oby attach ID
	 */
	@Override
	@Transactional
	public String getKObyAttachID(String attachID) {
		Session session=entityManager.unwrap(Session.class);
		List<KOInfoDTO> koList=new ArrayList<>();
		Query query=session.createSQLQuery("select * from fun_ciap_get_ko_by_attachid(:ticketId)")
				.setResultTransformer(Transformers.aliasToBean(KOInfoDTO.class));
		query.setString("attachID", attachID);	
		koList=query.list();
		if(Objects.nonNull(koList) && koList.size()>0) {
			return koList.get(0).getKoID();
		}
		return null;
	}

}