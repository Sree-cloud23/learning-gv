package com.ikon.rest.web.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

/**
 * The Class KOLinkedIncidentDTO.
 */
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class KOLinkedIncidentDTO {

	/** The koid. */
	private String koid;
	
	/** The linked Incidents. */
	private boolean linkedIncidents;
	
	/** The page Number. */
	private Integer startIndex;
	
	/** The page Size. */
	private Integer pageSize;
}
