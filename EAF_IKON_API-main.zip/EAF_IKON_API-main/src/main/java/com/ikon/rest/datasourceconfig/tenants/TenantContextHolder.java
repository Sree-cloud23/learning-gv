package com.ikon.rest.datasourceconfig.tenants;

import com.ikon.rest.datasourceconfig.beans.tenants.TenantInfo;

/**
 * Tenant Context Holder Class
 *
 * @author prapatel
 */
public class TenantContextHolder {

	/**
     * The threadlocal instance to store tenant specific information accessible only to the current thread
     */
    private static final ThreadLocal<TenantInfo> TENANT_CONTEXT_HOLDER_THREAD_LOCAL = new ThreadLocal<>();

    /**
     * Private Constructor to avoid Object instantiation
     */
    private TenantContextHolder() {
        throw new IllegalStateException("TenantContextHolder class cannot be instantiated");
    }

    /**
     * @param tenantInfo - TenantInfo
     */
    public static void setTenantContextHolderThreadLocal(TenantInfo tenantInfo) {
        TENANT_CONTEXT_HOLDER_THREAD_LOCAL.set(tenantInfo);
    }

    /**
     * @return String stored on ThreadLocal
     */
    public static TenantInfo getTenantContextHolder() {
        return TENANT_CONTEXT_HOLDER_THREAD_LOCAL.get();
    }

    /**
     * Clears the tenantContextHolder
     */
    public static void clear() {
        TENANT_CONTEXT_HOLDER_THREAD_LOCAL.remove();
    }
	
}
