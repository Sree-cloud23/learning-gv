package com.ikon.rest.master.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * entity object to map tenant account information
 */
@Entity
@Table(name = "account_mapping")
@Getter
@Setter
@EqualsAndHashCode
@ToString
public class TenantAccountMapping implements Serializable{/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Tenant Id
	 */
	@Column(name = "tenantid")
	private String tenantId;

	/**
	 * Account Id
	 */
	@Id
	@Column(name = "accountid")
	private String accountId;

	/**
	 * Active Status field
	 */
	@Column(name = "active")
	private boolean active;

	/**
	 * Has updated field
	 */
	@Column(name = "isupdated")
	private boolean isUpdated;
	
}
