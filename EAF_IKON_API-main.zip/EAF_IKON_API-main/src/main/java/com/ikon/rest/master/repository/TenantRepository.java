package com.ikon.rest.master.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ikon.rest.master.entity.Tenant;

@Repository
public interface TenantRepository extends JpaRepository<Tenant, String> {

	Tenant findByTenantId(final String tenantId);

	List<Tenant> findByActive(boolean value);
	
}
