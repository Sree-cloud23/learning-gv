package com.ikon.rest.datasourceconfig.tenants;

import java.util.Map;
import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.ikon.rest.master.service.TenantService;

import lombok.extern.slf4j.Slf4j;

/**
 * The Configuration Class for Multi-Tenant Support
 */
@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(basePackages = {"com.ikon.model","com.ikon.repository"},
        entityManagerFactoryRef = "multiEntityManager",
        transactionManagerRef = "multiTransactionManager")
@Slf4j
public class MultiTenantConfiguration {
	
	/**
     * The Map To Store Tenant ID and its DataSource Object
     */
    private static Map<Object, Object> tenants = null;

    /**
     * The Package Scan Field
     */
    private static final String[] PACKAGE_SCAN = {"com.ikon.model","com.ikon.repository"};

    /**
     * The Common DataSource
     */
    @Autowired
    @Qualifier(value = "commonDataSource")
    private transient DataSource commonDataSource;

    private transient TenantService tenantService;

    /**
     * Getter for tenants class field
     */
    public static Map<Object, Object> getTenants() {
        return tenants;
    }

    @Autowired
    public MultiTenantConfiguration(TenantService tenantService) {
        this.tenantService = tenantService;
    }

    /**
     * Sets Data Source
     */
    @Bean(name = "multiRoutingDataSource")
    public MultiRoutingDataSource multiRoutingDataSource() {
        return tenantService.loadAllTenants(commonDataSource);
    }

    /**
     * @return LocalContainerEntityManagerFactoryBean
     */
    @Bean(name = "multiEntityManager")
    public LocalContainerEntityManagerFactoryBean multiEntityManager() {
        LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource(multiRoutingDataSource());
        em.setPackagesToScan(PACKAGE_SCAN);
        HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
        em.setJpaVendorAdapter(vendorAdapter);
        em.setJpaProperties(hibernateProperties());
        return em;
    }

    /**
     * @return PlatformTransactionManager
     */
    @Bean(name = "multiTransactionManager")
    @Primary
    public PlatformTransactionManager multiTransactionManager() {
        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(multiEntityManager().getObject());
        return transactionManager;
    }

    /**
     * @return LocalSessionFactoryBean
     */
    @Primary
    @Bean(name = "multidbSessionFactory")
    public LocalSessionFactoryBean dbSessionFactory() {
        LocalSessionFactoryBean sessionFactoryBean = new LocalSessionFactoryBean();
        sessionFactoryBean.setDataSource(multiRoutingDataSource());
        sessionFactoryBean.setPackagesToScan(PACKAGE_SCAN);
        sessionFactoryBean.setHibernateProperties(hibernateProperties());
        return sessionFactoryBean;
    }

    /**
     * @return Hibernate Properties
     */
    private Properties hibernateProperties() {
        Properties properties = new Properties();
        properties.put("hibernate.show_sql", true);
        properties.put("hibernate.format_sql", true);
        return properties;
    }

	
	
}
