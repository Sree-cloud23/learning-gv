package com.ikon.rest.datasourceconfig.beans.keyvault;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;
import lombok.Setter;

/**
 * The Key Vault Bean Class
 */
@Getter
@Setter
@Configuration
@ConfigurationProperties("key.vault.properties")
public class KeyVaultBean {


    /**
     * The Vault type field
     */
    private String type;

    /**
     * The AWS Key Vault Bean
     */
    private AWSKeyVaultBean aws;

    /**
     * The Azure Key Vault Bean
     */
    private AzureKeyVaultBean azure;
	
}
