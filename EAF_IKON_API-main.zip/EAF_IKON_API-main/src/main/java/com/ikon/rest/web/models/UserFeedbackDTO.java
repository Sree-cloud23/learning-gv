package com.ikon.rest.web.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * The Class UserFeedbackDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserFeedbackDTO {

	/** The solutionnumber. */
	private String solutionnumber; // ticketID
	
	/** The incidentnumber. */
	private String incidentnumber; // ticketID
	
	/**
	 * Gets the solutionnumber.
	 *
	 * @return the solutionnumber
	 */
	public String getSolutionnumber() {
		return solutionnumber;
	}
	
	/**
	 * Sets the solutionnumber.
	 *
	 * @param solutionnumber the new solutionnumber
	 */
	public void setSolutionnumber(String solutionnumber) {
		this.solutionnumber = solutionnumber;
	}
	
	/**
	 * Gets the incidentnumber.
	 *
	 * @return the incidentnumber
	 */
	public String getIncidentnumber() {
		return incidentnumber;
	}
	
	/**
	 * Sets the incidentnumber.
	 *
	 * @param incidentnumber the new incidentnumber
	 */
	public void setIncidentnumber(String incidentnumber) {
		this.incidentnumber = incidentnumber;
	}
}
