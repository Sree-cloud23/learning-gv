package com.ikon.rest.web.models.dashboard;

/**
 * The Class KOUsageChartDTO.
 */
public class KOUsageChartDTO {

	/** The month. */
	private String month;
	
	/** The ko count. */
	private Object koCount;

	/**
	 * Gets the month.
	 *
	 * @return the month
	 */
	public String getMonth() {
		return month;
	}

	/**
	 * Sets the month.
	 *
	 * @param month the new month
	 */
	public void setMonth(String month) {
		this.month = month;
	}

	/**
	 * Gets the ko count.
	 *
	 * @return the ko count
	 */
	public Object getKoCount() {
		return koCount;
	}

	/**
	 * Sets the ko count.
	 *
	 * @param koCount the new ko count
	 */
	public void setKoCount(Object koCount) {
		this.koCount = koCount;
	}

	/**
	 * To string.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return "KOUsageChartDTO [month=" + month + ", koCount=" + koCount + "]";
	}
	
	
	
}
