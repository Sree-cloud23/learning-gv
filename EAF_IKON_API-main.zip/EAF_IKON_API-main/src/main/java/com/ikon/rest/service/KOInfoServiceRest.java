package com.ikon.rest.service;

import java.io.IOException;
import java.util.List;

import org.springframework.http.ResponseEntity;

import com.ikon.dto.KOInfoBean;
import com.ikon.dto.TicketDataBean;
import com.ikon.model.KOArtifacts;
import com.ikon.model.KOInfo;
import com.ikon.rest.web.models.AttachmentDTO;
import com.ikon.rest.web.models.IncidentRelatedKODTO;
import com.ikon.rest.web.models.KODetailsDTO;
import com.ikon.rest.web.models.KOInfoDTO;
import com.ikon.rest.web.models.KOReviewCommnetsDTO;
import com.ikon.rest.web.models.MultilingualKOStatusDTO;
import com.ikon.rest.web.models.TicketDataDTO;
import com.ikon.rest.web.models.UserDTO;

/**
 * The Interface KOInfoServiceRest.
 */
public interface KOInfoServiceRest 
{

	/**
	 * Run stored procedure with no param.
	 */
	void runStoredProcedureWithNoParam();

	/**
	 * Insert ticket detail.
	 *
	 * @param ticketDataDTO the ticket data DTO
	 * @return the int
	 */
	int insertTicketDetail(TicketDataDTO ticketDataDTO);

	/**
	 * Gets the tower for KO.
	 *
	 * @param assignmentGroup the assignment group
	 * @return the tower for KO
	 */
	String getTowerForKO(String assignmentGroup);

	/**
	 * Push KO.
	 *
	 * @param koInfoBean the ko info bean
	 */
	public void pushKO(KOInfoBean koInfoBean);

	/**
	 * Creates the user.
	 *
	 * @param userDTO the user DTO
	 */
	public void createUser(UserDTO userDTO);

	/**
	 * Gets the attachment list.
	 *
	 * @param serialNumber the serial number
	 * @return the attachment list
	 */
	List<AttachmentDTO> getAttachmentList(int serialNumber);

	/**
	 * Gets the attach type base.
	 *
	 * @param type the type
	 * @return the attach type base
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	String getAttachTypeBase(String type) throws IOException;

	/**
	 * Gets the attach name.
	 *
	 * @param attachTypeId the attach type id
	 * @param attachID the attach ID
	 * @return the attach name
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	String getAttachName(String attachTypeId, String attachID) throws IOException;

	/**
	 * Gets the KO info artifacts.
	 *
	 * @param koid the koid
	 * @return the KO info artifacts
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	KOInfo getKOInfoArtifacts(String koid) throws IOException;

	/**
	 * Save KO artifacts.
	 *
	 * @param koid the koid
	 * @param attachmentId the attachment id
	 * @param fileName the file name
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	void saveKOArtifacts(String koid, String attachmentId, String fileName) throws IOException;

	
	/**
	 * Kolistview SP.
	 *
	 * @param KoAttrVo the ko attr vo
	 * @return the list
	 */
	List<KOInfoBean> getKOList(String roleType);
	
	/**
	 * @param ticketID
	 * @return
	 */
	List<TicketDataBean> getTicketDetail(String ticketID);
	
	/**
	 * Create KO.
	 * @param koInfoBean
	 */
	public  List<KOInfoBean> createKO(KOInfoBean koInfoBean , String userName);
	
	/**
	 * @param type
	 * @return
	 */
	List<MultilingualKOStatusDTO> getAllKOStatus(String field);
	
	/**
	 * @param koId
	 * @return
	 */
	List<KOInfoBean> getKODetail(String koId);
	
	/**
	 * Retrieve review comments.
	 *
	 * @param koId the ko id
	 * @return the list
	 */
	List<KOReviewCommnetsDTO> retrieveReviewComments(String koId);
	
	/**
	 * @param koId
	 * @return
	 */
	String deleteKO(String koId,String userName);
	/***
	 * Update KO
	 * @param koInfo
	 * @param userName
	 * @return
	 */
	List<KOInfoBean> updateKO(KOInfoBean koInfo, String userName);
	
	/**
	 * Insert Review Comments
	 * @param koDTO
	 * @param reviewDTO
	 */
	void insertReviewComments(KODetailsDTO koDTO,KOReviewCommnetsDTO reviewDTO);

	/**
	 * Update Review Comments
	 * @param koDTO
	 * @param reviewDTO
	 */
	void updateReviewComments(KOReviewCommnetsDTO reviewDTO);
	
	/**
	 * Get KOArtifacts.
	 * @param koserialno
	 * @return
	 */
	KOArtifacts getArtifact(int koserialno);
	
	/**
	 * Delete attachment.
	 * @param attachedList
	 * @param koserialno
	 */
	void deleteAttachment(String attachedList,int koserialno);
	
	/**
	 * 
	 * @param type
	 * @param fileStr
	 * @param koid
	 * @param fileName
	 * @param attachmentId
	 */
	ResponseEntity<Object> pushAttachmentExtract(final String type, String fileStr, String koid,
			String fileName, String attachmentId);
	/**
	 * 
	 * @param koId
	 * @param ticketId
	 * @return
	 */
	KOInfoDTO validateKO(String accId,String koId,String ticketId);
	
	/**
	 * 
	 * @param ticketId
	 * @return
	 */
	List<IncidentRelatedKODTO> getRelatedKOs(String ticketId);
	
	/**
	 * 
	 * @param number
	 * @return
	 */
	List<TicketDataDTO> getIncidentKOrelevancy(String number) ;
	
	
	/**
	 * Gets the k oby attach ID.
	 *
	 * @param attachID the attach ID
	 * @return the k oby attach ID
	 */
	String getKObyAttachID(String attachID);
}
