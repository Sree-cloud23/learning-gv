package com.ikon.rest.service;

import java.util.List;

import com.ikon.rest.web.models.KOInfoDTO;
import com.ikon.rest.web.models.dashboard.AgeingWorkinfoDTO;
import com.ikon.rest.web.models.dashboard.ComplianceDTO;
import com.ikon.rest.web.models.dashboard.IncMissingKODTO;
import com.ikon.rest.web.models.dashboard.KOUsageChartDTO;
import com.ikon.rest.web.models.dashboard.MttrDTO;
import com.ikon.rest.web.models.dashboard.ReportChartDTO;
import com.ikon.rest.web.models.dashboard.RunToZeroDTO;

/**
 * The Interface DashboardService.
 */
public interface DashboardService {
	
	/**
	 * Get KO Usage Report
	 * @param accId
	 * @param reportChartDTO
	 * @return
	 */
	List<KOInfoDTO> getKOUsageReport(String accId,ReportChartDTO reportChartDTO);
 
	/**
	 * Get KO Usage Chart
	 * @param accId
	 * @param reportChartDTO
	 * @return
	 */
	List<KOUsageChartDTO> getKOUsageChart(String accId,ReportChartDTO reportChartDTO);
	
	/**
	 * Get Run To Zero Report.
	 * @param accId
	 * @param reportChartDTO
	 * @return
	 */
	List<RunToZeroDTO> getRunToZeroReport(String accId,ReportChartDTO reportChartDTO);
	
	/**
	 * Gets the compliance report.
	 *
	 * @param fromDate the from date
	 * @param toDate the to date
	 * @param assignmentGroup the assignment group
	 * @param applicationName the application name
	 * @return the compliance report
	 */
	List<ComplianceDTO> getComplianceReport(String fromDate, String toDate, String assignmentGroup,
			String applicationName);

	/**
	 * Gets the inc missing ko report.
	 *
	 * @param fromDate the from date
	 * @param toDate the to date
	 * @param assignmentGroup the assignment group
	 * @param applicationName the application name
	 * @return the inc missing ko report
	 */
	List<IncMissingKODTO> getIncMissingKoReport(String fromDate, String toDate, String assignmentGroup,
			String applicationName);

	/**
	 * Gets the inc missing ko chart.
	 *
	 * @param fromDate the from date
	 * @param toDate the to date
	 * @param assignmentGroup the assignment group
	 * @param applicationName the application name
	 * @return the inc missing ko chart
	 */
	List<IncMissingKODTO> getIncMissingKoChart(String fromDate, String toDate, String assignmentGroup,
			String applicationName);

	/**
	 * Gets the mttr report.
	 *
	 * @param fromDate the from date
	 * @param toDate the to date
	 * @param assignmentGroup the assignment group
	 * @param applicationName the application name
	 * @return the mttr report
	 */
	List<MttrDTO> getMttrReport(String fromDate, String toDate, String assignmentGroup, String applicationName);

	/**
	 * Gets the mttr chart.
	 *
	 * @param fromDate the from date
	 * @param toDate the to date
	 * @param assignmentGroup the assignment group
	 * @param applicationName the application name
	 * @return the mttr chart
	 */
	List<MttrDTO> getMttrChart(String fromDate, String toDate, String assignmentGroup, String applicationName);

	/**
	 * Gets the ageing workinfo report.
	 *
	 * @param fromDate the from date
	 * @param toDate the to date
	 * @param assignmentGroup the assignment group
	 * @param applicationName the application name
	 * @return the ageing workinfo report
	 */
	List<AgeingWorkinfoDTO> getAgeingWorkinfoReport(String fromDate, String toDate, String assignmentGroup,
			String applicationName);

	/**
	 * Gets the mttr priority report.
	 *
	 * @param fromDate the from date
	 * @param toDate the to date
	 * @param assignmentGroup the assignment group
	 * @param applicationName the application name
	 * @return the mttr priority report
	 */
	List<MttrDTO> getMttrPriorityReport(String fromDate, String toDate, String assignmentGroup, String applicationName);

	/**
	 * Gets the ageing workinfo report detail.
	 *
	 * @param fromDate the from date
	 * @param toDate the to date
	 * @param assignmentGroup the assignment group
	 * @param applicationName the application name
	 * @return the ageing workinfo report detail
	 */
	List<AgeingWorkinfoDTO> getAgeingWorkinfoReportDetail(String fromDate, String toDate, String assignmentGroup,
			String applicationName);

}
