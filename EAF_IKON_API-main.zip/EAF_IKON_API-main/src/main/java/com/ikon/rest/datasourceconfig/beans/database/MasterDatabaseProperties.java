package com.ikon.rest.datasourceconfig.beans.database;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import com.ikon.rest.master.entity.Tenant;

import lombok.Getter;
import lombok.Setter;

@Configuration
@ConfigurationProperties("spring.lookup")
@Getter
@Setter
public class MasterDatabaseProperties {

	private Tenant config;
}
