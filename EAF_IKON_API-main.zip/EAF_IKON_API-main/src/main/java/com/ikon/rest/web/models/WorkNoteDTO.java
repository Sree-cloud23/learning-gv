package com.ikon.rest.web.models;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import org.apache.logging.log4j.LogManager;import org.apache.logging.log4j.Logger;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.extern.slf4j.Slf4j;
@Slf4j
public class WorkNoteDTO {
	
	private String value;
	
	@JsonProperty(defaultValue = "sys_created_on")
	private Date sysCreatedOn;
	
	@JsonProperty(defaultValue = "sys_created_by")
	private String sysCreatedBy;
	
	  /** The SimpleDateFormat String. */
	  private static final String SDF_STRING = "yyyy-MM-dd HH:mm:ss";
	  
	  /** The Constant logger. */
	 // private static final Logger LOGGER = LogManager.getLogger(WorkNoteDTO.class);

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
	public Date getSysCreatedOn() {
		return sysCreatedOn;
	}

	public void setSysCreatedOn(Date sysCreatedOn) {
		this.sysCreatedOn = sysCreatedOn;
	}

	public String getSysCreatedBy() {
		return sysCreatedBy;
	}

	public void setSysCreatedBy(String sysCreatedBy) {
		this.sysCreatedBy = sysCreatedBy;
	}

	public void setSys_created_on(String sysCreatedOn) {
		try {
		      if (StringUtils.hasLength(sysCreatedOn))
		        this.sysCreatedOn = (new SimpleDateFormat(SDF_STRING,Locale.getDefault())).parse(sysCreatedOn); 
		    } catch (ParseException e) {
		    	log.error(e.getMessage());
		    } 
	}

	@Override
	public String toString() {
		return "WorkNoteDTO [value=" + value + ", sysCreatedOn=" + sysCreatedOn + ", sysCreatedBy="
				+ sysCreatedBy + "]";
	}

}
