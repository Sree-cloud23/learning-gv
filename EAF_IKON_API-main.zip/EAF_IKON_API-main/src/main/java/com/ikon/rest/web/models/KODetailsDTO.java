package com.ikon.rest.web.models;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.extern.slf4j.Slf4j;

/**
 * The Class KODetailsDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@Slf4j
public class KODetailsDTO {
	
	/** The solutionnumber. */
	private String solutionnumber; // ticketID
	
	/** The goal. */
	private String goal; //
    
    /** The description. */
    private String description; // Short Description
    
    /** The category name. */
    private String categoryName; //
    
    /** The user score. */
    private String userScore; //2
    
    /** The score. */
    private String score; //6.21511
    
    /** The rank. */
    private Integer rank;
    
    /** The problemdetail. */
    private String problemdetail;
    
    /** The solutiontext. */
    private String solutiontext;
    
    /** The category. */
    private String category;
    
    /** The userthumbscount. */
    private String userthumbscount;
    
    /** The attachment name. */
    private String attachmentName;
    
    /** The attachment path. */
    private String attachmentPath;
    
    /** The incident id. */
    private String incidentId;
    
    /** The linked ticket. */
    private String linkedTicket;
    
    /** The application name. */
    //PushKO fields
	private String applicationName;
	
	/** The assignment group. */
	private String assignmentGroup;
	
	/** The long description. */
	private String longDescription;
	
	/** The symptoms. */
	private String symptoms;
	
	/** The resolution. */
	private String resolution;
	
	/** The answer. */
	private String answer;
	
	/** The pub status. */
	private String pubStatus;
	
	/** The user id. */
	private String userId;
	
	/** The ticket id. */
	private String ticketId;
	
	/** The acc id. */
	private String accId;
	
	/** The createactionid. */
	private String createactionid;
	
	/** The created date. */
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Temporal(TemporalType.DATE)
	private Date createdDate;
	
	/** The modified date. */
	private Date modifiedDate;
	
	/** The created by. */
	private String createdBy;
	
	/** The meta keywords. */
	private String metaKeywords;
	
	/** The published by. */
	private String publishedBy;	
	
	/** The published date. */
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Temporal(TemporalType.DATE)
	Date publishedDate;

	/** The reviewed by. */
	private String reviewedBy;
	
	/** The reviewed date. */
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Temporal(TemporalType.DATE)
	Date reviewedDate;
	
	/** The Constant log. */
	//private static final log log = LogManager.getlog(KODetailsDTO.class);
	
	/** The attachment list. */
	private List<AttachmentDTO> attachmentList;

	/** The file. */
	private String file;	
	
	/** The attachName. */
	private String attachName;
	
	/** The causecode*/
	private String causeCode;
	
	/** The attachment list. */
	private List<KOReviewCommnetsDTO> reviewComments;
	
	/** The KO single tags. */
	String KOSingleTags;

	/** The KO bigram tags. */
	String KOBigramTags;

	/** The KO trigram tags. */
	String KOTrigramTags;
	
	String ticketID;
	
	/**The tags array*/
	List<String> tags;

	/**The attachId*/
	private String attachID;
	
	/**incLinkedCount */
	private Integer ticketLinkedCount;
	
	/** The itSMTool*/
	private boolean itSMTool;
	
	
	/** The attach I ds. */
	List<String> attachIDs;
	
	/** The text */
	private String text;
	


	/**
	 * Gets the solutionnumber.
	 *
	 * @return the solutionnumber
	 */
	public String getSolutionnumber() {
		return solutionnumber;
	}
	
	/**
	 * Sets the solutionnumber.
	 *
	 * @param solutionnumber the new solutionnumber
	 */
	public void setSolutionnumber(String solutionnumber) {
		this.solutionnumber = solutionnumber;
	}
	
	/**
	 * Gets the goal.
	 *
	 * @return the goal
	 */
	public String getGoal() {
		return goal;
	}
	
	/**
	 * Sets the goal.
	 *
	 * @param goal the new goal
	 */
	public void setGoal(String goal) {
		this.goal = goal;
	}
	
	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	
	/**
	 * Sets the description.
	 *
	 * @param description the new description
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	
	/**
	 * Gets the category name.
	 *
	 * @return the category name
	 */
	public String getCategoryName() {
		return categoryName;
	}
	
	/**
	 * Sets the category name.
	 *
	 * @param categoryName the new category name
	 */
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	
	/**
	 * Gets the user score.
	 *
	 * @return the user score
	 */
	public String getUserScore() {
		return userScore;
	}
	
	/**
	 * Sets the user score.
	 *
	 * @param userScore the new user score
	 */
	public void setUserScore(String userScore) {
		this.userScore = userScore;
	}
	
	/**
	 * Gets the score.
	 *
	 * @return the score
	 */
	public String getScore() {
		return score;
	}
	
	/**
	 * Sets the score.
	 *
	 * @param score the new score
	 */
	public void setScore(String score) {
		this.score = score;
	}
	
	/**
	 * Gets the problemdetail.
	 *
	 * @return the problemdetail
	 */
	public String getProblemdetail() {
		return problemdetail;
	}
	
	
	
	public String getTicketID() {
		return ticketID;
	}

	public void setTicketID(String ticketID) {
		this.ticketID = ticketID;
	}

	/**
	 * Sets the problemdetail.
	 *
	 * @param problemdetail the new problemdetail
	 */
	public void setProblemdetail(String problemdetail) {
		this.problemdetail = problemdetail;
	}
	
	/**
	 * Gets the solutiontext.
	 *
	 * @return the solutiontext
	 */
	public String getSolutiontext() {
		return solutiontext;
	}
	
	/**
	 * Sets the solutiontext.
	 *
	 * @param solutiontext the new solutiontext
	 */
	public void setSolutiontext(String solutiontext) {
		this.solutiontext = solutiontext;
	}
	
	/**
	 * Gets the category.
	 *
	 * @return the category
	 */
	public String getCategory() {
		return category;
	}
	
	/**
	 * Sets the category.
	 *
	 * @param category the new category
	 */
	public void setCategory(String category) {
		this.category = category;
	}
	
	/**
	 * Gets the userthumbscount.
	 *
	 * @return the userthumbscount
	 */
	public String getUserthumbscount() {
		return userthumbscount;
	}
	
	/**
	 * Sets the userthumbscount.
	 *
	 * @param userthumbscount the new userthumbscount
	 */
	public void setUserthumbscount(String userthumbscount) {
		this.userthumbscount = userthumbscount;
	}
	
	/**
	 * Gets the attachment name.
	 *
	 * @return the attachment name
	 */
	public String getAttachmentName() {
		return attachmentName;
	}
	
	/**
	 * Sets the attachment name.
	 *
	 * @param attachmentName the new attachment name
	 */
	public void setAttachmentName(String attachmentName) {
		this.attachmentName = attachmentName;
	}
	
	/**
	 * Gets the attachment path.
	 *
	 * @return the attachment path
	 */
	public String getAttachmentPath() {
		return attachmentPath;
	}
	
	/**
	 * Sets the attachment path.
	 *
	 * @param attachmentPath the new attachment path
	 */
	public void setAttachmentPath(String attachmentPath) {
		this.attachmentPath = attachmentPath;
	}
	
	/**
	 * Gets the incident id.
	 *
	 * @return the incident id
	 */
	public String getIncidentId() {
		return incidentId;
	}
	
	/**
	 * Sets the incident id.
	 *
	 * @param incidentId the new incident id
	 */
	public void setIncidentId(String incidentId) {
		this.incidentId = incidentId;
	}
	
	/**
	 * Gets the linked ticket.
	 *
	 * @return the linked ticket
	 */
	public String getLinkedTicket() {
		return linkedTicket;
	}
	
	/**
	 * Sets the linked ticket.
	 *
	 * @param linkedTicket the new linked ticket
	 */
	public void setLinkedTicket(String linkedTicket) {
		this.linkedTicket = linkedTicket;
	}
	
	/**
	 * Gets the application name.
	 *
	 * @return the application name
	 */
	public String getApplicationName() {
		return applicationName;
	}
	
	/**
	 * Sets the application name.
	 *
	 * @param applicationName the new application name
	 */
	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}
	
	/**
	 * Gets the assignment group.
	 *
	 * @return the assignment group
	 */
	public String getAssignmentGroup() {
		return assignmentGroup;
	}
	
	/**
	 * Sets the assignment group.
	 *
	 * @param assignmentGroup the new assignment group
	 */
	public void setAssignmentGroup(String assignmentGroup) {
		this.assignmentGroup = assignmentGroup;
	}
	
	/**
	 * Gets the long description.
	 *
	 * @return the long description
	 */
	public String getLongDescription() {
		return longDescription;
	}
	
	/**
	 * Sets the long description.
	 *
	 * @param longDescription the new long description
	 */
	public void setLongDescription(String longDescription) {
		this.longDescription = longDescription;
	}
	
	/**
	 * Gets the symptoms.
	 *
	 * @return the symptoms
	 */
	public String getSymptoms() {
		return symptoms;
	}
	
	/**
	 * Sets the symptoms.
	 *
	 * @param symptoms the new symptoms
	 */
	public void setSymptoms(String symptoms) {
		this.symptoms = symptoms;
	}
	
	/**
	 * Gets the resolution.
	 *
	 * @return the resolution
	 */
	public String getResolution() {
		return resolution;
	}
	
	/**
	 * Sets the resolution.
	 *
	 * @param resolution the new resolution
	 */
	public void setResolution(String resolution) {
		this.resolution = resolution;
	}
	
	/**
	 * Gets the answer.
	 *
	 * @return the answer
	 */
	public String getAnswer() {
		return answer;
	}
	
	/**
	 * Sets the answer.
	 *
	 * @param answer the new answer
	 */
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	
	/**
	 * Gets the pub status.
	 *
	 * @return the pub status
	 */
	public String getPubStatus() {
		return pubStatus;
	}
	
	/**
	 * Sets the pub status.
	 *
	 * @param pubStatus the new pub status
	 */
	public void setPubStatus(String pubStatus) {
		this.pubStatus = pubStatus;
	}
	
	/**
	 * Gets the user id.
	 *
	 * @return the user id
	 */
	public String getUserId() {
		return userId;
	}
	
	/**
	 * Sets the user id.
	 *
	 * @param userId the new user id
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	/**
	 * Gets the ticket id.
	 *
	 * @return the ticket id
	 */
	public String getTicketId() {
		return ticketId;
	}
	
	/**
	 * Sets the ticket id.
	 *
	 * @param ticketId the new ticket id
	 */
	public void setTicketId(String ticketId) {
		this.ticketId = ticketId;
	}
	
	/**
	 * Gets the acc id.
	 *
	 * @return the acc id
	 */
	public String getAccId() {
		return accId;
	}
	
	/**
	 * Sets the acc id.
	 *
	 * @param accId the new acc id
	 */
	public void setAccId(String accId) {
		this.accId = accId;
	}
	
	/**
	 * Gets the createactionid.
	 *
	 * @return the createactionid
	 */
	public String getCreateactionid() {
		return createactionid;
	}
	
	/**
	 * Sets the createactionid.
	 *
	 * @param createactionid the new createactionid
	 */
	public void setCreateactionid(String createactionid) {
		this.createactionid = createactionid;
	}
	
	/**
	 * Gets the created date.
	 *
	 * @return the created date
	 */
	public Date getCreatedDate() {
		return createdDate;
	}
	
	/**
	 * Sets the created date.
	 *
	 * @param createdDate the new created date
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	
	/**
	 * Gets the modified date.
	 *
	 * @return the modified date
	 */
	public Date getModifiedDate() {
		return modifiedDate;
	}
	
	/**
	 * Sets the modified date.
	 *
	 * @param modifiedDate the new modified date
	 */
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	
	/**
	 * Sets the created date.
	 *
	 * @param createdDate the new created date
	 */
	public void setCreatedDate(String createdDate) {
	    try {
	      if (StringUtils.hasLength(createdDate))
	        this.createdDate = (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())).parse(createdDate); 
	    } catch (ParseException e) {
	      log.error(e.getMessage());
	    } 
	  }
	
	/**
	 * Sets the modified date.
	 *
	 * @param modifiedDate the new modified date
	 */
	public void setModifiedDate(String modifiedDate) {
	    try {
	      if (StringUtils.hasLength(modifiedDate))
	        this.modifiedDate = (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())).parse(modifiedDate); 
	    } catch (ParseException e) {
	    	log.error(e.getMessage());
	    } 
	  }
	
	/**
	 * Gets the created by.
	 *
	 * @return the created by
	 */
	public String getCreatedBy() {
		return createdBy;
	}
	
	/**
	 * Sets the created by.
	 *
	 * @param createdBy the new created by
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	/**
	 * Gets the meta keywords.
	 *
	 * @return the meta keywords
	 */
	public String getMetaKeywords() {
		return metaKeywords;
	}
	
	/**
	 * Sets the meta keywords.
	 *
	 * @param metaKeywords the new meta keywords
	 */
	public void setMetaKeywords(String metaKeywords) {
		this.metaKeywords = metaKeywords;
	}
	
	/**
	 * Gets the published by.
	 *
	 * @return the published by
	 */
	public String getPublishedBy() {
		return publishedBy;
	}
	
	/**
	 * Sets the published by.
	 *
	 * @param publishedBy the new published by
	 */
	public void setPublishedBy(String publishedBy) {
		this.publishedBy = publishedBy;
	}

	public Integer getRank() {
		return rank;
	}

	public void setRank(Integer rank) {
		this.rank = rank;
	}

	/**
	 * Gets the attachment list.
	 *
	 * @return the attachment list
	 */
	public List<AttachmentDTO> getAttachmentList() {
		return attachmentList;
	}

	/**
	 * Sets the attachment list.
	 *
	 * @param attachmentList the new attachment list
	 */
	public void setAttachmentList(List<AttachmentDTO> attachmentList) {
		this.attachmentList = attachmentList;
	}

	/**
	 * 
	 * @return
	 */
	public String getCauseCode() {
		return causeCode;
	}

	/**
	 * 
	 * @param causeCode1
	 */
	public void setCauseCode(String causeCode) {
		this.causeCode = causeCode;
	}

	/**
	 * @return the file
	 */
	public String getFile() {
		return file;
	}

	/**
	 * @param file the file to set
	 */
	public void setFile(String file) {
		this.file = file;
	}

	/**
	 * @return the attachName
	 */
	public String getAttachName() {
		return attachName;
	}

	/**
	 * @param attachName the attachName to set
	 */
	public void setAttachName(String attachName) {
		this.attachName = attachName;
	}

	/**
	 * @return the reviewComments
	 */
	public List<KOReviewCommnetsDTO> getReviewComments() {
		return reviewComments;
	}

	/**
	 * @param reviewComments the reviewComments to set
	 */
	public void setReviewComments(List<KOReviewCommnetsDTO> reviewComments) {
		this.reviewComments = reviewComments;
	}

	/**
	 * @return the kOSingleTags
	 */
	public String getKOSingleTags() {
		return KOSingleTags;
	}

	/**
	 * @param kOSingleTags the kOSingleTags to set
	 */
	public void setKOSingleTags(String kOSingleTags) {
		KOSingleTags = kOSingleTags;
	}

	/**
	 * @return the kOBigramTags
	 */
	public String getKOBigramTags() {
		return KOBigramTags;
	}

	/**
	 * @param kOBigramTags the kOBigramTags to set
	 */
	public void setKOBigramTags(String kOBigramTags) {
		KOBigramTags = kOBigramTags;
	}

	/**
	 * @return the kOTrigramTags
	 */
	public String getKOTrigramTags() {
		return KOTrigramTags;
	}

	/**
	 * @param kOTrigramTags the kOTrigramTags to set
	 */
	public void setKOTrigramTags(String kOTrigramTags) {
		KOTrigramTags = kOTrigramTags;
	}

	/**
	 * @return the publishedDate
	 */
	public Date getPublishedDate() {
		return publishedDate;
	}

	/**
	 * @param publishedDate the publishedDate to set
	 */
	public void setPublishedDate(Date publishedDate) {
		this.publishedDate = publishedDate;
	}

	/**
	 * @return the reviewedBy
	 */
	public String getReviewedBy() {
		return reviewedBy;
	}

	/**
	 * @param reviewedBy the reviewedBy to set
	 */
	public void setReviewedBy(String reviewedBy) {
		this.reviewedBy = reviewedBy;
	}

	/**
	 * @return the reviewedDate
	 */
	public Date getReviewedDate() {
		return reviewedDate;
	}

	/**
	 * @param reviewedDate the reviewedDate to set
	 */
	public void setReviewedDate(Date reviewedDate) {
		this.reviewedDate = reviewedDate;
	}

	/**
	 * 
	 * @return
	 */
	public List<String> getTags() {
		return tags;
	}

	/**
	 * 
	 * @param tags
	 */
	public void setTags(List<String> tags) {
		this.tags = tags;
	}

	/**
	 * @return
	 */
	public String getAttachID() {
		return attachID;
	}

	/**
	 * 
	 * @param attachID
	 */
	public void setAttachID(String attachID) {
		this.attachID = attachID;
	}

	/**
	 * 
	 * @return
	 */
	public Integer getTicketLinkedCount() {
		return ticketLinkedCount;
	}
	/**
	 * 
	 * @param ticketLinkedCount
	 */
	public void setTicketLinkedCount(Integer ticketLinkedCount) {
		this.ticketLinkedCount = ticketLinkedCount;
	}

	/**
	 * 
	 * @return
	 */
	public boolean isItSMTool() {
		return itSMTool;
	}

	/**
	 * @param itSMTool
	 */
	public void setItSMTool(boolean itSMTool) {
		this.itSMTool = itSMTool;
	}
	
	

	public List<String> getAttachIDs() {
		return attachIDs;
	}

	public void setAttachIDs(List<String> attachIDs) {
		this.attachIDs = attachIDs;
	}

	/**
	 * 
	 * @return
	 */
	public String getText() {
		return text;
	}

	/**
	 * 
	 * @param text
	 */
	public void setText(String text) {
		this.text = text;
	}

	@Override
	public String toString() {
		return "KODetailsDTO [solutionnumber=" + solutionnumber + ", goal=" + goal + ", description=" + description
				+ ", categoryName=" + categoryName + ", userScore=" + userScore + ", score=" + score + ", rank=" + rank
				+ ", problemdetail=" + problemdetail + ", solutiontext=" + solutiontext + ", category=" + category
				+ ", userthumbscount=" + userthumbscount + ", attachmentName=" + attachmentName + ", attachmentPath="
				+ attachmentPath + ", incidentId=" + incidentId + ", linkedTicket=" + linkedTicket
				+ ", applicationName=" + applicationName + ", assignmentGroup=" + assignmentGroup + ", longDescription="
				+ longDescription + ", symptoms=" + symptoms + ", resolution=" + resolution + ", answer=" + answer
				+ ", pubStatus=" + pubStatus + ", userId=" + userId + ", ticketId=" + ticketId + ", accId=" + accId
				+ ", createactionid=" + createactionid + ", createdDate=" + createdDate + ", modifiedDate="
				+ modifiedDate + ", createdBy=" + createdBy + ", metaKeywords=" + metaKeywords + ", publishedBy="
				+ publishedBy + ", publishedDate=" + publishedDate + ", reviewedBy=" + reviewedBy + ", reviewedDate="
				+ reviewedDate + ", attachmentList=" + attachmentList + ", file=" + file + ", attachName=" + attachName
				+ ", causeCode=" + causeCode + ", reviewComments=" + reviewComments + ", KOSingleTags=" + KOSingleTags
				+ ", KOBigramTags=" + KOBigramTags + ", KOTrigramTags=" + KOTrigramTags + ", ticketID=" + ticketID
				+ ", tags=" + tags + ", attachID=" + attachID + ", ticketLinkedCount=" + ticketLinkedCount
				+ ", itSMTool=" + itSMTool + ", attachIDs=" + attachIDs + ", text=" + text + "]";
	}	
	
	
	
	

}