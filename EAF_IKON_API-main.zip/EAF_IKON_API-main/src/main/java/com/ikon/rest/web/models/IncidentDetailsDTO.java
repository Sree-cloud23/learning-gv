package com.ikon.rest.web.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * The Class IncidentDetailsDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class IncidentDetailsDTO {
	
	/** The solutionnumber. */
	private String solutionnumber; // ticketID
	
	/** The goal. */
	private String goal; //
	
	/** The problem detail. */
	private String problemDetail;
	
	/** The solution text. */
	private String solutionText;
	
	/** The sys id. */
	private String sysId;
    
    /** The description. */
    private String description; //
    
    /** The category. */
    private String category;
    
    /** The category name. */
    private String categoryName; //
    
    /** The user score. */
    private String userScore; //
    
    /** The score. */
    private String score; //6.21511
    
	/**
	 * Gets the solutionnumber.
	 *
	 * @return the solutionnumber
	 */
	public String getSolutionnumber() {
		return solutionnumber;
	}
	
	/**
	 * Sets the solutionnumber.
	 *
	 * @param solutionnumber the new solutionnumber
	 */
	public void setSolutionnumber(String solutionnumber) {
		this.solutionnumber = solutionnumber;
	}
	
	/**
	 * Gets the goal.
	 *
	 * @return the goal
	 */
	public String getGoal() {
		return goal;
	}
	
	/**
	 * Sets the goal.
	 *
	 * @param goal the new goal
	 */
	public void setGoal(String goal) {
		this.goal = goal;
	}
	
	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	
	/**
	 * Sets the description.
	 *
	 * @param description the new description
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	
	/**
	 * Gets the category name.
	 *
	 * @return the category name
	 */
	public String getCategoryName() {
		return categoryName;
	}
	
	/**
	 * Sets the category name.
	 *
	 * @param categoryName the new category name
	 */
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	
	/**
	 * Gets the user score.
	 *
	 * @return the user score
	 */
	public String getUserScore() {
		return userScore;
	}
	
	/**
	 * Sets the user score.
	 *
	 * @param userScore the new user score
	 */
	public void setUserScore(String userScore) {
		this.userScore = userScore;
	}
	
	/**
	 * Gets the score.
	 *
	 * @return the score
	 */
	public String getScore() {
		return score;
	}
	
	/**
	 * Sets the score.
	 *
	 * @param score the new score
	 */
	public void setScore(String score) {
		this.score = score;
	}
	
	/**
	 * Gets the problem detail.
	 *
	 * @return the problem detail
	 */
	public String getProblemDetail() {
		return problemDetail;
	}
	
	/**
	 * Sets the problem detail.
	 *
	 * @param problemDetail the new problem detail
	 */
	public void setProblemDetail(String problemDetail) {
		this.problemDetail = problemDetail;
	}
	
	/**
	 * Gets the solution text.
	 *
	 * @return the solution text
	 */
	public String getSolutionText() {
		return solutionText;
	}
	
	/**
	 * Sets the solution text.
	 *
	 * @param solutionText the new solution text
	 */
	public void setSolutionText(String solutionText) {
		this.solutionText = solutionText;
	}
	
	/**
	 * Gets the sys id.
	 *
	 * @return the sys id
	 */
	public String getSysId() {
		return sysId;
	}
	
	/**
	 * Sets the sys id.
	 *
	 * @param sysId the new sys id
	 */
	public void setSysId(String sysId) {
		this.sysId = sysId;
	}
	
	/**
	 * Gets the category.
	 *
	 * @return the category
	 */
	public String getCategory() {
		return category;
	}
	
	/**
	 * Sets the category.
	 *
	 * @param category the new category
	 */
	public void setCategory(String category) {
		this.category = category;
	}
}
