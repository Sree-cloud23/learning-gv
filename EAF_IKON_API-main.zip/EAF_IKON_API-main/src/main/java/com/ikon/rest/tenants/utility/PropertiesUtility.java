package com.ikon.rest.tenants.utility;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.ikon.rest.datasourceconfig.beans.tenants.TenantInfo;

public class PropertiesUtility {

	/**
	 * The Static TENANT_DATA_STORE Map.
	 */
	public static final Map<String, TenantInfo> TENANT_PROP_DATA_STORE = new ConcurrentHashMap<>();

	/**
	 * Private Constructor to ensure Singleton Class
	 */
	private PropertiesUtility() {
		throw new UnsupportedOperationException("PropertiesUtility Class cannot be instantiated");
	}
}
