package com.ikon.rest.web;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.Random;

import javax.inject.Inject;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.ikon.dto.KOInfoBean;
import com.ikon.dto.TicketDataBean;
import com.ikon.model.KOArtifacts;
import com.ikon.model.KOInfo;
import com.ikon.repository.KOInfoRepository;
import com.ikon.repository.KOUsageRepository;
import com.ikon.repository.TicketDataHistoryRepository;
import com.ikon.rest.datasourceconfig.tenants.TenantContextHolder;
import com.ikon.rest.security.constants.RequestConstants;
import com.ikon.rest.security.service.RequestValidationService;
import com.ikon.rest.service.KOInfoServiceRest;
import com.ikon.rest.web.models.ErrorResponseDTO;
import com.ikon.rest.web.models.KODetailsDTO;
import com.ikon.rest.web.models.KOInfoDTO;
import com.ikon.rest.web.models.KOListDTO;
import com.ikon.rest.web.models.KOReviewCommnetsDTO;
import com.ikon.rest.web.models.MultilingualKOStatusDTO;
import com.ikon.rest.web.models.SearchIncidentDTO;
import com.ikon.rest.web.models.SolutionNumberDTO;
import com.ikon.rest.web.models.TicketDataDTO;
import com.ikon.rest.web.models.dashboard.ParamBean;
import com.ikon.service.KOInfoService;
import com.ikon.service.MLDBProcess;
import com.ikon.service.TicketDataService;
import com.ikon.web.KOController;
import com.mongodb.MongoException;

import lombok.extern.slf4j.Slf4j;

/**
 * The Class KOControllerRest.
 *
 */


@RestController
@PropertySource("classpath:rest.properties")
@Slf4j
public class KOControllerRest {
	/** The Constant ACCOUNT_ID. */
	private static final String ACCOUNT_ID = "1"; // Account_ID = 1 for CIAP

	/** The ko info service. */
	@Autowired
	private transient KOInfoService koInfoService;

	/** The ko info service rest. */
	@Autowired
	private transient KOInfoServiceRest koInfoServiceRest;
	
	/** The ml DB process. */
	@Inject
	private transient MLDBProcess mlDBProcess;
	
	/** The ticket data service. */
	@Inject
	private transient TicketDataService ticketDataService;
	
	/** The k O usage repository. */
	@Autowired
	private transient KOUsageRepository kOUsageRepository;

	/** The Constant log. */
	//private static final log log = LogManager.getlog(KOControllerRest.class);
	
	/** The Constant ACCESS_CONTROL_ALLOW_ORIGIN. */
	private static final String ACCESS_CONTROL_ALLOW_ORIGIN = "Access-Control-Allow-Origin";

	/** The Constant ACCESS_CONTROL_ALLOW_CREDENTIALS. */
	private static final String ACCESS_CONTROL_ALLOW_CREDENTIALS = "Access-Control-Allow-Credentials";
	
	/** The Constant TRUE. */
	private static final String TRUE = "true";
	
	/** The ticket data history repository. */
	@Autowired
	private transient TicketDataHistoryRepository ticketDataHistoryRepository;

	
	/** The Constant MAX_Desc. */
	private static final int MAX_Desc = 120;
	
	/** The attach base. */
	//@Value("${ikon2.attachmentBase}")
	//private String attachBase;
	
	/** The account name. */
	//@Value("${ikon2.accountName}")
	//private String accountName;
	
	@Value("${status.field}")
	private String statusField;
	
	/** The Environment. */
	@Autowired
	private Environment env;
	
	/** The k O info repository. */
	@Inject
	private transient KOInfoRepository kOInfoRepository;
	
	@Inject
	private transient KOController koController;
	
	/**
	 * The Validation Service.
	 */
	@Autowired
	private RequestValidationService requestValidationServiceService;
	
	/**
	 * Gets the KOs.
	 *
	 * @param response        the response
	 * @return the kos
	 */
	@GetMapping(value = "/api/koList")
	public ResponseEntity<?> getAllKO(@RequestParam("roleType") String roleType,@RequestHeader(name = RequestConstants.TENANT_ID) final String encryptedTenantId,HttpServletResponse response) {
		log.info("START: Kolist Rest Controller");
		response.setHeader(ACCESS_CONTROL_ALLOW_ORIGIN, "*");
		response.setHeader(ACCESS_CONTROL_ALLOW_CREDENTIALS, TRUE);
		
		// Setting Tenant & MDC Context
        requestValidationServiceService.decryptAndValidateTenantId(encryptedTenantId);
        
		List<KOListDTO> responseKOList = new LinkedList<KOListDTO>();
		ErrorResponseDTO apiResponse = new ErrorResponseDTO();
		try {
		List<KOInfoBean> koInfoList = koInfoServiceRest.getKOList(roleType);
		koInfoList.forEach(infoBean -> {
			KOListDTO kDTO = new KOListDTO();
			kDTO.setSolutionnumber(infoBean.getKoID());
			kDTO.setDescription(infoBean.getShortDescription());
			kDTO.setAssignmentGroup(infoBean.getAssignmentGroup());
			kDTO.setApplicationName(infoBean.getApplicationName());
			kDTO.setPubStatus(infoBean.getPublicationStatus());
			responseKOList.add(kDTO);
		});
		log.info("No of KO's found: " + responseKOList.size());
		log.info("END: Kolist Rest Controller");
		return new ResponseEntity<>(responseKOList, HttpStatus.OK);
		}catch(Exception ex) {
			apiResponse.setError(true);
			apiResponse.setMessage("koList_001");
			log.info("END: Kolist Rest Controller"+ex.getMessage());
			return new ResponseEntity<>(apiResponse, HttpStatus.UNPROCESSABLE_ENTITY);
		}
	}
	
	/**
	 * @param ticketDataDTO
	 * @param response
	 * @return
	 */
	@PostMapping(value = "/api/searchIncident")
	public ResponseEntity<?> getTicketdetail(@RequestBody TicketDataDTO ticketDataDTO,@RequestHeader(name = RequestConstants.TENANT_ID) final String encryptedTenantId,
			HttpServletResponse response) {
		log.info("START:Get Ticket detail Method");
		response.setHeader(ACCESS_CONTROL_ALLOW_ORIGIN, "*");
		response.setHeader(ACCESS_CONTROL_ALLOW_CREDENTIALS, TRUE);
		
		// Setting Tenant & MDC Context
        requestValidationServiceService.decryptAndValidateTenantId(encryptedTenantId);
		
		List<SearchIncidentDTO> responseKOList = new LinkedList<>();
		ErrorResponseDTO apiResponse = new ErrorResponseDTO();
		try {
		List<TicketDataBean> koInfoList = koInfoServiceRest.getTicketDetail(ticketDataDTO.getNumber());
		if (Objects.nonNull(koInfoList) && koInfoList.size() > 0) {
			koInfoList.forEach(infoBean -> {
				SearchIncidentDTO tDTO = new SearchIncidentDTO();
				tDTO.setKoid(infoBean.getKoID());
				tDTO.setAssignmentGroup(infoBean.getAssignmentGroup());
				tDTO.setApplicationName(infoBean.getApplicationName());
				if(StringUtils.isEmpty(infoBean.getCauseCodeLevel1())) {
					tDTO.setCauseCode("");
				}else {
				tDTO.setCauseCode(infoBean.getCauseCodeLevel1()+"|"+infoBean.getCauseCodeLevel2()+"|"+infoBean.getCauseCodeLevel3()+"|"+infoBean.getCauseCodeLevel4()+"|"+infoBean.getCauseCodeLevel5());
				}
				responseKOList.add(tDTO);
			});

			if (!StringUtils.isEmpty(responseKOList.get(0).getKoid())) {
				apiResponse.setError(true);
				apiResponse.setMessage("searchIncident_001");
				return new ResponseEntity<>(apiResponse, HttpStatus.UNPROCESSABLE_ENTITY);
			} else {
				log.info("END: Get Ticket detail Method");
				return new ResponseEntity<>(responseKOList, HttpStatus.OK);
			}
		}
		else {
			apiResponse.setError(true);
			apiResponse.setMessage("searchIncident_002");
			return new ResponseEntity<>(apiResponse, HttpStatus.UNPROCESSABLE_ENTITY);
		}
		}catch(Exception ex) {
			log.error("Error: Kolist Rest Controller"+ex.getMessage());
			return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}	
	
	
	/**
	 * Create KO.
	 * @param koDTO
	 * @param response
	 * @return
	 */
	@PostMapping(value = "/api/createko", produces = MediaType.APPLICATION_JSON_VALUE)
	@JsonIgnoreProperties(ignoreUnknown = true)
	public ResponseEntity<?> createKOApi(@RequestHeader("Authorization") final String token, @RequestBody KODetailsDTO koDTO, @RequestHeader(name = RequestConstants.TENANT_ID) final String encryptedTenantId,HttpServletResponse response) {		
		log.info("START:Create KO ");
		
		response.setHeader(ACCESS_CONTROL_ALLOW_ORIGIN, "*");
		response.setHeader(ACCESS_CONTROL_ALLOW_CREDENTIALS, TRUE);
		
		// Setting Tenant & MDC Context
        requestValidationServiceService.decryptAndValidateTenantId(encryptedTenantId);
		
		final String payload = token.split(" ")[1];
		final DecodedJWT jwt = JWT.decode(payload);
		final String userName = jwt.getClaim("itsm_username").asString();
	
	     ErrorResponseDTO apiResponse = new ErrorResponseDTO();	
	     KOInfoBean koInfoBeanListvalue = null;	  
	 	List<KOInfoBean> koInfoBeanList = null;
	     try {
		/**Validation Starts*/	   
		     if(koDTO.getDescription().isEmpty()) {
					apiResponse.setError(true);
					apiResponse.setMessage("createKO_002");
					return new ResponseEntity<>(apiResponse,HttpStatus.UNPROCESSABLE_ENTITY);
				}
			if(koDTO.getDescription().length()>MAX_Desc) {
				apiResponse.setError(true);
				apiResponse.setMessage("createKO_003");
				return new ResponseEntity<>(apiResponse,HttpStatus.UNPROCESSABLE_ENTITY);
			}			
		/** Validation Ends */			
			KOInfoBean koInfo = new KOInfoBean();	
			koInfo.setTicketID(koDTO.getTicketID());
	     	koInfo.setShortDescription(koDTO.getDescription());
			koInfo.setLongDescription(koDTO.getLongDescription());
			koInfo.setApplicationName(koDTO.getApplicationName());
			koInfo.setCauseCode(koDTO.getCauseCode());
			koInfo.setAssignmentGroup(koDTO.getAssignmentGroup());	
			koInfo.setSymptoms(koDTO.getSymptoms());
			koInfo.setAnswer(koDTO.getAnswer());
			koInfo.setResolution(koDTO.getResolution());
			koInfo.setKoStage(koDTO.getPubStatus());	
			koInfo.setPublicationStatus(koDTO.getPubStatus());
			koInfoBeanList=koInfoServiceRest.createKO(koInfo,userName);
			if (Objects.nonNull(koInfoBeanList) && koInfoBeanList.size() > 0) {
				koInfoBeanListvalue = koInfoBeanList.get(0);
			}
			/**Validating base64 file*/
			byte[] decodedBytes = Base64.getDecoder().decode(koDTO.getFile());		
			long kilobytes = (decodedBytes.length / 1024);
	        long megabytes = (kilobytes / 1024);
	      	if(megabytes>15) {
				apiResponse.setError(true);
				apiResponse.setMessage("createKO_004");
				return new ResponseEntity<>(apiResponse, HttpStatus.UNPROCESSABLE_ENTITY);
				}
			
			try {
				if (StringUtils.hasLength(koDTO.getAttachName()) && StringUtils.hasLength(koDTO.getFile()) && StringUtils.hasLength(koInfoBeanListvalue.getVar_ko())) {
					final String koSerialNum = kOInfoRepository.getKOSerialNo(koInfoBeanListvalue.getVar_ko());
					String attachTypeBase = koInfoServiceRest.getAttachTypeBase("KO");
					String basePath = String.join(File.separator, TenantContextHolder.getTenantContextHolder().getAttachmentBase(), TenantContextHolder.getTenantContextHolder().getAccountName(), attachTypeBase,koInfoBeanListvalue.getVar_ko(),
							koSerialNum);
					
					// Creation of attachment id folder
					File f = new File(basePath);
					if (!f.exists()) {
						f.mkdirs();
					}
					// Save File content in the reporsitory
					Path copyLocation = Paths.get(basePath + File.separator + koDTO.getAttachName());
					byte[] data = Base64.getDecoder().decode(koDTO.getFile());
					System.out.println(data.length);
					Files.write(copyLocation, data);
					log.info("File is saved successfully : " + copyLocation.toString());
					// Save file data in KO Artifacts
					koInfoServiceRest.saveKOArtifacts(koInfoBeanListvalue.getVar_ko(),koSerialNum,koDTO.getAttachName());
				} else {
					throw new IOException("File content is empty or null");
				}
				log.info("Fiel Record has been saved in database sucessfully");
				

			} catch (IOException | HibernateException | ArrayIndexOutOfBoundsException e) {
				log.error(e+" Error : "+ e.getMessage());
				log.info("Error occurred while uploading the file");
				apiResponse.setError(true);
				apiResponse.setMessage("createKO_005");
				return new ResponseEntity<>(apiResponse,HttpStatus.UNPROCESSABLE_ENTITY);	
			}			
			try {
				mlDBProcess.insertDataIntoPostgres(koInfo, ACCOUNT_ID, koInfoBeanListvalue.getVar_ko(),koInfo.getPublicationStatus(),userName);
			
			} catch (IOException | MongoException e) {
				log.error("Error: Issue while inserting data in ML DB "+e.getMessage());
			}
    	  
       }catch (Exception ex) {
    	   log.error("Error: Create KO Rest Controller"+ex.getMessage());
    	   apiResponse.setError(true);
		   apiResponse.setMessage("createKO_005");
		   return new ResponseEntity<>(apiResponse,HttpStatus.UNPROCESSABLE_ENTITY);		   
	    }		
	    apiResponse.setError(false);
 		apiResponse.setMessage("createKO_001");
	 	log.info("END:Create KO");
		return new ResponseEntity<>(apiResponse,HttpStatus.OK);
	}
	


	/**
	 * @param param
	 * @param type
	 * @return
	 */
	@GetMapping(value = "/api/getStatus")
	public ResponseEntity<?> getKOStatusMapping(@RequestParam("param") String param,@RequestHeader(name = RequestConstants.TENANT_ID) final String encryptedTenantId) {
		log.info("START: Get KO Status");
		
		// Setting Tenant & MDC Context
        requestValidationServiceService.decryptAndValidateTenantId(encryptedTenantId);
		
		ParamBean responseList=new ParamBean();
		ErrorResponseDTO apiResponse = new ErrorResponseDTO();	
		String statusArr[];
		try {
			if(param==null||param.isEmpty() || param.equalsIgnoreCase("all")) {
				statusArr=statusField.split(",");
				responseList=getStatusData(statusArr);
			}
			else {
				statusArr=param.split(",");
				responseList=getStatusData(statusArr);
				}					
			
		} catch (Exception e) {
			log.error("Error occured while fetching KO status" + e.getMessage());
			apiResponse.setError(true);
		 	apiResponse.setMessage("getKOStatus_001");
			return new ResponseEntity<>(apiResponse, HttpStatus.UNPROCESSABLE_ENTITY);
		}
		log.info("END: Get KO Status");
		return new ResponseEntity<>(responseList, HttpStatus.OK);

	}
	
	public ParamBean getStatusData(String[] fieldArr) {
		List<MultilingualKOStatusDTO> koInfoList = null;
		ParamBean response=new ParamBean();
		for(String field:fieldArr) {
		koInfoList = koInfoServiceRest.getAllKOStatus(field.toLowerCase());	

		if(field.equalsIgnoreCase("charttype")) {
			response.setReportChartType(koInfoList);
			
		}
		 if(field.equalsIgnoreCase("reportName")) {
			 response.setReportName(koInfoList);
			
		}
		 if(field.equalsIgnoreCase("chartName")) {
			 response.setChartName(koInfoList);
		}
		 if(field.equalsIgnoreCase("frequency")) {
			 response.setFrequency(koInfoList);
		 }
		 
		 if(field.equalsIgnoreCase("KO")) {
			 response.setKoStatus(koInfoList);
		 }
		}
		 return response;
	
	}
	
	
	/**
	 * 
	 * @param koDTO
	 * @param response
	 * @return
	 */
	@PostMapping(value = "/api/getKODetail")
	public ResponseEntity<?> getKODetails(@RequestBody KODetailsDTO koDTO,@RequestHeader(name = RequestConstants.TENANT_ID) final String encryptedTenantId,HttpServletResponse response) {
		response.setHeader(ACCESS_CONTROL_ALLOW_ORIGIN, "*");
		response.setHeader(ACCESS_CONTROL_ALLOW_CREDENTIALS, TRUE);
		
		// Setting Tenant & MDC Context
        requestValidationServiceService.decryptAndValidateTenantId(encryptedTenantId);
		
		ErrorResponseDTO apiResponse = new ErrorResponseDTO();
		final KODetailsDTO kDTO = new KODetailsDTO();
		List<KODetailsDTO> responseKOList = new LinkedList<KODetailsDTO>();
		try {
			List<KOInfoBean> resultList = koInfoServiceRest.getKODetail(koDTO.getSolutionnumber());
			final String koSerialNum = kOInfoRepository.getKOSerialNo(koDTO.getSolutionnumber());
			final Integer linkedIncCount = kOUsageRepository.getLinkedIncCountForASerialNumber(Integer.parseInt(koSerialNum));
			resultList.forEach(infoBean -> {
				kDTO.setSolutionnumber(infoBean.getKoID());
				kDTO.setTicketID(infoBean.getTicketID());
				kDTO.setApplicationName(infoBean.getApplicationName());
				kDTO.setAssignmentGroup(infoBean.getAssignmentGroup());
				kDTO.setCauseCode(infoBean.getCauseCode());
				kDTO.setDescription(infoBean.getShortDescription());
				kDTO.setLongDescription(infoBean.getLongDescription());
				kDTO.setSymptoms(infoBean.getSymptoms());
				kDTO.setAnswer(infoBean.getAnswer());
				kDTO.setResolution(infoBean.getResolution());
				//Add the attachment list to existing flow
				kDTO.setAttachmentList(koInfoServiceRest.getAttachmentList(infoBean.getKOSerialNo()));
				kDTO.setTags(koController.getTagsList(infoBean));
				kDTO.setReviewComments(koInfoServiceRest.retrieveReviewComments(koDTO.getSolutionnumber()));				
				kDTO.setCreatedBy(infoBean.getCreatedBy());
				kDTO.setCreatedDate(infoBean.getCreatedDate());
				kDTO.setReviewedBy(infoBean.getReviewedBy());
				kDTO.setReviewedDate(infoBean.getReviewedDate());
				kDTO.setPublishedBy(infoBean.getPublishedBy());
				kDTO.setPublishedDate(infoBean.getPublishedDate());
				kDTO.setTicketLinkedCount(linkedIncCount);
				kDTO.setPubStatus(infoBean.getPublicationStatus());
				if(infoBean.getITSMTool()==null||!infoBean.getITSMTool().equals("UI"))
					kDTO.setItSMTool(true);
				responseKOList.add(kDTO);
			});	
		} catch (Exception e) {
			log.error("Error occured while fetching KO " + e.getMessage());
			apiResponse.setError(true);
		 	apiResponse.setMessage("getKODetail_001");
			return new ResponseEntity<>(apiResponse, HttpStatus.UNPROCESSABLE_ENTITY);
		}
		return new ResponseEntity<>(responseKOList.get(0), HttpStatus.OK);
		
	}
	
	/**
	 * 
	 * @param solutionnumber
	 * @return
	 */
	@PostMapping(value = "/api/deleteko")
	public ResponseEntity<?> deleteKOs(@RequestHeader("Authorization") final String token,@RequestBody SolutionNumberDTO solutionnumber,@RequestHeader(name = RequestConstants.TENANT_ID) final String encryptedTenantId) {
		log.info("START: Delete KO");
		
		// Setting Tenant & MDC Context
        requestValidationServiceService.decryptAndValidateTenantId(encryptedTenantId);
		
		final String payload = token.split(" ")[1];
		final DecodedJWT jwt = JWT.decode(payload);
		final String userName = jwt.getClaim("itsm_username").asString();
		ErrorResponseDTO apiResponse = new ErrorResponseDTO();	
		try {
			List<String> solutionnumberList=solutionnumber.getSolutionnumber();
			solutionnumberList.forEach(koid -> {
			     koInfoServiceRest.deleteKO(koid,userName);
			});
			
		} catch (Exception e) {
			log.error("Error occured while fetching deleting the KO's" + e.getMessage());
			apiResponse.setError(true);
		 	apiResponse.setMessage("deleteKO_002");
			return new ResponseEntity<>(apiResponse, HttpStatus.UNPROCESSABLE_ENTITY);
		}
		log.info("END: Delete KO");
		apiResponse.setError(false);
	 	apiResponse.setMessage("deleteKO_001");
		return new ResponseEntity<>(apiResponse, HttpStatus.OK);

	}
	
	

	/**
	 * Update KO.
	 * @param token
	 * @param koDTO
	 * @param response
	 * @return
	 */
	@PostMapping(value = "/api/updateko")
	public ResponseEntity<?> updateKO(@RequestHeader("Authorization") final String token,@RequestBody KODetailsDTO koDTO,@RequestHeader(name = RequestConstants.TENANT_ID) final String encryptedTenantId,HttpServletResponse response) {
		log.info("START: Update KO");
		
		// Setting Tenant & MDC Context
        requestValidationServiceService.decryptAndValidateTenantId(encryptedTenantId);
		
		final String payload = token.split(" ")[1];
		final DecodedJWT jwt = JWT.decode(payload);
		final String userName = jwt.getClaim("itsm_username").asString();
		response.setHeader(ACCESS_CONTROL_ALLOW_ORIGIN, "*");
		response.setHeader(ACCESS_CONTROL_ALLOW_CREDENTIALS, TRUE);	
		ErrorResponseDTO apiResponse = new ErrorResponseDTO();	
		try {
		List<KOReviewCommnetsDTO> dbReviewComments=koInfoServiceRest.retrieveReviewComments(koDTO.getSolutionnumber());
		List<KOReviewCommnetsDTO> requestReviewComments=koDTO.getReviewComments();		
		List<Integer> dbReviewCmt = new ArrayList<>();
		List<Integer> reqReviewCmt = new ArrayList<>();
		
	
		for(KOReviewCommnetsDTO reviewDTO:dbReviewComments)
			dbReviewCmt.add(reviewDTO.getReviewID());
		
		for(KOReviewCommnetsDTO reviewDTO2:requestReviewComments)
			reqReviewCmt.add(reviewDTO2.getReviewID());
		/**Delete review comments*/
		if(koDTO.getPubStatus().equals("3") || koDTO.getPubStatus().equals("4")) {
			for(int review:dbReviewCmt) {
			if(!reqReviewCmt.contains(review)) 
				koInfoService.deleteReviewComment(review);
		    }
		}
		/**Insert and Update review Comments*/
		for(KOReviewCommnetsDTO reviewDTO:requestReviewComments) {
			if(reviewDTO.getReviewID()==0 && reviewDTO.getReviewComments()!=null)
				koInfoServiceRest.insertReviewComments(koDTO,reviewDTO);
			else
				koInfoServiceRest.updateReviewComments(reviewDTO);
		}
			
		KOInfoBean koInfo = new KOInfoBean();
		koInfo.setKoID(koDTO.getSolutionnumber());
		koInfo.setTicketID(koDTO.getTicketID());
     	koInfo.setShortDescription(koDTO.getDescription());
		koInfo.setLongDescription(koDTO.getLongDescription());
		koInfo.setApplicationName(koDTO.getApplicationName());
		koInfo.setAssignmentGroup(koDTO.getAssignmentGroup());	
		koInfo.setSymptoms(koDTO.getSymptoms());
		koInfo.setAnswer(koDTO.getAnswer());
		koInfo.setResolution(koDTO.getResolution());
		koInfo.setKoStage(koDTO.getPubStatus());
		koInfo.setPublicationStatus(koDTO.getPubStatus());
		koInfo.setCreatedBy(koDTO.getCreatedBy());
		koInfo.setCreatedDate(koDTO.getCreatedDate());
		koInfo.setReviewedBy(koDTO.getReviewedBy());
		koInfo.setReviewedDate(koDTO.getReviewedDate());
		koInfo.setPublishedBy(koDTO.getPublishedBy());
		koInfo.setPublishedDate(koDTO.getPublishedDate());
		
		koInfoServiceRest.updateKO(koInfo, userName);		
		mlDBProcess.insertDataIntoPostgres(koInfo, ACCOUNT_ID, koInfo.getKoID(), koInfo.getPublicationStatus(),userName);	
		}catch (Exception e) {
			apiResponse.setError(true);
			apiResponse.setMessage("updateKO_002");
			log.info("Error occured while updating KO "+e.getMessage());
			return new ResponseEntity<>(apiResponse, HttpStatus.UNPROCESSABLE_ENTITY);
		}
		apiResponse.setError(false);
		apiResponse.setMessage("updateKO_001");
		log.info("END: Update KO");
		return new ResponseEntity<>(apiResponse, HttpStatus.OK);
	}
	
	/**
	 * Delete Attachment
	 * @param koDTO
	 * @param response
	 * @return
	 */
	@PostMapping(value = "/api/deleteAttachment")
	public ResponseEntity<?> deleteAttachment(@RequestBody KODetailsDTO koDTO,@RequestHeader(name = RequestConstants.TENANT_ID) final String encryptedTenantId,HttpServletResponse response){
		log.info("START: Delete KO Attachment");	
		
		// Setting Tenant & MDC Context
        requestValidationServiceService.decryptAndValidateTenantId(encryptedTenantId);
		
		ErrorResponseDTO apiResponse = new ErrorResponseDTO();	
		try {
		
		/**Deleting file from directory*/
		String attachTypeBase = koInfoServiceRest.getAttachTypeBase("KO");
		String basePath = String.join(File.separator, TenantContextHolder.getTenantContextHolder().getAttachmentBase(), TenantContextHolder.getTenantContextHolder().getAccountName(), attachTypeBase,koDTO.getSolutionnumber(),koDTO.getAttachID(),koDTO.getAttachName());
		File f = new File(basePath);
		f.delete();
		log.info("Attachment deleted from directory");	
		
		/**Deleting file from DB*/
		final String koSerialNum = kOInfoRepository.getKOSerialNo(koDTO.getSolutionnumber());
		KOArtifacts artifacts=koInfoServiceRest.getArtifact(Integer.parseInt(koSerialNum));		
		List<String> items = new ArrayList<String>(Arrays.asList(artifacts.getAttachmentName().split("\\|")));
		List<String> toRemove = new ArrayList<>();		
		for(String s:items ) {
     		String  x = s.replace(File.separator,",");
     		System.out.println(x);
     		List<String> items2=Arrays.asList(x.split(","));
     		if(koDTO.getAttachName().equals(items2.get(1)))
     			toRemove.add(s);    			
		}
		items.removeAll(toRemove);
		String attachedList="";
		for(String s:items)
		     attachedList=attachedList.concat(s+"|");		     
		koInfoServiceRest.deleteAttachment(attachedList,Integer.parseInt(koSerialNum));		
		log.info("Attachment deleted from DB");
		}catch (Exception e) {
			apiResponse.setError(true);
			apiResponse.setMessage("deleteAttachment_002");
			log.info("Error occured while deleting attachment");
			return new ResponseEntity<>(apiResponse, HttpStatus.UNPROCESSABLE_ENTITY);
		}
		apiResponse.setError(false);
		apiResponse.setMessage("deleteAttachment_001");
		log.info("END:Delete Attachment");
		return new ResponseEntity<>(apiResponse, HttpStatus.OK);		
		
	}
	
	 /**
		 * Upload Attachment.
		 * @param koDTO
		 * @param response
		 * @return
		 */
		@PostMapping(value = "/api/uploadAttachmentUI")
		public ResponseEntity<?> uploadAttachmentUI(@RequestBody KODetailsDTO koDTO,@RequestHeader(name = RequestConstants.TENANT_ID) final String encryptedTenantId,HttpServletResponse response) {
			log.info("START: Upload Attachment KO");
			
			// Setting Tenant & MDC Context
	        requestValidationServiceService.decryptAndValidateTenantId(encryptedTenantId);
			
			ErrorResponseDTO apiResponse = new ErrorResponseDTO();	
			final String type="KO";
			
			Random randonId=new Random();
			int Id=Math.abs(randonId.nextInt());			
			String attachId=null;
			attachId=Integer.toString(Id);			

			try {
				byte[] decodedBytes = Base64.getDecoder().decode(koDTO.getFile());		
				long kilobytes = (decodedBytes.length / 1024);
		        long megabytes = (kilobytes / 1024);
		      	if(megabytes>15) {
					apiResponse.setError(true);
					apiResponse.setMessage("uploadAttachmentUI_002");
					return new ResponseEntity<>(apiResponse, HttpStatus.UNPROCESSABLE_ENTITY);
				}
				
				List<String> attachNameSplit=Arrays.asList(koDTO.getAttachName().split("\\."));
				if(attachNameSplit.get(1).equals("docx")||attachNameSplit.get(1).equals("pdf")||attachNameSplit.get(1).equals("doc")) {
					//final String koSerialNum = kOInfoRepository.getKOSerialNo(koDTO.getSolutionnumber());		
					koInfoServiceRest.pushAttachmentExtract(type, koDTO.getFile(), koDTO.getSolutionnumber(), koDTO.getAttachName(), attachId);
				}
				else {
				apiResponse.setError(true);
				apiResponse.setMessage("uploadAttachmentUI_003");
				return new ResponseEntity<>(apiResponse, HttpStatus.UNPROCESSABLE_ENTITY);
				}
			}catch (Exception e) {
				apiResponse.setError(true);
				apiResponse.setMessage("uploadAttachmentUI_004");
				log.info("Error occured while uploading attachment "+e.getMessage());
				return new ResponseEntity<>(apiResponse, HttpStatus.UNPROCESSABLE_ENTITY);
			}
			apiResponse.setError(false);
			apiResponse.setMessage("uploadAttachmentUI_001");
			log.info("END: Upload Attachment KO");
			return new ResponseEntity<>(apiResponse, HttpStatus.OK);		
		}	 
		
		@GetMapping(value="/api/validateKO")
		public ResponseEntity<?> validateKO(@RequestParam("koId")String koId,@RequestParam("ticketId")String ticketId,@RequestHeader(name = RequestConstants.TENANT_ID) final String encryptedTenantId){
			log.info("START: Validate KO");
			
			// Setting Tenant & MDC Context
	        requestValidationServiceService.decryptAndValidateTenantId(encryptedTenantId);
			
			ErrorResponseDTO apiResponse = new ErrorResponseDTO();
			KOInfoDTO infoDTO=new KOInfoDTO();
			try {
			KOInfo koInfo=kOInfoRepository.findByKoID(koId);
			Object serialno=ticketDataHistoryRepository.getSerialNumberForTicket(ticketId);
			if(koInfo==null) {
				apiResponse.setError(true);
				apiResponse.setMessage("validateKO_001");
				return new ResponseEntity<>(apiResponse, HttpStatus.UNPROCESSABLE_ENTITY);
			}
			if(Objects.isNull(serialno)) {
				apiResponse.setError(true);
				apiResponse.setMessage("validateKO_002");
				return new ResponseEntity<>(apiResponse, HttpStatus.UNPROCESSABLE_ENTITY);
			}
			 infoDTO=koInfoServiceRest.validateKO(ACCOUNT_ID,koId, ticketId);
			if(infoDTO.getIncCount()>0) {
				apiResponse.setError(true);
				apiResponse.setMessage("validateKO_003");
				return new ResponseEntity<>(apiResponse, HttpStatus.UNPROCESSABLE_ENTITY);
			}
			
			if(infoDTO.getAsgFlag()==1 && infoDTO.getApnFlag()==1) {
				apiResponse.setError(true);
				apiResponse.setMessage("validateKO_005");
				return new ResponseEntity<>(apiResponse, HttpStatus.UNPROCESSABLE_ENTITY);
			}
			else if(infoDTO.getAsgFlag()==1 && infoDTO.getApnFlag()==0) {
				apiResponse.setError(true);
				apiResponse.setMessage("validateKO_006");
				return new ResponseEntity<>(apiResponse, HttpStatus.UNPROCESSABLE_ENTITY);
			}
			else if(infoDTO.getAsgFlag()==0 && infoDTO.getApnFlag()==1) {
				apiResponse.setError(true);
				apiResponse.setMessage("validateKO_007");
				return new ResponseEntity<>(apiResponse, HttpStatus.UNPROCESSABLE_ENTITY);
			}
			else {
				log.info("END: Validate KO");
				return new ResponseEntity<>(infoDTO, HttpStatus.OK);
			}
			
			}catch (Exception e) {
			log.error(e.getLocalizedMessage());
			apiResponse.setError(true);
			apiResponse.setMessage("validateKO_004");
			return new ResponseEntity<>(apiResponse, HttpStatus.UNPROCESSABLE_ENTITY);
		}
			
			
		}
	}
