package com.ikon.rest.security.service;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.logging.log4j.ThreadContext;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.ikon.rest.customexceptions.BadEncryptionException;
import com.ikon.rest.customexceptions.InvalidTenantException;
import com.ikon.rest.datasourceconfig.tenants.MultiRoutingDataSource;
import com.ikon.rest.datasourceconfig.tenants.TenantContextHolder;
import com.ikon.rest.master.entity.TenantAccountMapping;
import com.ikon.rest.master.repository.TenantRepository;
import com.ikon.rest.master.service.TenantService;
import com.ikon.rest.security.constants.RequestConstants;
import com.ikon.rest.tenants.utility.PropertiesUtility;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class RequestValidationService {
	/**
	 * The AES Algoritm
	 */
	public static final String AES_ALGO = "AES/GCM/NoPadding";
	/**
	 * The Encryption Standard
	 */
	public static final String ENCRYPTION_STD = "AES";
	/**
	 * The GCM TAG LENGTH
	 */
	public static final int GCM_TAG_LENGTH = 16;
	/**
	 * Environment object
	 */
	@Autowired
	private Environment environment;

	@Autowired
	private MultiRoutingDataSource multiRoutingDataSource;

	@Autowired
	private TenantService tenantService;

	/**
	 * Setting up tenant Account Mapping Repository
	 */
	@Autowired
	private TenantRepository tenantRepository;

	/**
	 * @param cryptedMessage
	 */
	public void decryptAndValidateTenantId(final String cryptedMessage) {
		// Clearing any existing context from previous thread execution
		TenantContextHolder.clear();
		MDC.clear();

		final String[] messageKeyIVEncryptedData = cryptedMessage.split(":");
		try {
			String tenantId = null;
			if (messageKeyIVEncryptedData.length == 3) {
				final Cipher cipher = Cipher.getInstance(AES_ALGO);
				cipher.init(Cipher.DECRYPT_MODE, this.getSecretKey(messageKeyIVEncryptedData[1]),
						new GCMParameterSpec(GCM_TAG_LENGTH * 8, this.decode(messageKeyIVEncryptedData[2])));
				tenantId = new String(cipher.doFinal(this.decode(messageKeyIVEncryptedData[0])));
			} else {
				tenantId = messageKeyIVEncryptedData[0];
			}
			this.validateAndSetTenantContext(tenantId);
		} catch (NoSuchAlgorithmException | NoSuchPaddingException | IllegalBlockSizeException | BadPaddingException
				| InvalidKeyException | InvalidAlgorithmParameterException e) {
			log.error("Incorrect Encryption Encountered : {}", Arrays.toString(messageKeyIVEncryptedData));
			throw new BadEncryptionException("Tenant Id Is Incorrectly Encrypted!");
		}
	}

	/**
	 * @param myKey
	 * @return SecretKey for decryption
	 */
	private SecretKey getSecretKey(final String myKey) {
		return new SecretKeySpec(decode(myKey), ENCRYPTION_STD);
	}

	/**
	 * @param data to decode
	 * @return
	 */
	private byte[] decode(final String data) {
		return Base64.getDecoder().decode(data);
	}

	/**
	 * Method to validate the tenant id sent in the request
	 *
	 * @param tenantId
	 */
	private void validateAndSetTenantContext(final String tenantId) {
		final TenantAccountMapping tenantAccountMapping = tenantService.fetchAccountIdByTenantId(tenantId);
		boolean isValid = false;
		if (tenantAccountMapping != null) {
			isValid = tenantService.validateTenant(tenantAccountMapping);
		}

		if (!isValid) {
			log.error("Invalid Tenant ID : {}", tenantId);
			throw new InvalidTenantException("Invalid Tenant ID");
		}

		TenantContextHolder.setTenantContextHolderThreadLocal(
				PropertiesUtility.TENANT_PROP_DATA_STORE.get(tenantAccountMapping.getAccountId()));
		
		MDC.put(RequestConstants.TENANT_ID, tenantAccountMapping.getAccountId());
	}
}
