package com.ikon.rest.datasourceconfig.constants;

public final class ConnectionConstants {

	/**
     * The Data Source URL String Parameter
     */
    public static final String DS_URL = "url";

    /**
     * The Data Source USER String Parameter
     */
    public static final String DS_USER = "user";

    /**
     * The Data Source PASSWORD String Parameter
     */
    public static final String DS_PASSWORD = "password";

    /**
     * The AWS String Parameter
     */
    public static final String AWS_STRING = "AWS";

    /**
     * The AWS_RESPONSE_KEY_STRING field
     */
    public static final String AWS_RESPONSE_KEY_STRING = "value";

    /**
     * The AZURE String Parameter
     */
    public static final String AZURE_STRING = "AZURE";

    /**
     * The USERNAME_AND_PASSWORD_STRING field
     */
    public static final String USERNAME_AND_PASSWORD_STRING = "usernameAndPassword";

    private ConnectionConstants() {
        throw new UnsupportedOperationException("RequestConstants Class cannot be instantiated");
    }
	
	
	
}
