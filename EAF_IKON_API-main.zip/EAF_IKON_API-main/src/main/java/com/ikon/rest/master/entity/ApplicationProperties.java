package com.ikon.rest.master.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * entity object to map tenant account information
 */
@Entity
@Table(name = "account_properties")
@Getter
@Setter
@EqualsAndHashCode
public class ApplicationProperties implements Serializable{
	
	private static final long serialVersionUID = 1L;

	
	@Id
    @Column(name = "accountid")
    private String accountId;


    @Column(name = "koprefix")
    private String koPrefix;

    @Column(name = "kostartingnumber")
    private String koStartingNumber;
	
    @Column(name = "attachmentbase")
    private String attachmentBase;
    
    @Column(name = "accountname")
    private String accountName;
    
    @Column(name = "attachmenttypebases")
    private String attachmentTypeBases;
    
    @Column(name = "statictoken")
    private String staticToken;
    
    @Column(name = "updatekbtodl")
    private String updateKbToDl;
}
