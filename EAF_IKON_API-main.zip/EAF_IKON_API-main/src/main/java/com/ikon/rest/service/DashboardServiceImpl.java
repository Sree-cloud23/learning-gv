package com.ikon.rest.service;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Service;

import com.ikon.rest.web.models.KOInfoDTO;
import com.ikon.rest.web.models.dashboard.AgeingWorkinfoDTO;
import com.ikon.rest.web.models.dashboard.ComplianceDTO;
import com.ikon.rest.web.models.dashboard.IncMissingKODTO;
import com.ikon.rest.web.models.dashboard.KOUsageChartDTO;
import com.ikon.rest.web.models.dashboard.MttrDTO;
import com.ikon.rest.web.models.dashboard.ReportChartDTO;
import com.ikon.rest.web.models.dashboard.RunToZeroDTO;

/**
 * The Class DashboardServiceImpl.
 */
@SuppressWarnings({"deprecation","unchecked","rawtypes"})
@Service
public class DashboardServiceImpl implements DashboardService {
	
	/** The entity manager. */
	@PersistenceContext(unitName = "multiEntityManager")
	private EntityManager entityManager;

	
	/**
	 * Gets the KO usage report.
	 *
	 * @param accId the acc id
	 * @param reportChartDTO the report chart DTO
	 * @return the KO usage report
	 */
	@Override
	@Transactional
	public List<KOInfoDTO> getKOUsageReport(String accId, ReportChartDTO reportChartDTO) {
		
		List<KOInfoDTO> koDetailsList=null;
		Session session=entityManager.unwrap(Session.class);
		Query query  = session.createSQLQuery("select * from fun_ciap_ko_usage_report(:accId,:fromDate,:toDate,:assignmentGroup,:applicationName)")
				.setResultTransformer(Transformers.aliasToBean(KOInfoDTO.class));
		query.setParameter("accId", accId);
		query.setParameter("fromDate", reportChartDTO.getFromDate());
		query.setParameter("toDate", reportChartDTO.getToDate());
		query.setParameter("assignmentGroup", reportChartDTO.getAssignmentGroup());
		query.setParameter("applicationName", reportChartDTO.getApplicationName());
		koDetailsList = query.list();
		return koDetailsList;
	}

	/**
	 * Gets the KO usage chart.
	 *
	 * @param accId the acc id
	 * @param reportChartDTO the report chart DTO
	 * @return the KO usage chart
	 */
	@Override
	@Transactional
	public List<KOUsageChartDTO> getKOUsageChart(String accId, ReportChartDTO reportChartDTO) {
		List<KOUsageChartDTO> usageChartList =new ArrayList<>();
		Session session=entityManager.unwrap(Session.class);

		Query query  = session.createSQLQuery("select * from fun_ciap_ko_usage_chart(:accId,:fromDate,:toDate,:assignmentGroup,:applicationName)")
				.setResultTransformer(Transformers.aliasToBean(KOUsageChartDTO.class));
		query.setParameter("accId", accId);
		query.setParameter("fromDate", reportChartDTO.getFromDate());
		query.setParameter("toDate", reportChartDTO.getToDate());
		query.setParameter("assignmentGroup", reportChartDTO.getAssignmentGroup());
		query.setParameter("applicationName", reportChartDTO.getApplicationName());
		usageChartList=query.list();
		return usageChartList;
	}

	/**
	 * Gets the run to zero report.
	 *
	 * @param accId the acc id
	 * @param reportChartDTO the report chart DTO
	 * @return the run to zero report
	 */
	@Override
	@Transactional
	public List<RunToZeroDTO> getRunToZeroReport(String accId, ReportChartDTO reportChartDTO) {
		List<RunToZeroDTO> runTozeroList =new ArrayList<>();
		Session session=entityManager.unwrap(Session.class);

		Query query  = session.createSQLQuery("select * from fun_ciap_run_to_zero_report(:applicationName,:assignmentGroup,:assigneeName,:fromDate,:toDate)")
				.setResultTransformer(Transformers.aliasToBean(RunToZeroDTO.class));
		query.setParameter("applicationName", reportChartDTO.getApplicationName());
		query.setParameter("assignmentGroup", reportChartDTO.getAssignmentGroup());
		query.setParameter("assigneeName", reportChartDTO.getAssigneeName());
		query.setParameter("fromDate", reportChartDTO.getFromDate());
		query.setParameter("toDate", reportChartDTO.getToDate());
		
		runTozeroList=query.list();
		return runTozeroList;
	}

	/**
	 * Gets the compliance report.
	 *
	 * @param fromDate the from date
	 * @param toDate the to date
	 * @param assignmentGroup the assignment group
	 * @param applicationName the application name
	 * @return the compliance report
	 */
	@Override
	@Transactional
	public List<ComplianceDTO> getComplianceReport(String fromDate, String toDate, String assignmentGroup,
			String applicationName) {
		
		List<ComplianceDTO> complianceList = new ArrayList<ComplianceDTO>();
		Session session = entityManager.unwrap( Session.class );
		Query query = session.createSQLQuery("select * from fun_ciap_compliance_report(:fromDate, :toDate, :assignmentGroup,:applicationName)")
				.setResultTransformer(Transformers.aliasToBean(ComplianceDTO.class));
		query.setParameter("fromDate", fromDate);
		query.setParameter("toDate", toDate);
		query.setParameter("assignmentGroup", assignmentGroup);
		query.setParameter("applicationName", applicationName);
		complianceList = query.list();
		return complianceList;
	}

	/**
	 * Gets the inc missing ko report.
	 *
	 * @param fromDate the from date
	 * @param toDate the to date
	 * @param assignmentGroup the assignment group
	 * @param applicationName the application name
	 * @return the inc missing ko report
	 */
	@Override
	@Transactional
	public List<IncMissingKODTO> getIncMissingKoReport(String fromDate, String toDate, String assignmentGroup,
			String applicationName) {
		List<IncMissingKODTO> incMissingKOReportList = new ArrayList<IncMissingKODTO>();
		Session session = entityManager.unwrap( Session.class );
		Query query = session.createSQLQuery("select * from fun_ciap_inc_missing_ko_report(:fromDate, :toDate, :assignmentGroup,:applicationName)")
				.setResultTransformer(Transformers.aliasToBean(IncMissingKODTO.class));
		query.setParameter("fromDate", fromDate);
		query.setParameter("toDate", toDate);
		query.setParameter("assignmentGroup", assignmentGroup);
		query.setParameter("applicationName", applicationName);
		incMissingKOReportList = query.list();
		return incMissingKOReportList;
	}

	/**
	 * Gets the inc missing ko chart.
	 *
	 * @param fromDate the from date
	 * @param toDate the to date
	 * @param assignmentGroup the assignment group
	 * @param applicationName the application name
	 * @return the inc missing ko chart
	 */
	@Override
	@Transactional
	public List<IncMissingKODTO> getIncMissingKoChart(String fromDate, String toDate, String assignmentGroup,
			String applicationName) {
		List<IncMissingKODTO> incMissingKOList = new ArrayList<IncMissingKODTO>();
		Session session = entityManager.unwrap( Session.class );
		Query query = session.createSQLQuery("select * from fun_ciap_inc_missing_ko_chart(:fromDate, :toDate, :assignmentGroup,:applicationName)")
				.setResultTransformer(Transformers.aliasToBean(IncMissingKODTO.class));
		query.setParameter("fromDate", fromDate);
		query.setParameter("toDate", toDate);
		query.setParameter("assignmentGroup", assignmentGroup);
		query.setParameter("applicationName", applicationName);
		incMissingKOList = query.list();
		return incMissingKOList;
	}

	/**
	 * Gets the mttr report.
	 *
	 * @param fromDate the from date
	 * @param toDate the to date
	 * @param assignmentGroup the assignment group
	 * @param applicationName the application name
	 * @return the mttr report
	 */
	@Override
	@Transactional
	public List<MttrDTO> getMttrReport(String fromDate, String toDate, String assignmentGroup, String applicationName) {
		List<MttrDTO> mttrList = new ArrayList<MttrDTO>();
		Session session = entityManager.unwrap( Session.class );
		Query query = session.createSQLQuery("select * from fun_ciap_mttr_report(:fromDate, :toDate, :assignmentGroup,:applicationName)")
				.setResultTransformer(Transformers.aliasToBean(MttrDTO.class));
		query.setParameter("fromDate", fromDate);
		query.setParameter("toDate", toDate);
		query.setParameter("assignmentGroup", assignmentGroup);
		query.setParameter("applicationName", applicationName);
		mttrList = query.list();
		return mttrList;
	}

	/**
	 * Gets the mttr chart.
	 *
	 * @param fromDate the from date
	 * @param toDate the to date
	 * @param assignmentGroup the assignment group
	 * @param applicationName the application name
	 * @return the mttr chart
	 */
	@Override
	@Transactional
	public List<MttrDTO> getMttrChart(String fromDate, String toDate, String assignmentGroup, String applicationName) {
		List<MttrDTO> mttrList = new ArrayList<MttrDTO>();
		Session session = entityManager.unwrap( Session.class );
		Query query = session.createSQLQuery("select * from fun_ciap_mttr_chart(:fromDate, :toDate, :assignmentGroup,:applicationName)")
				.setResultTransformer(Transformers.aliasToBean(MttrDTO.class));
		query.setParameter("fromDate", fromDate);
		query.setParameter("toDate", toDate);
		query.setParameter("assignmentGroup", assignmentGroup);
		query.setParameter("applicationName", applicationName);
		mttrList = query.list();
		return mttrList;
	}

	/**
	 * Gets the ageing workinfo report.
	 *
	 * @param fromDate the from date
	 * @param toDate the to date
	 * @param assignmentGroup the assignment group
	 * @param applicationName the application name
	 * @return the ageing workinfo report
	 */
	@Override
	@Transactional
	public List<AgeingWorkinfoDTO> getAgeingWorkinfoReport(String fromDate, String toDate, String assignmentGroup,
			String applicationName) {
		List<AgeingWorkinfoDTO> ageingWorkinfoList = new ArrayList<AgeingWorkinfoDTO>();
		Session session = entityManager.unwrap( Session.class );
		Query query = session.createSQLQuery("select * from fun_ciap_ageing_workinfo_report(:fromDate, :toDate, :assignmentGroup,:applicationName)")
				.setResultTransformer(Transformers.aliasToBean(AgeingWorkinfoDTO.class));
		query.setParameter("fromDate", fromDate);
		query.setParameter("toDate", toDate);
		query.setParameter("assignmentGroup", assignmentGroup);
		query.setParameter("applicationName", applicationName);
		ageingWorkinfoList = query.list();
		return ageingWorkinfoList;
	}

	/**
	 * Gets the mttr priority report.
	 *
	 * @param fromDate the from date
	 * @param toDate the to date
	 * @param assignmentGroup the assignment group
	 * @param applicationName the application name
	 * @return the mttr priority report
	 */
	@Override
	@Transactional
	public List<MttrDTO> getMttrPriorityReport(String fromDate, String toDate, String assignmentGroup, String applicationName) {
		List<MttrDTO> mttrList = new ArrayList<MttrDTO>();
		Session session = entityManager.unwrap( Session.class );
		Query query = session.createSQLQuery("select * from fun_ciap_mttr_priority_report(:fromDate, :toDate, :assignmentGroup,:applicationName)")
				.setResultTransformer(Transformers.aliasToBean(MttrDTO.class));
		query.setParameter("fromDate", fromDate);
		query.setParameter("toDate", toDate);
		query.setParameter("assignmentGroup", assignmentGroup);
		query.setParameter("applicationName", applicationName);
		mttrList = query.list();
		return mttrList;
	}

	/**
	 * Gets the ageing workinfo report detail.
	 *
	 * @param fromDate the from date
	 * @param toDate the to date
	 * @param assignmentGroup the assignment group
	 * @param applicationName the application name
	 * @return the ageing workinfo report detail
	 */
	@Override
	@Transactional
	public List<AgeingWorkinfoDTO> getAgeingWorkinfoReportDetail(String fromDate, String toDate, String assignmentGroup,
			String applicationName) {
		List<AgeingWorkinfoDTO> ageingWorkinfoList = new ArrayList<AgeingWorkinfoDTO>();
		Session session = entityManager.unwrap( Session.class );
		Query query = session.createSQLQuery("select * from fun_ciap_ageing_workinfo_detail_report(:fromDate, :toDate, :assignmentGroup,:applicationName)")
				.setResultTransformer(Transformers.aliasToBean(AgeingWorkinfoDTO.class));
		query.setParameter("fromDate", fromDate);
		query.setParameter("toDate", toDate);
		query.setParameter("assignmentGroup", assignmentGroup);
		query.setParameter("applicationName", applicationName);
		ageingWorkinfoList = query.list();
		return ageingWorkinfoList;
	}

}
