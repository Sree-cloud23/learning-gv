package com.ikon.rest.web.models.dashboard;

/**
 * The Class MttrDTO.
 */
public class MttrDTO {
	
	/** The application name. */
	private String applicationName;
	
	/** The assignment group. */
	private String assignmentGroup;
	
	/** The ticket priority. */
	//MTTR Priority
	private String ticketPriority;
	
	/** The average MTTR. */
	private String averageMTTR;
	
	/** The total tickets. */
	private String totalTickets;
	
	/** The incidents resolved. */
	private String incidentsResolved;
	//MTTR Priority
	
	/** The non linked ticket count. */
	private String nonLinkedTicketCount;
	
	/** The mttr non linked ticket. */
	private String mttrNonLinkedTicket;
	
	/** The linked ticket count. */
	private String linkedTicketCount;
	
	/** The mttr linked ticket. */
	private String mttrLinkedTicket;
	
	/** The mttr value for all incidents. */
	//private String ticketCount;
	private String mttrValueForAllIncidents;
	
	/** The month. */
	private String month;
	
	/** The ticket count. */
	private String ticketCount;
	
	/** The all incidentsmttr. */
	private String allIncidentsmttr;
	
	/** The ticket link count. */
	private String ticketLinkCount;
	
	/** The link ticketsmttr. */
	private String linkTicketsmttr;
	
	/**
	 * Gets the application name.
	 *
	 * @return the application name
	 */
	public String getApplicationName() {
		return applicationName;
	}
	
	/**
	 * Sets the application name.
	 *
	 * @param applicationName the new application name
	 */
	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}
	
	/**
	 * Gets the assignment group.
	 *
	 * @return the assignment group
	 */
	public String getAssignmentGroup() {
		return assignmentGroup;
	}
	
	/**
	 * Sets the assignment group.
	 *
	 * @param assignmentGroup the new assignment group
	 */
	public void setAssignmentGroup(String assignmentGroup) {
		this.assignmentGroup = assignmentGroup;
	}
	
	/**
	 * Gets the non linked ticket count.
	 *
	 * @return the non linked ticket count
	 */
	public String getNonLinkedTicketCount() {
		return nonLinkedTicketCount;
	}
	
	/**
	 * Sets the non linked ticket count.
	 *
	 * @param nonLinkedTicketCount the new non linked ticket count
	 */
	public void setNonLinkedTicketCount(String nonLinkedTicketCount) {
		this.nonLinkedTicketCount = nonLinkedTicketCount;
	}
	
	/**
	 * Gets the mttr non linked ticket.
	 *
	 * @return the mttr non linked ticket
	 */
	public String getMttrNonLinkedTicket() {
		return mttrNonLinkedTicket;
	}
	
	/**
	 * Sets the mttr non linked ticket.
	 *
	 * @param mttrNonLinkedTicket the new mttr non linked ticket
	 */
	public void setMttrNonLinkedTicket(String mttrNonLinkedTicket) {
		this.mttrNonLinkedTicket = mttrNonLinkedTicket;
	}
	
	/**
	 * Gets the linked ticket count.
	 *
	 * @return the linked ticket count
	 */
	public String getLinkedTicketCount() {
		return linkedTicketCount;
	}
	
	/**
	 * Sets the linked ticket count.
	 *
	 * @param linkedTicketCount the new linked ticket count
	 */
	public void setLinkedTicketCount(String linkedTicketCount) {
		this.linkedTicketCount = linkedTicketCount;
	}
	
	/**
	 * Gets the mttr linked ticket.
	 *
	 * @return the mttr linked ticket
	 */
	public String getMttrLinkedTicket() {
		return mttrLinkedTicket;
	}
	
	/**
	 * Sets the mttr linked ticket.
	 *
	 * @param mttrLinkedTicket the new mttr linked ticket
	 */
	public void setMttrLinkedTicket(String mttrLinkedTicket) {
		this.mttrLinkedTicket = mttrLinkedTicket;
	}
	
	/**
	 * Gets the mttr value for all incidents.
	 *
	 * @return the mttr value for all incidents
	 */
	public String getMttrValueForAllIncidents() {
		return mttrValueForAllIncidents;
	}
	
	/**
	 * Sets the mttr value for all incidents.
	 *
	 * @param mttrValueForAllIncidents the new mttr value for all incidents
	 */
	public void setMttrValueForAllIncidents(String mttrValueForAllIncidents) {
		this.mttrValueForAllIncidents = mttrValueForAllIncidents;
	}
	
	/**
	 * Gets the month.
	 *
	 * @return the month
	 */
	public String getMonth() {
		return month;
	}
	
	/**
	 * Sets the month.
	 *
	 * @param month the new month
	 */
	public void setMonth(String month) {
		this.month = month;
	}
	
	/**
	 * Gets the ticket count.
	 *
	 * @return the ticket count
	 */
	public String getTicketCount() {
		return ticketCount;
	}
	
	/**
	 * Sets the ticket count.
	 *
	 * @param ticketCount the new ticket count
	 */
	public void setTicketCount(String ticketCount) {
		this.ticketCount = ticketCount;
	}
	
	/**
	 * Gets the all incidentsmttr.
	 *
	 * @return the all incidentsmttr
	 */
	public String getAllIncidentsmttr() {
		return allIncidentsmttr;
	}
	
	/**
	 * Sets the all incidentsmttr.
	 *
	 * @param allIncidentsmttr the new all incidentsmttr
	 */
	public void setAllIncidentsmttr(String allIncidentsmttr) {
		this.allIncidentsmttr = allIncidentsmttr;
	}
	
	/**
	 * Gets the ticket link count.
	 *
	 * @return the ticket link count
	 */
	public String getTicketLinkCount() {
		return ticketLinkCount;
	}
	
	/**
	 * Sets the ticket link count.
	 *
	 * @param ticketLinkCount the new ticket link count
	 */
	public void setTicketLinkCount(String ticketLinkCount) {
		this.ticketLinkCount = ticketLinkCount;
	}
	
	/**
	 * Gets the link ticketsmttr.
	 *
	 * @return the link ticketsmttr
	 */
	public String getLinkTicketsmttr() {
		return linkTicketsmttr;
	}
	
	/**
	 * Sets the link ticketsmttr.
	 *
	 * @param linkTicketsmttr the new link ticketsmttr
	 */
	public void setLinkTicketsmttr(String linkTicketsmttr) {
		this.linkTicketsmttr = linkTicketsmttr;
	}
	
	/**
	 * Gets the ticket priority.
	 *
	 * @return the ticket priority
	 */
	public String getTicketPriority() {
		return ticketPriority;
	}
	
	/**
	 * Sets the ticket priority.
	 *
	 * @param ticketPriority the new ticket priority
	 */
	public void setTicketPriority(String ticketPriority) {
		this.ticketPriority = ticketPriority;
	}
	
	/**
	 * Gets the total tickets.
	 *
	 * @return the total tickets
	 */
	public String getTotalTickets() {
		return totalTickets;
	}
	
	/**
	 * Sets the total tickets.
	 *
	 * @param totalTickets the new total tickets
	 */
	public void setTotalTickets(String totalTickets) {
		this.totalTickets = totalTickets;
	}
	
	/**
	 * Gets the average MTTR.
	 *
	 * @return the average MTTR
	 */
	public String getAverageMTTR() {
		return averageMTTR;
	}
	
	/**
	 * Sets the average MTTR.
	 *
	 * @param averageMTTR the new average MTTR
	 */
	public void setAverageMTTR(String averageMTTR) {
		this.averageMTTR = averageMTTR;
	}
	
	/**
	 * Gets the incidents resolved.
	 *
	 * @return the incidents resolved
	 */
	public String getIncidentsResolved() {
		return incidentsResolved;
	}
	
	/**
	 * Sets the incidents resolved.
	 *
	 * @param incidentsResolved the new incidents resolved
	 */
	public void setIncidentsResolved(String incidentsResolved) {
		this.incidentsResolved = incidentsResolved;
	}
	
	/**
	 * To string.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return "MttrDTO [applicationName=" + applicationName + ", assignmentGroup=" + assignmentGroup
				+ ", ticketPriority=" + ticketPriority + ", averageMTTR=" + averageMTTR + ", totalTickets="
				+ totalTickets + ", incidentsResolved=" + incidentsResolved + ", nonLinkedTicketCount="
				+ nonLinkedTicketCount + ", mttrNonLinkedTicket=" + mttrNonLinkedTicket + ", linkedTicketCount="
				+ linkedTicketCount + ", mttrLinkedTicket=" + mttrLinkedTicket + ", mttrValueForAllIncidents="
				+ mttrValueForAllIncidents + ", month=" + month + ", ticketCount=" + ticketCount + ", allIncidentsmttr="
				+ allIncidentsmttr + ", ticketLinkCount=" + ticketLinkCount + ", linkTicketsmttr=" + linkTicketsmttr
				+ "]";
	}
	
	
	

	

}
