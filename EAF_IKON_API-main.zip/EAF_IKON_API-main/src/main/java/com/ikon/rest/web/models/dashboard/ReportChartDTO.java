package com.ikon.rest.web.models.dashboard;

public class ReportChartDTO {
	
	
	
	/**The 	fromDate */
	private String fromDate;	
	
	/**The 	toDate */
	private String toDate;	
	
	/**The 	frequency */
	private String frequency;
	
	/**The 	assignmentGroup */
	private String assignmentGroup;
	
	/**The 	applicationName */
	private String applicationName;
	
	/**The 	assigneeName */
	private String assigneeName;

	/**
	 * @return
	 */
	public String getFromDate() {
		return fromDate;
	}

	/**
	 * 
	 * @param fromDate
	 */
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	/**
	 * 
	 * @return
	 */
	public String getToDate() {
		return toDate;
	}

	/**
	 * 
	 * @param toDate
	 */
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	/**
	 * 
	 * @return
	 */
	public String getFrequency() {
		return frequency;
	}

	/**
	 * 
	 * @param frequency
	 */
	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	/**
	 * 
	 * @return
	 */
	public String getAssignmentGroup() {
		return assignmentGroup;
	}

	/**
	 * 
	 * @param assignmentGroup
	 */
	public void setAssignmentGroup(String assignmentGroup) {
		this.assignmentGroup = assignmentGroup;
	}

	/**
	 * 
	 * @return
	 */
	public String getApplicationName() {
		return applicationName;
	}

	/**
	 * 
	 * @param applicationName
	 */
	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}

	/**
	 * 
	 * @return
	 */
	public String getAssigneeName() {
		return assigneeName;
	}

	/**
	 * 
	 * @param assigneeName
	 */
	public void setAssigneeName(String assigneeName) {
		this.assigneeName = assigneeName;
	}
	
	
	
	
	

}
