package com.ikon.rest.web.models.dashboard;

public class KOUsageReportDTO {
	
	private String solutionnumber;
	
	private String applicationName;
	
	private String assignmentGroup;
	
	private Object koCount;
	
	private String maxLastlinkedDate;

	public String getSolutionnumber() {
		return solutionnumber;
	}

	public void setSolutionnumber(String solutionnumber) {
		this.solutionnumber = solutionnumber;
	}

	public String getApplicationName() {
		return applicationName;
	}

	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}

	public String getAssignmentGroup() {
		return assignmentGroup;
	}

	public void setAssignmentGroup(String assignmentGroup) {
		this.assignmentGroup = assignmentGroup;
	}

	public Object getKoCount() {
		return koCount;
	}

	public void setKoCount(Object koCount) {
		this.koCount = koCount;
	}

	public String getMaxLastlinkedDate() {
		return maxLastlinkedDate;
	}

	public void setMaxLastlinkedDate(String maxLastlinkedDate) {
		this.maxLastlinkedDate = maxLastlinkedDate;
	}

	@Override
	public String toString() {
		return "KOUsageReportDTO [solutionnumber=" + solutionnumber + ", applicationName=" + applicationName
				+ ", assignmentGroup=" + assignmentGroup + ", koCount=" + koCount + ", maxLastlinkedDate="
				+ maxLastlinkedDate + "]";
	}
	
	

}
