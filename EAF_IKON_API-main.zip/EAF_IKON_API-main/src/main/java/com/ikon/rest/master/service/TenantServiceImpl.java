package com.ikon.rest.master.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.sql.DataSource;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ikon.rest.datasourceconfig.beans.tenants.TenantInfo;
import com.ikon.rest.datasourceconfig.tenants.MultiRoutingDataSource;
import com.ikon.rest.datasourceconfig.utility.ConnectionUtility;
import com.ikon.rest.master.entity.Tenant;
import com.ikon.rest.master.entity.TenantAccountMapping;
import com.ikon.rest.master.repository.TenantAccountMappingRepository;
import com.ikon.rest.master.repository.TenantRepository;
import com.ikon.rest.tenants.utility.PropertiesUtility;

import lombok.extern.slf4j.Slf4j;


/**
 * The Tenant Service Implementation Class
 */
@Service
@Slf4j
public class TenantServiceImpl implements TenantService{

	private ConnectionUtility connectionUtility;

    private MultiRoutingDataSource multiRoutingDataSource;

    private TenantRepository tenantRepository;

    private transient TenantAccountMappingRepository tenantAccountMappingRepo;

    @Autowired
    public TenantServiceImpl(ConnectionUtility connectionUtility, TenantRepository tenantRepository,
                             TenantAccountMappingRepository tenantAccountMappingRepo) {
        this.connectionUtility = connectionUtility;
        this.tenantRepository = tenantRepository;
        this.tenantAccountMappingRepo = tenantAccountMappingRepo;
    }

    @Override
    public MultiRoutingDataSource loadAllTenants(DataSource commonDataSource) {
        log.info("Inside load ALL Tenants Method of Tenant Service");
        List<Tenant> list = tenantRepository.findByActive(true);
        multiRoutingDataSource = new MultiRoutingDataSource();
        multiRoutingDataSource.setTargetDataSources(this.getTargetDataSourcesMapFromTenantList(list));
        multiRoutingDataSource.setDefaultTargetDataSource(commonDataSource);
        return multiRoutingDataSource;
    }

    @Override
    public void addTenantToInMemoryCollectionsIfMissing(final Tenant tenant) {
        log.info("Inside addTenantToInMemoryCollections methode for tenant: {}", tenant.getTenantId());
        this.addConnectionForATenant(tenant);
        this.addPropertiesForATenant(tenant);
    }

    @Override
    public void deleteTenantFromInMemoryCollections(final String key) {
        assert multiRoutingDataSource.getResolvedDataSources() != null;
        assert multiRoutingDataSource.getTargetDataSources() != null;
        try {
            log.info("closing the connection for tenant : {}", key);
            if (multiRoutingDataSource.getResolvedDataSources().get(key) != null) {
                multiRoutingDataSource.getResolvedDataSources().get(key).getConnection().close();
                log.info("Connection closed successfully for tenant : {}", key);
            }
        } catch (SQLException e) {
            log.error("Error occurred while closing the connection");
        } finally {
            log.info("Removing DataSource object from memory");
            multiRoutingDataSource.getResolvedDataSources()
                    .remove(key);
            multiRoutingDataSource.getTargetDataSources()
                    .remove(key);
        }
        PropertiesUtility.TENANT_PROP_DATA_STORE.remove(key);
    }

    @Override
    public TenantAccountMapping fetchAccountIdByTenantId(final String tenantId) {
        return tenantAccountMappingRepo.findByTenantId(tenantId);
    }

    @Override
    public boolean validateTenant(TenantAccountMapping tenantAccountMapping) {
        boolean isValid = false;
        if (tenantAccountMapping.isActive()) {
            isValid = updateConnectionAndPropertiesForATenant(tenantAccountMapping);
        } else {
            isValid = false;
            this.deleteTenantFromInMemoryCollections(tenantAccountMapping.getAccountId());
        }
        return isValid;
    }

    @Override
    public void rescanAndValidateTenants() {
//        List<TenantAccountMapping> list = tenantAccountMappingRepo.findAll();
//        list.forEach(tenant -> {
//            if (!tenant.isActive()) {
//
//            }
//        });
    }

    private Map<Object, Object> getTargetDataSourcesMapFromTenantList(List<Tenant> list) {
        log.info("Inside getTargetDataSourcesMapFromTenantList for creating Target Data sources Map!");
        return list
                .stream()
                .collect(Collectors.toMap(Tenant::getAccountId, t -> this.addTenant(t)));
    }

    private DataSource addTenant(Tenant tenant) {
        this.addPropertiesToInMemoryCollection(tenant);
        return createDataSource(tenant);
    }

    private DataSource createDataSource(Tenant tenant) {
        log.info("Inside createDataSource Method to create a DataSource");
        return connectionUtility.createDataSource(tenant);
    }

    private void addConnectionForATenant(Tenant tenant) {
        if (!checkConnectionExists(tenant.getAccountId())) {
            this.addConnectionToInMemoryCollection(tenant);
        }
    }

    private void addConnectionToInMemoryCollection(Tenant tenant) {
        DataSource dataSource = this.createDataSource(tenant);
        assert multiRoutingDataSource.getResolvedDataSources() != null;
        assert multiRoutingDataSource.getTargetDataSources() != null;
        multiRoutingDataSource.getResolvedDataSources()
                .put(tenant.getAccountId(), dataSource);
        multiRoutingDataSource.getTargetDataSources()
                .put(tenant.getAccountId(), dataSource);
    }

    private void updateTenant(Tenant tenant) {
        this.deleteTenantFromInMemoryCollections(tenant.getAccountId());
        this.addConnectionToInMemoryCollection(tenant);
        this.addPropertiesToInMemoryCollection(tenant);
    }

    private void addPropertiesForATenant(Tenant tenant) {
        if (!checkPropertiesExists(tenant.getAccountId())) {
            this.addPropertiesToInMemoryCollection(tenant);
        }
    }

    private void addPropertiesToInMemoryCollection(Tenant tenant) {
        TenantInfo tenantInfo = new TenantInfo();
        BeanUtils.copyProperties(tenant.getApplicationProperties(), tenantInfo);
        System.out.println("tenantInfo-->"+tenantInfo);
        PropertiesUtility.TENANT_PROP_DATA_STORE.put(tenant.getAccountId(), tenantInfo);
    }

    private boolean updateConnectionAndPropertiesForATenant(TenantAccountMapping tenantAccountMapping) {
        Tenant tenant = null;
        if (tenantAccountMapping.isUpdated()) {
            tenant = tenantRepository.findByTenantId(tenantAccountMapping.getTenantId());
            this.updateTenant(tenant);
            tenantAccountMapping.setUpdated(false);
            tenantAccountMappingRepo.save(tenantAccountMapping);
        } else if (!checkConnectionExists(tenantAccountMapping.getAccountId()) || !checkPropertiesExists(tenantAccountMapping.getAccountId())) {
            if (tenant == null) {
                tenant = tenantRepository.findByTenantId(tenantAccountMapping.getTenantId());
            }
            this.addTenantToInMemoryCollectionsIfMissing(tenant);
        }
        return true;
    }

    private boolean checkConnectionExists(String accountId) {
        return multiRoutingDataSource.getResolvedDataSources()
                .containsKey(accountId);
    }

    private boolean checkPropertiesExists(String accountId) {
        return PropertiesUtility.TENANT_PROP_DATA_STORE.containsKey(accountId);
    }
}
