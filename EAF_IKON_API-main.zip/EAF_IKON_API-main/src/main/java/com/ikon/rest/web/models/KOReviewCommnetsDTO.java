package com.ikon.rest.web.models;
/**
 * The Class KOReviewCommnetsDTO.
 */
public class KOReviewCommnetsDTO {
	
	/** The attach name. */
	private Integer reviewID;
	
	/** The reviewComments. */
	private String reviewComments;
	
	/** The reworkArea. */
	private String reworkArea;
	
	/** The actionRequired. */ 
	private int actionRequired;



	/**
	 * @return the reviewID
	 */
	public Integer getReviewID() {
		return reviewID;
	}

	/**
	 * @param reviewID the reviewID to set
	 */
	public void setReviewID(Integer reviewID) {
		this.reviewID = reviewID;
	}

	/**
	 * @return the reviewComments
	 */
	public String getReviewComments() {
		return reviewComments;
	}

	/**
	 * @param reviewComments the reviewComments to set
	 */
	public void setReviewComments(String reviewComments) {
		this.reviewComments = reviewComments;
	}

	/**
	 * @return the reworkArea
	 */
	public String getReworkArea() {
		return reworkArea;
	}

	/**
	 * @param reworkArea the reworkArea to set
	 */
	public void setReworkArea(String reworkArea) {
		this.reworkArea = reworkArea;
	}

	/**
	 * @return the actionRequired
	 */
	public int getActionRequired() {
		return actionRequired;
	}

	/**
	 * @param actionRequired the actionRequired to set
	 */
	public void setActionRequired(int actionRequired) {
		this.actionRequired = actionRequired;
	}

	/**
	 *
	 */
	@Override
	public String toString() {
		return "KOReviewCommnetsDTO [reviewID=" + reviewID + ", reviewComments=" + reviewComments + ", reworkArea="
				+ reworkArea + ", actionRequired=" + actionRequired + "]";
	}

	
	
	
}
