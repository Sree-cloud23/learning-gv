package com.ikon.rest.web.models;

import java.util.List;

public class SolutionNumberDTO {
	
	private List<String> solutionnumber;

	/**
	 * 
	 * @return
	 */
	public List<String> getSolutionnumber() {
		return solutionnumber;
	}

	/**
	 * 
	 * @param solutionnumber
	 */
	public void setSolutionnumber(List<String> solutionnumber) {
		this.solutionnumber = solutionnumber;
	}
	
	

}
