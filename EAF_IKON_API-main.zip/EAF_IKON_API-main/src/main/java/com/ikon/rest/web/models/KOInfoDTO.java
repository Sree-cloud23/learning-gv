package com.ikon.rest.web.models;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

/**
 * The Class KOInfoDTO.
 */
public class KOInfoDTO {

	/** The ko ID. */
	String koID;

	/** The symptoms. */
	String symptoms;

	/** The cause. */
	String cause;

	/** The attachment name. */
	String attachmentName;

	/** The attachment path. */
	String attachmentPath;

	/** The incident id. */
	String incidentId;
	
	private Object koCount;
	
	/** The maxLastlinkedDate */
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date max_Date;
	
	  /** The application name. */
	private String applicationName;
	
	/** The assignment group. */
	private String assignmentGroup;

	/** The incCount */
	Integer incCount;

	/** The description */
	String description;

	/** The asgFlag **/
	Integer asgFlag;

	/** The apnFlag **/
	Integer apnFlag;

	/**
	 * Gets the ko ID.
	 *
	 * @return the koID
	 */
	public String getKoID() {
		return koID;
	}

	/**
	 * Sets the ko ID.
	 *
	 * @param koID the koID to set
	 */
	public void setKoID(String koID) {
		this.koID = koID;
	}

	/**
	 * Gets the symptoms.
	 *
	 * @return the symptoms
	 */
	public String getSymptoms() {
		return symptoms;
	}

	/**
	 * Sets the symptoms.
	 *
	 * @param symptoms the symptoms to set
	 */
	public void setSymptoms(String symptoms) {
		this.symptoms = symptoms;
	}

	/**
	 * Gets the cause.
	 *
	 * @return the cause
	 */
	public String getCause() {
		return cause;
	}

	/**
	 * Sets the cause.
	 *
	 * @param cause the cause to set
	 */
	public void setCause(String cause) {
		this.cause = cause;
	}

	/**
	 * Gets the attachment name.
	 *
	 * @return the attachmentName
	 */
	public String getAttachmentName() {
		return attachmentName;
	}

	/**
	 * Sets the attachment name.
	 *
	 * @param attachmentName the attachmentName to set
	 */
	public void setAttachmentName(String attachmentName) {
		this.attachmentName = attachmentName;
	}

	/**
	 * Gets the attachment path.
	 *
	 * @return the attachmentPath
	 */
	public String getAttachmentPath() {
		return attachmentPath;
	}

	/**
	 * Sets the attachment path.
	 *
	 * @param attachmentPath the attachmentPath to set
	 */
	public void setAttachmentPath(String attachmentPath) {
		this.attachmentPath = attachmentPath;
	}

	/**
	 * Gets the incident id.
	 *
	 * @return the incidentId
	 */
	public String getIncidentId() {
		return incidentId;
	}

	/**
	 * Sets the incident id.
	 *
	 * @param incidentId the incidentId to set
	 */
	public void setIncidentId(String incidentId) {
		this.incidentId = incidentId;
	}

	public Object getKoCount() {
		return koCount;
	}

	public void setKoCount(Object koCount) {
		this.koCount = koCount;
	}

	public Date getMax_Date() {
		return max_Date;
	}

	public void setMax_Date(Date max_Date) {
		this.max_Date = max_Date;
	}

	public String getApplicationName() {
		return applicationName;
	}

	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}

	public String getAssignmentGroup() {
		return assignmentGroup;
	}

	public void setAssignmentGroup(String assignmentGroup) {
		this.assignmentGroup = assignmentGroup;
	}
	
	
	/**
	 * 
	 * @return
	 */
	public Integer getIncCount() {
		return incCount;
	}

	/**
	 * 
	 * @param incCount
	 */
	public void setIncCount(Integer incCount) {
		this.incCount = incCount;
	}

	/**
	 * 
	 * @return
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * 
	 * @param description
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * 
	 * @return
	 */
	public Integer getAsgFlag() {
		return asgFlag;
	}

	/**
	 * 
	 * @param asgFlag
	 */
	public void setAsgFlag(Integer asgFlag) {
		this.asgFlag = asgFlag;
	}

	/**
	 * 
	 * @return
	 */
	public Integer getApnFlag() {
		return apnFlag;
	}

	/**
	 * 
	 * @param apnFlag
	 */
	public void setApnFlag(Integer apnFlag) {
		this.apnFlag = apnFlag;
	}



}