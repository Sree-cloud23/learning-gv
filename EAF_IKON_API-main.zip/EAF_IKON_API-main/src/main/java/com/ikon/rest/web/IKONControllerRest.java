package com.ikon.rest.web;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.util.StreamUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.google.gson.JsonObject;
import com.ikon.dto.KOInfoBean;
import com.ikon.dto.KoDataAttribute;
import com.ikon.dto.KoDataAttributeVO;
import com.ikon.dto.MasterDataAttributeVO;
import com.ikon.dto.SearchDataAttributeVO;
import com.ikon.dto.TicketDataAttributeVO;
import com.ikon.dto.TicketDataBean;
import com.ikon.model.IncKoLinkML;
import com.ikon.model.KOInfo;
import com.ikon.model.KOUsage;
import com.ikon.repository.IncKOLinkMLRepository;
import com.ikon.repository.KOInfoRepository;
import com.ikon.repository.KOUsageRepository;
import com.ikon.repository.TicketDataHistoryRepository;
import com.ikon.rest.datasourceconfig.tenants.TenantContextHolder;
import com.ikon.rest.security.constants.RequestConstants;
import com.ikon.rest.security.service.RequestValidationService;
import com.ikon.rest.service.KOInfoServiceRest;
import com.ikon.rest.web.models.ApiResponseDTO;
import com.ikon.rest.web.models.AttachmentDTO;
import com.ikon.rest.web.models.DLkbLink;
import com.ikon.rest.web.models.ErrorResponseDTO;
import com.ikon.rest.web.models.IncidentDetailsDTO;
import com.ikon.rest.web.models.IncidentRelatedKODTO;
import com.ikon.rest.web.models.KODetailsDTO;
import com.ikon.rest.web.models.KOLinkedIncidentDTO;
import com.ikon.rest.web.models.LinkedTicketDataDTO;
import com.ikon.rest.web.models.TicketDataDTO;
import com.ikon.rest.web.models.UserDTO;
import com.ikon.rest.web.models.UserFeedbackDTO;
import com.ikon.rest.web.models.WorkNoteDTO;
import com.ikon.service.KOInfoService;
import com.ikon.service.MLDBProcess;
import com.ikon.service.TicketDataService;
import com.mongodb.MongoException;

import lombok.extern.slf4j.Slf4j;

/**
 * The Class IKONControllerRest.
 */
@RestController
@PropertySource("classpath:rest.properties")
@Slf4j
public class IKONControllerRest {

	/** The Constant ACCOUNT_ID. */
	private static final String ACCOUNT_ID = "1"; // Account_ID = 1 for CIAP

	/** The ko info service. */
	@Autowired
	private transient KOInfoService koInfoService;

	/** The ko info service rest. */
	@Autowired
	private transient KOInfoServiceRest koInfoServiceRest;

	/** The ticket data service. */
	@Autowired
	private transient TicketDataService ticketDataService;

	/** The k O usage repository. */
	@Autowired
	private transient KOUsageRepository kOUsageRepository;

	/** The Inc Ko Link Mongo Repository */
	@Autowired
	private transient IncKOLinkMLRepository incKOLinkMLRepo;

	@Autowired
	private transient KOInfoRepository kOInfoRepository;

	/** The ticket data history repository. */
	@Autowired
	private transient TicketDataHistoryRepository ticketDataHistoryRepository;

	/** The Constant log. */
	//private static final log log = LogManager.getlog(IKONControllerRest.class);

	/** The Constant CATEGORY_KO. */
	private static final String CATEGORY_KO = "kb_knowledge";

	/** The Constant CATEGORY_INCIDENT. */
	private static final String CATEGORY_INCIDENT = "incident";

	/** The Constant ACCESS_CONTROL_ALLOW_ORIGIN. */
	private static final String ACCESS_CONTROL_ALLOW_ORIGIN = "Access-Control-Allow-Origin";

	/** The Constant ACCESS_CONTROL_ALLOW_CREDENTIALS. */
	private static final String ACCESS_CONTROL_ALLOW_CREDENTIALS = "Access-Control-Allow-Credentials";

	/** The Constant TRUE. */
	private static final String TRUE = "true";

	@Autowired
	private Environment env;

	//@Autowired
	@PersistenceContext(unitName = "multiEntityManager")
	private EntityManager em;

	/** The ml DB process. */
	@Autowired
	private transient MLDBProcess mlDBProcess;

	/**
	 * The Validation Service.
	 */
	@Autowired
	private RequestValidationService requestValidationServiceService;

	/** The attach base. */
	//@Value("${ikon2.attachmentBase}")
	//private String attachBase;

	/** The account name. */
	//@Value("${ikon2.accountName}")
	//private String accountName;

	/** The koTower */
	@Value("${KO.tower}")
	private String koTower;

	/**
	 * Gets the KOs.
	 *
	 * @param applicationName the application name
	 * @param assignmentGroup the assignment group
	 * @param response        the response
	 * @return the kos
	 */
	@GetMapping(value = "/api/getAllKO")
	public ResponseEntity<?> getAllKO(@RequestParam(required = false) String applicationName,
			@RequestParam(required = false) String assignmentGroup, @RequestParam(required = false) String param,
			@RequestHeader(name = RequestConstants.TENANT_ID) final String encryptedTenantId,
			HttpServletResponse response) {
		response.setHeader(ACCESS_CONTROL_ALLOW_ORIGIN, "*");
		response.setHeader(ACCESS_CONTROL_ALLOW_CREDENTIALS, TRUE);

		// Setting Tenant & MDC Context
		requestValidationServiceService.decryptAndValidateTenantId(encryptedTenantId);

		List<KODetailsDTO> responseKOList = new LinkedList<KODetailsDTO>();
		KoDataAttributeVO KoAttrVo = new KoDataAttributeVO();
		KoAttrVo.setMasterDtAttrVo(
				new MasterDataAttributeVO(ACCOUNT_ID, StringUtils.hasLength(applicationName) ? applicationName : "",
						StringUtils.hasLength(assignmentGroup) ? assignmentGroup : "", "", "", "", ""));
		KoAttrVo.setKoDtAttr(new KoDataAttribute("", "", "", "", "", 0));
		List<KOInfoBean> koInfoBeanList = koInfoService.kolistviewSP(KoAttrVo);

		if (param == null || param.isEmpty()) {

			koInfoBeanList.forEach(infoBean -> {
				KODetailsDTO kDTO = new KODetailsDTO();
				kDTO.setSolutionnumber(infoBean.getKoID());
				kDTO.setGoal(infoBean.getShortDescription());
				kDTO.setDescription(infoBean.getLongDescription());
				kDTO.setCategoryName(CATEGORY_KO);
				kDTO.setProblemdetail(infoBean.getShortDescription());
				kDTO.setSolutiontext(infoBean.getResolution());

				if (StringUtils.hasLength(infoBean.getAssignmentGroup())) {
					kDTO.setCategory(koInfoServiceRest.getTowerForKO(infoBean.getAssignmentGroup()));
				} else {
					kDTO.setCategory(koTower);

				}
//				final Integer linkedIncCount = kOUsageRepository
//						.getLinkedIncCountForASerialNumber(infoBean.getKOSerialNo());
				kDTO.setLinkedTicket(String.valueOf(infoBean.getLinkedCount()));

				kDTO.setScore(getScorePerc(infoBean.getRelevPerc(), infoBean.getKoID()));
				kDTO.setUserScore(infoBean.getUsagePerc());
				kDTO.setUserthumbscount(infoBean.getUsagePerc());
				responseKOList.add(kDTO);
			});
			log.info("No of KO's found: " + responseKOList.size());
			return new ResponseEntity<>(responseKOList, HttpStatus.OK);
		} else {
			List<String> paramList = new ArrayList<>(Arrays.asList(param.split(",")));
			JSONArray filterResponse = new JSONArray();

			koInfoBeanList.forEach(infoBean -> {
				JSONObject json = new JSONObject();
				for (String params : paramList) {

					if (params.equalsIgnoreCase("solutionnumber"))
						json.put("solutionnumber", infoBean.getKoID());

					if (params.equalsIgnoreCase("goal"))
						json.put("goal", infoBean.getShortDescription());

					if (params.equalsIgnoreCase("description"))
						json.put("description", infoBean.getLongDescription());

					if (params.equalsIgnoreCase("categoryName"))
						json.put("categoryName", CATEGORY_KO);

					if (params.equalsIgnoreCase("category")) {
						if (StringUtils.hasLength(infoBean.getAssignmentGroup())) {
							json.put("category", koInfoServiceRest.getTowerForKO(infoBean.getAssignmentGroup()));
						} else {
							json.put("category", koTower);
						}
					}
					if (params.equalsIgnoreCase("problemdetail"))
						json.put("problemdetail", infoBean.getShortDescription());

					if (params.equalsIgnoreCase("solutiontext"))
						json.put("solutiontext", infoBean.getResolution());

					if (params.equalsIgnoreCase("linkedTicket")) {
//						final Integer linkedIncCount = kOUsageRepository
//								.getLinkedIncCountForASerialNumber(infoBean.getKOSerialNo());
//						kDTO.setLinkedTicket((String)infoBean.getTicketLinkCount());
						json.put("linkedTicket", String.valueOf(infoBean.getLinkedCount()));
					}

					if (params.equalsIgnoreCase("score"))
						json.put("score", getScorePerc(infoBean.getRelevPerc(), infoBean.getKoID()));

					if (params.equalsIgnoreCase("userScore"))
						json.put("userScore", infoBean.getUsagePerc());

					if (params.equalsIgnoreCase("userthumbscount"))
						json.put("userthumbscount", infoBean.getUsagePerc());

				}
				filterResponse.put(json);
			});

			log.info("No of KO's found filter: " + filterResponse.length());
			return new ResponseEntity<>(filterResponse.toString(), HttpStatus.OK);
		}

	}

	/**
	 * Gets the KO details.
	 *
	 * @param ticketDataDTO the ticket data DTO
	 * @param response      the response
	 * @return the KO details
	 */
	@PostMapping(value = "/api/getKOIncidentTicketDetails", produces = MediaType.APPLICATION_JSON_VALUE)
	@JsonIgnoreProperties(ignoreUnknown = true)
	public ResponseEntity<List<Object>> getKODetails(@RequestBody KOLinkedIncidentDTO koLinkedIncidentDTO,
			@RequestHeader(name = RequestConstants.TENANT_ID) final String encryptedTenantId,
			HttpServletResponse response) {
		response.setHeader(ACCESS_CONTROL_ALLOW_ORIGIN, "*");
		response.setHeader(ACCESS_CONTROL_ALLOW_CREDENTIALS, TRUE);

		// Setting Tenant & MDC Context
		requestValidationServiceService.decryptAndValidateTenantId(encryptedTenantId);

		final List<Object> responseObjs = new ArrayList<>();
		if (Objects.nonNull(koLinkedIncidentDTO.getKoid())) {
			final KOInfo koInfo = kOInfoRepository.findByKoID(koLinkedIncidentDTO.getKoid());

			if (koInfo != null) {
				final Integer linkedIncCount = kOUsageRepository
						.getLinkedIncCountForASerialNumber(koInfo.getKoSerialNo());
				final String resolution = kOInfoRepository.getResolutionForAKO(koInfo.getKoSerialNo());

				final KODetailsDTO kDTO = new KODetailsDTO();
				kDTO.setSolutionnumber(koInfo.getKoID());
				kDTO.setGoal(koInfo.getShortDescrption());
				kDTO.setDescription(koInfo.getLongDescription());
				kDTO.setCategoryName(CATEGORY_KO);
				kDTO.setProblemdetail(koInfo.getShortDescrption());
				kDTO.setSolutiontext(resolution);

				// Add the attachment list to existing flow
				kDTO.setAttachmentList(koInfoServiceRest.getAttachmentList(koInfo.getKoSerialNo()));

				List<String> attachIDs = getKoAttachIds(kDTO.getAttachmentList(), resolution);
				kDTO.setAttachIDs(attachIDs);

				if (StringUtils.hasLength(koInfo.getAssignmentGroup())) {
					kDTO.setCategory(koInfoServiceRest.getTowerForKO(koInfo.getAssignmentGroup()));
				} else {
					kDTO.setCategory(koTower);
				}
				kDTO.setLinkedTicket(Integer.toString(linkedIncCount));
				responseObjs.add(kDTO);

				if (linkedIncCount != 0 && koLinkedIncidentDTO.isLinkedIncidents()) {
					final int pageSize = koLinkedIncidentDTO.getPageSize() == null
							? Integer.parseInt(env.getProperty("linked.tickets.pagesize"))
							: koLinkedIncidentDTO.getPageSize();
					final int index = koLinkedIncidentDTO.getStartIndex() == null
							? Integer.parseInt(env.getProperty("linked.tickets.startindex"))
							: koLinkedIncidentDTO.getStartIndex();

					final int startIndex = index == 0 ? index : index - 1;

					final List<LinkedTicketDataDTO> linkedTicketData = em.createQuery(
							"select new com.ikon.rest.web.models.LinkedTicketDataDTO(tdh.ticketID, tdh.resolutionNote, tdh.summary, tdh.notes, tdh.category, tdh.relevPerc, tdh.usagePerc) "
									+ "from TicketDataHistory tdh "
									+ "JOIN KOUsage kou on tdh.serialNumber = kou.serialNumber "
									+ "JOIN KOInfo koi on kou.koSerialNo = koi.koSerialNo where koi.koID =  :koid "
									+ "Order By kou.linkedDate DESC",
							LinkedTicketDataDTO.class).setParameter("koid", koInfo.getKoID()).setMaxResults(pageSize)
							.setFirstResult(startIndex).getResultList();

					linkedTicketData.stream().forEach(ticketDetail -> {
						final IncidentDetailsDTO incident = new IncidentDetailsDTO();
						incident.setSolutionnumber(ticketDetail.getTicketID());
						incident.setGoal(ticketDetail.getSummary());
						incident.setProblemDetail(ticketDetail.getNotes());
						incident.setSolutionText(ticketDetail.getResolutionNote());
						incident.setDescription(ticketDetail.getSummary());
						incident.setCategory(ticketDetail.getCategory());
						incident.setCategoryName(CATEGORY_INCIDENT);

						incident.setScore(getScorePerc(ticketDetail.getRelevPerc(), koLinkedIncidentDTO.getKoid()));
						incident.setUserScore(getScorePerc(ticketDetail.getUsagePerc(), koLinkedIncidentDTO.getKoid()));
						responseObjs.add(incident);
					});
				}
			}
		}
		log.info("No of Records's found: " + responseObjs.size());

		return new ResponseEntity<>(responseObjs, HttpStatus.OK);
	}

	private List<String> getKoAttachIds(List<AttachmentDTO> list, String resolution) {
		final String patternReplaceFind = env.getProperty("ikon2.patternReplaceFind");
		final String formatString = env.getProperty("ikon2.imgFormats").trim();
		final Set<String> attachIDs = new LinkedHashSet<String>();
		List<String> validImgIDs = new ArrayList<String>();
		List<String> formats = new ArrayList<String>(Arrays.asList(formatString.split(",")));

		Matcher matches = Pattern.compile(patternReplaceFind).matcher(resolution);

		while (matches.find()) {
			attachIDs.add(matches.group(2));
		}
		log.info("Attach IDs found : " + attachIDs);

		for (AttachmentDTO attachDto : list) {
			if (attachIDs.contains(attachDto.getAttachID())
					&& formats.contains(attachDto.getAttachType().toLowerCase())) {
				validImgIDs.add(attachDto.getAttachID());
			}
		}

		// validImgIDs = koInfoServiceRest.getValidImgIDs(attachIDs);
		log.info("Attach IDs Valid : " + validImgIDs);
		// return validImgIDs;
		return validImgIDs;
	}

	/**
	 * Gets the k os.
	 *
	 * @param ticketDataDTO the ticket data DTO
	 * @param response      the response
	 * @return the k os
	 */
	@PostMapping(value = "/api/SearchKOSolution", produces = MediaType.APPLICATION_JSON_VALUE)
	@JsonIgnoreProperties(ignoreUnknown = true)
	public ResponseEntity<List<KODetailsDTO>> getKOs(@RequestBody TicketDataDTO ticketDataDTO,
			@RequestHeader(name = RequestConstants.TENANT_ID) final String encryptedTenantId,
			HttpServletResponse response) {
		response.setHeader(ACCESS_CONTROL_ALLOW_ORIGIN, "*");
		response.setHeader(ACCESS_CONTROL_ALLOW_CREDENTIALS, TRUE);

		// Setting Tenant & MDC Context
		requestValidationServiceService.decryptAndValidateTenantId(encryptedTenantId);

		List<KODetailsDTO> responseKOList = new LinkedList<KODetailsDTO>();
		if (StringUtils.hasLength(ticketDataDTO.getSearchString())) {
			TicketDataAttributeVO tktDtAttrVO = new TicketDataAttributeVO();
			SearchDataAttributeVO searchDtAttrVo = new SearchDataAttributeVO();
			searchDtAttrVo.setSearch(ticketDataDTO.getSearchString());
			searchDtAttrVo.setSearchid("");
			tktDtAttrVO.setSearchDtAttrVo(searchDtAttrVo);

			List<KOInfoBean> koInfoBeanList = koInfoService.simpleKOSearch(tktDtAttrVO);

			koInfoBeanList.forEach(infoBean -> {
				String[] relevPercStrArr = null;
				String[] usagePercStrArr = null;
				String[] koIdWithPerc = null;
				KODetailsDTO kDTO = new KODetailsDTO();
				kDTO.setSolutionnumber(infoBean.getKoID());
				kDTO.setGoal(infoBean.getShortDescription());
				kDTO.setDescription(infoBean.getLongDescription());
				kDTO.setCategoryName(CATEGORY_KO);
				kDTO.setProblemdetail(infoBean.getShortDescription());
				kDTO.setSolutiontext(infoBean.getResolution());
				if (StringUtils.hasLength(infoBean.getAssignmentGroup())) {
					kDTO.setCategory(koInfoServiceRest.getTowerForKO(infoBean.getAssignmentGroup()));
				} else {
					kDTO.setCategory(koTower);

				}

				final Integer linkedIncCount = kOUsageRepository
						.getLinkedIncCountForASerialNumber(infoBean.getKOSerialNo());
				kDTO.setLinkedTicket(linkedIncCount.toString());

				if (StringUtils.hasLength(infoBean.getRelevPerc())) {
					relevPercStrArr = infoBean.getRelevPerc().split(";");
					if (Objects.nonNull(relevPercStrArr) && relevPercStrArr.length > 0) {
						koIdWithPerc = relevPercStrArr[0].split(":");
						kDTO.setScore(koIdWithPerc[1]);
					}
				}
				if (StringUtils.hasLength(infoBean.getUsagePerc())) {
					usagePercStrArr = infoBean.getUsagePerc().split(";");
					if (Objects.nonNull(relevPercStrArr) && relevPercStrArr.length > 0) {
						koIdWithPerc = usagePercStrArr[0].split(":");
						kDTO.setUserScore(koIdWithPerc[1]);
						kDTO.setUserthumbscount(koIdWithPerc[1]);
					}
				}
				responseKOList.add(kDTO);
			});
		}
		log.info("No of KO's found: " + responseKOList.size());
		return new ResponseEntity<>(responseKOList, HttpStatus.OK);
	}

	/**
	 * Updateticket API.
	 *
	 * @param ticketDataDTO the ticket data DTO
	 * @param response      the response
	 * @return the response entity
	 */
	@PostMapping(value = "/api/updateTicket", produces = MediaType.APPLICATION_JSON_VALUE)
	@JsonIgnoreProperties(ignoreUnknown = true)
	public ResponseEntity<ApiResponseDTO> updateticketAPI(@RequestBody TicketDataDTO ticketDataDTO,
			@RequestHeader(name = RequestConstants.TENANT_ID) final String encryptedTenantId,
			HttpServletResponse response) {
		response.setHeader(ACCESS_CONTROL_ALLOW_ORIGIN, "*");
		response.setHeader(ACCESS_CONTROL_ALLOW_CREDENTIALS, TRUE);

		// Setting Tenant & MDC Context
		requestValidationServiceService.decryptAndValidateTenantId(encryptedTenantId);

		log.info("Ticket Object: " + ticketDataDTO);
		ApiResponseDTO apiResponse = new ApiResponseDTO();

		try {

			koInfoServiceRest.insertTicketDetail(ticketDataDTO);
			// Get MongoDB Connection
			// MongoDBConnection mongodbcon = new MongoDBConnection();
			// Insert data into MongoDB
			// mongodbcon.insertINCtoMongoInterTable(ticketDataDTO, 1);
			mlDBProcess.insertIncToPostgres(ticketDataDTO);

			// Call sp_ticket_data_insert SP to insert data to ticket tables
			koInfoServiceRest.runStoredProcedureWithNoParam();

			// Incident KO Link
			linkKOfromWorkNotes(ticketDataDTO,encryptedTenantId);

			apiResponse.setStatus(true);
			apiResponse.setMessage("Ticket Created Successfully");

			log.info("Ticket Created Successfully");
			return new ResponseEntity<>(apiResponse, HttpStatus.OK);

		} catch (MongoException ex) {
			apiResponse.setStatus(false);
			apiResponse.setMessage("Error occurred while creating the ticket");
			log.error("Exception occurred in updating ticket details: " + ex.getMessage());
			return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/**
	 * Gets the KO incident details.
	 *
	 * @param ticketDataDTO the ticket data DTO
	 * @param response      the response
	 * @return the KO incident details
	 */
	@JsonIgnoreProperties(ignoreUnknown = true)
	@PostMapping(value = "/api/getKOIncidentDetails", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Object> getKOIncidentDetails(@RequestBody TicketDataDTO ticketDataDTO,
			@RequestHeader(name = RequestConstants.TENANT_ID) final String encryptedTenantId,
			HttpServletResponse response) {
		response.setHeader(ACCESS_CONTROL_ALLOW_ORIGIN, "*");
		response.setHeader(ACCESS_CONTROL_ALLOW_CREDENTIALS, TRUE);

		// Setting Tenant & MDC Context
		requestValidationServiceService.decryptAndValidateTenantId(encryptedTenantId);

		int rank[] = { 1 };
		List<IncidentDetailsDTO> similarIncidents = new ArrayList<IncidentDetailsDTO>();
		List<KODetailsDTO> responseKOList = new ArrayList<KODetailsDTO>();

		if (Objects.nonNull(ticketDataDTO) && StringUtils.hasLength(ticketDataDTO.getNumber())) {
			log.info("getKOIncidentDetails: " + ticketDataDTO.getNumber());
			if (ticketDataService.isTicketExists(ticketDataDTO.getNumber())) {

				if (Objects.nonNull(ticketDataDTO) && StringUtils.hasLength(ticketDataDTO.getNumber()))
					getExistingIncidentDetails(ticketDataDTO, responseKOList, similarIncidents);
			} else {
				try {
					log.info("Ticket Object getKOIncidentDetails: " + ticketDataDTO);

					koInfoServiceRest.insertTicketDetail(ticketDataDTO);
					// Get MongoDB Connection
					// MongoDBConnection mongodbcon = new MongoDBConnection();
					// Insert data into MongoDB
					// mongodbcon.insertINCtoMongoInterTable(ticketDataDTO, 1);
					mlDBProcess.insertIncToPostgres(ticketDataDTO);

					// Call sp_ticket_data_insert SP to insert data to ticket tables
					koInfoServiceRest.runStoredProcedureWithNoParam();

					// Incident KO Link
					linkKOfromWorkNotes(ticketDataDTO,encryptedTenantId);

				} catch (MongoException ex) {
					log.error("Exception occurred in getKOIncidentDetails api: " + ex.getMessage());
				}
			}
		}

		// Temporary fix for assigning rank to KOs
		Function<String, Integer> stringToInt = score -> StringUtils.isEmpty(score) ? 0 : Integer.parseInt(score);
		Function<String, Integer> compareKOID = koid -> Integer.parseInt(koid.split("[A-Za-z]{2}")[1]);

		Comparator<KODetailsDTO> compareByScoreAndKOID = Comparator
				.comparing((KODetailsDTO koDetailsDTO) -> stringToInt.apply(koDetailsDTO.getScore()))
				.thenComparing((KODetailsDTO koDetailsDTO) -> stringToInt.apply(koDetailsDTO.getUserScore()))
				.thenComparing((KODetailsDTO koDetailsDTO) -> compareKOID.apply(koDetailsDTO.getSolutionnumber()));
		Collections.sort(responseKOList, compareByScoreAndKOID.reversed());

		responseKOList.stream().forEach(ko -> {
			ko.setRank(rank[0]);
			rank[0]++;
		});

		List<Object> responseObjs = new ArrayList<>();
		responseObjs.addAll(similarIncidents);
		responseObjs.addAll(responseKOList);

		log.info("No of Records's found: " + responseObjs.size());

		return responseObjs;
	}

	/**
	 * Gets the existing incident details.
	 *
	 * @param ticketDataDTO    the ticket data DTO
	 * @param responseKOList   the response KO list
	 * @param similarIncidents the similar incidents
	 */
	private void getExistingIncidentDetails(TicketDataDTO ticketDataDTO, List<KODetailsDTO> responseKOList,
			List<IncidentDetailsDTO> similarIncidents) {

		List<TicketDataBean> ticketDataBeanList = ticketDataService.getTicketData(ticketDataDTO.getNumber());
		List<TicketDataBean> similarIncidentsList = ticketDataService.getSimilarIncidentList(ticketDataDTO.getNumber());

		if (Objects.nonNull(ticketDataBeanList) && ticketDataBeanList.size() > 0) {
			for (TicketDataBean ticketBean : ticketDataBeanList) {
				if (StringUtils.hasLength(ticketBean.getKoID())) {

					KODetailsDTO kDTO = new KODetailsDTO();
					kDTO.setSolutionnumber(ticketBean.getKoID());
					kDTO.setGoal(ticketBean.getShortDescription());
					kDTO.setDescription(ticketBean.getKo_LongDescription());
					kDTO.setCategoryName(CATEGORY_KO);

					final Integer linkedIncCount = kOUsageRepository
							.getLinkedIncCountForASerialNumber(ticketBean.getKOSerialNo());
					kDTO.setLinkedTicket(linkedIncCount.toString());

					kDTO.setScore(getScorePerc(ticketBean.getRelevPerc(), ticketBean.getKoID()));
					kDTO.setUserScore(getScorePerc(ticketBean.getUsagePerc(), ticketBean.getKoID()));
					responseKOList.add(kDTO);
				}
			}
		}

		if (Objects.nonNull(similarIncidentsList) && similarIncidentsList.size() > 0) {
			for (TicketDataBean similarIncident : similarIncidentsList) {
				IncidentDetailsDTO incident = new IncidentDetailsDTO();
				incident.setSolutionnumber(similarIncident.getTicketID());
				incident.setGoal(similarIncident.getSummary());
				incident.setProblemDetail(similarIncident.getNotes());
				incident.setSolutionText(similarIncident.getResolution());
				incident.setDescription(similarIncident.getShortDescription());
				incident.setCategory(similarIncident.getCategory());
				incident.setCategoryName(CATEGORY_INCIDENT);

				incident.setScore(getScorePerc(similarIncident.getRelevPerc(), similarIncident.getKoID()));
				incident.setUserScore(getScorePerc(similarIncident.getUsagePerc(), similarIncident.getKoID()));
				similarIncidents.add(incident);
				// });
			}
		}
	}

	/**
	 * Gets the score perc.
	 *
	 * @param relevPerc the relev perc
	 * @return the score perc
	 */
	private String getScorePerc(String relevPerc, String koId) {
		String[] relevPercStrArr = null;
		String[] koIdWithPerc = null;
		int counter = 0;
		boolean flag = false;
		if (StringUtils.hasLength(relevPerc)) {
			relevPercStrArr = relevPerc.split(";");

			for (String ko : relevPercStrArr) {
				String[] koSplit = ko.split(":");

				if (koId != null && koId.equalsIgnoreCase(koSplit[0])) {
					flag = true;
					break;
				}
				counter++;
			}

			if (flag && Objects.nonNull(relevPercStrArr) && relevPercStrArr.length > 0) {
				koIdWithPerc = relevPercStrArr[counter].split(":");
				return koIdWithPerc[1];
			}
		}
		return "";
	}

	/**
	 * Save user feedback.
	 *
	 * @param feedBack the feed back
	 * @param response the response
	 * @return the response entity
	 */
	@PostMapping(value = "/api/UserFeedBack", produces = MediaType.APPLICATION_JSON_VALUE)
	@JsonIgnoreProperties(ignoreUnknown = true)
	public ResponseEntity<Void> saveUserFeedback(@RequestHeader("Authorization") final String token,
			@RequestBody UserFeedbackDTO feedBack,
			@RequestHeader(name = RequestConstants.TENANT_ID) final String encryptedTenantId,
			HttpServletResponse response) {
		response.setHeader(ACCESS_CONTROL_ALLOW_ORIGIN, "*");
		response.setHeader(ACCESS_CONTROL_ALLOW_CREDENTIALS, TRUE);

		// Setting Tenant & MDC Context
		requestValidationServiceService.decryptAndValidateTenantId(encryptedTenantId);

		final String payload = token.split(" ")[1];
		final DecodedJWT jwt = JWT.decode(payload);
		final String userName = jwt.getClaim("itsm_username").asString();

		final String ticketId = feedBack.getIncidentnumber();
		final String koId = feedBack.getSolutionnumber();
		final Date date = new Date();
		final LocalDateTime dateTime = LocalDateTime.now();
		KOUsage koUsage = new KOUsage();
		koUsage.setAccountID(Integer.parseInt(ACCOUNT_ID));
		IncKoLinkML incKoLinkML = new IncKoLinkML();
		koUsage.setFeedId(1);
		if (StringUtils.hasLength(ticketId) && StringUtils.hasLength(koId)) {
			Long ticketSerialNumber = ticketDataHistoryRepository.getSerialNumberForTicket(ticketId);
			final KOInfo koInfo = kOInfoRepository.findByKoID(koId);
			if (Objects.nonNull(ticketSerialNumber) && Objects.nonNull(koInfo)) {
				koUsage.addSerialPublic(ticketSerialNumber.intValue());
				koUsage.setKoSerialNo(koInfo.getKoSerialNo());
				koUsage.setLinkedDate(date);
				koUsage.setUserID(userName);
				incKoLinkML.setKoID(koId);
				incKoLinkML.setIncidentID(ticketId);
				incKoLinkML.setLinkedDate(dateTime);
				kOUsageRepository.save(koUsage);
				incKOLinkMLRepo.save(incKoLinkML);
			}
		}
		log.info("User Feedback Saved ");
		return new ResponseEntity<>(HttpStatus.ACCEPTED);
	}

	/**
	 * Creates the KO.
	 *
	 * @param koDTO    the ko DTO
	 * @param response the response
	 * @return the response entity
	 */
	@PostMapping(value = "/api/PushKO", produces = MediaType.APPLICATION_JSON_VALUE)
	@JsonIgnoreProperties(ignoreUnknown = true)
	public ResponseEntity<Void> createKO(@RequestBody KODetailsDTO koDTO,
			@RequestHeader(name = RequestConstants.TENANT_ID) final String encryptedTenantId,
			HttpServletResponse response) {

		// Setting Tenant & MDC Context
		requestValidationServiceService.decryptAndValidateTenantId(encryptedTenantId);
		log.info("Push KO:"+ koDTO.toString());
		try {
			String resolution="";
			KOInfoBean koInfo = new KOInfoBean();
			koInfo.setKoID(koDTO.getSolutionnumber());
			koInfo.setShortDescription(koDTO.getDescription());
			koInfo.setApplicationName(koDTO.getApplicationName());
			koInfo.setAssignmentGroup(koDTO.getAssignmentGroup());
			koInfo.setLongDescription(koDTO.getLongDescription());
			koInfo.setSymptoms(koDTO.getSymptoms());
			
			String text=koDTO.getText();
			String resolutionStr=koDTO.getResolution();
			
			if(Objects.isNull(text)||StringUtils.isEmpty(text) ) {
				koDTO.setResolution(resolutionStr);
			}
			else if(Objects.isNull(resolutionStr) ||StringUtils.isEmpty(resolutionStr) ) {
				koDTO.setResolution(text);
			}
			else if(Objects.isNull(resolutionStr) ||StringUtils.isEmpty(resolutionStr)  && Objects.isNull(text)||StringUtils.isEmpty(text) ) {
				koDTO.setResolution("");
			}
			else {
				if(!resolutionStr.equalsIgnoreCase(text))
					koDTO.setResolution(resolutionStr.concat(text));
				else 
					koDTO.setResolution(resolutionStr);
			}
			

			
			if(Objects.nonNull(koDTO.getResolution())) {
				final String pattern=env.getProperty("ikon2.patternFind");
				final String patternReplace=env.getProperty("ikon2.patternReplace").replace("@@KO@@", koDTO.getSolutionnumber());
				resolution=koDTO.getResolution().replaceAll(pattern, patternReplace);
			}	
			koInfo.setResolution(resolution);
			koInfo.setAnswer(koDTO.getAnswer());
			koInfo.setKoStage(koDTO.getPubStatus());
			koInfo.setPublicationStatus(koDTO.getPubStatus());
			koInfo.setCreatedDate(koDTO.getCreatedDate());
			koInfo.setModifiedDate(koDTO.getModifiedDate());
			koInfo.setCreatedBy(koDTO.getCreatedBy());
			koInfo.setTower(koDTO.getCategory());
			koInfo.setPublishedBy(koDTO.getPublishedBy());
			koInfo.setTicketID(koDTO.getTicketId());

			koInfoServiceRest.pushKO(koInfo);
			// com.mongo.MongoDBprocess.insertData(koInfo, "1", koInfo.getKoID(),
			// koInfo.getKoStage());
			mlDBProcess.insertDataIntoPostgres(koInfo, "1", koInfo.getKoID(), koInfo.getKoStage(), "");

			log.info("KO Saved");

			return new ResponseEntity<>(HttpStatus.OK);
		} catch (MongoException | IOException ex) {
			log.error("Exception occurred in PushKO api: " + ex.getMessage());
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * Creates the user.
	 *
	 * @param uDTO     the u DTO
	 * @param response the response
	 * @return the response entity
	 */
	@PostMapping(value = "/api/PushUser", produces = MediaType.APPLICATION_JSON_VALUE)
	@JsonIgnoreProperties(ignoreUnknown = true)
	public ResponseEntity<Void> createUser(@RequestBody List<UserDTO> uDTO,
			@RequestHeader(name = RequestConstants.TENANT_ID) final String encryptedTenantId,
			HttpServletResponse response) {

		// Setting Tenant & MDC Context
		requestValidationServiceService.decryptAndValidateTenantId(encryptedTenantId);

		if (Objects.nonNull(uDTO) && uDTO.size() > 0) {
			uDTO.forEach(user -> {
				koInfoServiceRest.createUser(user);
			});
		}
		log.info(uDTO.size() + " Users Saved");
		return new ResponseEntity<>(HttpStatus.OK);
	}

	/**
	 * Download attachment.
	 *
	 * @param attachType   the attach type
	 * @param attachTypeId the attach type id
	 * @param attachID     the attach ID
	 * @return the response entity
	 */
	@GetMapping("/api/downloadAttachment")
	@JsonIgnoreProperties(ignoreUnknown = true)
	public ResponseEntity<Object> downloadAttachment(@RequestParam("attachType") String attachType,
			@RequestParam("attachTypeID") String attachTypeId, @RequestParam("attachID") final String attachID,
			@RequestParam(name = "embedded", required = false, defaultValue = "false") final boolean embedded,
			@RequestHeader(name = RequestConstants.TENANT_ID) final String encryptedTenantId) {
		log.info("Start : downloadAttachment");

		// Setting Tenant & MDC Context
		requestValidationServiceService.decryptAndValidateTenantId(encryptedTenantId);

		long start = System.currentTimeMillis();
		byte[] fileData = null;
		try {

			if (Objects.isNull(attachType)) {
				attachType = "KO";
			}
			if (Objects.isNull(attachTypeId) || attachTypeId.isEmpty()) {
				attachTypeId = koInfoServiceRest.getKObyAttachID(attachID);
			}

			String attachTypeBase = koInfoServiceRest.getAttachTypeBase(attachType);
			String attachName = koInfoServiceRest.getAttachName(attachTypeId, attachID);

			// Locate the file
			Path localPath = Paths.get(StringUtils.cleanPath(String.join(File.separator, TenantContextHolder.getTenantContextHolder().getAttachmentBase(), TenantContextHolder.getTenantContextHolder().getAccountName(),
					attachTypeBase, attachTypeId, attachID, attachName)));
			try (InputStream inputStream = Files.newInputStream(localPath)) {
				// Convert to Base64
				log.info("Base64 Conversion Start");
				fileData = Base64.getEncoder().encode(StreamUtils.copyToByteArray(inputStream));
				log.info("Base64 Conversion End");
			}

			// Respond in Json
			JsonObject json = new JsonObject();
			if (embedded) {
				String mimeType = Files.probeContentType(localPath);
				String prefix = "data:" + mimeType + ";base64," + new String(fileData);
				json.addProperty("file", prefix);
			} else {
				json.addProperty("file", new String(fileData));
			}
			log.info("Time taken (ms) : " + (System.currentTimeMillis() - start));
			log.info("End : downloadAttachment");
			return ResponseEntity.ok().body(json.toString());

		} catch (IOException | ArrayIndexOutOfBoundsException e) {
			log.error(e + " Error : " + e.getMessage());
			log.info("Time taken (ms) : " + (System.currentTimeMillis() - start));
			log.info("End : downloadAttachment");
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * Push KO attachment.
	 *
	 * @param type         the type
	 * @param fileStr      the file str
	 * @param koid         the koid
	 * @param fileName     the file name
	 * @param attachmentId the attachment id
	 * @param response     the response
	 * @param request      the request
	 * @return the response entity
	 */
	@PostMapping(value = "/api/pushAttachment", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	@JsonIgnoreProperties(ignoreUnknown = true)
	public ResponseEntity<Object> pushKOAttachment(@RequestPart("attachType") final String type,
			@RequestPart("file") String fileStr, @RequestPart("attachTypeID") String koid,
			@RequestPart("attachName") String fileName, @RequestPart("attachID") String attachmentId,
			HttpServletResponse response,
			@RequestHeader(name = RequestConstants.TENANT_ID) final String encryptedTenantId,
			HttpServletRequest request) {

		// Setting Tenant & MDC Context
		requestValidationServiceService.decryptAndValidateTenantId(encryptedTenantId);

		return koInfoServiceRest.pushAttachmentExtract(type, fileStr, koid, fileName, attachmentId);
	}

	/**
	 * Link K ofrom work notes.
	 *
	 * @param ticketDataDTO the ticket data DTO
	 */
	private void linkKOfromWorkNotes(TicketDataDTO ticketDataDTO,String encryptedTenantId) {

		String pattern = env.getProperty("ko.pattern");// "KMDB Solution:([A-Za-z0-9]+)#";
		List<WorkNoteDTO> workNotes = ticketDataDTO.getWorkNotes();
		StringBuilder workNote = new StringBuilder();
		if (workNotes != null) {
			workNotes.sort((x,y)->x.getSysCreatedOn().compareTo(y.getSysCreatedOn()));
			Collections.reverse(workNotes);
			for (WorkNoteDTO workNoteDto : workNotes) {
				workNote.append(workNoteDto.getValue());
				workNote.append(" ");
			}
		Matcher matches = Pattern.compile(pattern).matcher(workNote.toString());
		if (matches.find()) {
			String koid = matches.group(1);
			log.info("KO Found in update ticket : " + koid);
			final String ticketId = ticketDataDTO.getNumber();
			final Date date = new Date();
			final LocalDateTime dateTime = LocalDateTime.now();

			KOUsage koUsage = new KOUsage();
			koUsage.setAccountID(Integer.parseInt(ACCOUNT_ID));
			IncKoLinkML incKoLinkML = new IncKoLinkML();
			koUsage.setFeedId(1);
			if (StringUtils.hasLength(ticketId) && StringUtils.hasLength(koid)) {
				Long ticketSerialNumber = ticketDataHistoryRepository.getSerialNumberForTicket(ticketId);

				final KOInfo koInfo = kOInfoRepository.findByKoID(koid);

				if (Objects.nonNull(ticketSerialNumber) && Objects.nonNull(koInfo)) {

					final KOUsage koUsageDB = kOUsageRepository.findBySerialNumber(ticketSerialNumber.intValue());

					if (Objects.isNull(koUsageDB) || (Objects.nonNull(koUsageDB)
							&& !(Objects.equals(ticketSerialNumber.intValue(), koUsageDB.getSerialNumber())
									&& Objects.equals(koInfo.getKoSerialNo(), koUsageDB.getKoSerialNo())))) {
						koUsage.addSerialPublic(ticketSerialNumber.intValue());
						koUsage.setKoSerialNo(koInfo.getKoSerialNo());
						koUsage.setLinkedDate(date);
						koUsage.setUserID("system");
						kOUsageRepository.save(koUsage);

						incKoLinkML.setKoID(koid);
						incKoLinkML.setIncidentID(ticketId);
						incKoLinkML.setLinkedDate(dateTime);
						incKOLinkMLRepo.save(incKoLinkML);
						log.info(String.join("", "KOID : ", koid, " is linked to ticketId : ", ticketId,
								" in ikon successfully"));
					} else {
						log.info(String.join("", "KOID : ", koid, " is already linked to ticketId : ", ticketId));
					}
				}
			}

			// Linking to Data Lake
			linkToDL(ticketDataDTO, koid,encryptedTenantId);
		}
		}
	}

	/**
	 * Link to DL.
	 *
	 * @param ticketDataDTO the ticket data DTO
	 * @param koid          the koid
	 */
	private void linkToDL(TicketDataDTO ticketDataDTO, String koid,String encryptedTenantId) {

		int attempt = 0;
		System.out.println("tenant name -->"+encryptedTenantId);
		String staticToken = TenantContextHolder.getTenantContextHolder().getStaticToken();
		String updateKBtoDLURL = TenantContextHolder.getTenantContextHolder().getUpdateKbToDl();
		List<HttpMessageConverter<?>> messageConverters = new ArrayList<HttpMessageConverter<?>>();
		MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
		converter.setSupportedMediaTypes(Collections.singletonList(MediaType.ALL));
		messageConverters.add(converter);
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.setMessageConverters(messageConverters);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("Authorization", "Bearer " + staticToken);
		headers.add(RequestConstants.TENANT_ID, encryptedTenantId);

		DLkbLink dlkbLink = new DLkbLink(ticketDataDTO.getSys_id(), koid, ticketDataDTO.getLastModifiedBy(),
				ticketDataDTO.getServiceType());

		HttpEntity<DLkbLink> entity = new HttpEntity<>(dlkbLink, headers);
		while (attempt < 3) {
			try {

				ResponseEntity<Object> dlResponse = restTemplate.postForEntity(updateKBtoDLURL, entity, Object.class);
				log.info("DL Response code : " + dlResponse.getStatusCodeValue());
				break;
			} catch (RestClientException e) {
				attempt++;
				log.error("Failed to update ko into DL, attempt " + attempt);
				log.error("Error : " + e.getMessage());
			}
		}
	}

	@GetMapping(value = "/api/showRelatedKOs")
	public ResponseEntity<?> getRelatedKOs(@RequestParam("ticketId") String ticketId,
			@RequestHeader(name = RequestConstants.TENANT_ID) final String encryptedTenantId,
			HttpServletResponse response) {
		log.info("Start : Show All Related KO's");

		// Setting Tenant & MDC Context
		requestValidationServiceService.decryptAndValidateTenantId(encryptedTenantId);

		List<IncidentRelatedKODTO> relatedKOList = new ArrayList<>();
		ErrorResponseDTO apiResponse = new ErrorResponseDTO();
		List<TicketDataDTO> relevancies = new ArrayList<>();
		try {
			relevancies = koInfoServiceRest.getIncidentKOrelevancy(ticketId);
			if (!relevancies.isEmpty()) {
				for (TicketDataDTO relKO : relevancies) {
					System.out.println(relKO.getRelvpercs());
					if (relKO.getRelvpercs() != null) {
						String relvKO[] = relKO.getRelvpercs().split(";");
						String usageKO[] = relKO.getUsagepercs().split(";");
						int c = 0;
						for (String ko : relvKO) {
							KOInfoBean koInfo = koInfoServiceRest.getKODetail(ko.split(":")[0]).get(0);
							IncidentRelatedKODTO dto = new IncidentRelatedKODTO();
							dto.setKoID(koInfo.getKoID());
							dto.setApplicationName(koInfo.getApplicationName());
							dto.setAssignmentGroup(koInfo.getAssignmentGroup());
							dto.setDescription(koInfo.getShortDescription());
							dto.setLongDescription(koInfo.getLongDescription());
							dto.setResolution(koInfo.getResolution());
							dto.setRelevPerc(ko.split(":")[1]);
							dto.setUsagePerc(usageKO[c].split(":")[1]);
							relatedKOList.add(dto);
							c++;
						}
					}
				}

			}
			log.info("End : Show All Related KO's");
			return new ResponseEntity<>(relatedKOList, HttpStatus.OK);
		} catch (Exception e) {
			apiResponse.setError(true);
			apiResponse.setMessage("showRelatedKOs_001");
			log.error(e + " Error : " + e.getMessage());
			return new ResponseEntity<>(apiResponse, HttpStatus.UNPROCESSABLE_ENTITY);
		}

	}

	@PostMapping(value = "/api/getIncidentKOrelevancy")
	@JsonIgnoreProperties(ignoreUnknown = true)
	public ResponseEntity<Object> getIncidentKOrelevancy(@RequestBody TicketDataDTO ticketDataDTO,
			@RequestHeader(name = RequestConstants.TENANT_ID) final String encryptedTenantId) {

		// Setting Tenant & MDC Context
		requestValidationServiceService.decryptAndValidateTenantId(encryptedTenantId);

		if (Objects.nonNull(ticketDataDTO) && Objects.nonNull(ticketDataDTO.getTicketids())
				&& ticketDataDTO.getTicketids().size() > 0) {
			try {
				String tickets = String.join(",", ticketDataDTO.getTicketids());
				List<TicketDataDTO> relevancies = koInfoServiceRest.getIncidentKOrelevancy(tickets);
				List<JsonObject> jsonlist = new ArrayList<JsonObject>();
				for (TicketDataDTO relevancy : relevancies) {
					JsonObject json = new JsonObject();
					json.addProperty("ticketid", relevancy.getNumber());
					json.addProperty("korelvscores",
							Objects.isNull(relevancy.getRelvpercs()) ? "" : relevancy.getRelvpercs());
					json.addProperty("kousagescores",
							Objects.isNull(relevancy.getUsagepercs()) ? "" : relevancy.getUsagepercs());
					jsonlist.add(json);
				}

				return ResponseEntity.ok().body(jsonlist.toString());
			} catch (Exception e) {
				log.error(e.getMessage());
				return new ResponseEntity<>(HttpStatus.UNPROCESSABLE_ENTITY);
			}
		}

		return new ResponseEntity<>(HttpStatus.UNPROCESSABLE_ENTITY);
	}

}