package com.ikon.rest.datasourceconfig.utility;

import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.ikon.rest.datasourceconfig.beans.keyvault.KeyVaultBean;
import com.ikon.rest.datasourceconfig.constants.ConnectionConstants;
import com.ikon.rest.master.entity.Tenant;
import com.zaxxer.hikari.HikariDataSource;

import lombok.extern.slf4j.Slf4j;

/**
 * The SecretsUtility Class to retrieve Database secrets from KeyVault
 */
@Slf4j
@Component
public class ConnectionUtility {

	/**
     * The idle timeout property
     */
    @Value("${spring.datasource.hikari.idleTimeout}")
    private long idleTimeout;

    /**
     * The minimum idle property
     */
    @Value("${spring.datasource.hikari.minimumIdle}")
    private int minimumIdleCount;

    /**
     * The max lifetime property
     */
    @Value("${spring.datasource.hikari.maxLifetime}")
    private long maxLifeTime;

    /**
     * The max lifetime property
     */
    @Value("${spring.datasource.hikari.connectionTimeout}")
    private long connTimeOut;

   // @Value("${spring.datasource.hikari.maxPoolSize.key}")
  //  private String poolSizeStringKey;
    
    @Value("${spring.datasource.hikari.poolName}")
     private String poolName;

    /**
     * The Key Vault Bean
     */
    @Autowired
    private KeyVaultBean keyVaultBean;

    public DataSource createDataSource(Tenant tenant) {
        HikariDataSource dataSource = new HikariDataSource();
        this.setPoolSize(dataSource, tenant);
        dataSource.setIdleTimeout(idleTimeout);
        dataSource.setMaxLifetime(maxLifeTime);
        dataSource.setPoolName(poolName);
        dataSource.setInitializationFailTimeout(10000);
        dataSource.setConnectionTimeout(connTimeOut);
        dataSource.setDataSourceClassName(tenant.getConnectionConfig()
                                                  .getClassName());
        dataSource.addDataSourceProperty(ConnectionConstants.DS_URL, tenant.getConnectionConfig()
                .getUrl());

        SecretsUtility.getDatabaseSecrets(tenant, dataSource, keyVaultBean);

        // Attempting to validate the connection details by acquiring the connection
        try {
            log.info("Attempting to acquire JDBC connection for tenant: {}", tenant.getAccountId());
            dataSource.getConnection();
            log.info("Attempt to acquire JDBC connection for tenant: {}, successful!", tenant.getAccountId());
        } catch (SQLException e) {
            throw new RuntimeException(e.getMessage());
        }

        return dataSource;
    }

    private void setPoolSize(HikariDataSource dataSource, Tenant tenant) {
        String poolSizeString = tenant.getConnectionConfig()
                .getPoolSizes();
        if (StringUtils.hasLength(poolSizeString)) {
            try {
                String[] poolSizes = poolSizeString.split("-");
                dataSource.setMaximumPoolSize(Integer.parseInt(poolSizes[0]));
                dataSource.setMinimumIdle(Math.min(Integer.parseInt(poolSizes[1]), dataSource.getMaximumPoolSize()));
                log.info("Pool Sizes are set with values, MaxPoolSize : {} & MinIdle : {}", dataSource.getMaximumPoolSize(), dataSource.getMinimumIdle());
            } catch (RuntimeException e) {
                log.error("Error Occurred while setting pool sizes!");
                this.setDefaultPoolValuesForConnection(dataSource);
            }
        }
    }

    private void setDefaultPoolValuesForConnection(HikariDataSource dataSource) {
        log.info("Setting default values for MaxPool and MinIdle");
        dataSource.setMaximumPoolSize(10);
        dataSource.setMinimumIdle(Math.min(minimumIdleCount, dataSource.getMaximumPoolSize()));
    } 	 	
	
	
}
