package com.ikon.rest.web.models;

import java.util.Date;

public class IncidentRelatedKODTO {

	private String ticketID;
	private String koID;
	private String description;
	private String applicationName ;
	private String assignmentGroup ;  
	private String longDescription ; 
	private String resolution ;  
	private String relevPerc ;  
	private String usagePerc ;
	private String publicationStatus;
	private String symptoms;
	private String createdBy;	
	private Date createdDate;
	private String selectedKoForResolution;
	
	public String getTicketID() {
		return ticketID;
	}
	public void setTicketID(String ticketID) {
		this.ticketID = ticketID;
	}
	public String getKoID() {
		return koID;
	}
	public void setKoID(String koID) {
		this.koID = koID;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getApplicationName() {
		return applicationName;
	}
	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}
	public String getAssignmentGroup() {
		return assignmentGroup;
	}
	public void setAssignmentGroup(String assignmentGroup) {
		this.assignmentGroup = assignmentGroup;
	}
	public String getLongDescription() {
		return longDescription;
	}
	public void setLongDescription(String longDescription) {
		this.longDescription = longDescription;
	}
	public String getResolution() {
		return resolution;
	}
	public void setResolution(String resolution) {
		this.resolution = resolution;
	}
	public String getRelevPerc() {
		return relevPerc;
	}
	public void setRelevPerc(String relevPerc) {
		this.relevPerc = relevPerc;
	}
	public String getUsagePerc() {
		return usagePerc;
	}
	public void setUsagePerc(String usagePerc) {
		this.usagePerc = usagePerc;
	}
	public String getPublicationStatus() {
		return publicationStatus;
	}
	public void setPublicationStatus(String publicationStatus) {
		this.publicationStatus = publicationStatus;
	}
	public String getSymptoms() {
		return symptoms;
	}
	public void setSymptoms(String symptoms) {
		this.symptoms = symptoms;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	
	
	public String getSelectedKoForResolution() {
		return selectedKoForResolution;
	}
	public void setSelectedKoForResolution(String selectedKoForResolution) {
		this.selectedKoForResolution = selectedKoForResolution;
	}
	
	
}
