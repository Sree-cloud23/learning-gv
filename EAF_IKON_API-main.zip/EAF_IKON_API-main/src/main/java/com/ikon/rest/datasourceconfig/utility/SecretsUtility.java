package com.ikon.rest.datasourceconfig.utility;

import java.io.IOException;
import java.util.Map;
import java.util.Objects;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ikon.rest.datasourceconfig.beans.keyvault.KeyVaultBean;
import com.ikon.rest.datasourceconfig.constants.ConnectionConstants;
import com.ikon.rest.master.entity.Secret;
import com.ikon.rest.master.entity.Tenant;
import com.microsoft.azure.AzureEnvironment;
import com.microsoft.azure.credentials.ApplicationTokenCredentials;
import com.microsoft.azure.keyvault.KeyVaultClient;
import com.microsoft.azure.keyvault.models.SecretBundle;
import com.zaxxer.hikari.HikariDataSource;

import lombok.extern.slf4j.Slf4j;


/**
 * The SecretsUtility Class to retrieve Database secrets from KeyVault
 */
@Slf4j
public class SecretsUtility {

	/**
	 * The Rest Template to make rest calls
	 */
	private static final RestTemplate restTemplate = new RestTemplate();

	/**
	 * Private Constructor to ensure Singleton Class
	 */
	private SecretsUtility() {
		throw new UnsupportedOperationException("SecretsUtility Class cannot be instantiated");
	}

	/**
	 * Retrieves Database secrets for a datasource
	 *
	 * @param tenant       - TenantAccountMapping
	 * @param dataSource   - HikariDataSource
	 * @param keyVaultBean - KeyVaultBean
	 */
	public static void getDatabaseSecrets(Tenant tenant, HikariDataSource dataSource, KeyVaultBean keyVaultBean) {
		log.info("Inside SecretsUtility Class' getDatabaseSecrets method!");
		if (Objects.isNull(keyVaultBean.getType())) {
			dataSource.addDataSourceProperty(ConnectionConstants.DS_USER, tenant.getConnectionConfig().getUserName());
			dataSource.addDataSourceProperty(ConnectionConstants.DS_PASSWORD,
					tenant.getConnectionConfig().getPassword());
		} else {
			final String vaultType = keyVaultBean.getType();
			if (ConnectionConstants.AWS_STRING.equalsIgnoreCase(vaultType)) {
				getSecretsFromAWSVault(tenant, dataSource, keyVaultBean);
			} else if (ConnectionConstants.AZURE_STRING.equalsIgnoreCase(vaultType)) {
				getSecretFromAZUREVault(tenant, dataSource, keyVaultBean);
			}
		}
	}

	/**
	 * Retrieves secrets from AWS Vault
	 *
	 * @param tenant       - TenantAccountMapping
	 * @param dataSource   - HikariDataSource
	 * @param keyVaultBean - KeyVaultBean
	 */
	private static void getSecretsFromAWSVault(Tenant tenant, HikariDataSource dataSource, KeyVaultBean keyVaultBean) {
		log.info("Inside SecretsUtility Class' getSecretsFromAWSVault method!");
		final HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setBearerAuth(keyVaultBean.getAws().getToken());
		final HttpEntity<String> entity = new HttpEntity<>(null, headers);

		for (Secret secret : tenant.getSecrets()) {

			final ResponseEntity<? extends Map> response = restTemplate.exchange(keyVaultBean.getAws().getUrl(),
					HttpMethod.GET, entity, Map.class, secret.getName());
			try {
				if (response.hasBody()) {
					Map<String, String> responseMap = response.getBody();
					if (responseMap != null && responseMap.containsKey(ConnectionConstants.AWS_RESPONSE_KEY_STRING)) {
						String valueString = (responseMap.get(ConnectionConstants.AWS_RESPONSE_KEY_STRING))
								.replace("\"{\"", "{\"").replace("}\"}", "}}");
						final JsonNode jsonNode = new ObjectMapper().readTree(valueString);
						retrieveAndSetSecretFromJSONNode(tenant, dataSource, jsonNode, secret.getType());
					}
				}
			} catch (IOException | RestClientException e) {
				log.error("Error Occurred While Reading fetching Secret from the Vault! {}", e.getMessage());
				throw new IllegalStateException("Error Occurred While Reading fetching Secret from the Vault!");
			}

		}
	}

	/**
	 * Retrieves secrets from AWS Vault
	 *
	 * @param tenant       - TenantAccountMapping
	 * @param dataSource   - HikariDataSource
	 * @param keyVaultBean - KeyVaultBean
	 */
	private static void getSecretFromAZUREVault(Tenant tenant, HikariDataSource dataSource, KeyVaultBean keyVaultBean) {
		log.info("Inside SecretsUtility Class' getSecretFromAZUREVault method!");
		try {
			final ApplicationTokenCredentials credentials = new ApplicationTokenCredentials(
					keyVaultBean.getAzure().getClientId(), keyVaultBean.getAzure().getTenantId(),
					keyVaultBean.getAzure().getClientKey(), AzureEnvironment.AZURE);
			final KeyVaultClient vaultClient = new KeyVaultClient(credentials);
			if (!tenant.getSecrets().isEmpty()) {
				tenant.getSecrets().forEach(secret -> {
					final SecretBundle secretBundle = vaultClient.getSecret(keyVaultBean.getAzure().getUrl(),
							tenant.getAccountId());
					if (secret.getType().equalsIgnoreCase(ConnectionConstants.DS_USER)) {
						dataSource.addDataSourceProperty(ConnectionConstants.DS_USER, secretBundle.value());
					}

					if (secret.getType().equalsIgnoreCase(ConnectionConstants.DS_PASSWORD)) {
						dataSource.addDataSourceProperty(ConnectionConstants.DS_PASSWORD, secretBundle.value());
					}
				});
			}
		} catch (RuntimeException e) {
			throw new IllegalStateException("Error Occurred While Reading fetching Secret from the Vault!");
		}
	}

	private static void retrieveAndSetSecretFromJSONNode(Tenant tenant, HikariDataSource dataSource, JsonNode jsonNode,
			String secretType) {
		if (jsonNode.has(tenant.getAccountId())
				&& ConnectionConstants.USERNAME_AND_PASSWORD_STRING.equalsIgnoreCase(secretType)) {
			if (jsonNode.get(tenant.getAccountId()).has(ConnectionConstants.DS_USER)) {
				dataSource.addDataSourceProperty(ConnectionConstants.DS_USER,
						jsonNode.get(tenant.getAccountId()).get(ConnectionConstants.DS_USER).textValue());
			}
			if (jsonNode.get(tenant.getAccountId()).has(ConnectionConstants.DS_PASSWORD)) {
				dataSource.addDataSourceProperty(ConnectionConstants.DS_PASSWORD,
						jsonNode.get(tenant.getAccountId()).get(ConnectionConstants.DS_PASSWORD).textValue());
			}
		}
	}
}
