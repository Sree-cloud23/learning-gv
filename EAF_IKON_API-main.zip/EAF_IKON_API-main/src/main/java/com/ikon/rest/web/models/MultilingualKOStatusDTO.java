package com.ikon.rest.web.models;

/**
 * The Class MultilingualKOStatusDTO
 *
 */
public class MultilingualKOStatusDTO {
	/**
	 * The statusId
	 */
	private String statusId;

	/**
	 * The language
	 */
	private String language;
	
	/**
	 * The Description
	 */
	private String description;

	/**
	 * The displayDescription
	 */
	private String displayDescription;

	/**
	 * @return the statusId
	 */
	public String getStatusId() {
		return statusId;
	}

	/**
	 * @param statusId the statusId to set
	 */
	public void setStatusId(String statusId) {
		this.statusId = statusId;
	}

	/**
	 * @return the language
	 */
	public String getLanguage() {
		return language;
	}

	/**
	 * @param language the language to set
	 */
	public void setLanguage(String language) {
		this.language = language;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the displayDescription
	 */
	public String getDisplayDescription() {
		return displayDescription;
	}

	/**
	 * @param displayDescription the displayDescription to set
	 */
	public void setDisplayDescription(String displayDescription) {
		this.displayDescription = displayDescription;
	}

	/**
	 *
	 */
	@Override
	public String toString() {
		return "MultilingualKOStatusDTO [statusId=" + statusId + ", language=" + language + ", description="
				+ description + ", displayDescription=" + displayDescription + "]";
	}
	
	
}
