package com.ikon.rest.master.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ikon.rest.master.entity.TenantAccountMapping;

@Repository
public interface TenantAccountMappingRepository extends JpaRepository<TenantAccountMapping, String>{

	TenantAccountMapping findByTenantId(final String tenantId);
}
