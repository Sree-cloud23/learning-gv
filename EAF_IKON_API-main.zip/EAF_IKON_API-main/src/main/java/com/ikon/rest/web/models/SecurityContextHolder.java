package com.ikon.rest.web.models;

public class SecurityContextHolder {

	public static SecurityContext getContext() {
		// TODO Auto-generated method stub
		return new SecurityContext();
	}
}
