package com.ikon.rest.web.models;

public class SecurityContext {

	public Authentication getAuthentication() {
		// TODO Auto-generated method stub
		return new Authentication();
	}
}
