package com.ikon.rest.security.constants;

/**
 * The Tenant Data Store Class
 */
public class RequestConstants {

	/** The Constant TENANT_ID. */
	public static final String TENANT_ID = "tenant_name";

	private RequestConstants() {
		throw new UnsupportedOperationException("RequestConstants Class cannot be instantiated");
	}
}
