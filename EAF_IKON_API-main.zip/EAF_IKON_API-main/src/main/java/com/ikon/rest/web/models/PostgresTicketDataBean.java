package com.ikon.rest.web.models;

/**
 * The Class PostgresTicketDataBean.
 */
public class PostgresTicketDataBean
{
	
	/** The incident id. */
	private String incident_id;
	
	/** The inc text. */
	private String inc_text;
	
	/** The Assigned group. */
	private String Assigned_Group;
	
	/** The App name. */
	private String App_Name;
	
	/** The Status. */
	private String Status;
	
	/** The Summary. */
	private String Summary;
	
	/** The Category. */
	private String Category;
	
	/**
	 * Gets the category.
	 *
	 * @return the category
	 */
	public String getCategory() {
		return Category;
	}
	
	/**
	 * Sets the category.
	 *
	 * @param category the new category
	 */
	public void setCategory(String category) {
		Category = category;
	}
	
	/**
	 * Gets the summary.
	 *
	 * @return the summary
	 */
	public String getSummary() {
		return Summary;
	}
	
	/**
	 * Sets the summary.
	 *
	 * @param summary the new summary
	 */
	public void setSummary(String summary) {
		Summary = summary;
	}
	
	/**
	 * Gets the incident id.
	 *
	 * @return the incident id
	 */
	public String getIncident_id() {
		return incident_id;
	}
	
	/**
	 * Sets the incident id.
	 *
	 * @param incident_id the new incident id
	 */
	public void setIncident_id(String incident_id) {
		this.incident_id = incident_id;
	}
	
	/**
	 * Gets the inc text.
	 *
	 * @return the inc text
	 */
	public String getInc_text() {
		return inc_text;
	}
	
	/**
	 * Sets the inc text.
	 *
	 * @param inc_text the new inc text
	 */
	public void setInc_text(String inc_text) {
		this.inc_text = inc_text;
	}
	
	/**
	 * Gets the assigned group.
	 *
	 * @return the assigned group
	 */
	public String getAssigned_Group() {
		return Assigned_Group;
	}
	
	/**
	 * Sets the assigned group.
	 *
	 * @param assigned_Group the new assigned group
	 */
	public void setAssigned_Group(String assigned_Group) {
		Assigned_Group = assigned_Group;
	}
	
	/**
	 * Gets the app name.
	 *
	 * @return the app name
	 */
	public String getApp_Name() {
		return App_Name;
	}
	
	/**
	 * Sets the app name.
	 *
	 * @param app_Name the new app name
	 */
	public void setApp_Name(String app_Name) {
		App_Name = app_Name;
	}
	
	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getStatus() {
		return Status;
	}
	
	/**
	 * Sets the status.
	 *
	 * @param status the new status
	 */
	public void setStatus(String status) {
		Status = status;
	}

	@Override
	public String toString() {
		return "PostgresTicketDataBean [incident_id=" + incident_id + ", inc_text=" + inc_text + ", Assigned_Group="
				+ Assigned_Group + ", App_Name=" + App_Name + ", Status=" + Status + ", Summary=" + Summary
				+ ", Category=" + Category + "]";
	}

}
