package com.ikon.rest.web.models;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.extern.slf4j.Slf4j;

/**
 * The Class TicketDataDTO.
 */
@Slf4j
@JsonIgnoreProperties(ignoreUnknown = true)
public class TicketDataDTO {

	/** The number. */
	private String number;

	/** The caller id. */
	private String callerId;

	/** The service type. */
	private String serviceType;

	/** The location. */
	private String location;

	/** The company. */
	private String company;

	/** The category. */
	private String category;

	/** The sub category. */
	private String subCategory;

	/** The application name. */
	private String applicationName;

	/** The impact. */
	private String impact;

	/** The urgency. */
	private String urgency;

	/** The priority. */
	private String priority;

	/** The opened date. */
	private Date openedDate;

	/** The opened by. */
	private String openedBy;

	/** The contact type. */
	private String contactType;

	/** The state. */
	private String state;

	/** The assignment group. */
	private String assignmentGroup;

	/** The assigned to. */
	private String assignedTo;

	/** The short description. */
	private String shortDescription;

	/** The description. */
	private String description;

	/** The resolution note. */
	private String resolutionNote;

	/** The work notes. */
	private List<WorkNoteDTO> workNotes;

	/** The closed by. */
	private String closedBy;

	/** The resolution category. */
	private String resolutionCategory;

	/** The due date. */
	private Date dueDate;

	/** The last modified by. */
	private String lastModifiedBy;

	/** The last modified date. */
	private Date lastModifiedDate;

	/** The resolved at. */
	private Date resolvedAt;

	/** The cause code level 1. */
	private String causeCodeLevel1;

	/** The cause code level 2. */
	private String causeCodeLevel2;

	/** The cause code level 3. */
	private String causeCodeLevel3;

	/** The cause code level 3. */
	private String causeCodeLevel4;

	/** The cause code level 3. */
	private String causeCodeLevel5;

	/** The cause code level. */
	private String causeCode;

	/** The closed at. */
	private Date closedAt;

	/** The search string. */
	@JsonProperty(value = "SearchString")
	private String searchString;

	/** The koid. */
	private String koid;

	/** The SimpleDateFormat String. */
	private static final String SDF_STRING = "yyyy-MM-dd HH:mm:ss";

	/** The Constant log. */
	// private static final log log = LogManager.getlog(TicketDataDTO.class);

	/** The sys id. */
	private String sys_id;

	private String relvpercs;

	private String usagepercs;

	private List<String> ticketids;

	/**
	 * Gets the koid.
	 *
	 * @return the koid
	 */
	public String getKoid() {
		return this.koid;
	}

	/**
	 * Sets the koid.
	 *
	 * @param koid the new koid
	 */
	public void setKoid(String koid) {
		this.koid = koid;
	}

	/**
	 * Sets the opened date.
	 *
	 * @param openedDate the new opened date
	 */
	public void setOpenedDate(Date openedDate) {
		this.openedDate = openedDate;
	}

	/**
	 * Sets the last modified date.
	 *
	 * @param lastModifiedDate the new last modified date
	 */
	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	/**
	 * Sets the resolved at.
	 *
	 * @param resolvedAt the new resolved at
	 */
	public void setResolvedAt(Date resolvedAt) {
		this.resolvedAt = resolvedAt;
	}

	/**
	 * Sets the closed at.
	 *
	 * @param closedAt the new closed at
	 */
	public void setClosedAt(Date closedAt) {
		this.closedAt = closedAt;
	}

	/**
	 * Gets the number.
	 *
	 * @return the number
	 */
	public String getNumber() {
		return this.number;
	}

	/**
	 * Sets the number.
	 *
	 * @param number the new number
	 */
	public void setNumber(String number) {
		this.number = number;
	}

	/**
	 * Gets the caller id.
	 *
	 * @return the caller id
	 */
	public String getCallerId() {
		return this.callerId;
	}

	/**
	 * Sets the caller id.
	 *
	 * @param callerId the new caller id
	 */
	public void setCallerId(String callerId) {
		this.callerId = callerId;
	}

	/**
	 * Gets the service type.
	 *
	 * @return the service type
	 */
	public String getServiceType() {
		return this.serviceType;
	}

	/**
	 * Sets the service type.
	 *
	 * @param serviceType the new service type
	 */
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	/**
	 * Gets the location.
	 *
	 * @return the location
	 */
	public String getLocation() {
		return this.location;
	}

	/**
	 * Sets the location.
	 *
	 * @param location the new location
	 */
	public void setLocation(String location) {
		this.location = location;
	}

	/**
	 * Gets the company.
	 *
	 * @return the company
	 */
	public String getCompany() {
		return this.company;
	}

	/**
	 * Sets the company.
	 *
	 * @param company the new company
	 */
	public void setCompany(String company) {
		this.company = company;
	}

	/**
	 * Gets the category.
	 *
	 * @return the category
	 */
	public String getCategory() {
		return this.category;
	}

	/**
	 * Sets the category.
	 *
	 * @param category the new category
	 */
	public void setCategory(String category) {
		this.category = category;
	}

	/**
	 * Gets the sub category.
	 *
	 * @return the sub category
	 */
	public String getSubCategory() {
		return this.subCategory;
	}

	/**
	 * Sets the sub category.
	 *
	 * @param subCategory the new sub category
	 */
	public void setSubCategory(String subCategory) {
		this.subCategory = subCategory;
	}

	/**
	 * Gets the application name.
	 *
	 * @return the application name
	 */
	public String getApplicationName() {
		return this.applicationName;
	}

	/**
	 * Sets the application name.
	 *
	 * @param applicationName the new application name
	 */
	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}

	/**
	 * Gets the impact.
	 *
	 * @return the impact
	 */
	public String getImpact() {
		return this.impact;
	}

	/**
	 * Sets the impact.
	 *
	 * @param impact the new impact
	 */
	public void setImpact(String impact) {
		this.impact = impact;
	}

	/**
	 * Gets the urgency.
	 *
	 * @return the urgency
	 */
	public String getUrgency() {
		return this.urgency;
	}

	/**
	 * Sets the urgency.
	 *
	 * @param urgency the new urgency
	 */
	public void setUrgency(String urgency) {
		this.urgency = urgency;
	}

	/**
	 * Gets the priority.
	 *
	 * @return the priority
	 */
	public String getPriority() {
		return this.priority;
	}

	/**
	 * Sets the priority.
	 *
	 * @param priority the new priority
	 */
	public void setPriority(String priority) {
		this.priority = priority;
	}

	/**
	 * Gets the opened date.
	 *
	 * @return the opened date
	 */
	public Date getOpenedDate() {
		return this.openedDate;
	}

	/**
	 * Sets the opened date.
	 *
	 * @param openedDate the new opened date
	 */
	public void setOpenedDate(String openedDate) {
		try {
			if (StringUtils.hasLength(openedDate))
				this.openedDate = (new SimpleDateFormat(SDF_STRING, Locale.getDefault())).parse(openedDate);
		} catch (ParseException e) {
			log.error(e.getMessage());
		}
	}

	/**
	 * Gets the opened by.
	 *
	 * @return the opened by
	 */
	public String getOpenedBy() {
		return this.openedBy;
	}

	/**
	 * Sets the opened by.
	 *
	 * @param openedBy the new opened by
	 */
	public void setOpenedBy(String openedBy) {
		this.openedBy = openedBy;
	}

	/**
	 * Gets the contact type.
	 *
	 * @return the contact type
	 */
	public String getContactType() {
		return this.contactType;
	}

	/**
	 * Sets the contact type.
	 *
	 * @param contactType the new contact type
	 */
	public void setContactType(String contactType) {
		this.contactType = contactType;
	}

	/**
	 * Gets the state.
	 *
	 * @return the state
	 */
	public String getState() {
		return this.state;
	}

	/**
	 * Sets the state.
	 *
	 * @param state the new state
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * Gets the assignment group.
	 *
	 * @return the assignment group
	 */
	public String getAssignmentGroup() {
		return this.assignmentGroup;
	}

	/**
	 * Sets the assignment group.
	 *
	 * @param assignmentGroup the new assignment group
	 */
	public void setAssignmentGroup(String assignmentGroup) {
		this.assignmentGroup = assignmentGroup;
	}

	/**
	 * Gets the assigned to.
	 *
	 * @return the assigned to
	 */
	public String getAssignedTo() {
		return this.assignedTo;
	}

	/**
	 * Sets the assigned to.
	 *
	 * @param assignedTo the new assigned to
	 */
	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}

	/**
	 * Gets the short description.
	 *
	 * @return the short description
	 */
	public String getShortDescription() {
		return this.shortDescription;
	}

	/**
	 * Sets the short description.
	 *
	 * @param shortDescription the new short description
	 */
	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {
		return this.description;
	}

	/**
	 * Sets the description.
	 *
	 * @param description the new description
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * Gets the resolution note.
	 *
	 * @return the resolution note
	 */
	public String getResolutionNote() {
		return this.resolutionNote;
	}

	/**
	 * Sets the resolution note.
	 *
	 * @param resolutionNote the new resolution note
	 */
	public void setResolutionNote(String resolutionNote) {
		this.resolutionNote = resolutionNote;
	}

	/**
	 * Gets the work notes.
	 *
	 * @return the work notes
	 */
	public List<WorkNoteDTO> getWorkNotes() {
		return this.workNotes;
	}

	/**
	 * Sets the work notes.
	 *
	 * @param workNotes the new work notes
	 */
	public void setWorkNotes(List<WorkNoteDTO> workNotes) {
		this.workNotes = workNotes;
	}

	/**
	 * Gets the closed by.
	 *
	 * @return the closed by
	 */
	public String getClosedBy() {
		return this.closedBy;
	}

	/**
	 * Sets the closed by.
	 *
	 * @param closedBy the new closed by
	 */
	public void setClosedBy(String closedBy) {
		this.closedBy = closedBy;
	}

	/**
	 * Gets the resolution category.
	 *
	 * @return the resolution category
	 */
	public String getResolutionCategory() {
		return this.resolutionCategory;
	}

	/**
	 * Sets the resolution category.
	 *
	 * @param resolutionCategory the new resolution category
	 */
	public void setResolutionCategory(String resolutionCategory) {
		this.resolutionCategory = resolutionCategory;
	}

	/**
	 * Gets the due date.
	 *
	 * @return the due date
	 */
	public Date getDueDate() {
		return this.dueDate;
	}

	/**
	 * Sets the due date.
	 *
	 * @param dueDate the new due date
	 */
	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	/**
	 * Sets the due date.
	 *
	 * @param dueDate the new due date
	 */
	public void setDueDate(String dueDate) {
		try {
			if (StringUtils.hasLength(dueDate))
				this.dueDate = (new SimpleDateFormat(SDF_STRING, Locale.getDefault())).parse(dueDate);
		} catch (ParseException e) {
			log.error(e.getMessage());
		}
	}

	/**
	 * Gets the last modified by.
	 *
	 * @return the last modified by
	 */
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	/**
	 * Sets the last modified by.
	 *
	 * @param lastModifiedBy the new last modified by
	 */
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	/**
	 * Gets the last modified date.
	 *
	 * @return the last modified date
	 */
	public Date getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	/**
	 * Sets the last modified date.
	 *
	 * @param lastModifiedDate the new last modified date
	 */
	public void setLastModifiedDate(String lastModifiedDate) {
		try {
			if (StringUtils.hasLength(lastModifiedDate))
				this.lastModifiedDate = (new SimpleDateFormat(SDF_STRING, Locale.getDefault())).parse(lastModifiedDate);
		} catch (ParseException e) {
			log.error(e.getMessage());
		}
	}

	/**
	 * Gets the resolved at.
	 *
	 * @return the resolved at
	 */
	public Date getResolvedAt() {
		return this.resolvedAt;
	}

	/**
	 * Sets the resolved at.
	 *
	 * @param resolvedAt the new resolved at
	 */
	public void setResolvedAt(String resolvedAt) {
		try {
			if (StringUtils.hasLength(resolvedAt))
				this.resolvedAt = (new SimpleDateFormat(SDF_STRING, Locale.getDefault())).parse(resolvedAt);
		} catch (ParseException e) {
			log.error(e.getMessage());
		}
	}

	/**
	 * Gets the cause code level 1.
	 *
	 * @return the cause code level 1
	 */
	public String getCauseCodeLevel1() {
		return this.causeCodeLevel1;
	}

	/**
	 * Sets the cause code level 1.
	 *
	 * @param causeCodeLevel1 the new cause code level 1
	 */
	public void setCauseCodeLevel1(String causeCodeLevel1) {
		this.causeCodeLevel1 = causeCodeLevel1;
	}

	/**
	 * Gets the cause code level 2.
	 *
	 * @return the cause code level 2
	 */
	public String getCauseCodeLevel2() {
		return this.causeCodeLevel2;
	}

	/**
	 * Sets the cause code level 2.
	 *
	 * @param causeCodeLevel2 the new cause code level 2
	 */
	public void setCauseCodeLevel2(String causeCodeLevel2) {
		this.causeCodeLevel2 = causeCodeLevel2;
	}

	/**
	 * Gets the cause code level 3.
	 *
	 * @return the cause code level 3
	 */
	public String getCauseCodeLevel3() {
		return this.causeCodeLevel3;
	}

	/**
	 * Sets the cause code level 3.
	 *
	 * @param causeCodeLevel3 the new cause code level 3
	 */
	public void setCauseCodeLevel3(String causeCodeLevel3) {
		this.causeCodeLevel3 = causeCodeLevel3;
	}

	/**
	 * Gets the closed at.
	 *
	 * @return the closed at
	 */
	public Date getClosedAt() {
		return this.closedAt;
	}

	/**
	 * Sets the closed at.
	 *
	 * @param closedAt the new closed at
	 */
	public void setClosedAt(String closedAt) {
		try {
			if (StringUtils.hasLength(closedAt))
				this.closedAt = (new SimpleDateFormat(SDF_STRING, Locale.getDefault())).parse(closedAt);
		} catch (ParseException e) {
			log.error(e.getMessage());
		}
	}

	/**
	 * Gets the search string.
	 *
	 * @return the search string
	 */
	public String getSearchString() {
		return this.searchString;
	}

	/**
	 * Sets the search string.
	 *
	 * @param searchString the new search string
	 */
	public void setSearchString(String searchString) {
		this.searchString = searchString;
	}

	/**
	 * @return the causeCodeLevel4
	 */
	public String getCauseCodeLevel4() {
		return causeCodeLevel4;
	}

	/**
	 * @param causeCodeLevel4 the causeCodeLevel4 to set
	 */
	public void setCauseCodeLevel4(String causeCodeLevel4) {
		this.causeCodeLevel4 = causeCodeLevel4;
	}

	/**
	 * @return the causeCodeLevel5
	 */
	public String getCauseCodeLevel5() {
		return causeCodeLevel5;
	}

	/**
	 * @param causeCodeLevel5 the causeCodeLevel5 to set
	 */
	public void setCauseCodeLevel5(String causeCodeLevel5) {
		this.causeCodeLevel5 = causeCodeLevel5;
	}

	/**
	 * @return the causeCode
	 */
	public String getCauseCode() {
		return causeCode;
	}

	/**
	 * @param causeCode the causeCode to set
	 */
	public void setCauseCode(String causeCode) {
		this.causeCode = causeCode;
	}

	/**
	 * 
	 * @return
	 */
	public String getSys_id() {
		return sys_id;
	}

	/**
	 * 
	 * @param sys_id
	 */
	public void setSys_id(String sys_id) {
		this.sys_id = sys_id;
	}

	public String getRelvpercs() {
		return relvpercs;
	}

	public void setRelvpercs(String relvpercs) {
		this.relvpercs = relvpercs;
	}

	public String getUsagepercs() {
		return usagepercs;
	}

	public void setUsagepercs(String usagepercs) {
		this.usagepercs = usagepercs;
	}

	public List<String> getTicketids() {
		return ticketids;
	}

	public void setTicketids(List<String> ticketids) {
		this.ticketids = ticketids;
	}

	@Override
	public String toString() {
		return "TicketDataDTO [number=" + number + ", callerId=" + callerId + ", serviceType=" + serviceType
				+ ", location=" + location + ", company=" + company + ", category=" + category + ", subCategory="
				+ subCategory + ", applicationName=" + applicationName + ", impact=" + impact + ", urgency=" + urgency
				+ ", priority=" + priority + ", openedDate=" + openedDate + ", openedBy=" + openedBy + ", contactType="
				+ contactType + ", state=" + state + ", assignmentGroup=" + assignmentGroup + ", assignedTo="
				+ assignedTo + ", shortDescription=" + shortDescription + ", description=" + description
				+ ", resolutionNote=" + resolutionNote + ", workNotes=" + workNotes + ", closedBy=" + closedBy
				+ ", resolutionCategory=" + resolutionCategory + ", dueDate=" + dueDate + ", lastModifiedBy="
				+ lastModifiedBy + ", lastModifiedDate=" + lastModifiedDate + ", resolvedAt=" + resolvedAt
				+ ", causeCodeLevel1=" + causeCodeLevel1 + ", causeCodeLevel2=" + causeCodeLevel2 + ", causeCodeLevel3="
				+ causeCodeLevel3 + ", causeCodeLevel4=" + causeCodeLevel4 + ", causeCodeLevel5=" + causeCodeLevel5
				+ ", causeCode=" + causeCode + ", closedAt=" + closedAt + ", searchString=" + searchString + ", koid="
				+ koid + ", sys_id=" + sys_id + ", relvpercs=" + relvpercs + ", usagepercs=" + usagepercs
				+ ", ticketids=" + ticketids + "]";
	}

}
