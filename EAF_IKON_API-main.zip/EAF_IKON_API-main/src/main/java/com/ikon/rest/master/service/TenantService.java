package com.ikon.rest.master.service;

import javax.sql.DataSource;

import com.ikon.rest.datasourceconfig.tenants.MultiRoutingDataSource;
import com.ikon.rest.master.entity.Tenant;
import com.ikon.rest.master.entity.TenantAccountMapping;

public interface TenantService {

	MultiRoutingDataSource loadAllTenants(DataSource commonDataSource);

	void addTenantToInMemoryCollectionsIfMissing(Tenant tenant);

	void deleteTenantFromInMemoryCollections(String key);

	TenantAccountMapping fetchAccountIdByTenantId(String tenantId);

	boolean validateTenant(TenantAccountMapping tenantAccountMapping);

	void rescanAndValidateTenants();

}
