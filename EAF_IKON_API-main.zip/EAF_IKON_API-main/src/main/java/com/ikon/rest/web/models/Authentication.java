package com.ikon.rest.web.models;

public class Authentication {

	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

}
