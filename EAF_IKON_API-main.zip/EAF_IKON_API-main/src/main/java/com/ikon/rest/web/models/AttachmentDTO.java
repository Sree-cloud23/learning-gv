package com.ikon.rest.web.models;

// TODO: Auto-generated Javadoc
/**
 * The Class AttachmentDTO.
 */
public class AttachmentDTO {
	
	/** The attach name. */
	private String attachName;
	
	/** The attach ID. */
	private String attachID;
	
	/** The attach type. */
	private String attachType;

	

	/**
	 * Instantiates a new attachment DTO.
	 *
	 * @param attachName the attach name
	 * @param attachID the attach ID
	 * @param attachType the attach type
	 */
	public AttachmentDTO(String attachName, String attachID, String attachType) {
		super();
		this.attachName = attachName;
		this.attachID = attachID;
		this.attachType = attachType;
	}



	/**
	 * To string.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return "AttachmentDTO [attachName=" + attachName + ", attachID=" + attachID + ", attachType=" + attachType
				+ "]";
	}



	/**
	 * Gets the attach name.
	 *
	 * @return the attach name
	 */
	public String getAttachName() {
		return attachName;
	}



	/**
	 * Sets the attach name.
	 *
	 * @param attachName the new attach name
	 */
	public void setAttachName(String attachName) {
		this.attachName = attachName;
	}



	/**
	 * Gets the attach ID.
	 *
	 * @return the attach ID
	 */
	public String getAttachID() {
		return attachID;
	}



	/**
	 * Sets the attach ID.
	 *
	 * @param attachID the new attach ID
	 */
	public void setAttachID(String attachID) {
		this.attachID = attachID;
	}



	/**
	 * Gets the attach type.
	 *
	 * @return the attach type
	 */
	public String getAttachType() {
		return attachType;
	}



	/**
	 * Sets the attach type.
	 *
	 * @param attachType the new attach type
	 */
	public void setAttachType(String attachType) {
		this.attachType = attachType;
	}



	/**
	 * Instantiates a new attachment DTO.
	 */
	public AttachmentDTO() {
		super();
	}
	
	
	
	

}
