package com.ikon.rest.web.models.dashboard;

public class ReportChartDetailsDTO {
	
	/** The reportChartType */
	private Integer reportChartType;
	
	
	/** The reportChartTypeName */
	private String reportChartTypeName;
	
	/** The reportChartId */
	private Integer reportChartId;
	
	/** The reportChartName */
	private String reportChartName;
	


	/**
	 * 
	 * @return
	 */
	public Integer getReportChartType() {
		return reportChartType;
	}


	/**
	 * 
	 * @param reportChartType
	 */
	public void setReportChartType(Integer reportChartType) {
		this.reportChartType = reportChartType;
	}


	/**
	 * 
	 * @return
	 */
	public String getReportChartTypeName() {
		return reportChartTypeName;
	}


	/**
	 * 
	 * @param reportChartTypeName
	 */
	public void setReportChartTypeName(String reportChartTypeName) {
		this.reportChartTypeName = reportChartTypeName;
	}


	public Integer getReportChartId() {
		return reportChartId;
	}


	public void setReportChartId(Integer reportChartId) {
		this.reportChartId = reportChartId;
	}


	public String getReportChartName() {
		return reportChartName;
	}


	public void setReportChartName(String reportChartName) {
		this.reportChartName = reportChartName;
	}
	
	
	

}
