package com.ikon.rest.datasourceconfig.master;

import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.ikon.rest.datasourceconfig.beans.database.MasterDatabaseProperties;
import com.ikon.rest.datasourceconfig.utility.ConnectionUtility;

import lombok.extern.slf4j.Slf4j;

/**
 * The Configuration Class for Common Database
 */
@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(basePackages = "com.ikon.rest.master",
        entityManagerFactoryRef = "commonEntityManager",
        transactionManagerRef = "commonTransactionManager")
@Slf4j
public class MasterDataSourceConfig {

	

    /**
     * The Package Scan Field
     */
    private static final String PACKAGE_SCAN = "com.ikon.rest.master";

    @Autowired
    private MasterDatabaseProperties masterDatabaseProperties;

    @Autowired
    private ConnectionUtility connectionUtility;

    /**
     * Creates a Data Source for a giving input tenant
     *
     * @return
     */
    @Bean(name = "commonDataSource")
    public DataSource commonDataSource() {
        return connectionUtility.createDataSource(masterDatabaseProperties.getConfig());
    }

    /**
     * @return LocalContainerEntityManagerFactoryBean
     */
    @Bean(name = "commonEntityManager")
    public LocalContainerEntityManagerFactoryBean commonEntityManager() {
        LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource(commonDataSource());
        em.setPackagesToScan(PACKAGE_SCAN);
        HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
        em.setJpaVendorAdapter(vendorAdapter);
        em.setJpaProperties(hibernateProperties());
        return em;
    }

    /**
     * @return PlatformTransactionManager
     */
    @Bean(name = "commonTransactionManager")
    public PlatformTransactionManager commonTransactionManager() {
        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(commonEntityManager().getObject());
        return transactionManager;
    }

    /**
     * @return LocalSessionFactoryBean
     */
    @Bean(name = "dbSessionFactory")
    public LocalSessionFactoryBean dbSessionFactory() {
        LocalSessionFactoryBean sessionFactoryBean = new LocalSessionFactoryBean();
        sessionFactoryBean.setDataSource(commonDataSource());
        sessionFactoryBean.setPackagesToScan(PACKAGE_SCAN);
        sessionFactoryBean.setHibernateProperties(hibernateProperties());
        return sessionFactoryBean;
    }

    /**
     * @return Hibernate Properties
     */
    private Properties hibernateProperties() {
        Properties properties = new Properties();
        properties.put("hibernate.show_sql", true);
        properties.put("hibernate.format_sql", true);
        return properties;
    }
}
