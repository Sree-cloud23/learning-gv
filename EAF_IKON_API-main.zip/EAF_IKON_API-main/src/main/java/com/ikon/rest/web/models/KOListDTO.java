package com.ikon.rest.web.models;

/**
 * The Class KOListDTO.
 *
 */
public class KOListDTO {
	/** The solutionnumber. */
	private String solutionnumber;
	
	/** The description. */
    private String description;
    
    /** The application name. */
	private String applicationName;
	
	/** The assignment group. */
	private String assignmentGroup;
	
	/**
	 * @return the solutionnumber
	 */
	public String getSolutionnumber() {
		return solutionnumber;
	}

	/**
	 * @param solutionnumber the solutionnumber to set
	 */
	public void setSolutionnumber(String solutionnumber) {
		this.solutionnumber = solutionnumber;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the applicationName
	 */
	public String getApplicationName() {
		return applicationName;
	}

	/**
	 * @param applicationName the applicationName to set
	 */
	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}

	/**
	 * @return the assignmentGroup
	 */
	public String getAssignmentGroup() {
		return assignmentGroup;
	}

	/**
	 * @param assignmentGroup the assignmentGroup to set
	 */
	public void setAssignmentGroup(String assignmentGroup) {
		this.assignmentGroup = assignmentGroup;
	}

	/**
	 * @return the pubStatus
	 */
	public String getPubStatus() {
		return pubStatus;
	}

	/**
	 * @param pubStatus the pubStatus to set
	 */
	public void setPubStatus(String pubStatus) {
		this.pubStatus = pubStatus;
	}


	/** The pub status. */
	private String pubStatus;
	

}
