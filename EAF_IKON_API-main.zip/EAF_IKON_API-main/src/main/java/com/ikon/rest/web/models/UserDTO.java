package com.ikon.rest.web.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * The Class UserDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserDTO {
	
	/** The name. */
	@JsonProperty(value = "Name")
	private String name;
	
	/** The user id. */
	@JsonProperty(value = "Crophandle")
	private String userId;
	
	/** The email. */
	@JsonProperty(value = "Emailid")
	private String email;
	
	/** The assignment group. */
	@JsonProperty(value = "AssignmentGroup")
	private String assignmentGroup;
	
	/** The assignment group id. */
	@JsonProperty(value = "AssignmentGroupID")
	private String assignmentGroupId;
	
	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * Gets the user id.
	 *
	 * @return the user id
	 */
	public String getUserId() {
		return userId;
	}
	
	/**
	 * Sets the user id.
	 *
	 * @param userId the new user id
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	/**
	 * Gets the email.
	 *
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}
	
	/**
	 * Sets the email.
	 *
	 * @param email the new email
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	
	/**
	 * Gets the assignment group.
	 *
	 * @return the assignment group
	 */
	public String getAssignmentGroup() {
		return assignmentGroup;
	}
	
	/**
	 * Sets the assignment group.
	 *
	 * @param assignmentGroup the new assignment group
	 */
	public void setAssignmentGroup(String assignmentGroup) {
		this.assignmentGroup = assignmentGroup;
	}
	
	/**
	 * Gets the assignment group id.
	 *
	 * @return the assignment group id
	 */
	public String getAssignmentGroupId() {
		return assignmentGroupId;
	}
	
	/**
	 * Sets the assignment group id.
	 *
	 * @param assignmentGroupId the new assignment group id
	 */
	public void setAssignmentGroupId(String assignmentGroupId) {
		this.assignmentGroupId = assignmentGroupId;
	}
}
