package com.ikon.rest.web;

import java.text.SimpleDateFormat;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.ikon.rest.security.constants.RequestConstants;
import com.ikon.rest.security.service.RequestValidationService;
import com.ikon.rest.service.DashboardService;
import com.ikon.rest.web.models.ErrorResponseDTO;
import com.ikon.rest.web.models.KOInfoDTO;
import com.ikon.rest.web.models.dashboard.AgeingWorkinfoDTO;
import com.ikon.rest.web.models.dashboard.ComplianceDTO;
import com.ikon.rest.web.models.dashboard.IncMissingKODTO;
import com.ikon.rest.web.models.dashboard.KOUsageChartDTO;
import com.ikon.rest.web.models.dashboard.KOUsageReportDTO;
import com.ikon.rest.web.models.dashboard.MttrDTO;
import com.ikon.rest.web.models.dashboard.ReportChartDTO;
import com.ikon.rest.web.models.dashboard.RunToZeroDTO;

import lombok.extern.slf4j.Slf4j;

/**
 * The Class DashboardControllerRest.
 */
@RestController
@CrossOrigin
@Slf4j
public class DashboardControllerRest {

	/** The Constant ACCOUNT_ID. */
	private static final String ACCOUNT_ID = "1"; // Account_ID = 1 for CIAP

	/** The Constant log. */
	//private static final log log = LogManager.getlog(KOControllerRest.class);

	/** The Constant ACCESS_CONTROL_ALLOW_ORIGIN. */
	private static final String ACCESS_CONTROL_ALLOW_ORIGIN = "Access-Control-Allow-Origin";

	/** The Constant ACCESS_CONTROL_ALLOW_CREDENTIALS. */
	private static final String ACCESS_CONTROL_ALLOW_CREDENTIALS = "Access-Control-Allow-Credentials";

	/** The Constant TRUE. */
	private static final String TRUE = "true";

	/** The reportChartService */
	@Autowired
	private DashboardService dashboardService;

	/**
	 * The Validation Service.
	 */
	@Autowired
	private RequestValidationService requestValidationServiceService;

	/**
	 * 
	 * @param fromDate
	 * @param toDate
	 * @param assignmentGroup
	 * @param applicationName
	 * @param response
	 * @return
	 */
	@GetMapping(value = "/api/koUsageReport")
	@JsonIgnoreProperties(ignoreUnknown = true)
	public ResponseEntity<?> koUsageReport(@RequestParam("fromDate") String fromDate,
			@RequestParam("toDate") String toDate, @RequestParam("assignmentGroup") String assignmentGroup,
			@RequestParam("applicationName") String applicationName,
			@RequestHeader(name = RequestConstants.TENANT_ID) final String encryptedTenantId,
			HttpServletResponse response) {

		// Setting Tenant & MDC Context
		requestValidationServiceService.decryptAndValidateTenantId(encryptedTenantId);

		log.info("START:KO Usage Report");
		response.setHeader(ACCESS_CONTROL_ALLOW_ORIGIN, "*");
		response.setHeader(ACCESS_CONTROL_ALLOW_CREDENTIALS, TRUE);
		ErrorResponseDTO apiResponse = new ErrorResponseDTO();
		List<KOUsageReportDTO> koUsageList = new LinkedList<>();
		try {
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
			ReportChartDTO reportChartDTO = new ReportChartDTO();
			reportChartDTO.setFromDate(fromDate);
			reportChartDTO.setToDate(toDate);
			reportChartDTO.setApplicationName(applicationName);
			reportChartDTO.setAssignmentGroup(assignmentGroup);

			List<KOInfoDTO> koInfoList = dashboardService.getKOUsageReport(ACCOUNT_ID, reportChartDTO);

			koInfoList.forEach(infoList -> {
				KOUsageReportDTO koUsageDTO = new KOUsageReportDTO();
				koUsageDTO.setSolutionnumber(infoList.getKoID());
				koUsageDTO.setAssignmentGroup(infoList.getAssignmentGroup());
				koUsageDTO.setApplicationName(infoList.getApplicationName());
				koUsageDTO.setKoCount(infoList.getKoCount());
				koUsageDTO.setMaxLastlinkedDate(simpleDateFormat.format(infoList.getMax_Date()));
//			 koUsageDTO.setMaxLastlinkedDate(infoList.getMax_Date().toString());
				koUsageList.add(koUsageDTO);
			});
			log.info("END:KO Usage Report");
			return new ResponseEntity<>(koUsageList, HttpStatus.OK);
		} catch (Exception ex) {
			log.error(ex.getMessage());
			apiResponse.setError(true);
			apiResponse.setMessage("koUsageReport_001");
			return new ResponseEntity<>(apiResponse, HttpStatus.UNPROCESSABLE_ENTITY);
		}

	}

	/**
	 * Ko usage chart.
	 *
	 * @param fromDate        the from date
	 * @param toDate          the to date
	 * @param assignmentGroup the assignment group
	 * @param applicationName the application name
	 * @param response        the response
	 * @return the response entity
	 */
	@GetMapping(value = "/api/koUsageChart")
	public ResponseEntity<?> koUsageChart(@RequestParam("fromDate") String fromDate,
			@RequestParam("toDate") String toDate, @RequestParam("assignmentGroup") String assignmentGroup,
			@RequestParam("applicationName") String applicationName,
			@RequestHeader(name = RequestConstants.TENANT_ID) final String encryptedTenantId,
			HttpServletResponse response) {

		// Setting Tenant & MDC Context
		requestValidationServiceService.decryptAndValidateTenantId(encryptedTenantId);

		log.info("START:KO Usage Chart");
		response.setHeader(ACCESS_CONTROL_ALLOW_ORIGIN, "*");
		response.setHeader(ACCESS_CONTROL_ALLOW_CREDENTIALS, TRUE);
		ErrorResponseDTO apiResponse = new ErrorResponseDTO();
		try {
			ReportChartDTO reportChartDTO = new ReportChartDTO();
			reportChartDTO.setFromDate(fromDate);
			reportChartDTO.setToDate(toDate);
			reportChartDTO.setApplicationName(applicationName);
			reportChartDTO.setAssignmentGroup(assignmentGroup);

			List<KOUsageChartDTO> koInfoList = dashboardService.getKOUsageChart(ACCOUNT_ID, reportChartDTO);

			log.info("END:KO Usage Chart");
			return new ResponseEntity<>(koInfoList, HttpStatus.OK);
		} catch (Exception ex) {
			log.error(ex.getMessage());
			apiResponse.setError(true);
			apiResponse.setMessage("koUsageChart_001");
			return new ResponseEntity<>(apiResponse, HttpStatus.UNPROCESSABLE_ENTITY);
		}
	}

	/**
	 * 
	 * @param assigneeName
	 * @param fromDate
	 * @param toDate
	 * @param assignmentGroup
	 * @param applicationName
	 * @param response
	 * @return
	 */
	@GetMapping(value = "/api/runToZeroReport")
	public ResponseEntity<?> runToZeroReport(@RequestParam("fromDate") String fromDate,
			@RequestParam("toDate") String toDate, @RequestParam("assignmentGroup") String assignmentGroup,
			@RequestParam("applicationName") String applicationName, @RequestParam("assigneeName") String assigneeName,
			@RequestHeader(name = RequestConstants.TENANT_ID) final String encryptedTenantId,
			HttpServletResponse response) {
		log.info("START:Run To Zero Report");

		// Setting Tenant & MDC Context
		requestValidationServiceService.decryptAndValidateTenantId(encryptedTenantId);

		response.setHeader(ACCESS_CONTROL_ALLOW_ORIGIN, "*");
		response.setHeader(ACCESS_CONTROL_ALLOW_CREDENTIALS, TRUE);
		ErrorResponseDTO apiResponse = new ErrorResponseDTO();
		try {
			ReportChartDTO reportChartDTO = new ReportChartDTO();
			reportChartDTO.setAssigneeName(assigneeName);
			reportChartDTO.setFromDate(fromDate);
			reportChartDTO.setToDate(toDate);
			reportChartDTO.setApplicationName(applicationName);
			reportChartDTO.setAssignmentGroup(assignmentGroup);

			List<RunToZeroDTO> runToZeroList = dashboardService.getRunToZeroReport(ACCOUNT_ID, reportChartDTO);
			log.info("START:Run To Zero Report");
			return new ResponseEntity<>(runToZeroList, HttpStatus.OK);
		} catch (Exception ex) {
			log.error(ex.getMessage());
			apiResponse.setError(true);
			apiResponse.setMessage("runToZeroReport_001");
			return new ResponseEntity<>(apiResponse, HttpStatus.UNPROCESSABLE_ENTITY);
		}
	}

	/**
	 * Compliance report.
	 *
	 * @param fromDate        the from date
	 * @param toDate          the to date
	 * @param assignmentGroup the assignment group
	 * @param applicationName the application name
	 * @param response        the response
	 * @return the response entity
	 */
	@GetMapping("/api/complianceReport")
	@JsonIgnoreProperties(ignoreUnknown = true)
	public ResponseEntity<Object> complianceReport(@RequestParam("fromDate") String fromDate,
			@RequestParam("toDate") String toDate, @RequestParam("assignmentGroup") String assignmentGroup,
			@RequestParam("applicationName") String applicationName, @RequestHeader(name = RequestConstants.TENANT_ID) final String encryptedTenantId,HttpServletResponse response) {
		log.info("Starts: CIAP Compliance Report");

		// Setting Tenant & MDC Context
		requestValidationServiceService.decryptAndValidateTenantId(encryptedTenantId);

		ErrorResponseDTO apiResponse = new ErrorResponseDTO();
		try {

			List<ComplianceDTO> complianceReportList = dashboardService.getComplianceReport(fromDate, toDate,
					assignmentGroup, applicationName);
			log.info("End: CIAP Compliance Report");

			return new ResponseEntity<>(complianceReportList, HttpStatus.OK);
		} catch (Exception ex) {
			log.error(ex.getMessage());
			apiResponse.setError(true);
			apiResponse.setMessage("complianceReport_001");
			return new ResponseEntity<>(apiResponse, HttpStatus.UNPROCESSABLE_ENTITY);
		}
	}

	/**
	 * Inc missing ko report.
	 *
	 * @param fromDate        the from date
	 * @param toDate          the to date
	 * @param assignmentGroup the assignment group
	 * @param applicationName the application name
	 * @param response        the response
	 * @return the response entity
	 */
	@GetMapping("/api/incMissingKoReport")
	@JsonIgnoreProperties(ignoreUnknown = true)
	public ResponseEntity<Object> incMissingKoReport(@RequestParam("fromDate") String fromDate,
			@RequestParam("toDate") String toDate, @RequestParam("assignmentGroup") String assignmentGroup,
			@RequestParam("applicationName") String applicationName,
			@RequestHeader(name = RequestConstants.TENANT_ID) final String encryptedTenantId,
			HttpServletResponse response) {
		log.info("Starts: CIAP incMissingKo Report");

		// Setting Tenant & MDC Context
		requestValidationServiceService.decryptAndValidateTenantId(encryptedTenantId);

		ErrorResponseDTO apiResponse = new ErrorResponseDTO();
		try {

			List<IncMissingKODTO> incMissingKOReportList = dashboardService.getIncMissingKoReport(fromDate, toDate,
					assignmentGroup, applicationName);
			log.info("End: CIAP incMissingKo Report");

			return new ResponseEntity<>(incMissingKOReportList, HttpStatus.OK);
		} catch (Exception ex) {
			log.error(ex.getMessage());
			apiResponse.setError(true);
			apiResponse.setMessage("incMissingKoReport_001");
			return new ResponseEntity<>(apiResponse, HttpStatus.UNPROCESSABLE_ENTITY);
		}
	}

	/**
	 * Inc missing ko chart.
	 *
	 * @param fromDate        the from date
	 * @param toDate          the to date
	 * @param assignmentGroup the assignment group
	 * @param applicationName the application name
	 * @param response        the response
	 * @return the response entity
	 */
	@GetMapping("/api/incMissingKoChart")
	@JsonIgnoreProperties(ignoreUnknown = true)
	public ResponseEntity<Object> incMissingKoChart(@RequestParam("fromDate") String fromDate,
			@RequestParam("toDate") String toDate, @RequestParam("assignmentGroup") String assignmentGroup,
			@RequestParam("applicationName") String applicationName,
			@RequestHeader(name = RequestConstants.TENANT_ID) final String encryptedTenantId,
			HttpServletResponse response) {
		log.info("Starts: CIAP incMissingKoChart Report");

		// Setting Tenant & MDC Context
		requestValidationServiceService.decryptAndValidateTenantId(encryptedTenantId);

		ErrorResponseDTO apiResponse = new ErrorResponseDTO();
		try {

			List<IncMissingKODTO> incMissingKOChartList = dashboardService.getIncMissingKoChart(fromDate, toDate,
					assignmentGroup, applicationName);
			log.info("End: CIAP incMissingKoChart Report");

			return new ResponseEntity<>(incMissingKOChartList, HttpStatus.OK);
		} catch (Exception ex) {
			log.error(ex.getMessage());
			apiResponse.setError(true);
			apiResponse.setMessage("incMissingKoChart_001");
			return new ResponseEntity<>(apiResponse, HttpStatus.UNPROCESSABLE_ENTITY);
		}
	}

	/**
	 * Mttr report.
	 *
	 * @param fromDate        the from date
	 * @param toDate          the to date
	 * @param assignmentGroup the assignment group
	 * @param applicationName the application name
	 * @param response        the response
	 * @return the response entity
	 */
	@GetMapping("/api/mttrReport")
	@JsonIgnoreProperties(ignoreUnknown = true)
	public ResponseEntity<Object> mttrReport(@RequestParam("fromDate") String fromDate,
			@RequestParam("toDate") String toDate, @RequestParam("assignmentGroup") String assignmentGroup,
			@RequestParam("applicationName") String applicationName,
			@RequestHeader(name = RequestConstants.TENANT_ID) final String encryptedTenantId,
			HttpServletResponse response) {
		log.info("Starts: CIAP mttrReport Report");

		// Setting Tenant & MDC Context
		requestValidationServiceService.decryptAndValidateTenantId(encryptedTenantId);

		ErrorResponseDTO apiResponse = new ErrorResponseDTO();
		try {

			List<MttrDTO> mttrReportList = dashboardService.getMttrReport(fromDate, toDate, assignmentGroup,
					applicationName);
			log.info("End: CIAP mttrReport Report");

			return new ResponseEntity<>(mttrReportList, HttpStatus.OK);
		} catch (Exception ex) {
			log.error(ex.getMessage());
			apiResponse.setError(true);
			apiResponse.setMessage("mttrReport_001");
			return new ResponseEntity<>(apiResponse, HttpStatus.UNPROCESSABLE_ENTITY);
		}
	}

	/**
	 * Mttr chart.
	 *
	 * @param fromDate        the from date
	 * @param toDate          the to date
	 * @param assignmentGroup the assignment group
	 * @param applicationName the application name
	 * @param response        the response
	 * @return the response entity
	 */
	@GetMapping("/api/mttrChart")
	@JsonIgnoreProperties(ignoreUnknown = true)
	public ResponseEntity<Object> mttrChart(@RequestParam("fromDate") String fromDate,
			@RequestParam("toDate") String toDate, @RequestParam("assignmentGroup") String assignmentGroup,
			@RequestParam("applicationName") String applicationName,
			@RequestHeader(name = RequestConstants.TENANT_ID) final String encryptedTenantId,
			HttpServletResponse response) {
		log.info("Starts: CIAP mttrChart Report");

		// Setting Tenant & MDC Context
		requestValidationServiceService.decryptAndValidateTenantId(encryptedTenantId);

		ErrorResponseDTO apiResponse = new ErrorResponseDTO();
		try {

			List<MttrDTO> mttrChartList = dashboardService.getMttrChart(fromDate, toDate, assignmentGroup,
					applicationName);
			log.info("End: CIAP mttrChart Report");

			return new ResponseEntity<>(mttrChartList, HttpStatus.OK);
		} catch (Exception ex) {
			log.error(ex.getMessage());
			apiResponse.setError(true);
			apiResponse.setMessage("mttrChart_001");
			return new ResponseEntity<>(apiResponse, HttpStatus.UNPROCESSABLE_ENTITY);
		}
	}

	/**
	 * Ageing workinfo report.
	 *
	 * @param fromDate        the from date
	 * @param toDate          the to date
	 * @param assignmentGroup the assignment group
	 * @param applicationName the application name
	 * @param response        the response
	 * @return the response entity
	 */
	@GetMapping("/api/ageingWorkinfoReport")
	@JsonIgnoreProperties(ignoreUnknown = true)
	public ResponseEntity<Object> ageingWorkinfoReport(@RequestParam("fromDate") String fromDate,
			@RequestParam("toDate") String toDate, @RequestParam("assignmentGroup") String assignmentGroup,
			@RequestParam("applicationName") String applicationName,
			@RequestHeader(name = RequestConstants.TENANT_ID) final String encryptedTenantId,
			HttpServletResponse response) {
		log.info("Starts: CIAP Ageing Workinfo Report");

		// Setting Tenant & MDC Context
		requestValidationServiceService.decryptAndValidateTenantId(encryptedTenantId);

		ErrorResponseDTO apiResponse = new ErrorResponseDTO();
		try {

			List<AgeingWorkinfoDTO> ageingWorkinfoReportList = dashboardService.getAgeingWorkinfoReport(fromDate,
					toDate, assignmentGroup, applicationName);

			log.info("End: CIAP Ageing Workinfo Report");
			return new ResponseEntity<>(ageingWorkinfoReportList, HttpStatus.OK);
		} catch (Exception ex) {
			log.error(ex.getMessage());
			apiResponse.setError(true);
			apiResponse.setMessage("ageingWorkinfoReport_001");
			return new ResponseEntity<>(apiResponse, HttpStatus.UNPROCESSABLE_ENTITY);
		}
	}

	/**
	 * Mttr priority report.
	 *
	 * @param fromDate        the from date
	 * @param toDate          the to date
	 * @param assignmentGroup the assignment group
	 * @param applicationName the application name
	 * @param response        the response
	 * @return the response entity
	 */
	@GetMapping("/api/mttrPriorityReport")
	@JsonIgnoreProperties(ignoreUnknown = true)
	public ResponseEntity<Object> mttrPriorityReport(@RequestParam("fromDate") String fromDate,
			@RequestParam("toDate") String toDate, @RequestParam("assignmentGroup") String assignmentGroup,
			@RequestParam("applicationName") String applicationName,
			@RequestHeader(name = RequestConstants.TENANT_ID) final String encryptedTenantId,
			HttpServletResponse response) {
		log.info("Starts: CIAP mttrPriorityReport Report");

		// Setting Tenant & MDC Context
		requestValidationServiceService.decryptAndValidateTenantId(encryptedTenantId);

		ErrorResponseDTO apiResponse = new ErrorResponseDTO();
		try {

			List<MttrDTO> mttrReportList = dashboardService.getMttrPriorityReport(fromDate, toDate, assignmentGroup,
					applicationName);
			log.info("End: CIAP mttrPriorityReport Report");

			return new ResponseEntity<>(mttrReportList, HttpStatus.OK);
		} catch (Exception ex) {
			log.error(ex.getMessage());
			apiResponse.setError(true);
			apiResponse.setMessage("mttrPriorityReport_001");
			return new ResponseEntity<>(apiResponse, HttpStatus.UNPROCESSABLE_ENTITY);
		}
	}

	/**
	 * Ageing workinfo report detail.
	 *
	 * @param fromDate        the from date
	 * @param toDate          the to date
	 * @param assignmentGroup the assignment group
	 * @param applicationName the application name
	 * @param response        the response
	 * @return the response entity
	 */
	@GetMapping("/api/ageingWorkinfoReportDetail")
	@JsonIgnoreProperties(ignoreUnknown = true)
	public ResponseEntity<Object> ageingWorkinfoReportDetail(@RequestParam("fromDate") String fromDate,
			@RequestParam("toDate") String toDate, @RequestParam("assignmentGroup") String assignmentGroup,
			@RequestParam("applicationName") String applicationName,
			@RequestHeader(name = RequestConstants.TENANT_ID) final String encryptedTenantId,
			HttpServletResponse response) {
		log.info("Starts: CIAP Ageing Workinfo Report");

		// Setting Tenant & MDC Context
		requestValidationServiceService.decryptAndValidateTenantId(encryptedTenantId);

		ErrorResponseDTO apiResponse = new ErrorResponseDTO();
		try {

			List<AgeingWorkinfoDTO> ageingWorkinfoReportList = dashboardService.getAgeingWorkinfoReportDetail(fromDate,
					toDate, assignmentGroup, applicationName);

			log.info("End: CIAP Ageing Workinfo Report");
			return new ResponseEntity<>(ageingWorkinfoReportList, HttpStatus.OK);
		} catch (Exception ex) {
			log.error(ex.getMessage());
			apiResponse.setError(true);
			apiResponse.setMessage("ageingWorkinfoReportDetail_001");
			return new ResponseEntity<>(apiResponse, HttpStatus.UNPROCESSABLE_ENTITY);
		}
	}

}
