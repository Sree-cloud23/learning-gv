package com.ikon.dto;

import java.util.Date;

/**
 * The Class ReportBean.
 *
 * @author Capgemini
 */
public class ReportBean {
	

    /** The favourite ID. */
    private String favouriteID;
    
    /** The account ID. */
    private Object accountID;
    
    /** The user ID. */
    private String userID;
    
    /** The report chart ID. */
    private int reportChartID;
    
    /** The favourite. */
    private String favourite;
    
    /** The created date. */
    private Date createdDate;
    
    /** The created by. */
    private String createdBy;
    
    /** The modified date. */
    private Date modifiedDate;
    
    /** The modified by. */
    private String modifiedBy;
    
    /** The report chart type. */
    private String reportChartType;
    
    /** The report chart type name. */
    private String reportChartTypeName;
    
    /** The usage count. */
    private Object usageCount;
    
    /** The recommended priority. */
    private Object recommendedPriority;
    
    /** The last used report date. */
    private Date lastUsedReportDate;
    
    /** The component type ID. */
    private Object componentTypeID;

	/**
	 * Gets the favourite ID.
	 *
	 * @return the favouriteID
	 */
	public String getFavouriteID() {
		return favouriteID;
	}

	/**
	 * Sets the favourite ID.
	 *
	 * @param favouriteID the favouriteID to set
	 */
	public void setFavouriteID(String favouriteID) {
		this.favouriteID = favouriteID;
	}

	/**
	 * Gets the account ID.
	 *
	 * @return the accountID
	 */
	public String getAccountID() {
		if(accountID != null){
		return String.valueOf(accountID);
		}
		return "0";
	}

	/**
	 * Sets the account ID.
	 *
	 * @param accountID the accountID to set
	 */
	public void setAccountID(Object accountID) {
		this.accountID = accountID;
	}

	/**
	 * Gets the user ID.
	 *
	 * @return the userID
	 */
	public String getUserID() {
		return userID;
	}

	/**
	 * Sets the user ID.
	 *
	 * @param userID the userID to set
	 */
	public void setUserID(String userID) {
		this.userID = userID;
	}

	/**
	 * Gets the report chart ID.
	 *
	 * @return the reportChartID
	 */
	public int getReportChartID() {
		return reportChartID;
	}

	/**
	 * Sets the report chart ID.
	 *
	 * @param reportChartID the reportChartID to set
	 */
	public void setReportChartID(int reportChartID) {
		this.reportChartID = reportChartID;
	}

	/**
	 * Gets the favourite.
	 *
	 * @return the favourite
	 */
	public String getFavourite() {
		return favourite;
	}

	/**
	 * Sets the favourite.
	 *
	 * @param favourite the favourite to set
	 */
	public void setFavourite(String favourite) {
		this.favourite = favourite;
	}

	/**
	 * Gets the created date.
	 *
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * Sets the created date.
	 *
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * Gets the created by.
	 *
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * Sets the created by.
	 *
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * Gets the modified date.
	 *
	 * @return the modifiedDate
	 */
	public Date getModifiedDate() {
		return modifiedDate;
	}

	/**
	 * Sets the modified date.
	 *
	 * @param modifiedDate the modifiedDate to set
	 */
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	/**
	 * Gets the modified by.
	 *
	 * @return the modifiedBy
	 */
	public String getModifiedBy() {
		return modifiedBy;
	}

	/**
	 * Sets the modified by.
	 *
	 * @param modifiedBy the modifiedBy to set
	 */
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	/**
	 * Gets the report chart type.
	 *
	 * @return the reportChartType
	 */
	public String getReportChartType() {
		return reportChartType;
	}

	/**
	 * Sets the report chart type.
	 *
	 * @param reportChartType the reportChartType to set
	 */
	public void setReportChartType(String reportChartType) {
		this.reportChartType = reportChartType;
	}

	/**
	 * Gets the report chart type name.
	 *
	 * @return the reportChartTypeName
	 */
	public String getReportChartTypeName() {
		return reportChartTypeName;
	}

	/**
	 * Sets the report chart type name.
	 *
	 * @param reportChartTypeName the reportChartTypeName to set
	 */
	public void setReportChartTypeName(String reportChartTypeName) {
		this.reportChartTypeName = reportChartTypeName;
	}

	/**
	 * Gets the usage count.
	 *
	 * @return the usageCount
	 */
	public String getUsageCount() {
		if(usageCount != null){
			return String.valueOf(usageCount);
		}
		return "";
	}

	/**
	 * Sets the usage count.
	 *
	 * @param usageCount the usageCount to set
	 */
	public void setUsageCount(Object usageCount) {
		this.usageCount = usageCount;
	}

	/**
	 * Gets the recommended priority.
	 *
	 * @return the recommendedPriority
	 */
	public String getRecommendedPriority() {
		if(recommendedPriority != null){
			return String.valueOf(recommendedPriority);
		}
		return "";
	}

	/**
	 * Sets the recommended priority.
	 *
	 * @param recommendedPriority the recommendedPriority to set
	 */
	public void setRecommendedPriority(Object recommendedPriority) {
		this.recommendedPriority = recommendedPriority;
	}

	/**
	 * Gets the last used report date.
	 *
	 * @return the lastUsedReportDate
	 */
	public Date getLastUsedReportDate() {
		return lastUsedReportDate;
	}

	/**
	 * Sets the last used report date.
	 *
	 * @param lastUsedReportDate the lastUsedReportDate to set
	 */
	public void setLastUsedReportDate(Date lastUsedReportDate) {
		this.lastUsedReportDate = lastUsedReportDate;
	}

	/**
	 * Gets the component type ID.
	 *
	 * @return the componentTypeID
	 */
	public Object getComponentTypeID() {
		return componentTypeID;
	}

	/**
	 * Sets the component type ID.
	 *
	 * @param componentTypeID the componentTypeID to set
	 */
	public void setComponentTypeID(Object componentTypeID) {
		this.componentTypeID = componentTypeID;
	}
    
}
