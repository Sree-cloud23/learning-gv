
package com.ikon.dto;

/**
 * The Class Item.
 */
public class KOusageItem {

	/** The Tower. */
	private String Tower;

	/** The cc. */
	private String CC;

	/** The Cluster. */
	private String Cluster;

	/** The Application name. */
	private String ApplicationName;

	/** The Assignment group. */
	private String AssignmentGroup;

	/** The Ko count. */
	private Object KoCount;

	/** The Linked. */
	private Object Linked;

	/** The Not linked. */
	private Object Not_Linked;
	
	/** The ticketMonth. */
	private String ticketMonth;
	
	/** The ticketCount. */
	private Object ticketCount;
	
	/** The allIncidentsmttr. */
	private Object allIncidentsmttr;
	
	/** The ticketLinkedCount. */
	private Object ticketLinkedCount;
	
	/** The linkedTicketsmttr. */
	private Object linkedTicketsmttr;
	
	/** The koIDCount. */
	private Object koIDCount;
	
	/** The GenericKoIDCount. */
	private Object GenericKoIDCount;

	/**
	 * Instantiates a new item.
	 *
	 * @param TicketMonth the ticket month
	 * @param Tower           the tower
	 * @param CC              the cc
	 * @param Cluster         the cluster
	 * @param AssignmentGroup the assignment group
	 * @param ApplicationName the application name
	 * @param KoIDCount the ko ID count
	 * @param GenericKoIDCount the generic ko ID count
	 */

	public KOusageItem(String TicketMonth, String Tower, String CC, String Cluster, String AssignmentGroup,
			String ApplicationName, Object KoIDCount, Object GenericKoIDCount) {
		// TODO Auto-generated constructor stub

		this.ticketMonth = TicketMonth;
		this.Tower = Tower;
		this.CC = CC;
		this.Cluster = Cluster;
		this.ApplicationName = ApplicationName;
		this.AssignmentGroup = AssignmentGroup;
		this.koIDCount = KoIDCount;
		this.GenericKoIDCount = GenericKoIDCount;
	}

	/**
	 * Gets the ticket month.
	 *
	 * @return the ticketMonth
	 */
	public String getTicketMonth() {
		return ticketMonth;
	}

	/**
	 * Sets the ticket month.
	 *
	 * @param ticketMonth the ticketMonth to set
	 */
	public void setTicketMonth(String ticketMonth) {
		this.ticketMonth = ticketMonth;
	}

	/**
	 * Gets the ko ID count.
	 *
	 * @return the koIDCount
	 */
	public int getKoIDCount() {
		return Integer.parseInt(String.valueOf(koIDCount));
	}

	/**
	 * Sets the ko ID count.
	 *
	 * @param koIDCount the koIDCount to set
	 */
	public void setKoIDCount(Object koIDCount) {
		this.koIDCount = koIDCount;
	}

	/**
	 * Gets the generic ko ID count.
	 *
	 * @return the genericKoIDCount
	 */
	public int getGenericKoIDCount() {
		return Integer.parseInt(String.valueOf(GenericKoIDCount));
	}

	/**
	 * Sets the generic ko ID count.
	 *
	 * @param genericKoIDCount the genericKoIDCount to set
	 */
	public void setGenericKoIDCount(Object genericKoIDCount) {
		this.GenericKoIDCount = genericKoIDCount;
	}

	/**
	 * Gets the tower.
	 *
	 * @return the tower
	 */
	public String getTower() {
		return Tower;
	}

	/**
	 * Sets the tower.
	 *
	 * @param tower the new tower
	 */
	public void setTower(String tower) {
		Tower = tower;
	}

	/**
	 * Gets the cc.
	 *
	 * @return the cc
	 */
	public String getCC() {
		return CC;
	}

	/**
	 * Sets the cc.
	 *
	 * @param cC the new cc
	 */
	public void setCC(String cC) {
		CC = cC;
	}

	/**
	 * Gets the cluster.
	 *
	 * @return the cluster
	 */
	public String getCluster() {
		return Cluster;
	}

	/**
	 * Sets the cluster.
	 *
	 * @param cluster the new cluster
	 */
	public void setCluster(String cluster) {
		Cluster = cluster;
	}

	/**
	 * Gets the application name.
	 *
	 * @return the application name
	 */
	public String getApplicationName() {
		return ApplicationName;
	}

	/**
	 * Sets the application name.
	 *
	 * @param applicationName the new application name
	 */
	public void setApplicationName(String applicationName) {
		ApplicationName = applicationName;
	}

	/**
	 * Gets the assignment group.
	 *
	 * @return the assignment group
	 */
	public String getAssignmentGroup() {
		return AssignmentGroup;
	}

	/**
	 * Sets the assignment group.
	 *
	 * @param assignmentGroup the new assignment group
	 */
	public void setAssignmentGroup(String assignmentGroup) {
		AssignmentGroup = assignmentGroup;
	}

	/**
	 * Gets the ko count.
	 *
	 * @return the koCount
	 */
	public int getKoCount() {
		return Integer.parseInt(String.valueOf(KoCount));
	}

	/**
	 * Sets the ko count.
	 *
	 * @param koCount the koCount to set
	 */
	public void setKoCount(Object koCount) {
		KoCount = koCount;
	}

	/**
	 * Gets the linked.
	 *
	 * @return the linked
	 */
	public int getLinked() {
		// return Linked;
		return Integer.parseInt(String.valueOf(Linked));
	}

	/**
	 * Sets the linked.
	 *
	 * @param linked the linked to set
	 */
	public void setLinked(Object linked) {
		Linked = linked;
	}

	/**
	 * Gets the not linked.
	 *
	 * @return the not_Linked
	 */
	public int getNot_Linked() {
		// return Not_Linked;
		return Integer.parseInt(String.valueOf(Not_Linked));
	}

	/**
	 * Sets the not linked.
	 *
	 * @param not_Linked the not_Linked to set
	 */
	public void setNot_Linked(Object not_Linked) {
		Not_Linked = not_Linked;
	}

	/**
	 * Gets the ticket count.
	 *
	 * @return the ticketCount
	 */
	public int getTicketCount() {
		return Integer.parseInt(String.valueOf(ticketCount));
	}

	/**
	 * Sets the ticket count.
	 *
	 * @param ticketCount the ticketCount to set
	 */
	public void setTicketCount(Object ticketCount) {
		this.ticketCount = ticketCount;
	}

	/**
	 * Gets the all incidentsmttr.
	 *
	 * @return the allIncidentsmttr
	 */
	public int getAllIncidentsmttr() {
		return Integer.parseInt(String.valueOf(allIncidentsmttr));
	}

	/**
	 * Sets the all incidentsmttr.
	 *
	 * @param allIncidentsmttr the allIncidentsmttr to set
	 */
	public void setAllIncidentsmttr(Object allIncidentsmttr) {
		this.allIncidentsmttr = allIncidentsmttr;
	}

	/**
	 * Gets the ticket linked count.
	 *
	 * @return the ticketLinkedCount
	 */
	public int getTicketLinkedCount() {
		return Integer.parseInt(String.valueOf(ticketLinkedCount));
	}

	/**
	 * Sets the ticket linked count.
	 *
	 * @param ticketLinkedCount the ticketLinkedCount to set
	 */
	public void setTicketLinkedCount(Object ticketLinkedCount) {
		this.ticketLinkedCount = ticketLinkedCount;
	}

	/**
	 * Gets the linked ticketsmttr.
	 *
	 * @return the linkedTicketsmttr
	 */
	public int getLinkedTicketsmttr() {
		return Integer.parseInt(String.valueOf(linkedTicketsmttr));
	}

	/**
	 * Sets the linked ticketsmttr.
	 *
	 * @param linkedTicketsmttr the linkedTicketsmttr to set
	 */
	public void setLinkedTicketsmttr(Object linkedTicketsmttr) {
		this.linkedTicketsmttr = linkedTicketsmttr;
	}

}
