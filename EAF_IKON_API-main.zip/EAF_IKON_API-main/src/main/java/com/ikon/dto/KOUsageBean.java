package com.ikon.dto;

import java.util.Date;

/**
 * The Class KOUsageBean.
 */
public class KOUsageBean {

	/** The ko serial no. */
	int koSerialNo;

	/** The account ID. */
	int accountID;

	/** The serial number. */
	String serialNumber;

	/** The user ID. */
	String userID;

	/** The linked date. */
	Date linkedDate;

	/** The feed id. */
	int feedId;

	/**
	 * Gets the ko serial no.
	 *
	 * @return the ko serial no
	 */
	public int getKoSerialNo() {
		return koSerialNo;
	}

	/**
	 * Sets the ko serial no.
	 *
	 * @param koSerialNo the new ko serial no
	 */
	public void setKoSerialNo(int koSerialNo) {
		this.koSerialNo = koSerialNo;
	}

	/**
	 * Gets the account ID.
	 *
	 * @return the account ID
	 */
	public int getAccountID() {
		return accountID;
	}

	/**
	 * Sets the account ID.
	 *
	 * @param accountID the new account ID
	 */
	public void setAccountID(int accountID) {
		this.accountID = accountID;
	}

	/**
	 * Gets the serial number.
	 *
	 * @return the serial number
	 */
	public String getSerialNumber() {
		return serialNumber;
	}

	/**
	 * Sets the serial number.
	 *
	 * @param serialNumber the new serial number
	 */
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	/**
	 * Gets the user ID.
	 *
	 * @return the user ID
	 */
	public String getUserID() {
		return userID;
	}

	/**
	 * Sets the user ID.
	 *
	 * @param userID the new user ID
	 */
	public void setUserID(String userID) {
		this.userID = userID;
	}

	/**
	 * Gets the linked date.
	 *
	 * @return the linked date
	 */
	public Date getLinkedDate() {
		return linkedDate;
	}

	/**
	 * Sets the linked date.
	 *
	 * @param linkedDate the new linked date
	 */
	public void setLinkedDate(Date linkedDate) {
		this.linkedDate = linkedDate;
	}

	/**
	 * Gets the feed id.
	 *
	 * @return the feed id
	 */
	public int getFeedId() {
		return feedId;
	}

	/**
	 * Sets the feed id.
	 *
	 * @param feedId the new feed id
	 */
	public void setFeedId(int feedId) {
		this.feedId = feedId;
	}
	
}
