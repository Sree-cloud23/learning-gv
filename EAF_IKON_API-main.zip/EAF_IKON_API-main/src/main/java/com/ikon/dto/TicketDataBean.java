package com.ikon.dto;

import java.util.Date;
import java.util.Map;

/**
 * The Class TicketDataBean.
 *
 * @author Capgemini
 */
public class TicketDataBean implements Comparable<TicketDataBean> {
	
    /** The Serial number. */
    private Integer SerialNumber;
	
    /** The account ID. */
    private int accountID;
    
    /** The account name. */
    private String accountName;
    
    /** The ticket ID. */
    private String ticketID;
    
    /** The summary. */
    private String summary;
    
    /** The notes. */
    private String notes;
    
    /** The application name. */
    private String applicationName;
    
    /** The assignment group. */
    private String assignmentGroup;
    
    /** The assignee name. */
    private String assigneeName;
    
    /** The status. */
    private String status;
    
    /** The closed date. */
    private Date closedDate;
    
    /** The closed by. */
    private String closedBy;
    
    /** The resolution note. */
    private String resolutionNote;
    
    /** The service type. */
    private String serviceType;
    
    /** The company. */
    private String company;
    
    /** The category. */
    private String category;
    
    /** The sub category. */
    private String subCategory;
    
    /** The urgency. */
    private String urgency;
    
    /** The priority. */
    private String priority;
    
    /** The priority num. */
    private int priorityNum;
    
    /** The impact. */
    private String impact;
    
    /** The reported date. */
    private Date reportedDate;
    
    /** The work notes. */
    private String workNotes;
    
    /** The Last modified by. */
    private String LastModifiedBy;
    
    /** The last modified date. */
    private Date lastModifiedDate;
    
    /** The resolved date. */
    private Date resolvedDate;
    
    /** The opened by. */
    private String openedBy;
    
    /** The location. */
    private String location;
    
    /** The breach exception. */
    private String breachException;
    
    /** The breach reason. */
    private String breachReason;
    
    /** The contact type. */
    private String contactType;
    
    /** The environment. */
    private String environment;
    
    /** The estimated resolution date. */
    private String estimatedResolutionDate;
    
    /** The incident association type. */
    private String incidentAssociationType;
    
    /** The support company. */
    private String supportCompany;
    
    /** The app tier. */
    private String appTier;
    
    /** The inc ageing. */
    private String incAgeing;
    
    /** The next target date. */
    private Date nextTargetDate;
    
    /** The operational categorization tier 1. */
    private String operationalCategorizationTier1;
    
    /** The operational categorization tier 2. */
    private String operationalCategorizationTier2;
    
    /** The operational categorization tier 3. */
    private String operationalCategorizationTier3;
    
    /** The product categorization tier 1. */
    private String productCategorizationTier1;
    
    /** The product categorization tier 2. */
    private String productCategorizationTier2;
    
    /** The product categorization tier 3. */
    private String productCategorizationTier3;
    
    /** The SLM status. */
    private String SLMStatus;
    
    /** The support organization. */
    private String supportOrganization;
    
    /** The resolution category. */
    private String resolutionCategory;
    
    /** The status reason. */
    private String statusReason;
    
    /** The is primary. */
    private String isPrimary;
    
    /** The relev perc. */
    private String relevPerc;
    
    /** The usage perc. */
    private String usagePerc;
    
    /** The tower. */
    private String tower;
    
    /** The cc. */
    private String cc;
    
    /** The cluster. */
    private String cluster;
    
    /** The feedback perc. */
    private String feedbackPerc;
    
    /** The master rel. */
    private String masterRel;
    
    /** The done flag. */
    private String doneFlag;
    
    /** The User ID. */
    private String UserID;
    
    /** The search type. */
    private String searchType;
    
    /** The KO serial no. */
    private Integer KOSerialNo;
    
    /** The Ko ID. */
    private String KoID;
    
    /** The Ko attachment present. */
    private Object Ko_AttachmentPresent;
    
    /** The attachment present. */
    private Integer attachmentPresent;
    
    /** The Ko application name. */
    private String Ko_ApplicationName;
    
    /** The Ko assignment group. */
    private String Ko_AssignmentGroup;
    
    /** The KO status. */
    private Object KOStatus;
    
    /** The Symptoms. */
    private String Symptoms;
    
    /** The Resolution. */
    private String Resolution;
    
    /** The Cause. */
    private String Cause;
    
    /** The Question. */
    private String Question;
    
    /** The Answer. */
    private String Answer;
    
    /** The Caller detail. */
    private String CallerDetail;
    
    /** The expire hours. */
    private String expireHours;
    
    /** The linked date. */
    private Date linkedDate;
    
    /** The short description. */
    private String shortDescription;
    
    /** The Ko file type. */
    private String KoFileType;
    
    /** The attachment number. */
    private Integer attachmentNumber;
    
    /** The attachment name. */
    private String attachmentName;
    
    /** The attachment path. */
    private String attachmentPath;
    
    /** The created by. */
    private String createdBy;
    
    /** The selected vals. */
    private String selectedVals;
    
    /** The external link. */
    private String externalLink;
    
    /** The KO single tags. */
    private String KOSingleTags;
    
    /** The KO bigram tags. */
    private String KOBigramTags;
    
    /** The KO trigram tags. */
    private String KOTrigramTags;
    
    /** The INC single tags. */
    private String INCSingleTags;
    
    /** The INC bigram tags. */
    private String INCBigramTags;
    
    /** The INC trigram tags. */
    private String INCTrigramTags;
    
    /** The kotags. */
    private Map<String,String> kotags;
    
    /** The Ko long description. */
    private String Ko_LongDescription;
    
    /** The selected ko for resolution. */
    private String selectedKoForResolution;
    
    /** The is selected for resolution. */
    private String isSelectedForResolution;
    
    /** The is BOT enabled. */
    private Short isBOTEnabled;
    
    /** The is bot auto executor. */
    private Short isBotAutoExecutor;
    
    /** The heading collapse show. */
    private String headingCollapseShow;
    
    /** The incident tags. */
    private Map<String,String> incidentTags;
    
    /** The heading collapse id. */
    private String headingCollapseId;
    
    /** The incbotenbled. */
    private Short INCBOTENBLED;
    
    /** The ticket linked count. */
    private Long ticketLinkedCount;
    
    /** The ko value. */
    private String koValue;
    
    /** The best match flag. */
    private String bestMatchFlag;
    
    /** The seperated ko ID. */
    private String seperatedKoID;
    
    /** The seperated ko perc. */
    private String seperatedKoPerc;
    
    /** The seperated koRel perc. */
    private String seperatedKoRelPer;
    
    /** The seperated koRel ID. */
    private String seperatedKoRelID;
    
    
    /** The cause code level 1. */
    private String causeCodeLevel1;
    
    /** The cause code level 2. */
    private String causeCodeLevel2;
    
    /** The cause code level 3. */
    private String causeCodeLevel3;
    
    /** The cause code level 3. */
    private String causeCodeLevel4;
    
    /** The cause code level 3. */
    private String causeCodeLevel5;
    
    /**
     * Gets the seperated ko rel ID.
     *
     * @return the seperated ko rel ID
     */
    public String getSeperatedKoRelID() {
		return seperatedKoRelID;
	}

	/**
	 * Sets the seperated ko rel ID.
	 *
	 * @param seperatedKoRelID the new seperated ko rel ID
	 */
	public void setSeperatedKoRelID(String seperatedKoRelID) {
		this.seperatedKoRelID = seperatedKoRelID;
	}

	/**
	 * Gets the seperated ko rel per.
	 *
	 * @return the seperated ko rel per
	 */
	public String getSeperatedKoRelPer() {
		return seperatedKoRelPer;
	}

	/**
	 * Sets the seperated ko rel per.
	 *
	 * @param seperatedKoRelPer the new seperated ko rel per
	 */
	public void setSeperatedKoRelPer(String seperatedKoRelPer) {
		this.seperatedKoRelPer = seperatedKoRelPer;
	}

	/** The subject matter specialist. */
    private String subjectMatterSpecialist;
    
    /** The ticket count. */
    private Object ticketCount;
    
    /** The created date. */
    private Date createdDate;
    
    /** The from date. */
    private String fromDate;
    
    /** The to date. */
    private String toDate;
    
    /** The is search by resolved date. */
    private String isSearchByResolvedDate; 
    
    /** The Reporteddate. */
    private Date Reporteddate;
    
    /** The inc cause. */
    private String incCause;
    
    /** The breach time. */
    private Date breachTime;
    
    /** The start time of last feed. */
    private Date startTimeOfLastFeed;
    
    /** The publication status. */
    private String publicationStatus;
    
	/**
	 * Gets the start time of last feed.
	 *
	 * @return the start time of last feed
	 */
	public Date getStartTimeOfLastFeed() {
		return startTimeOfLastFeed;
	}

	/**
	 * Sets the start time of last feed.
	 *
	 * @param startTimeOfLastFeed the new start time of last feed
	 */
	public void setStartTimeOfLastFeed(Date startTimeOfLastFeed) {
		this.startTimeOfLastFeed = startTimeOfLastFeed;
	}
   
	/**
	 * Gets the breach time.
	 *
	 * @return the breach time
	 */
	public Date getBreachTime() {
		return breachTime;
	}

	/**
	 * Sets the breach time.
	 *
	 * @param breachTime the new breach time
	 */
	public void setBreachTime(Date breachTime) {
		this.breachTime = breachTime;
	}

	/**
	 * Gets the created date.
	 *
	 * @return the created date
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * Sets the created date.
	 *
	 * @param createdDate the new created date
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * Gets the from date.
	 *
	 * @return the from date
	 */
	public String getFromDate() {
		return fromDate;
	}

	/**
	 * Sets the from date.
	 *
	 * @param fromDate the new from date
	 */
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	/**
	 * Gets the to date.
	 *
	 * @return the to date
	 */
	public String getToDate() {
		return toDate;
	}

	/**
	 * Sets the to date.
	 *
	 * @param toDate the new to date
	 */
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	/**
	 * Gets the checks if is search by resolved date.
	 *
	 * @return the checks if is search by resolved date
	 */
	public String getIsSearchByResolvedDate() {
		return isSearchByResolvedDate;
	}

	/**
	 * Sets the checks if is search by resolved date.
	 *
	 * @param isSearchByResolvedDate the new checks if is search by resolved date
	 */
	public void setIsSearchByResolvedDate(String isSearchByResolvedDate) {
		this.isSearchByResolvedDate = isSearchByResolvedDate;
	}

	/**
	 * Gets the ko value.
	 *
	 * @return the ko value
	 */
	public String getKoValue() {
		return koValue;
	}

	/**
	 * Sets the ko value.
	 *
	 * @param koValue the new ko value
	 */
	public void setKoValue(String koValue) {
		this.koValue = koValue;
	}

	/**
	 * Gets the KO single tags.
	 *
	 * @return the KO single tags
	 */
	public String getKOSingleTags() {
		return KOSingleTags;
	}

	/**
	 * Sets the KO single tags.
	 *
	 * @param kOSingleTags the new KO single tags
	 */
	public void setKOSingleTags(String kOSingleTags) {
		KOSingleTags = kOSingleTags;
	}

	/**
	 * Gets the KO bigram tags.
	 *
	 * @return the KO bigram tags
	 */
	public String getKOBigramTags() {
		return KOBigramTags;
	}

	/**
	 * Sets the KO bigram tags.
	 *
	 * @param kOBigramTags the new KO bigram tags
	 */
	public void setKOBigramTags(String kOBigramTags) {
		KOBigramTags = kOBigramTags;
	}

	/**
	 * Gets the KO trigram tags.
	 *
	 * @return the KO trigram tags
	 */
	public String getKOTrigramTags() {
		return KOTrigramTags;
	}

	/**
	 * Sets the KO trigram tags.
	 *
	 * @param kOTrigramTags the new KO trigram tags
	 */
	public void setKOTrigramTags(String kOTrigramTags) {
		KOTrigramTags = kOTrigramTags;
	}

	/**
	 * Gets the attachment number.
	 *
	 * @return the attachment number
	 */
	public int getAttachmentNumber() {
		return attachmentNumber;
	}

	/**
	 * Sets the attachment number.
	 *
	 * @param attachmentNumber the new attachment number
	 */
	public void setAttachmentNumber(Integer attachmentNumber) {
		this.attachmentNumber = attachmentNumber;
	}

	/**
	 * Gets the serial number.
	 *
	 * @return the serial number
	 */
	public Integer getSerialNumber() {
		return SerialNumber;
	}

	/**
	 * Sets the serial number.
	 *
	 * @param serialNumber the new serial number
	 */
	public void setSerialNumber(Integer serialNumber) {
		SerialNumber = serialNumber;
	}

	/**
	 * Gets the account ID.
	 *
	 * @return the account ID
	 */
	public int getAccountID() {
		return accountID;
	}

	/**
	 * Sets the account ID.
	 *
	 * @param accountID the new account ID
	 */
	public void setAccountID(int accountID) {
		this.accountID = accountID;
	}

	/**
	 * Gets the ticket ID.
	 *
	 * @return the ticket ID
	 */
	public String getTicketID() {
		return ticketID;
	}

	/**
	 * Sets the ticket ID.
	 *
	 * @param ticketID the new ticket ID
	 */
	public void setTicketID(String ticketID) {
		this.ticketID = ticketID;
	}

	/**
	 * Gets the summary.
	 *
	 * @return the summary
	 */
	public String getSummary() {
		return summary;
	}

	/**
	 * Sets the summary.
	 *
	 * @param summary the new summary
	 */
	public void setSummary(String summary) {
		this.summary = summary;
	}

	/**
	 * Gets the notes.
	 *
	 * @return the notes
	 */
	public String getNotes() {
		return notes;
	}

	/**
	 * Sets the notes.
	 *
	 * @param notes the new notes
	 */
	public void setNotes(String notes) {
		this.notes = notes;
	}

	/**
	 * Gets the application name.
	 *
	 * @return the application name
	 */
	public String getApplicationName() {
		return applicationName;
	}

	/**
	 * Sets the application name.
	 *
	 * @param applicationName the new application name
	 */
	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}

	/**
	 * Gets the assignment group.
	 *
	 * @return the assignment group
	 */
	public String getAssignmentGroup() {
		return assignmentGroup;
	}

	/**
	 * Sets the assignment group.
	 *
	 * @param assignmentGroup the new assignment group
	 */
	public void setAssignmentGroup(String assignmentGroup) {
		this.assignmentGroup = assignmentGroup;
	}

	/**
	 * Gets the assignee name.
	 *
	 * @return the assignee name
	 */
	public String getAssigneeName() {
		return assigneeName;
	}

	/**
	 * Sets the assignee name.
	 *
	 * @param assigneeName the new assignee name
	 */
	public void setAssigneeName(String assigneeName) {
		this.assigneeName = assigneeName;
	}

	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Sets the status.
	 *
	 * @param status the new status
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Gets the closed date.
	 *
	 * @return the closed date
	 */
	public Date getClosedDate() {
		return closedDate;
	}

	/**
	 * Sets the closed date.
	 *
	 * @param closedDate the new closed date
	 */
	public void setClosedDate(Date closedDate) {
		this.closedDate = closedDate;
	}

	/**
	 * Gets the closed by.
	 *
	 * @return the closed by
	 */
	public String getClosedBy() {
		return closedBy;
	}

	/**
	 * Sets the closed by.
	 *
	 * @param closedBy the new closed by
	 */
	public void setClosedBy(String closedBy) {
		this.closedBy = closedBy;
	}

	/**
	 * Gets the resolution note.
	 *
	 * @return the resolution note
	 */
	public String getResolutionNote() {
		return resolutionNote;
	}

	/**
	 * Sets the resolution note.
	 *
	 * @param resolutionNote the new resolution note
	 */
	public void setResolutionNote(String resolutionNote) {
		this.resolutionNote = resolutionNote;
	}

	/**
	 * Gets the service type.
	 *
	 * @return the service type
	 */
	public String getServiceType() {
		return serviceType;
	}

	/**
	 * Sets the service type.
	 *
	 * @param serviceType the new service type
	 */
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	/**
	 * Gets the company.
	 *
	 * @return the company
	 */
	public String getCompany() {
		return company;
	}

	/**
	 * Sets the company.
	 *
	 * @param company the new company
	 */
	public void setCompany(String company) {
		this.company = company;
	}

	/**
	 * Gets the category.
	 *
	 * @return the category
	 */
	public String getCategory() {
		return category;
	}

	/**
	 * Sets the category.
	 *
	 * @param category the new category
	 */
	public void setCategory(String category) {
		this.category = category;
	}

	/**
	 * Gets the sub category.
	 *
	 * @return the sub category
	 */
	public String getSubCategory() {
		return subCategory;
	}

	/**
	 * Sets the sub category.
	 *
	 * @param subCategory the new sub category
	 */
	public void setSubCategory(String subCategory) {
		this.subCategory = subCategory;
	}

	/**
	 * Gets the urgency.
	 *
	 * @return the urgency
	 */
	public String getUrgency() {
		return urgency;
	}

	/**
	 * Sets the urgency.
	 *
	 * @param urgency the new urgency
	 */
	public void setUrgency(String urgency) {
		this.urgency = urgency;
	}

	/**
	 * Gets the priority.
	 *
	 * @return the priority
	 */
	public String getPriority() {
		return priority;
	}

	/**
	 * Sets the priority.
	 *
	 * @param priority the new priority
	 */
	public void setPriority(String priority) {
		this.priority = priority;
	}

	/**
	 * Gets the impact.
	 *
	 * @return the impact
	 */
	public String getImpact() {
		return impact;
	}

	/**
	 * Sets the impact.
	 *
	 * @param impact the new impact
	 */
	public void setImpact(String impact) {
		this.impact = impact;
	}

	/**
	 * Gets the reported date.
	 *
	 * @return the reported date
	 */
	public Date getReportedDate() {
		return reportedDate;
	}

	/**
	 * Sets the reported date.
	 *
	 * @param reportedDate the new reported date
	 */
	public void setReportedDate(Date reportedDate) {
		this.reportedDate = reportedDate;
	}

	/**
	 * Gets the work notes.
	 *
	 * @return the work notes
	 */
	public String getWorkNotes() {
		return workNotes;
	}

	/**
	 * Sets the work notes.
	 *
	 * @param workNotes the new work notes
	 */
	public void setWorkNotes(String workNotes) {
		this.workNotes = workNotes;
	}

	/**
	 * Gets the last modified by.
	 *
	 * @return the last modified by
	 */
	public String getLastModifiedBy() {
		return LastModifiedBy;
	}

	/**
	 * Sets the last modified by.
	 *
	 * @param lastModifiedBy the new last modified by
	 */
	public void setLastModifiedBy(String lastModifiedBy) {
		LastModifiedBy = lastModifiedBy;
	}

	/**
	 * Gets the last modified date.
	 *
	 * @return the last modified date
	 */
	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	/**
	 * Sets the last modified date.
	 *
	 * @param lastModifiedDate the new last modified date
	 */
	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	/**
	 * Gets the resolved date.
	 *
	 * @return the resolved date
	 */
	public Date getResolvedDate() {
		return resolvedDate;
	}

	/**
	 * Sets the resolved date.
	 *
	 * @param resolvedDate the new resolved date
	 */
	public void setResolvedDate(Date resolvedDate) {
		this.resolvedDate = resolvedDate;
	}

	/**
	 * Gets the opened by.
	 *
	 * @return the opened by
	 */
	public String getOpenedBy() {
		return openedBy;
	}

	/**
	 * Sets the opened by.
	 *
	 * @param openedBy the new opened by
	 */
	public void setOpenedBy(String openedBy) {
		this.openedBy = openedBy;
	}

	/**
	 * Gets the location.
	 *
	 * @return the location
	 */
	public String getLocation() {
		return location;
	}

	/**
	 * Sets the location.
	 *
	 * @param location the new location
	 */
	public void setLocation(String location) {
		this.location = location;
	}

	/**
	 * Gets the breach exception.
	 *
	 * @return the breach exception
	 */
	public String getBreachException() {
		return breachException;
	}

	/**
	 * Sets the breach exception.
	 *
	 * @param breachException the new breach exception
	 */
	public void setBreachException(String breachException) {
		this.breachException = breachException;
	}

	/**
	 * Gets the breach reason.
	 *
	 * @return the breach reason
	 */
	public String getBreachReason() {
		return breachReason;
	}

	/**
	 * Sets the breach reason.
	 *
	 * @param breachReason the new breach reason
	 */
	public void setBreachReason(String breachReason) {
		this.breachReason = breachReason;
	}

	/**
	 * Gets the contact type.
	 *
	 * @return the contact type
	 */
	public String getContactType() {
		return contactType;
	}

	/**
	 * Sets the contact type.
	 *
	 * @param contactType the new contact type
	 */
	public void setContactType(String contactType) {
		this.contactType = contactType;
	}

	/**
	 * Gets the environment.
	 *
	 * @return the environment
	 */
	public String getEnvironment() {
		return environment;
	}

	/**
	 * Sets the environment.
	 *
	 * @param environment the new environment
	 */
	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	/**
	 * Gets the estimated resolution date.
	 *
	 * @return the estimated resolution date
	 */
	public String getEstimatedResolutionDate() {
		return estimatedResolutionDate;
	}

	/**
	 * Sets the estimated resolution date.
	 *
	 * @param estimatedResolutionDate the new estimated resolution date
	 */
	public void setEstimatedResolutionDate(String estimatedResolutionDate) {
		this.estimatedResolutionDate = estimatedResolutionDate;
	}

	/**
	 * Gets the incident association type.
	 *
	 * @return the incident association type
	 */
	public String getIncidentAssociationType() {
		return incidentAssociationType;
	}

	/**
	 * Sets the incident association type.
	 *
	 * @param incidentAssociationType the new incident association type
	 */
	public void setIncidentAssociationType(String incidentAssociationType) {
		this.incidentAssociationType = incidentAssociationType;
	}

	/**
	 * Gets the support company.
	 *
	 * @return the support company
	 */
	public String getSupportCompany() {
		return supportCompany;
	}

	/**
	 * Sets the support company.
	 *
	 * @param supportCompany the new support company
	 */
	public void setSupportCompany(String supportCompany) {
		this.supportCompany = supportCompany;
	}

	/**
	 * Gets the app tier.
	 *
	 * @return the app tier
	 */
	public String getAppTier() {
		return appTier;
	}

	/**
	 * Sets the app tier.
	 *
	 * @param appTier the new app tier
	 */
	public void setAppTier(String appTier) {
		this.appTier = appTier;
	}

	/**
	 * Gets the inc ageing.
	 *
	 * @return the inc ageing
	 */
	public String getIncAgeing() {
		return incAgeing;
	}

	/**
	 * Sets the inc ageing.
	 *
	 * @param incAgeing the new inc ageing
	 */
	public void setIncAgeing(String incAgeing) {
		this.incAgeing = incAgeing;
	}

	/**
	 * Gets the next target date.
	 *
	 * @return the next target date
	 */
	public Date getNextTargetDate() {
		return nextTargetDate;
	}

	/**
	 * Sets the next target date.
	 *
	 * @param nextTargetDate the new next target date
	 */
	public void setNextTargetDate(Date nextTargetDate) {
		this.nextTargetDate = nextTargetDate;
	}

	/**
	 * Gets the operational categorization tier 1.
	 *
	 * @return the operational categorization tier 1
	 */
	public String getOperationalCategorizationTier1() {
		return operationalCategorizationTier1;
	}

	/**
	 * Sets the operational categorization tier 1.
	 *
	 * @param operationalCategorizationTier1 the new operational categorization tier 1
	 */
	public void setOperationalCategorizationTier1(String operationalCategorizationTier1) {
		this.operationalCategorizationTier1 = operationalCategorizationTier1;
	}

	/**
	 * Gets the operational categorization tier 2.
	 *
	 * @return the operational categorization tier 2
	 */
	public String getOperationalCategorizationTier2() {
		return operationalCategorizationTier2;
	}

	/**
	 * Sets the operational categorization tier 2.
	 *
	 * @param operationalCategorizationTier2 the new operational categorization tier 2
	 */
	public void setOperationalCategorizationTier2(String operationalCategorizationTier2) {
		this.operationalCategorizationTier2 = operationalCategorizationTier2;
	}

	/**
	 * Gets the operational categorization tier 3.
	 *
	 * @return the operational categorization tier 3
	 */
	public String getOperationalCategorizationTier3() {
		return operationalCategorizationTier3;
	}

	/**
	 * Sets the operational categorization tier 3.
	 *
	 * @param operationalCategorizationTier3 the new operational categorization tier 3
	 */
	public void setOperationalCategorizationTier3(String operationalCategorizationTier3) {
		this.operationalCategorizationTier3 = operationalCategorizationTier3;
	}

	/**
	 * Gets the product categorization tier 1.
	 *
	 * @return the product categorization tier 1
	 */
	public String getProductCategorizationTier1() {
		return productCategorizationTier1;
	}

	/**
	 * Sets the product categorization tier 1.
	 *
	 * @param productCategorizationTier1 the new product categorization tier 1
	 */
	public void setProductCategorizationTier1(String productCategorizationTier1) {
		this.productCategorizationTier1 = productCategorizationTier1;
	}

	/**
	 * Gets the product categorization tier 2.
	 *
	 * @return the product categorization tier 2
	 */
	public String getProductCategorizationTier2() {
		return productCategorizationTier2;
	}

	/**
	 * Sets the product categorization tier 2.
	 *
	 * @param productCategorizationTier2 the new product categorization tier 2
	 */
	public void setProductCategorizationTier2(String productCategorizationTier2) {
		this.productCategorizationTier2 = productCategorizationTier2;
	}

	/**
	 * Gets the product categorization tier 3.
	 *
	 * @return the product categorization tier 3
	 */
	public String getProductCategorizationTier3() {
		return productCategorizationTier3;
	}

	/**
	 * Sets the product categorization tier 3.
	 *
	 * @param productCategorizationTier3 the new product categorization tier 3
	 */
	public void setProductCategorizationTier3(String productCategorizationTier3) {
		this.productCategorizationTier3 = productCategorizationTier3;
	}

	/**
	 * Gets the SLM status.
	 *
	 * @return the SLM status
	 */
	public String getSLMStatus() {
		return SLMStatus;
	}

	/**
	 * Sets the SLM status.
	 *
	 * @param sLMStatus the new SLM status
	 */
	public void setSLMStatus(String sLMStatus) {
		SLMStatus = sLMStatus;
	}

	/**
	 * Gets the support organization.
	 *
	 * @return the support organization
	 */
	public String getSupportOrganization() {
		return supportOrganization;
	}

	/**
	 * Sets the support organization.
	 *
	 * @param supportOrganization the new support organization
	 */
	public void setSupportOrganization(String supportOrganization) {
		this.supportOrganization = supportOrganization;
	}

	/**
	 * Gets the resolution category.
	 *
	 * @return the resolution category
	 */
	public String getResolutionCategory() {
		return resolutionCategory;
	}

	/**
	 * Sets the resolution category.
	 *
	 * @param resolutionCategory the new resolution category
	 */
	public void setResolutionCategory(String resolutionCategory) {
		this.resolutionCategory = resolutionCategory;
	}

	/**
	 * Gets the status reason.
	 *
	 * @return the status reason
	 */
	public String getStatusReason() {
		return statusReason;
	}

	/**
	 * Sets the status reason.
	 *
	 * @param statusReason the new status reason
	 */
	public void setStatusReason(String statusReason) {
		this.statusReason = statusReason;
	}

	/**
	 * Gets the checks if is primary.
	 *
	 * @return the checks if is primary
	 */
	public String getIsPrimary() {
		return isPrimary;
	}

	/**
	 * Sets the checks if is primary.
	 *
	 * @param isPrimary the new checks if is primary
	 */
	public void setIsPrimary(String isPrimary) {
		this.isPrimary = isPrimary;
	}

	/**
	 * Gets the relev perc.
	 *
	 * @return the relev perc
	 */
	public String getRelevPerc() {
		return relevPerc;
	}

	/**
	 * Sets the relev perc.
	 *
	 * @param relevPerc the new relev perc
	 */
	public void setRelevPerc(String relevPerc) {
		this.relevPerc = relevPerc;
	}

	/**
	 * Gets the usage perc.
	 *
	 * @return the usage perc
	 */
	public String getUsagePerc() {
		return usagePerc;
	}

	/**
	 * Sets the usage perc.
	 *
	 * @param usagePerc the new usage perc
	 */
	public void setUsagePerc(String usagePerc) {
		this.usagePerc = usagePerc;
	}

	/**
	 * Gets the tower.
	 *
	 * @return the tower
	 */
	public String getTower() {
		return tower;
	}

	/**
	 * Sets the tower.
	 *
	 * @param tower the new tower
	 */
	public void setTower(String tower) {
		this.tower = tower;
	}

	/**
	 * Gets the cc.
	 *
	 * @return the cc
	 */
	public String getCc() {
		return cc;
	}

	/**
	 * Sets the cc.
	 *
	 * @param cc the new cc
	 */
	public void setCc(String cc) {
		this.cc = cc;
	}

	/**
	 * Gets the cluster.
	 *
	 * @return the cluster
	 */
	public String getCluster() {
		return cluster;
	}

	/**
	 * Sets the cluster.
	 *
	 * @param cluster the new cluster
	 */
	public void setCluster(String cluster) {
		this.cluster = cluster;
	}

	/**
	 * Gets the feedback perc.
	 *
	 * @return the feedback perc
	 */
	public String getFeedbackPerc() {
		return feedbackPerc;
	}

	/**
	 * Sets the feedback perc.
	 *
	 * @param feedbackPerc the new feedback perc
	 */
	public void setFeedbackPerc(String feedbackPerc) {
		this.feedbackPerc = feedbackPerc;
	}

	/**
	 * Gets the master rel.
	 *
	 * @return the master rel
	 */
	public String getMasterRel() {
		return masterRel;
	}

	/**
	 * Sets the master rel.
	 *
	 * @param masterRel the new master rel
	 */
	public void setMasterRel(String masterRel) {
		this.masterRel = masterRel;
	}

	/**
	 * Gets the done flag.
	 *
	 * @return the done flag
	 */
	public String getDoneFlag() {
		return doneFlag;
	}

	/**
	 * Sets the done flag.
	 *
	 * @param doneFlag the new done flag
	 */
	public void setDoneFlag(String doneFlag) {
		this.doneFlag = doneFlag;
	}

	/**
	 * Gets the user ID.
	 *
	 * @return the user ID
	 */
	public String getUserID() {
		return UserID;
	}

	/**
	 * Sets the user ID.
	 *
	 * @param userID the new user ID
	 */
	public void setUserID(String userID) {
		UserID = userID;
	}

	/**
	 * Gets the search type.
	 *
	 * @return the search type
	 */
	public String getSearchType() {
		return searchType;
	}

	/**
	 * Sets the search type.
	 *
	 * @param searchType the new search type
	 */
	public void setSearchType(String searchType) {
		this.searchType = searchType;
	}

	/**
	 * Gets the KO serial no.
	 *
	 * @return the KO serial no
	 */
	public int getKOSerialNo() {
		return KOSerialNo;
	}

	/**
	 * Sets the KO serial no.
	 *
	 * @param kOSerialNo the new KO serial no
	 */
	public void setKOSerialNo(Integer kOSerialNo) {
		KOSerialNo = kOSerialNo;
	}

	/**
	 * Gets the ko ID.
	 *
	 * @return the ko ID
	 */
	public String getKoID() {
		return KoID;
	}

	/**
	 * Sets the ko ID.
	 *
	 * @param koID the new ko ID
	 */
	public void setKoID(String koID) {
		KoID = koID;
	}

	/**
	 * Gets the ko attachment present.
	 *
	 * @return the ko attachment present
	 */
	public Object getKo_AttachmentPresent() {
		return Ko_AttachmentPresent;
	}

	/**
	 * Sets the ko attachment present.
	 *
	 * @param ko_AttachmentPresent the new ko attachment present
	 */
	public void setKo_AttachmentPresent(Object ko_AttachmentPresent) {
		Ko_AttachmentPresent = ko_AttachmentPresent;
	}

	/**
	 * Gets the ko assignment group.
	 *
	 * @return the ko assignment group
	 */
	public String getKo_AssignmentGroup() {
		return Ko_AssignmentGroup;
	}

	/**
	 * Sets the ko assignment group.
	 *
	 * @param ko_AssignmentGroup the new ko assignment group
	 */
	public void setKo_AssignmentGroup(String ko_AssignmentGroup) {
		Ko_AssignmentGroup = ko_AssignmentGroup;
	}

	/**
	 * Gets the KO status.
	 *
	 * @return the KO status
	 */
	public Object getKOStatus() {
		return KOStatus;
	}

	/**
	 * Sets the KO status.
	 *
	 * @param kOStatus the new KO status
	 */
	public void setKOStatus(Object kOStatus) {
		KOStatus = kOStatus;
	}

	/**
	 * Gets the symptoms.
	 *
	 * @return the symptoms
	 */
	public String getSymptoms() {
		return Symptoms;
	}

	/**
	 * Sets the symptoms.
	 *
	 * @param symptoms the new symptoms
	 */
	public void setSymptoms(String symptoms) {
		Symptoms = symptoms;
	}

	/**
	 * Gets the resolution.
	 *
	 * @return the resolution
	 */
	public String getResolution() {
		return Resolution;
	}

	/**
	 * Sets the resolution.
	 *
	 * @param resolution the new resolution
	 */
	public void setResolution(String resolution) {
		Resolution = resolution;
	}

	/**
	 * Gets the cause.
	 *
	 * @return the cause
	 */
	public String getCause() {
		return Cause;
	}

	/**
	 * Sets the cause.
	 *
	 * @param cause the new cause
	 */
	public void setCause(String cause) {
		Cause = cause;
	}

	/**
	 * Gets the question.
	 *
	 * @return the question
	 */
	public String getQuestion() {
		return Question;
	}

	/**
	 * Sets the question.
	 *
	 * @param question the new question
	 */
	public void setQuestion(String question) {
		Question = question;
	}

	/**
	 * Gets the answer.
	 *
	 * @return the answer
	 */
	public String getAnswer() {
		return Answer;
	}

	/**
	 * Sets the answer.
	 *
	 * @param answer the new answer
	 */
	public void setAnswer(String answer) {
		Answer = answer;
	}

	/**
	 * Gets the account name.
	 *
	 * @return the account name
	 */
	public String getAccountName() {
		return accountName;
	}

	/**
	 * Sets the account name.
	 *
	 * @param accountName the new account name
	 */
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	/**
	 * Gets the caller detail.
	 *
	 * @return the caller detail
	 */
	public String getCallerDetail() {
		return CallerDetail;
	}

	/**
	 * Sets the caller detail.
	 *
	 * @param callerDetail the new caller detail
	 */
	public void setCallerDetail(String callerDetail) {
		CallerDetail = callerDetail;
	}

	/**
	 * Gets the ko application name.
	 *
	 * @return the ko application name
	 */
	public String getKo_ApplicationName() {
		return Ko_ApplicationName;
	}

	/**
	 * Sets the ko application name.
	 *
	 * @param ko_ApplicationName the new ko application name
	 */
	public void setKo_ApplicationName(String ko_ApplicationName) {
		Ko_ApplicationName = ko_ApplicationName;
	}

	/**
	 * Gets the expire hours.
	 *
	 * @return the expire hours
	 */
	public String getExpireHours() {
		return expireHours;
	}

	/**
	 * Sets the expire hours.
	 *
	 * @param expireHours the new expire hours
	 */
	public void setExpireHours(String expireHours) {
		this.expireHours = expireHours;
	}

	/**
	 * Gets the linked date.
	 *
	 * @return the linked date
	 */
	public Date getLinkedDate() {
		return linkedDate;
	}

	/**
	 * Sets the linked date.
	 *
	 * @param linkedDate the new linked date
	 */
	public void setLinkedDate(Date linkedDate) {
		this.linkedDate = linkedDate;
	}

	/**
	 * Gets the short description.
	 *
	 * @return the short description
	 */
	public String getShortDescription() {
		return shortDescription;
	}

	/**
	 * Sets the short description.
	 *
	 * @param shortDescription the new short description
	 */
	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}

	/**
	 * Gets the attachment present.
	 *
	 * @return the attachment present
	 */
	public int getAttachmentPresent() {
		return attachmentPresent;
	}

	/**
	 * Sets the attachment present.
	 *
	 * @param attachmentPresent the new attachment present
	 */
	public void setAttachmentPresent(Integer attachmentPresent) {
		this.attachmentPresent = attachmentPresent;
	}

	/**
	 * Gets the ko file type.
	 *
	 * @return the ko file type
	 */
	public String getKoFileType() {
		return KoFileType;
	}

	/**
	 * Sets the ko file type.
	 *
	 * @param koFileType the new ko file type
	 */
	public void setKoFileType(String koFileType) {
		KoFileType = koFileType;
	}



	/**
	 * Gets the attachment name.
	 *
	 * @return the attachment name
	 */
	public String getAttachmentName() {
		return attachmentName;
	}

	/**
	 * Sets the attachment name.
	 *
	 * @param attachmentName the new attachment name
	 */
	public void setAttachmentName(String attachmentName) {
		this.attachmentName = attachmentName;
	}

	/**
	 * Gets the attachment path.
	 *
	 * @return the attachment path
	 */
	public String getAttachmentPath() {
		return attachmentPath;
	}

	/**
	 * Sets the attachment path.
	 *
	 * @param attachmentPath the new attachment path
	 */
	public void setAttachmentPath(String attachmentPath) {
		this.attachmentPath = attachmentPath;
	}

	/**
	 * Gets the created by.
	 *
	 * @return the created by
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * Sets the created by.
	 *
	 * @param createdBy the new created by
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * Gets the selected vals.
	 *
	 * @return the selected vals
	 */
	public String getSelectedVals() {
		return selectedVals;
	}

	/**
	 * Sets the selected vals.
	 *
	 * @param selectedVals the new selected vals
	 */
	public void setSelectedVals(String selectedVals) {
		this.selectedVals = selectedVals;
	}

	/**
	 * Gets the external link.
	 *
	 * @return the external link
	 */
	public String getExternalLink() {
		return externalLink;
	}

	/**
	 * Sets the external link.
	 *
	 * @param externalLink the new external link
	 */
	public void setExternalLink(String externalLink) {
		this.externalLink = externalLink;
	}

	/**
	 * Gets the priority num.
	 *
	 * @return the priority num
	 */
	public int getPriorityNum() {
		return priorityNum;
	}

	/**
	 * Sets the priority num.
	 *
	 * @param priorityNum the new priority num
	 */
	public void setPriorityNum(int priorityNum) {
		this.priorityNum = priorityNum;
	}
	
	/**
	 * Gets the INC single tags.
	 *
	 * @return the INC single tags
	 */
	public String getINCSingleTags() {
		return INCSingleTags;
	}

	/**
	 * Sets the INC single tags.
	 *
	 * @param iNCSingleTags the new INC single tags
	 */
	public void setINCSingleTags(String iNCSingleTags) {
		INCSingleTags = iNCSingleTags;
	}

	/**
	 * Gets the INC bigram tags.
	 *
	 * @return the INC bigram tags
	 */
	public String getINCBigramTags() {
		return INCBigramTags;
	}

	/**
	 * Sets the INC bigram tags.
	 *
	 * @param iNCBigramTags the new INC bigram tags
	 */
	public void setINCBigramTags(String iNCBigramTags) {
		INCBigramTags = iNCBigramTags;
	}

	/**
	 * Gets the INC trigram tags.
	 *
	 * @return the INC trigram tags
	 */
	public String getINCTrigramTags() {
		return INCTrigramTags;
	}

	/**
	 * Sets the INC trigram tags.
	 *
	 * @param iNCTrigramTags the new INC trigram tags
	 */
	public void setINCTrigramTags(String iNCTrigramTags) {
		INCTrigramTags = iNCTrigramTags;
	}

	/**
	 * Compare to.
	 *
	 * @param candidate the candidate
	 * @return the int
	 */
	@Override     
	  public int compareTo(TicketDataBean candidate) {          
	    return (this.getPriorityNum() < candidate.getPriorityNum() ? -1 : 
	            (this.getPriorityNum() == candidate.getPriorityNum() ? 0 : 1));     
	  }

	/**
	 * Gets the ko long description.
	 *
	 * @return the ko long description
	 */
	public String getKo_LongDescription() {
		return Ko_LongDescription;
	}

	/**
	 * Sets the ko long description.
	 *
	 * @param ko_LongDescription the new ko long description
	 */
	public void setKo_LongDescription(String ko_LongDescription) {
		Ko_LongDescription = ko_LongDescription;
	}

	/**
	 * Gets the selected ko for resolution.
	 *
	 * @return the selected ko for resolution
	 */
	public String getSelectedKoForResolution() {
		return selectedKoForResolution;
	}

	/**
	 * Sets the selected ko for resolution.
	 *
	 * @param selectedKoForResolution the new selected ko for resolution
	 */
	public void setSelectedKoForResolution(String selectedKoForResolution) {
		this.selectedKoForResolution = selectedKoForResolution;
	}

	/**
	 * Gets the checks if is selected for resolution.
	 *
	 * @return the checks if is selected for resolution
	 */
	public String getIsSelectedForResolution() {
		return isSelectedForResolution;
	}

	/**
	 * Sets the checks if is selected for resolution.
	 *
	 * @param isSelectedForResolution the new checks if is selected for resolution
	 */
	public void setIsSelectedForResolution(String isSelectedForResolution) {
		this.isSelectedForResolution = isSelectedForResolution;
	}

	/**
	 * Gets the heading collapse show.
	 *
	 * @return the heading collapse show
	 */
	public String getHeadingCollapseShow() {
		return headingCollapseShow;
	}

	/**
	 * Sets the heading collapse show.
	 *
	 * @param headingCollapseShow the new heading collapse show
	 */
	public void setHeadingCollapseShow(String headingCollapseShow) {
		this.headingCollapseShow = headingCollapseShow;
	}

	/**
	 * Gets the kotags.
	 *
	 * @return the kotags
	 */
	public Map<String, String> getKotags() {
		return kotags;
	}

	/**
	 * Sets the kotags.
	 *
	 * @param kotags the kotags to set
	 */
	public void setKotags(Map<String, String> kotags) {
		this.kotags = kotags;
	}

	/**
	 * Gets the incident tags.
	 *
	 * @return the incidentTags
	 */
	public Map<String, String> getIncidentTags() {
		return incidentTags;
	}

	/**
	 * Sets the incident tags.
	 *
	 * @param incidentTags the incidentTags to set
	 */
	public void setIncidentTags(Map<String, String> incidentTags) {
		this.incidentTags = incidentTags;
	}

	/**
	 * Gets the heading collapse id.
	 *
	 * @return the heading collapse id
	 */
	public String getHeadingCollapseId() {
		return headingCollapseId;
	}

	/**
	 * Sets the heading collapse id.
	 *
	 * @param headingCollapseId the new heading collapse id
	 */
	public void setHeadingCollapseId(String headingCollapseId) {
		this.headingCollapseId = headingCollapseId;
	}

	/**
	 * Gets the checks if is BOT enabled.
	 *
	 * @return the checks if is BOT enabled
	 */
	public Short getIsBOTEnabled() {
		return isBOTEnabled;
	}

	/**
	 * Sets the checks if is BOT enabled.
	 *
	 * @param isBOTEnabled the new checks if is BOT enabled
	 */
	public void setIsBOTEnabled(Short isBOTEnabled) {
		this.isBOTEnabled = isBOTEnabled;
	}

	/**
	 * Gets the checks if is bot auto executor.
	 *
	 * @return the checks if is bot auto executor
	 */
	public Short getIsBotAutoExecutor() {
		return isBotAutoExecutor;
	}

	/**
	 * Sets the checks if is bot auto executor.
	 *
	 * @param isBotAutoExecutor the new checks if is bot auto executor
	 */
	public void setIsBotAutoExecutor(Short isBotAutoExecutor) {
		this.isBotAutoExecutor = isBotAutoExecutor;
	}

	/**
	 * Gets the incbotenbled.
	 *
	 * @return the incbotenbled
	 */
	public Short getINCBOTENBLED() {
		return INCBOTENBLED;
	}

	/**
	 * Sets the incbotenbled.
	 *
	 * @param iNCBOTENBLED the new incbotenbled
	 */
	public void setINCBOTENBLED(Short iNCBOTENBLED) {
		INCBOTENBLED = iNCBOTENBLED;
	}

	/**
	 * Gets the ticket linked count.
	 *
	 * @return the ticket linked count
	 */
	public Long getTicketLinkedCount() {
		return ticketLinkedCount;
	}

	/**
	 * Sets the ticket linked count.
	 *
	 * @param ticketLinkedCount the new ticket linked count
	 */
	public void setTicketLinkedCount(Long ticketLinkedCount) {
		this.ticketLinkedCount = ticketLinkedCount;
	}

	/**
	 * Gets the best match flag.
	 *
	 * @return the bestMatchFlag
	 */
	public String getBestMatchFlag() {
		return bestMatchFlag;
	}

	/**
	 * Sets the best match flag.
	 *
	 * @param bestMatchFlag the bestMatchFlag to set
	 */
	public void setBestMatchFlag(String bestMatchFlag) {
		this.bestMatchFlag = bestMatchFlag;
	}

	/**
	 * Gets the seperated ko ID.
	 *
	 * @return the seperatedKoID
	 */
	public String getSeperatedKoID() {
		return seperatedKoID;
	}

	/**
	 * Sets the seperated ko ID.
	 *
	 * @param seperatedKoID the seperatedKoID to set
	 */
	public void setSeperatedKoID(String seperatedKoID) {
		this.seperatedKoID = seperatedKoID;
	}

	/**
	 * Gets the seperated ko perc.
	 *
	 * @return the seperatedKoPerc
	 */
	public String getSeperatedKoPerc() {
		return seperatedKoPerc;
	}

	/**
	 * Sets the seperated ko perc.
	 *
	 * @param seperatedKoPerc the seperatedKoPerc to set
	 */
	public void setSeperatedKoPerc(String seperatedKoPerc) {
		this.seperatedKoPerc = seperatedKoPerc;
	}

	/**
	 * Gets the subject matter specialist.
	 *
	 * @return the subjectMatterSpecialist
	 */
	public String getSubjectMatterSpecialist() {
		return subjectMatterSpecialist;
	}

	/**
	 * Sets the subject matter specialist.
	 *
	 * @param subjectMatterSpecialist the subjectMatterSpecialist to set
	 */
	public void setSubjectMatterSpecialist(String subjectMatterSpecialist) {
		this.subjectMatterSpecialist = subjectMatterSpecialist;
	}

	/**
	 * Gets the ticket count.
	 *
	 * @return the ticketCount
	 */
	public Object getTicketCount() {
		return ticketCount;
	}

	/**
	 * Sets the ticket count.
	 *
	 * @param ticketCount the ticketCount to set
	 */
	public void setTicketCount(Object ticketCount) {
		this.ticketCount = ticketCount;
	}

	/**
	 * Gets the reporteddate.
	 *
	 * @return the reporteddate
	 */
	public Date getReporteddate() {
		return Reporteddate;
	}

	/**
	 * Sets the reporteddate.
	 *
	 * @param reporteddate the reporteddate to set
	 */
	public void setReporteddate(Date reporteddate) {
		Reporteddate = reporteddate;
	}

	/**
	 * Gets the publication status.
	 *
	 * @return the publicationStatus
	 */
	public String getPublicationStatus() {
		return publicationStatus;
	}

	/**
	 * Sets the publication status.
	 *
	 * @param publicationStatus the publicationStatus to set
	 */
	public void setPublicationStatus(String publicationStatus) {
		this.publicationStatus = publicationStatus;
	}

	/**
	 * Gets the inc cause.
	 *
	 * @return the incCause
	 */
	public String getIncCause() {
		return incCause;
	}

	/**
	 * Sets the inc cause.
	 *
	 * @param incCause the incCause to set
	 */
	public void setIncCause(String incCause) {
		this.incCause = incCause;
	}
	
	
	
	
	
	/**
	 * @return the causeCodeLevel1
	 */
	public String getCauseCodeLevel1() {
		return causeCodeLevel1;
	}

	/**
	 * @param causeCodeLevel1 the causeCodeLevel1 to set
	 */
	public void setCauseCodeLevel1(String causeCodeLevel1) {
		this.causeCodeLevel1 = causeCodeLevel1;
	}

	/**
	 * @return the causeCodeLevel2
	 */
	public String getCauseCodeLevel2() {
		return causeCodeLevel2;
	}

	/**
	 * @param causeCodeLevel2 the causeCodeLevel2 to set
	 */
	public void setCauseCodeLevel2(String causeCodeLevel2) {
		this.causeCodeLevel2 = causeCodeLevel2;
	}

	/**
	 * @return the causeCodeLevel3
	 */
	public String getCauseCodeLevel3() {
		return causeCodeLevel3;
	}

	/**
	 * @param causeCodeLevel3 the causeCodeLevel3 to set
	 */
	public void setCauseCodeLevel3(String causeCodeLevel3) {
		this.causeCodeLevel3 = causeCodeLevel3;
	}

	/**
	 * @return the causeCodeLevel4
	 */
	public String getCauseCodeLevel4() {
		return causeCodeLevel4;
	}

	/**
	 * @param causeCodeLevel4 the causeCodeLevel4 to set
	 */
	public void setCauseCodeLevel4(String causeCodeLevel4) {
		this.causeCodeLevel4 = causeCodeLevel4;
	}

	/**
	 * @return the causeCodeLevel5
	 */
	public String getCauseCodeLevel5() {
		return causeCodeLevel5;
	}

	/**
	 * @param causeCodeLevel5 the causeCodeLevel5 to set
	 */
	public void setCauseCodeLevel5(String causeCodeLevel5) {
		this.causeCodeLevel5 = causeCodeLevel5;
	}

	/**
	 * 
	 * @return the String
	 */
	@Override
	public String toString() {
		return "TicketDataBean [SerialNumber=" + SerialNumber + ", ticketID=" + ticketID + ", KoID=" + KoID
				+ ", KOSingleTags=" + KOSingleTags + ", KOBigramTags=" + KOBigramTags + ", KOTrigramTags="
				+ KOTrigramTags + ", INCSingleTags=" + INCSingleTags + ", INCBigramTags=" + INCBigramTags
				+ ", INCTrigramTags=" + INCTrigramTags + ", kotags=" + kotags + ", incidentTags=" + incidentTags + "]";
	}
	
}
