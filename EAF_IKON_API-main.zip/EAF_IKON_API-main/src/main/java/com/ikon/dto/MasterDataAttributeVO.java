package com.ikon.dto;

/**
 * The Class MasterDataAttributeVO.
 */
public class MasterDataAttributeVO {
	
	/** The acc id. */
	private String accId;
	
	/** The app name. */
	private String appName;
	
	/** The assignment group. */
	private String assignmentGroup;
	
	/** The tower. */
	private String tower;
	
	/** The cc. */
	private String cc;
	
	/** The cluster. */
	private String cluster;
	
	/** The user id. */
	private String userId;
	
	/** The level 1. */
	private String level1;
	
	/** The level 2. */
	private String level2;
	
	/** The level 3. */
	private String level3;
	
	/** The from date. */
	private String fromDate;
	
	/** The to date. */
	private String toDate;
	
	/** The account name. */
	private String accountName;
	
	
	
	/**
	 * Instantiates a new master data attribute VO.
	 *
	 * @param accId the acc id
	 * @param appName the app name
	 * @param assignmentGroup the assignment group
	 * @param tower the tower
	 * @param cc the cc
	 * @param cluster the cluster
	 * @param userId the user id
	 */
	public MasterDataAttributeVO(String accId, String appName, String assignmentGroup, String tower, String cc,
			String cluster, String userId) {
		super();
		this.accId = accId;
		this.appName = appName;
		this.assignmentGroup = assignmentGroup;
		this.tower = tower;
		this.cc = cc;
		this.cluster = cluster;
		this.userId = userId;
	}
	
	/**
	 * Instantiates a new master data attribute VO.
	 */
	public MasterDataAttributeVO() {
		super();
	}

	
	/**
	 * Gets the account name.
	 *
	 * @return the account name
	 */
	public String getAccountName() {
		return accountName;
	}

	/**
	 * Sets the account name.
	 *
	 * @param accountName the new account name
	 */
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	/**
	 * Gets the user id.
	 *
	 * @return the user id
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * Sets the user id.
	 *
	 * @param userId the new user id
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * Gets the acc id.
	 *
	 * @return the acc id
	 */
	public String getAccId() {
		return accId;
	}
	
	/**
	 * Sets the acc id.
	 *
	 * @param accId the new acc id
	 */
	public void setAccId(String accId) {
		this.accId = accId;
	}
	
	/**
	 * Gets the app name.
	 *
	 * @return the app name
	 */
	public String getAppName() {
		return appName;
	}
	
	/**
	 * Sets the app name.
	 *
	 * @param appName the new app name
	 */
	public void setAppName(String appName) {
		this.appName = appName;
	}
	
	/**
	 * Gets the assignment group.
	 *
	 * @return the assignment group
	 */
	public String getAssignmentGroup() {
		return assignmentGroup;
	}
	
	/**
	 * Sets the assignment group.
	 *
	 * @param assignmentGroup the new assignment group
	 */
	public void setAssignmentGroup(String assignmentGroup) {
		this.assignmentGroup = assignmentGroup;
	}
	
	/**
	 * Gets the tower.
	 *
	 * @return the tower
	 */
	public String getTower() {
		return tower;
	}
	
	/**
	 * Sets the tower.
	 *
	 * @param tower the new tower
	 */
	public void setTower(String tower) {
		this.tower = tower;
	}
	
	/**
	 * Gets the cc.
	 *
	 * @return the cc
	 */
	public String getCc() {
		return cc;
	}
	
	/**
	 * Sets the cc.
	 *
	 * @param cc the new cc
	 */
	public void setCc(String cc) {
		this.cc = cc;
	}
	
	/**
	 * Gets the cluster.
	 *
	 * @return the cluster
	 */
	public String getCluster() {
		return cluster;
	}
	
	/**
	 * Sets the cluster.
	 *
	 * @param cluster the new cluster
	 */
	public void setCluster(String cluster) {
		this.cluster = cluster;
	}
	
	/**
	 * Gets the level 1.
	 *
	 * @return the level 1
	 */
	public String getLevel1() {
		return level1;
	}
	
	/**
	 * Sets the level 1.
	 *
	 * @param level1 the new level 1
	 */
	public void setLevel1(String level1) {
		this.level1 = level1;
	}
	
	/**
	 * Gets the level 2.
	 *
	 * @return the level 2
	 */
	public String getLevel2() {
		return level2;
	}
	
	/**
	 * Sets the level 2.
	 *
	 * @param level2 the new level 2
	 */
	public void setLevel2(String level2) {
		this.level2 = level2;
	}
	
	/**
	 * Gets the level 3.
	 *
	 * @return the level 3
	 */
	public String getLevel3() {
		return level3;
	}
	
	/**
	 * Sets the level 3.
	 *
	 * @param level3 the new level 3
	 */
	public void setLevel3(String level3) {
		this.level3 = level3;
	}
	
	/**
	 * Sets the all levels.
	 *
	 * @param level1 the level 1
	 * @param level2 the level 2
	 * @param level3 the level 3
	 */
	public void setAllLevels(String level1,String level2,String level3) {
		this.level1 = level1;
		this.level2 = level2;
		this.level3 = level3;
	}
	
	/**
	 * Gets the from date.
	 *
	 * @return the from date
	 */
	public String getFromDate() {
		return fromDate;
	}

	/**
	 * Sets the from date.
	 *
	 * @param fromDate the new from date
	 */
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	/**
	 * Gets the to date.
	 *
	 * @return the to date
	 */
	public String getToDate() {
		return toDate;
	}

	/**
	 * Sets the to date.
	 *
	 * @param toDate the new to date
	 */
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	
	/**
	 * Sets the from date todate.
	 *
	 * @param fromDate the from date
	 * @param toDate the to date
	 */
	public void setFromDateTodate(String fromDate,String toDate) {
		this.fromDate = fromDate;
		this.toDate = toDate;
	}
	
	
	

}
