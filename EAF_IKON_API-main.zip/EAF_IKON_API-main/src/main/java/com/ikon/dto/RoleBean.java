package com.ikon.dto;

import java.util.Date;

/**
 * The Class RoleBean.
 */
public class RoleBean {

	/** The rolecategory ID. */
	private Long rolecategoryID;

	/** The role category name. */
	private String roleCategoryName;

	/** The status. */
	private String status;

	/** The created date. */
	private Date createdDate;

	/** The created by. */
	private String createdBy;

	/** The modified date. */
	private Date modifiedDate;

	/** The modified by. */
	private String modifiedBy;

	/**
	 * Gets the rolecategory ID.
	 *
	 * @return the rolecategory ID
	 */
	public Long getRolecategoryID() {
		return rolecategoryID;
	}

	/**
	 * Sets the rolecategory ID.
	 *
	 * @param rolecategoryID the new rolecategory ID
	 */
	public void setRolecategoryID(Long rolecategoryID) {
		this.rolecategoryID = rolecategoryID;
	}

	/**
	 * Gets the role category name.
	 *
	 * @return the role category name
	 */
	public String getRoleCategoryName() {
		return roleCategoryName;
	}

	/**
	 * Sets the role category name.
	 *
	 * @param roleCategoryName the new role category name
	 */
	public void setRoleCategoryName(String roleCategoryName) {
		this.roleCategoryName = roleCategoryName;
	}

	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Sets the status.
	 *
	 * @param status the new status
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Gets the created date.
	 *
	 * @return the created date
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * Sets the created date.
	 *
	 * @param createdDate the new created date
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * Gets the created by.
	 *
	 * @return the created by
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * Sets the created by.
	 *
	 * @param createdBy the new created by
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * Gets the modified date.
	 *
	 * @return the modified date
	 */
	public Date getModifiedDate() {
		return modifiedDate;
	}

	/**
	 * Sets the modified date.
	 *
	 * @param modifiedDate the new modified date
	 */
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	/**
	 * Gets the modified by.
	 *
	 * @return the modified by
	 */
	public String getModifiedBy() {
		return modifiedBy;
	}

	/**
	 * Sets the modified by.
	 *
	 * @param modifiedBy the new modified by
	 */
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

}
