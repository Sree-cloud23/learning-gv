package com.ikon.dto;

/**
 * The Class TicketDataAttributeVO.
 */
public class TicketDataAttributeVO {
	
	/** The master dt attr vo. */
	private MasterDataAttributeVO masterDtAttrVo = new MasterDataAttributeVO();
	
	/** The ko dt attr. */
	private KoDataAttribute koDtAttr = new KoDataAttribute();
	
	/** The search dt attr vo. */
	private SearchDataAttributeVO searchDtAttrVo = new SearchDataAttributeVO();
	
	/** The assignee name. */
	private String assigneeName;
	
	/** The service type. */
	private String serviceType;
	
	/** The ticket id. */
	private String ticketId;
	
	/** The status. */
	private String status;
	
	/** The priority. */
	private String priority;
	
	/** The ko value. */
	private String koValue;
	
	/** The search type. */
	private String searchType;
	
	
	/**
	 * Gets the search type.
	 *
	 * @return the search type
	 */
	public String getSearchType() {
		return searchType;
	}
	
	/**
	 * Sets the search type.
	 *
	 * @param searchType the new search type
	 */
	public void setSearchType(String searchType) {
		this.searchType = searchType;
	}
	
	/**
	 * Gets the master dt attr vo.
	 *
	 * @return the master dt attr vo
	 */
	public MasterDataAttributeVO getMasterDtAttrVo() {
		return masterDtAttrVo;
	}
	
	/**
	 * Sets the master dt attr vo.
	 *
	 * @param masterDtAttrVo the new master dt attr vo
	 */
	public void setMasterDtAttrVo(MasterDataAttributeVO masterDtAttrVo) {
		this.masterDtAttrVo = masterDtAttrVo;
	}
	
	/**
	 * Gets the ko dt attr.
	 *
	 * @return the ko dt attr
	 */
	public KoDataAttribute getKoDtAttr() {
		return koDtAttr;
	}
	
	/**
	 * Sets the ko dt attr.
	 *
	 * @param koDtAttr the new ko dt attr
	 */
	public void setKoDtAttr(KoDataAttribute koDtAttr) {
		this.koDtAttr = koDtAttr;
	}
	
	/**
	 * Gets the assignee name.
	 *
	 * @return the assignee name
	 */
	public String getAssigneeName() {
		return assigneeName;
	}
	
	/**
	 * Sets the assignee name.
	 *
	 * @param assigneeName the new assignee name
	 */
	public void setAssigneeName(String assigneeName) {
		this.assigneeName = assigneeName;
	}
	
	/**
	 * Gets the service type.
	 *
	 * @return the service type
	 */
	public String getServiceType() {
		return serviceType;
	}
	
	/**
	 * Sets the service type.
	 *
	 * @param serviceType the new service type
	 */
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	
	/**
	 * Gets the ticket id.
	 *
	 * @return the ticket id
	 */
	public String getTicketId() {
		return ticketId;
	}
	
	/**
	 * Sets the ticket id.
	 *
	 * @param ticketId the new ticket id
	 */
	public void setTicketId(String ticketId) {
		this.ticketId = ticketId;
	}
	
	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	
	/**
	 * Sets the status.
	 *
	 * @param status the new status
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	
	/**
	 * Gets the priority.
	 *
	 * @return the priority
	 */
	public String getPriority() {
		return priority;
	}
	
	/**
	 * Sets the priority.
	 *
	 * @param priority the new priority
	 */
	public void setPriority(String priority) {
		this.priority = priority;
	}
	
	/**
	 * Gets the ko value.
	 *
	 * @return the ko value
	 */
	public String getKoValue() {
		return koValue;
	}
	
	/**
	 * Sets the ko value.
	 *
	 * @param koValue the new ko value
	 */
	public void setKoValue(String koValue) {
		this.koValue = koValue;
	}
	
	/**
	 * Gets the search dt attr vo.
	 *
	 * @return the search dt attr vo
	 */
	public SearchDataAttributeVO getSearchDtAttrVo() {
		return searchDtAttrVo;
	}
	
	/**
	 * Sets the search dt attr vo.
	 *
	 * @param searchDtAttrVo the new search dt attr vo
	 */
	public void setSearchDtAttrVo(SearchDataAttributeVO searchDtAttrVo) {
		this.searchDtAttrVo = searchDtAttrVo;
	}
	
	
	
}