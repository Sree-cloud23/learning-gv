/**
 * 
 */
package com.ikon.dto;

/**
 * The Class ComplianceBean.
 *
 * @author Tools n Methods
 */
public class ComplianceBean {
	
	/** The tower. */
	private String tower;
	
	/** The cc. */
	private String cc;
	
	/** The cluster. */
	private String cluster;
	
	/** The group. */
	private String group;
	
	/** The inc resolved. */
	private String incResolved;
	
	/** The sr resolved. */
	private String srResolved;
	
	/** The total resolved. */
	private String totalResolved;
	
	/** The ko created. */
	private String koCreated;
	
	/** The ko linked. */
	private String koLinked;
	
	/** The res vs linked. */
	private String resVsLinked;
	
	/** The assignment group. */
	private String assignmentGroup;
	
	/** The application Name. */
	private String applicationName;
	/** The Months Name. */
	private String months;
	
 
	/**
	 * @return
	 */
	public String getMonths() {
		return months;
	}

	/**
	 * @param months
	 */
	public void setMonths(String months) {
		this.months = months;
	}

	/**
	 * Gets the group.
	 *
	 * @return the group
	 */
	public String getGroup() {
		return group;
	}

	/**
	 * Sets the group.
	 *
	 * @param group the new group
	 */
	public void setGroup(String group) {
		this.group = group;
	}

	/**
	 * Gets the inc resolved.
	 *
	 * @return the inc resolved
	 */
	public String getIncResolved() {
		return incResolved;
	}

	/**
	 * Sets the inc resolved.
	 *
	 * @param incResolved the new inc resolved
	 */
	public void setIncResolved(String incResolved) {
		this.incResolved = incResolved;
	}

	/**
	 * Gets the sr resolved.
	 *
	 * @return the sr resolved
	 */
	public String getSrResolved() {
		return srResolved;
	}

	/**
	 * Sets the sr resolved.
	 *
	 * @param srResolved the new sr resolved
	 */
	public void setSrResolved(String srResolved) {
		this.srResolved = srResolved;
	}

	/**
	 * Gets the total resolved.
	 *
	 * @return the total resolved
	 */
	public String getTotalResolved() {
		return totalResolved;
	}

	/**
	 * Sets the total resolved.
	 *
	 * @param totalResolved the new total resolved
	 */
	public void setTotalResolved(String totalResolved) {
		this.totalResolved = totalResolved;
	}

	/**
	 * Gets the ko created.
	 *
	 * @return the ko created
	 */
	public String getKoCreated() {
		return koCreated;
	}

	/**
	 * Sets the ko created.
	 *
	 * @param koCreated the new ko created
	 */
	public void setKoCreated(String koCreated) {
		this.koCreated = koCreated;
	}

	/**
	 * Gets the ko linked.
	 *
	 * @return the ko linked
	 */
	public String getKoLinked() {
		return koLinked;
	}

	/**
	 * Sets the ko linked.
	 *
	 * @param koLinked the new ko linked
	 */
	public void setKoLinked(String koLinked) {
		this.koLinked = koLinked;
	}

	/**
	 * Gets the res vs linked.
	 *
	 * @return the res vs linked
	 */
	public String getResVsLinked() {
		return resVsLinked;
	}

	/**
	 * Sets the res vs linked.
	 *
	 * @param resVsLinked the new res vs linked
	 */
	public void setResVsLinked(String resVsLinked) {
		this.resVsLinked = resVsLinked;
	}
	
	/**
	 * Gets the tower.
	 *
	 * @return the tower
	 */
	public String getTower() {
		return tower;
	}

	/**
	 * Sets the tower.
	 *
	 * @param tower the new tower
	 */
	public void setTower(String tower) {
		this.tower = tower;
	}

	/**
	 * Gets the cc.
	 *
	 * @return the cc
	 */
	public String getCc() {
		return cc;
	}

	/**
	 * Sets the cc.
	 *
	 * @param cc the new cc
	 */
	public void setCc(String cc) {
		this.cc = cc;
	}

	/**
	 * Gets the cluster.
	 *
	 * @return the cluster
	 */
	public String getCluster() {
		return cluster;
	}

	/**
	 * Sets the cluster.
	 *
	 * @param cluster the new cluster
	 */
	public void setCluster(String cluster) {
		this.cluster = cluster;
	}

	
	/**
	 * Gets the assignment group.
	 *
	 * @return the assignment group
	 */
	public String getAssignmentGroup() {
		return assignmentGroup;
	}
	/**
	 * Sets the assignment group.
	 *
	 * @param assignmentGroup the new assignment group
	 */
	public void setAssignmentGroup(String assignmentGroup) {
		this.assignmentGroup = assignmentGroup;
	}
	/**
	 * Gets the application name.
	 *
	 * @return the application name
	 */
	public String getApplicationName() {
		return applicationName;
	}
	/**
	 * Sets the application name.
	 *
	 * @param applicationName the new application name
	 */
	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}

	/**
	 * 
	 * @return
	 */
	@Override
	public String toString() {
		return "ComplianceBean [group=" + group + ", incResolved=" + incResolved + ", srResolved=" + srResolved
				+ ", totalResolved=" + totalResolved + ", koCreated=" + koCreated + ", koLinked=" + koLinked
				+ ", resVsLinked=" + resVsLinked + "]";
	}

	/**
	 * Instantiates a new compliance bean.
	 *
	 * @param group the group
	 * @param incResolved the inc resolved
	 * @param srResolved the sr resolved
	 * @param totalResolved the total resolved
	 * @param koCreated the ko created
	 * @param koLinked the ko linked
	 * @param resVsLinked the res vs linked
	 */

	public ComplianceBean(String tower, String cc, String cluster, String group, String incResolved, String srResolved,
			String totalResolved, String koCreated, String koLinked, String resVsLinked, String assignmentGroup,
			String applicationName) {
		super();
		this.tower = tower;
		this.cc = cc;
		this.cluster = cluster;
		this.group = group;
		this.incResolved = incResolved;
		this.srResolved = srResolved;
		this.totalResolved = totalResolved;
		this.koCreated = koCreated;
		this.koLinked = koLinked;
		this.resVsLinked = resVsLinked;
		this.assignmentGroup = assignmentGroup;
		this.applicationName = applicationName;
	}

	/**
	 * Instantiates a new compliance bean.
	 */
	public ComplianceBean() {
		super();
	}
	
	

}
