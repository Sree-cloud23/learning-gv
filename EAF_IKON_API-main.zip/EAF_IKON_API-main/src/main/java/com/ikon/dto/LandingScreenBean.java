package com.ikon.dto;

import java.util.Date;

/**
 * The Class LandingScreenBean.
 */
public class LandingScreenBean {

	/** The id. */
	private int ID;

	/** The User id. */
	private String UserId;

	/** The Name. */
	private String Name;

	/** The Email. */
	private String Email;

	/** The Default account ID. */
	private int DefaultAccountID;

	/** The Account name. */
	private String AccountName;

	/** The Access ID. */
	private int AccessID;

	/** The Profile ID. */
	private int ProfileID;

	/** The Role id. */
	private int RoleId;

	/** The Settings ID. */
	private int SettingsID;

	/** The Color theme ID. */
	private int ColorThemeID;

	/** The Last query ID. */
	private int LastQueryID;

	/** The Default landing page. */
	private int DefaultLandingPage;

	/** The Ticket ID. */
	private String TicketID;

	/** The Application name. */
	private String ApplicationName;

	/** The Assignment group. */
	private String AssignmentGroup;

	/** The Assignee name. */
	private String AssigneeName;

	/** The Ticket status. */
	private String TicketStatus;

	/** The Priority. */
	private String Priority;

	/** The Reported date. */
	private Date ReportedDate;

	/** The Last modified by. */
	private String LastModifiedBy;

	/** The Last modified date. */
	private Date LastModifiedDate;

	/** The Resolved date. */
	private Date ResolvedDate;

	/** The Notes. */
	private String Notes;

	/** The Summary. */
	private String Summary;

	/** The Closed date. */
	private Date ClosedDate;

	/** The Closed by. */
	private String ClosedBy;

	/** The Resolution note. */
	private String ResolutionNote;

	/** The Servicetype. */
	private String Servicetype;

	/** The Company. */
	private String Company;

	/** The Category. */
	private String Category;

	/** The Subcategory. */
	private String Subcategory;

	/** The Urgency. */
	private String Urgency;

	/** The Impact. */
	private String Impact;

	/** The Worknotes. */
	private String Worknotes;

	/** The Opened by. */
	private String OpenedBy;

	/** The Next target date. */
	private Date NextTargetDate;

	/** The Status reason. */
	private String StatusReason;

	/** The Relev perc. */
	private String RelevPerc;

	/** The Usage perc. */
	private String UsagePerc;

	/** The status. */
	private String status;

	/** The Landing page. */
	String LandingPage;

	/**
	 * Gets the landing page.
	 *
	 * @return the landing page
	 */
	public String getLandingPage() {
		return LandingPage;
	}

	/**
	 * Sets the landing page.
	 *
	 * @param landingPage the new landing page
	 */
	public void setLandingPage(String landingPage) {
		LandingPage = landingPage;
	}

	/**
	 * Gets the user id.
	 *
	 * @return the user id
	 */
	public String getUserId() {
		return UserId;
	}

	/**
	 * Sets the user id.
	 *
	 * @param userId the new user id
	 */
	public void setUserId(String userId) {
		UserId = userId;
	}

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return Name;
	}

	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {
		Name = name;
	}

	/**
	 * Gets the email.
	 *
	 * @return the email
	 */
	public String getEmail() {
		return Email;
	}

	/**
	 * Sets the email.
	 *
	 * @param email the new email
	 */
	public void setEmail(String email) {
		Email = email;
	}

	/**
	 * Gets the default account ID.
	 *
	 * @return the default account ID
	 */
	public int getDefaultAccountID() {
		return DefaultAccountID;
	}

	/**
	 * Sets the default account ID.
	 *
	 * @param defaultAccountID the new default account ID
	 */
	public void setDefaultAccountID(int defaultAccountID) {
		DefaultAccountID = defaultAccountID;
	}

	/**
	 * Gets the account name.
	 *
	 * @return the account name
	 */
	public String getAccountName() {
		return AccountName;
	}

	/**
	 * Sets the account name.
	 *
	 * @param accountName the new account name
	 */
	public void setAccountName(String accountName) {
		AccountName = accountName;
	}

	/**
	 * Gets the access ID.
	 *
	 * @return the access ID
	 */
	public int getAccessID() {
		return AccessID;
	}

	/**
	 * Sets the access ID.
	 *
	 * @param accessID the new access ID
	 */
	public void setAccessID(int accessID) {
		AccessID = accessID;
	}

	/**
	 * Gets the profile ID.
	 *
	 * @return the profile ID
	 */
	public int getProfileID() {
		return ProfileID;
	}

	/**
	 * Sets the profile ID.
	 *
	 * @param profileID the new profile ID
	 */
	public void setProfileID(int profileID) {
		ProfileID = profileID;
	}

	/**
	 * Gets the role id.
	 *
	 * @return the role id
	 */
	public int getRoleId() {
		return RoleId;
	}

	/**
	 * Sets the role id.
	 *
	 * @param roleId the new role id
	 */
	public void setRoleId(int roleId) {
		RoleId = roleId;
	}

	/**
	 * Gets the settings ID.
	 *
	 * @return the settings ID
	 */
	public int getSettingsID() {
		return SettingsID;
	}

	/**
	 * Sets the settings ID.
	 *
	 * @param settingsID the new settings ID
	 */
	public void setSettingsID(int settingsID) {
		SettingsID = settingsID;
	}

	/**
	 * Gets the color theme ID.
	 *
	 * @return the color theme ID
	 */
	public int getColorThemeID() {
		return ColorThemeID;
	}

	/**
	 * Sets the color theme ID.
	 *
	 * @param colorThemeID the new color theme ID
	 */
	public void setColorThemeID(int colorThemeID) {
		ColorThemeID = colorThemeID;
	}

	/**
	 * Gets the last query ID.
	 *
	 * @return the last query ID
	 */
	public int getLastQueryID() {
		return LastQueryID;
	}

	/**
	 * Sets the last query ID.
	 *
	 * @param lastQueryID the new last query ID
	 */
	public void setLastQueryID(int lastQueryID) {
		LastQueryID = lastQueryID;
	}

	/**
	 * Gets the default landing page.
	 *
	 * @return the default landing page
	 */
	public int getDefaultLandingPage() {
		return DefaultLandingPage;
	}

	/**
	 * Sets the default landing page.
	 *
	 * @param defaultLandingPage the new default landing page
	 */
	public void setDefaultLandingPage(int defaultLandingPage) {
		DefaultLandingPage = defaultLandingPage;
	}

	/**
	 * Gets the ticket ID.
	 *
	 * @return the ticket ID
	 */
	public String getTicketID() {
		return TicketID;
	}

	/**
	 * Sets the ticket ID.
	 *
	 * @param ticketID the new ticket ID
	 */
	public void setTicketID(String ticketID) {
		TicketID = ticketID;
	}

	/**
	 * Gets the application name.
	 *
	 * @return the application name
	 */
	public String getApplicationName() {
		return ApplicationName;
	}

	/**
	 * Sets the application name.
	 *
	 * @param applicationName the new application name
	 */
	public void setApplicationName(String applicationName) {
		ApplicationName = applicationName;
	}

	/**
	 * Gets the assignment group.
	 *
	 * @return the assignment group
	 */
	public String getAssignmentGroup() {
		return AssignmentGroup;
	}

	/**
	 * Sets the assignment group.
	 *
	 * @param assignmentGroup the new assignment group
	 */
	public void setAssignmentGroup(String assignmentGroup) {
		AssignmentGroup = assignmentGroup;
	}

	/**
	 * Gets the assignee name.
	 *
	 * @return the assignee name
	 */
	public String getAssigneeName() {
		return AssigneeName;
	}

	/**
	 * Sets the assignee name.
	 *
	 * @param assigneeName the new assignee name
	 */
	public void setAssigneeName(String assigneeName) {
		AssigneeName = assigneeName;
	}

	/**
	 * Gets the ticket status.
	 *
	 * @return the ticket status
	 */
	public String getTicketStatus() {
		return TicketStatus;
	}

	/**
	 * Sets the ticket status.
	 *
	 * @param ticketStatus the new ticket status
	 */
	public void setTicketStatus(String ticketStatus) {
		TicketStatus = ticketStatus;
	}

	/**
	 * Gets the priority.
	 *
	 * @return the priority
	 */
	public String getPriority() {
		return Priority;
	}

	/**
	 * Sets the priority.
	 *
	 * @param priority the new priority
	 */
	public void setPriority(String priority) {
		Priority = priority;
	}

	/**
	 * Gets the notes.
	 *
	 * @return the notes
	 */
	public String getNotes() {
		return Notes;
	}

	/**
	 * Sets the notes.
	 *
	 * @param notes the new notes
	 */
	public void setNotes(String notes) {
		Notes = notes;
	}

	/**
	 * Gets the summary.
	 *
	 * @return the summary
	 */
	public String getSummary() {
		return Summary;
	}

	/**
	 * Sets the summary.
	 *
	 * @param summary the new summary
	 */
	public void setSummary(String summary) {
		Summary = summary;
	}

	/**
	 * Gets the closed by.
	 *
	 * @return the closed by
	 */
	public String getClosedBy() {
		return ClosedBy;
	}

	/**
	 * Sets the closed by.
	 *
	 * @param closedBy the new closed by
	 */
	public void setClosedBy(String closedBy) {
		ClosedBy = closedBy;
	}

	/**
	 * Gets the resolution note.
	 *
	 * @return the resolution note
	 */
	public String getResolutionNote() {
		return ResolutionNote;
	}

	/**
	 * Sets the resolution note.
	 *
	 * @param resolutionNote the new resolution note
	 */
	public void setResolutionNote(String resolutionNote) {
		ResolutionNote = resolutionNote;
	}

	/**
	 * Gets the servicetype.
	 *
	 * @return the servicetype
	 */
	public String getServicetype() {
		return Servicetype;
	}

	/**
	 * Sets the servicetype.
	 *
	 * @param servicetype the new servicetype
	 */
	public void setServicetype(String servicetype) {
		Servicetype = servicetype;
	}

	/**
	 * Gets the company.
	 *
	 * @return the company
	 */
	public String getCompany() {
		return Company;
	}

	/**
	 * Sets the company.
	 *
	 * @param company the new company
	 */
	public void setCompany(String company) {
		Company = company;
	}

	/**
	 * Gets the category.
	 *
	 * @return the category
	 */
	public String getCategory() {
		return Category;
	}

	/**
	 * Sets the category.
	 *
	 * @param category the new category
	 */
	public void setCategory(String category) {
		Category = category;
	}

	/**
	 * Gets the subcategory.
	 *
	 * @return the subcategory
	 */
	public String getSubcategory() {
		return Subcategory;
	}

	/**
	 * Sets the subcategory.
	 *
	 * @param subcategory the new subcategory
	 */
	public void setSubcategory(String subcategory) {
		Subcategory = subcategory;
	}

	/**
	 * Gets the urgency.
	 *
	 * @return the urgency
	 */
	public String getUrgency() {
		return Urgency;
	}

	/**
	 * Sets the urgency.
	 *
	 * @param urgency the new urgency
	 */
	public void setUrgency(String urgency) {
		Urgency = urgency;
	}

	/**
	 * Gets the impact.
	 *
	 * @return the impact
	 */
	public String getImpact() {
		return Impact;
	}

	/**
	 * Sets the impact.
	 *
	 * @param impact the new impact
	 */
	public void setImpact(String impact) {
		Impact = impact;
	}

	/**
	 * Gets the worknotes.
	 *
	 * @return the worknotes
	 */
	public String getWorknotes() {
		return Worknotes;
	}

	/**
	 * Sets the worknotes.
	 *
	 * @param worknotes the new worknotes
	 */
	public void setWorknotes(String worknotes) {
		Worknotes = worknotes;
	}

	/**
	 * Gets the opened by.
	 *
	 * @return the opened by
	 */
	public String getOpenedBy() {
		return OpenedBy;
	}

	/**
	 * Sets the opened by.
	 *
	 * @param openedBy the new opened by
	 */
	public void setOpenedBy(String openedBy) {
		OpenedBy = openedBy;
	}

	/**
	 * Gets the next target date.
	 *
	 * @return the next target date
	 */
	public Date getNextTargetDate() {
		return NextTargetDate;
	}

	/**
	 * Sets the next target date.
	 *
	 * @param nextTargetDate the new next target date
	 */
	public void setNextTargetDate(Date nextTargetDate) {
		NextTargetDate = nextTargetDate;
	}

	/**
	 * Gets the status reason.
	 *
	 * @return the status reason
	 */
	public String getStatusReason() {
		return StatusReason;
	}

	/**
	 * Sets the status reason.
	 *
	 * @param statusReason the new status reason
	 */
	public void setStatusReason(String statusReason) {
		StatusReason = statusReason;
	}

	/**
	 * Gets the relev perc.
	 *
	 * @return the relev perc
	 */
	public String getRelevPerc() {
		return RelevPerc;
	}

	/**
	 * Sets the relev perc.
	 *
	 * @param relevPerc the new relev perc
	 */
	public void setRelevPerc(String relevPerc) {
		RelevPerc = relevPerc;
	}

	/**
	 * Gets the usage perc.
	 *
	 * @return the usage perc
	 */
	public String getUsagePerc() {
		return UsagePerc;
	}

	/**
	 * Sets the usage perc.
	 *
	 * @param usagePerc the new usage perc
	 */
	public void setUsagePerc(String usagePerc) {
		UsagePerc = usagePerc;
	}

	/**
	 * Gets the reported date.
	 *
	 * @return the reported date
	 */
	public Date getReportedDate() {
		return ReportedDate;
	}

	/**
	 * Sets the reported date.
	 *
	 * @param reportedDate the new reported date
	 */
	public void setReportedDate(Date reportedDate) {
		ReportedDate = reportedDate;
	}

	/**
	 * Gets the last modified by.
	 *
	 * @return the last modified by
	 */
	public String getLastModifiedBy() {
		return LastModifiedBy;
	}

	/**
	 * Sets the last modified by.
	 *
	 * @param lastModifiedBy the new last modified by
	 */
	public void setLastModifiedBy(String lastModifiedBy) {
		LastModifiedBy = lastModifiedBy;
	}

	/**
	 * Gets the last modified date.
	 *
	 * @return the last modified date
	 */
	public Date getLastModifiedDate() {
		return LastModifiedDate;
	}

	/**
	 * Sets the last modified date.
	 *
	 * @param lastModifiedDate the new last modified date
	 */
	public void setLastModifiedDate(Date lastModifiedDate) {
		LastModifiedDate = lastModifiedDate;
	}

	/**
	 * Gets the resolved date.
	 *
	 * @return the resolved date
	 */
	public Date getResolvedDate() {
		return ResolvedDate;
	}

	/**
	 * Sets the resolved date.
	 *
	 * @param resolvedDate the new resolved date
	 */
	public void setResolvedDate(Date resolvedDate) {
		ResolvedDate = resolvedDate;
	}

	/**
	 * Gets the closed date.
	 *
	 * @return the closed date
	 */
	public Date getClosedDate() {
		return ClosedDate;
	}

	/**
	 * Sets the closed date.
	 *
	 * @param closedDate the new closed date
	 */
	public void setClosedDate(Date closedDate) {
		ClosedDate = closedDate;
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getID() {
		return ID;
	}

	/**
	 * Sets the id.
	 *
	 * @param iD the new id
	 */
	public void setID(int iD) {
		ID = iD;
	}

	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Sets the status.
	 *
	 * @param status the new status
	 */
	public void setStatus(String status) {
		this.status = status;
	}
}
