package com.ikon.dto;

import java.util.Date;

/**
 * The Class UserBean.
 */
public class UserBean {

	/** The Username. */
	private String Username;

	/** The Password. */
	private String Password;

	/** The Resourcename. */
	private String Resourcename;

	/** The Email ID. */
	private String Email_ID;

	/** The Contact no. */
	private String Contact_no;

	/** The Account name. */
	private String Account_Name;

	/** The Status. */
	private long Status;

	/** The id. */
	int ID;

	/** The user ID. */
	private String userID;

	/** The name. */
	private String name;

	/** The Email. */
	String Email;

	/** The Reset token. */
	String ResetToken;

	/** The Attempts. */
	int Attempts;

	/** The Created date. */
	String CreatedDate;

	/** The Created by. */
	String CreatedBy;

	/** The Modified date. */
	String ModifiedDate;

	/** The Modified by. */
	String ModifiedBy;

	/** The logged in date. */
	Date loggedInDate;

	/** The from date. */
	private String fromDate;

	/** The to date. */
	private String toDate;
	
	/** The to isGeneric. */
	private Integer isGeneric =0;
	
	
	/**
	 * Gets the isGeneric.
	 *
	 * @return the isGeneric
	 */
	public Integer getIsGeneric() {
		return isGeneric;
	}

	/**
	 * Sets the isGeneric.
	 *
	 * @param isGeneric the new checks if is generic
	 */
	public void setIsGeneric(Integer isGeneric) {
		this.isGeneric = isGeneric;
	}

	/**
	 * Gets the from date.
	 *
	 * @return the from date
	 */
	public String getFromDate() {
		return fromDate;
	}

	/**
	 * Sets the from date.
	 *
	 * @param fromDate the new from date
	 */
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	/**
	 * Gets the to date.
	 *
	 * @return the to date
	 */
	public String getToDate() {
		return toDate;
	}

	/**
	 * Sets the to date.
	 *
	 * @param toDate the new to date
	 */
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getID() {
		return ID;
	}

	/**
	 * Sets the id.
	 *
	 * @param iD the new id
	 */
	public void setID(int iD) {
		ID = iD;
	}

	/**
	 * Gets the user ID.
	 *
	 * @return the user ID
	 */
	public String getUserID() {
		return userID;
	}

	/**
	 * Sets the user ID.
	 *
	 * @param userID the new user ID
	 */
	public void setUserID(String userID) {
		this.userID = userID;
	}

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Gets the email.
	 *
	 * @return the email
	 */
	public String getEmail() {
		return Email;
	}

	/**
	 * Sets the email.
	 *
	 * @param email the new email
	 */
	public void setEmail(String email) {
		Email = email;
	}

	/**
	 * Gets the reset token.
	 *
	 * @return the reset token
	 */
	public String getResetToken() {
		return ResetToken;
	}

	/**
	 * Sets the reset token.
	 *
	 * @param resetToken the new reset token
	 */
	public void setResetToken(String resetToken) {
		ResetToken = resetToken;
	}

	/**
	 * Gets the attempts.
	 *
	 * @return the attempts
	 */
	public int getAttempts() {
		return Attempts;
	}

	/**
	 * Sets the attempts.
	 *
	 * @param attempts the new attempts
	 */
	public void setAttempts(int attempts) {
		Attempts = attempts;
	}

	/**
	 * Gets the created date.
	 *
	 * @return the created date
	 */
	public String getCreatedDate() {
		return CreatedDate;
	}

	/**
	 * Sets the created date.
	 *
	 * @param createdDate the new created date
	 */
	public void setCreatedDate(String createdDate) {
		CreatedDate = createdDate;
	}

	/**
	 * Gets the created by.
	 *
	 * @return the created by
	 */
	public String getCreatedBy() {
		return CreatedBy;
	}

	/**
	 * Sets the created by.
	 *
	 * @param createdBy the new created by
	 */
	public void setCreatedBy(String createdBy) {
		CreatedBy = createdBy;
	}

	/**
	 * Gets the modified date.
	 *
	 * @return the modified date
	 */
	public String getModifiedDate() {
		return ModifiedDate;
	}

	/**
	 * Sets the modified date.
	 *
	 * @param modifiedDate the new modified date
	 */
	public void setModifiedDate(String modifiedDate) {
		ModifiedDate = modifiedDate;
	}

	/**
	 * Gets the modified by.
	 *
	 * @return the modified by
	 */
	public String getModifiedBy() {
		return ModifiedBy;
	}

	/**
	 * Sets the modified by.
	 *
	 * @param modifiedBy the new modified by
	 */
	public void setModifiedBy(String modifiedBy) {
		ModifiedBy = modifiedBy;
	}

	/**
	 * Gets the account name.
	 *
	 * @return the account name
	 */
	public String getAccount_Name() {
		return Account_Name;
	}

	/**
	 * Sets the account name.
	 *
	 * @param account_Name the new account name
	 */
	public void setAccount_Name(String account_Name) {
		Account_Name = account_Name;
	}

	/**
	 * Gets the username.
	 *
	 * @return the username
	 */
	public String getUsername() {
		return Username;
	}

	/**
	 * Sets the username.
	 *
	 * @param username the new username
	 */
	public void setUsername(String username) {
		Username = username;
	}

	/**
	 * Gets the password.
	 *
	 * @return the password
	 */
	public String getPassword() {
		return Password;
	}

	/**
	 * Sets the password.
	 *
	 * @param password the new password
	 */
	public void setPassword(String password) {
		Password = password;
	}

	/**
	 * Gets the resourcename.
	 *
	 * @return the resourcename
	 */
	public String getResourcename() {
		return Resourcename;
	}

	/**
	 * Sets the resourcename.
	 *
	 * @param resourcename the new resourcename
	 */
	public void setResourcename(String resourcename) {
		Resourcename = resourcename;
	}

	/**
	 * Gets the email ID.
	 *
	 * @return the email ID
	 */
	public String getEmail_ID() {
		return Email_ID;
	}

	/**
	 * Sets the email ID.
	 *
	 * @param email_ID the new email ID
	 */
	public void setEmail_ID(String email_ID) {
		Email_ID = email_ID;
	}

	/**
	 * Gets the contact no.
	 *
	 * @return the contact no
	 */
	public String getContact_no() {
		return Contact_no;
	}

	/**
	 * Sets the contact no.
	 *
	 * @param contact_no the new contact no
	 */
	public void setContact_no(String contact_no) {
		Contact_no = contact_no;
	}

	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public long getStatus() {
		return Status;
	}

	/**
	 * Sets the status.
	 *
	 * @param status the new status
	 */
	public void setStatus(long status) {
		Status = status;
	}

	/**
	 * Gets the logged in date.
	 *
	 * @return the logged in date
	 */
	public Date getLoggedInDate() {
		return loggedInDate;
	}

	/**
	 * Sets the logged in date.
	 *
	 * @param loggedInDate the new logged in date
	 */
	public void setLoggedInDate(Date loggedInDate) {
		this.loggedInDate = loggedInDate;
	}

}