package com.ikon.dto;

import java.math.BigDecimal;
import java.math.BigInteger;

public class AgeingWorkinfoBean {
	
	private String tower;
	private String cc;
	private String cluster;
	private String applicationName;
	private String assignmentGroup;
	private BigInteger totalTicketCount;
	private BigInteger incUpdateCount;
	private BigDecimal incUpdatePerc;
	private String incidentId;
	private String summary;
	private String assignee;
	private String reportedDate;
	private String priority;
	private String status;
	private String modifiedDate;
	private String ageing;
	private String modifiedBy;
	private String serviceType;
	
	public String getTower() {
		return tower;
	}
	public void setTower(String tower) {
		this.tower = tower;
	}
	public String getCc() {
		return cc;
	}
	public void setCc(String cc) {
		this.cc = cc;
	}
	public String getCluster() {
		return cluster;
	}
	public void setCluster(String cluster) {
		this.cluster = cluster;
	}
	public String getApplicationName() {
		return applicationName;
	}
	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}
	public String getAssignmentGroup() {
		return assignmentGroup;
	}
	public void setAssignmentGroup(String assignmentGroup) {
		this.assignmentGroup = assignmentGroup;
	}
	public BigInteger getTotalTicketCount() {
		return totalTicketCount;
	}
	public void setTotalTicketCount(BigInteger totalTicketCount) {
		this.totalTicketCount = totalTicketCount;
	}
	public BigInteger getIncUpdateCount() {
		return incUpdateCount;
	}
	public void setIncUpdateCount(BigInteger incUpdateCount) {
		this.incUpdateCount = incUpdateCount;
	}
	public BigDecimal getIncUpdatePerc() {
		return incUpdatePerc;
	}
	public void setIncUpdatePerc(BigDecimal incUpdatePerc) {
		this.incUpdatePerc = incUpdatePerc;
	}
	public String getIncidentId() {
		return incidentId;
	}
	public void setIncidentId(String incidentId) {
		this.incidentId = incidentId;
	}
	public String getSummary() {
		return summary;
	}
	public void setSummary(String summary) {
		this.summary = summary;
	}
	public String getAssignee() {
		return assignee;
	}
	public void setAssignee(String assignee) {
		this.assignee = assignee;
	}
	public String getReportedDate() {
		return reportedDate;
	}
	public void setReportedDate(String reportedDate) {
		this.reportedDate = reportedDate;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getAgeing() {
		return ageing;
	}
	public void setAgeing(String ageing) {
		this.ageing = ageing;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	
	
}
