package com.ikon.dto;

/**
 * The Class SearchDataAttributeVO.
 */
public class SearchDataAttributeVO {
	
	/** The search. */
	private String search;
	
	/** The searchid. */
	private String searchid;
	
	/**
	 * Gets the search.
	 *
	 * @return the search
	 */
	public String getSearch() {
		return search;
	}
	
	/**
	 * Sets the search.
	 *
	 * @param search the new search
	 */
	public void setSearch(String search) {
		this.search = search;
	}
	
	/**
	 * Gets the searchid.
	 *
	 * @return the searchid
	 */
	public String getSearchid() {
		return searchid;
	}
	
	/**
	 * Sets the searchid.
	 *
	 * @param searchid the new searchid
	 */
	public void setSearchid(String searchid) {
		this.searchid = searchid;
	}
	
	

}
