
package com.ikon.dto;

/**
 * The Class Item.
 */
public class Item {

	/** The Tower. */
	private String Tower;

	/** The cc. */
	private String CC;

	/** The Cluster. */
	private String Cluster;

	/** The Application name. */
	private String ApplicationName;

	/** The Assignment group. */
	private String AssignmentGroup;

	/** The Ko count. */
	private Object KoCount;

	/** The Linked. */
	private Object Linked;

	/** The Not linked. */
	private Object Not_Linked;
	/** The TicketMonth. */
	private String TicketMonth;
	/** The ticketCount. */
	private Object ticketCount;
	/** The allIncidentsmttr. */
	private Object allIncidentsmttr;
	/** The ticketLinkedCount. */
	private Object ticketLinkedCount;
	/** The linkedTicketsmttr. */
	private Object linkedTicketsmttr;

	/**
	 * Instantiates a new item.
	 *
	 * @param Tower           the tower
	 * @param CC              the cc
	 * @param Cluster         the cluster
	 * @param AssignmentGroup the assignment group
	 * @param ApplicationName the application name
	 * @param KoCount         the ko count
	 */
	public Item(String Tower, String CC, String Cluster, String AssignmentGroup, String ApplicationName,
			Object KoCount) {
		// TODO Auto-generated constructor stub

		this.Tower = Tower;
		this.CC = CC;
		this.Cluster = Cluster;
		this.ApplicationName = ApplicationName;
		this.AssignmentGroup = AssignmentGroup;
		this.KoCount = KoCount;
	}

	/**
	 * Instantiates a new item.
	 *
	 * @param Tower           the tower
	 * @param CC              the cc
	 * @param Cluster         the cluster
	 * @param AssignmentGroup the assignment group
	 * @param ApplicationName the application name
	 * @param Linked          the linked
	 * @param Not_Linked      the not linked
	 */
	public Item(String Tower, String CC, String Cluster, String AssignmentGroup, String ApplicationName, Object Linked,
			Object Not_Linked) {
		// TODO Auto-generated constructor stub

		this.Tower = Tower;
		this.CC = CC;
		this.Cluster = Cluster;
		this.ApplicationName = ApplicationName;
		this.AssignmentGroup = AssignmentGroup;
		this.Linked = Linked;
		this.Not_Linked = Not_Linked;
	}

	/**
	 * Instantiates a new item.
	 *
	 * @param TicketMonth the ticket month
	 * @param Tower the tower
	 * @param CC the cc
	 * @param Cluster the cluster
	 * @param AssignmentGroup the assignment group
	 * @param ticketCount the ticket count
	 * @param allIncidentsmttr the all incidentsmttr
	 * @param ticketLinkedCount the ticket linked count
	 * @param linkedTicketsmttr the linked ticketsmttr
	 */
	public Item(String TicketMonth, String Tower, String CC, String Cluster, String AssignmentGroup, Object ticketCount,
			Object allIncidentsmttr, Object ticketLinkedCount, Object linkedTicketsmttr) {

		this.TicketMonth = TicketMonth;
		this.Tower = Tower;
		this.CC = CC;
		this.Cluster = Cluster;
		this.AssignmentGroup = AssignmentGroup;
		this.ticketCount = ticketCount;
		this.allIncidentsmttr = allIncidentsmttr;
		this.ticketLinkedCount = ticketLinkedCount;
		this.linkedTicketsmttr = linkedTicketsmttr;
	}

	/**
	 * Gets the tower.
	 *
	 * @return the tower
	 */
	public String getTower() {
		return Tower;
	}

	/**
	 * Sets the tower.
	 *
	 * @param tower the new tower
	 */
	public void setTower(String tower) {
		Tower = tower;
	}

	/**
	 * Gets the cc.
	 *
	 * @return the cc
	 */
	public String getCC() {
		return CC;
	}

	/**
	 * Sets the cc.
	 *
	 * @param cC the new cc
	 */
	public void setCC(String cC) {
		CC = cC;
	}

	/**
	 * Gets the cluster.
	 *
	 * @return the cluster
	 */
	public String getCluster() {
		return Cluster;
	}

	/**
	 * Sets the cluster.
	 *
	 * @param cluster the new cluster
	 */
	public void setCluster(String cluster) {
		Cluster = cluster;
	}

	/**
	 * Gets the application name.
	 *
	 * @return the application name
	 */
	public String getApplicationName() {
		return ApplicationName;
	}

	/**
	 * Sets the application name.
	 *
	 * @param applicationName the new application name
	 */
	public void setApplicationName(String applicationName) {
		ApplicationName = applicationName;
	}

	/**
	 * Gets the assignment group.
	 *
	 * @return the assignment group
	 */
	public String getAssignmentGroup() {
		return AssignmentGroup;
	}

	/**
	 * Sets the assignment group.
	 *
	 * @param assignmentGroup the new assignment group
	 */
	public void setAssignmentGroup(String assignmentGroup) {
		AssignmentGroup = assignmentGroup;
	}

	/**
	 * Gets the ko count.
	 *
	 * @return the koCount
	 */
	public int getKoCount() {
		return Integer.parseInt(String.valueOf(KoCount));
	}

	/**
	 * Sets the ko count.
	 *
	 * @param koCount the koCount to set
	 */
	public void setKoCount(Object koCount) {
		KoCount = koCount;
	}

	/**
	 * Gets the linked.
	 *
	 * @return the linked
	 */
	public int getLinked() {
		// return Linked;
		return Integer.parseInt(String.valueOf(Linked));
	}

	/**
	 * Sets the linked.
	 *
	 * @param linked the linked to set
	 */
	public void setLinked(Object linked) {
		Linked = linked;
	}

	/**
	 * Gets the not linked.
	 *
	 * @return the not_Linked
	 */
	public int getNot_Linked() {
		// return Not_Linked;
		return Integer.parseInt(String.valueOf(Not_Linked));
	}

	/**
	 * Sets the not linked.
	 *
	 * @param not_Linked the not_Linked to set
	 */
	public void setNot_Linked(Object not_Linked) {
		Not_Linked = not_Linked;
	}

	/**
	 * Gets the ticket month.
	 *
	 * @return the ticketMonth
	 */
	public String getTicketMonth() {
		return TicketMonth;
	}

	/**
	 * Sets the ticket month.
	 *
	 * @param ticketMonth the ticketMonth to set
	 */
	public void setTicketMonth(String ticketMonth) {
		TicketMonth = ticketMonth;
	}

	/**
	 * Gets the ticket count.
	 *
	 * @return the ticketCount
	 */
	public int getTicketCount() {
		return Integer.parseInt(String.valueOf(ticketCount));
	}

	/**
	 * Sets the ticket count.
	 *
	 * @param ticketCount the ticketCount to set
	 */
	public void setTicketCount(Object ticketCount) {
		this.ticketCount = ticketCount;
	}

	/**
	 * Gets the all incidentsmttr.
	 *
	 * @return the allIncidentsmttr
	 */
	public int getAllIncidentsmttr() {
		return Integer.parseInt(String.valueOf(allIncidentsmttr));
	}

	/**
	 * Sets the all incidentsmttr.
	 *
	 * @param allIncidentsmttr the allIncidentsmttr to set
	 */
	public void setAllIncidentsmttr(Object allIncidentsmttr) {
		this.allIncidentsmttr = allIncidentsmttr;
	}

	/**
	 * Gets the ticket linked count.
	 *
	 * @return the ticketLinkedCount
	 */
	public int getTicketLinkedCount() {
		return Integer.parseInt(String.valueOf(ticketLinkedCount));
	}

	/**
	 * Sets the ticket linked count.
	 *
	 * @param ticketLinkedCount the ticketLinkedCount to set
	 */
	public void setTicketLinkedCount(Object ticketLinkedCount) {
		this.ticketLinkedCount = ticketLinkedCount;
	}

	/**
	 * Gets the linked ticketsmttr.
	 *
	 * @return the linkedTicketsmttr
	 */
	public int getLinkedTicketsmttr() {
		return Integer.parseInt(String.valueOf(linkedTicketsmttr));
	}

	/**
	 * Sets the linked ticketsmttr.
	 *
	 * @param linkedTicketsmttr the linkedTicketsmttr to set
	 */
	public void setLinkedTicketsmttr(Object linkedTicketsmttr) {
		this.linkedTicketsmttr = linkedTicketsmttr;
	}

}
