package com.ikon.dto;

/**
 * The Class ApplicationMasterBean.
 */
public class ApplicationMasterBean {
	
	/** The app master id. */
	private Long appMasterId;
    
    /** The account id. */
    private Long accountId;
    
    /** The app name. */
    private String appName;
    
    /** The assignment group. */
    private String assignmentGroup;
    
    /** The tower. */
    private String tower;
    
    /** The cc. */
    private String cc;
    
    /** The cluster. */
    private String cluster;
    
    /** The technology. */
    private String technology;

	/**
	 * Gets the app master id.
	 *
	 * @return the app master id
	 */
	public Long getAppMasterId() {
		return appMasterId;
	}

	/**
	 * Sets the app master id.
	 *
	 * @param appMasterId the new app master id
	 */
	public void setAppMasterId(Long appMasterId) {
		this.appMasterId = appMasterId;
	}

	/**
	 * Gets the account id.
	 *
	 * @return the account id
	 */
	public Long getAccountId() {
		return accountId;
	}

	/**
	 * Sets the account id.
	 *
	 * @param accountId the new account id
	 */
	public void setAccountId(Long accountId) {
		this.accountId = accountId;
	}

	/**
	 * Gets the app name.
	 *
	 * @return the app name
	 */
	public String getAppName() {
		return appName;
	}

	/**
	 * Sets the app name.
	 *
	 * @param appName the new app name
	 */
	public void setAppName(String appName) {
		this.appName = appName;
	}

	/**
	 * Gets the assignment group.
	 *
	 * @return the assignment group
	 */
	public String getAssignmentGroup() {
		return assignmentGroup;
	}

	/**
	 * Sets the assignment group.
	 *
	 * @param assignmentGroup the new assignment group
	 */
	public void setAssignmentGroup(String assignmentGroup) {
		this.assignmentGroup = assignmentGroup;
	}

	/**
	 * Gets the tower.
	 *
	 * @return the tower
	 */
	public String getTower() {
		return tower;
	}

	/**
	 * Sets the tower.
	 *
	 * @param tower the new tower
	 */
	public void setTower(String tower) {
		this.tower = tower;
	}

	/**
	 * Gets the cc.
	 *
	 * @return the cc
	 */
	public String getCc() {
		return cc;
	}

	/**
	 * Sets the cc.
	 *
	 * @param cc the new cc
	 */
	public void setCc(String cc) {
		this.cc = cc;
	}

	/**
	 * Gets the cluster.
	 *
	 * @return the cluster
	 */
	public String getCluster() {
		return cluster;
	}

	/**
	 * Sets the cluster.
	 *
	 * @param cluster the new cluster
	 */
	public void setCluster(String cluster) {
		this.cluster = cluster;
	}

	/**
	 * Gets the technology.
	 *
	 * @return the technology
	 */
	public String getTechnology() {
		return technology;
	}

	/**
	 * Sets the technology.
	 *
	 * @param technology the new technology
	 */
	public void setTechnology(String technology) {
		this.technology = technology;
	}
    
}
