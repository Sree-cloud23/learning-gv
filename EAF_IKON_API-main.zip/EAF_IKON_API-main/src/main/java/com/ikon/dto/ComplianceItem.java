package com.ikon.dto;

import com.ikon.validator.IKONUtils;

public class ComplianceItem {

	/** The tower. */
	private String tower;
	
	/** The cc. */
	private String cc;
	
	/** The cluster. */
	private String cluster;
	
	/** The group. */
	private String group;
	
	/** The inc resolved. */
	private Object incResolved;
	
	/** The sr resolved. */
	private Object srResolved;
	
	/** The total resolved. */
	private Object totalResolved;
	
	/** The ko created. */
	private Object koCreated;
	
	/** The ko linked. */
	private Object koLinked;
	
	/** The res vs linked. */
	private Object resVsLinked;
	
	/** The assignment group. */
	private String assignmentGroup;
	
	/** The application Name. */
	private String applicationName;

	/** The Months Name. */
	private String months;
	
	
	/**
	 * @return
	 */
	public String getCc() {
		return cc;
	}

	/**
	 * @param cc
	 */
	public void setCc(String cc) {
		this.cc = cc;
	}

	/**
	 * @return
	 */
	public String getMonths() {
		return months;
	}

	/**
	 * @param months
	 */
	public void setMonths(String months) {
		this.months = months;
	}

	/**
	 * Gets the tower.
	 *
	 * @return the tower
	 */
	public String getTower() {
		return tower;
	}

	/**
	 * Sets the tower.
	 *
	 * @param tower the new tower
	 */
	public void setTower(String tower) {
		tower = tower;
	}

	/**
	 * Gets the cc.
	 *
	 * @return the cc
	 */
	public String getCC() {
		return cc;
	}

	/**
	 * Sets the cc.
	 *
	 * @param cC the new cc
	 */
	public void setCC(String cC) {
		cc = cC;
	}

	/**
	 * Gets the cluster.
	 *
	 * @return the cluster
	 */
	public String getCluster() {
		return cluster;
	}

	/**
	 * Sets the cluster.
	 *
	 * @param cluster the new cluster
	 */
	public void setCluster(String cluster) {
		cluster = cluster;
	}

	/**
	 * Gets the application name.
	 *
	 * @return the application name
	 */
	public String getApplicationName() {
		return applicationName;
	}

	/**
	 * Sets the application name.
	 *
	 * @param applicationName the new application name
	 */
	public void setApplicationName(String applicationName) {
		applicationName = applicationName;
	}

	/**
	 * Gets the assignment group.
	 *
	 * @return the assignment group
	 */
	public String getAssignmentGroup() {
		return assignmentGroup;
	}

	/**
	 * Sets the assignment group.
	 *
	 * @param assignmentGroup the new assignment group
	 */
	public void setAssignmentGroup(String assignmentGroup) {
		assignmentGroup = assignmentGroup;
	}

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}

	public int getIncResolved() {
		return Integer.parseInt(String.valueOf(incResolved));
	}

	public void setIncResolved(Object incResolved) {
		this.incResolved = incResolved;
	}

	public int getSrResolved() {
		return Integer.parseInt(String.valueOf(srResolved));
	}

	public void setSrResolved(Object srResolved) {
		this.srResolved = srResolved;
	}

	public int getTotalResolved() {
		return Integer.parseInt(IKONUtils.isNullOrEmpty(String.valueOf(totalResolved))?"0":String.valueOf(totalResolved));
	}

	public void setTotalResolved(Object totalResolved) {
		this.totalResolved = totalResolved;
	}

	public int getKoCreated() {
		return Integer.parseInt(String.valueOf(koCreated));
	}

	public void setKoCreated(Object koCreated) {
		this.koCreated = koCreated;
	}

	public int getKoLinked() {
		return Integer.parseInt(String.valueOf(koLinked));
	}

	public void setKoLinked(Object koLinked) {
		this.koLinked = koLinked;
	}

	public double getResVsLinked() {
		return Double.parseDouble(IKONUtils.isNullOrEmpty(String.valueOf(resVsLinked))|| "null".equalsIgnoreCase(String.valueOf(resVsLinked))?"0":String.valueOf(resVsLinked));
	}
	public void setResVsLinked(Object resVsLinked) {
		this.resVsLinked = resVsLinked;
	}


	/**
	 *
	 */
	@Override
	public String toString() {
		return "ComplianceItem [tower=" + tower + ", cc=" + cc + ", cluster=" + cluster + ", group=" + group
				+ ", incResolved=" + incResolved + ", srResolved=" + srResolved + ", totalResolved=" + totalResolved
				+ ", koCreated=" + koCreated + ", koLinked=" + koLinked + ", resVsLinked=" + resVsLinked
				+ ", assignmentGroup=" + assignmentGroup + ", applicationName=" + applicationName + "]";
	}

	/**
	 * @param tower
	 * @param cc
	 * @param cluster
	 * @param group
	 * @param incResolved
	 * @param srResolved
	 * @param totalResolved
	 * @param koCreated
	 * @param koLinked
	 * @param resVsLinked
	 * @param assignmentGroup
	 * @param applicationName
	 */
	public ComplianceItem(String months, String tower, String cc, String cluster, String group, Object incResolved, Object srResolved,
			Object totalResolved, Object koCreated, Object koLinked, Object resVsLinked, String assignmentGroup,
			String applicationName) {
		super();
		this.months = months;
		this.tower = tower;
		this.cc = cc;
		this.cluster = cluster;
		this.group = group;
		this.incResolved = incResolved;
		this.srResolved = srResolved;
		this.totalResolved = totalResolved;
		this.koCreated = koCreated;
		this.koLinked = koLinked;
		this.resVsLinked = resVsLinked;
		this.applicationName = applicationName;
		this.assignmentGroup = assignmentGroup;
		
	}

}
