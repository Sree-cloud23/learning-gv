package com.ikon.dto;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotBlank;

import org.springframework.format.annotation.DateTimeFormat;

/**
 * The Class KOInfoBean.
 */
public class KOInfoBean {

	/** The KO serial no. */
	int KOSerialNo;

	/** The account ID. */
	int accountID;

	/** The ko ID. */
	String koID;

	/** The ticketsearchbox. */
	String ticketsearchbox;

	/** The kosearchbox. */
	String kosearchbox;

	/** The short description. */
	@NotBlank(message = "Short Description is required")
	String shortDescription;

	/** The Created in IKON. */
	Integer CreatedInIKON;

	/** The attachment present. */
	int attachmentPresent;

	/** The application name. */
	@NotBlank(message = "ApplicationName is required, search with ticket number to populate")
	String applicationName;

	/** The assignment group. */
	String assignmentGroup;

	/** The publication status. */
	String publicationStatus;

	/** The KO status. */
	int KOStatus;

	/** The it SM tool. */
	String itSMTool;

	/** The topic. */
	String topic;

	/** The KO category. */
	String KOCategory;

	/** The long description. */
	String longDescription;

	/** The meta keywords. */
	String metaKeywords;

	/** The feed ID. */
	Integer feedID;

	/** The symptoms. */
	String symptoms;

	/** The resolution. */
	String resolution;

	/** The cause. */
	String cause;

	/** The question. */
	String question;

	/** The answer. */
	String answer;

	/** The technotes. */
	String technotes;

	/** The ITSM tool. */
	String ITSMTool;

	/** The Attachment name. */
	String AttachmentName;

	/** The Attachment path. */
	String AttachmentPath;

	/** The Created by. */
	String CreatedBy;

	/** The ko upload file. */
	String koUploadFile;

	/** The cause code. */
	String causeCode;

	/** The Resoultion category. */
	String ResoultionCategory;

	/** The Ticket ID. */
	String TicketID;

	/** The resolution note. */
	String resolutionNote;

	/** The created date. */
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Temporal(TemporalType.DATE)
	Date createdDate;

	/** The reviewed date. */
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Temporal(TemporalType.DATE)
	Date reviewedDate;

	/** The reviewed by. */
	String reviewedBy;

	/** The published date. */
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Temporal(TemporalType.DATE)
	Date publishedDate;

	/** The published by. */
	String publishedBy;

	/** The review comments. */
	String reviewComments;

	/** The rework area. */
	String reworkArea;

	/** The action required. */
	int actionRequired;

	/** The KO single tags. */
	String KOSingleTags;

	/** The KO bigram tags. */
	String KOBigramTags;

	/** The KO trigram tags. */
	String KOTrigramTags;

	/** The var ko. */
	String var_ko;

	/** The new review comment. */
	String newReviewComment;

	/** The new rework area. */
	String newReworkArea;

	/** The new action required. */
	int newActionRequired;

	/** The review ID. */
	int reviewID;

	/** The Resolution category. */
	String ResolutionCategory;

	/** The Attachment number. */
	Integer AttachmentNumber;

	/** The Serial number. */
	int SerialNumber;

	/** The service type. */
	String serviceType;

	/** The priority. */
	String priority;

	/** The assignee name. */
	String assigneeName;

	/** The KO percentage. */
	int KOPercentage;

	/** The KO usage percentage. */
	int KOUsagePercentage;

	/** The cause code 1. */
	String causeCode1;

	/** The Summary. */
	String Summary;

	/** The Reported date. */
	Date ReportedDate;

	/** The Feedback perc. */
	String FeedbackPerc;

	/** The Master rel. */
	String MasterRel;

	/** The status. */
	String status;

	/** The Relev perc. */
	String RelevPerc;

	/** The Usage perc. */
	String UsagePerc;

	/** The Linked date. */
	Date LinkedDate;

	/** The ticketorko. */
	String ticketorko;

	/** The attachment document name. */
	String attachmentDocumentName;

	/** The ko view serial num. */
	int koViewSerialNum;

	/** The ko stage. */
	String koStage;

	/** The Approver user ID. */
	String ApproverUserID;

	/** The Approver email. */
	String ApproverEmail;

	/** The Creater email. */
	String CreaterEmail;

	/** The varkoid. */
	String varkoid;

	/** The KO info bean list value. */
	String KOInfoBeanList_value;

	/** The reviewed yor N. */
	String reviewedYorN;

	/** The review comments yor N. */
	String reviewCommentsYorN;

	/** The rework completed yor N. */
	String reworkCompletedYorN;

	/** The approved yor N. */
	String approvedYorN;

	/** The ticket linked count. */
	private Long ticketLinkedCount;

	/** The seperated ko ID. */
	private String seperatedKoID;

	/** The seperated ko perc. */
	private String seperatedKoPerc;
	/**
	 * The seperated seperatedKoRelPer.
	 */
	private String seperatedKoRelPer;

	/**
	 * The seperated seperatedKoRelID.
	 */
	private String seperatedKoRelID;

	/** The selected ko for resolution. */
	private String selectedKoForResolution;

	/** The is selected for resolution. */
	private String isSelectedForResolution;

	/** The processed search string. */
	private String processedSearchString;

	/** The komonth. */
	private String komonth;

	/** The Ko ID count. */
	private Object KoIDCount;

	/** The Ko linked month. */
	private String KoLinkedMonth;

	/** The from date. */
	private String fromDate;

	/** The to date. */
	private String toDate;

	/** The selected vals. */
	private String selectedVals;

	/** The modified date. */
	Date modifiedDate;

	/** The modified by. */
	private String modifiedBy;

	/** The ko reviewers list. */
	private List<KOReviewerBean> koReviewersList;
	/** The business Process LeveId. */
	private int businessProcessLevelid;

	/** The business Process Level1. */
	private String bnsProL1;
	/** The business Process Level2. */
	private String bnsProL2;
	/** The business Process Level3. */
	private String bnsProL3;

	/** The Ko type. */
	private String kotype;
	
	/** The Ko type. */
	private Integer koType;

	/** The generic ko ID. */
	String genericKoID = "";

	/** The cloned count. */
	private BigInteger clonedCount;

	/** The Top KO count. */
	private BigDecimal topKOCount;

	/** The Name. */
	private String name;
	
	/** The isMapped . */
	private Boolean isMapped;
	
	
	private BigInteger linkedCount;
	
	/** The ko reviewers list. */
	//private List<KOReviewCommnetsBean> reviewComments;
	
	/**
	 * Gets the checks if is mapped.
	 *
	 * @return the checks if is mapped
	 */
	public Boolean getIsMapped() {
		return isMapped;
	}

	/**
	 * Sets the checks if is mapped.
	 *
	 * @param isMapped the new checks if is mapped
	 */
	public void setIsMapped(Boolean isMapped) {
		this.isMapped = isMapped;
	}

	/**  module name. */
	private String moduleName;

	
	

	/**
	 * Gets the module name.
	 *
	 * @return the moduleName
	 */
	public String getModuleName() {
		return moduleName;
	}

	/**
	 * Sets the module name.
	 *
	 * @param moduleName the moduleName to set
	 */
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	/**
	 * Gets the top KO count.
	 *
	 * @return the top KO count
	 */
	public BigDecimal getTopKOCount() {
		return topKOCount;
	}

	/**
	 * Sets the top KO count.
	 *
	 * @param topKOCount the new top KO count
	 */
	public void setTopKOCount(BigDecimal topKOCount) {
		this.topKOCount = topKOCount;
	}

	/**
	 * Gets the cloned count.
	 *
	 * @return the cloned count
	 */
	public BigInteger getClonedCount() {
		return clonedCount;
	}

	/**
	 * Sets the cloned count.
	 *
	 * @param clonedCount the new cloned count
	 */
	public void setClonedCount(BigInteger clonedCount) {
		this.clonedCount = clonedCount;
	}

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Gets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Gets the selected vals.
	 *
	 * @return the selected vals
	 */
	public String getSelectedVals() {
		return selectedVals;
	}

	/**
	 * Sets the selected vals.
	 *
	 * @param selectedVals the new selected vals
	 */
	public void setSelectedVals(String selectedVals) {
		this.selectedVals = selectedVals;
	}

	/**
	 * Gets the from date.
	 *
	 * @return the from date
	 */
	public String getFromDate() {
		return fromDate;
	}

	/**
	 * Sets the from date.
	 *
	 * @param fromDate the new from date
	 */
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	/**
	 * Gets the to date.
	 *
	 * @return the to date
	 */
	public String getToDate() {
		return toDate;
	}

	/**
	 * Sets the to date.
	 *
	 * @param toDate the new to date
	 */
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	/** The Inc month. */
	private String IncMonth;

	/** The Ticket link count. */
	private Object TicketLinkCount;

	/** The Ko linked count. */
	private Object KoLinkedCount;

	/** The Tower. */
	private String Tower;

	/** The cc. */
	private String CC;

	/** The Cluster. */
	private String Cluster;

	/** The Ko count. */
	private Object KoCount;

	/** The Ticket count. */
	private Object TicketCount;
	/** The Ticket Linked count. */
	private Object TicketLinkedCounts;

	/** The Linked. */
	private Object Linked;

	/** The Non linked. */
	private Object Non_Linked;

	/** The all incident Mttr. */
	private Object AllIncidentsmttr;
	/** The Linked ticket Mttr. */
	private Object LinkTicketsmttr;
	/** The Ticket month. */
	private String TicketMonth;

	/** The Is cloned. */
	private Boolean isCloned;
	
	/** The GenericKoIDCount. */								  
    private Object GenericKoIDCount;
    

	/**
	 * Gets the generic ko ID count.
	 *
	 * @return the generic ko ID count
	 */
	public Object getGenericKoIDCount() {
		return GenericKoIDCount;
	}

	/**
	 * Sets the generic ko ID count.
	 *
	 * @param genericKoIDCount the new generic ko ID count
	 */
	public void setGenericKoIDCount(Object genericKoIDCount) {
		GenericKoIDCount = genericKoIDCount;
	}

	/**
	 * Gets the checks if is cloned.
	 *
	 * @return the checks if is cloned
	 */
	public Boolean getIsCloned() {
		return isCloned;
	}

	/**
	 * Sets the checks if is cloned.
	 *
	 * @param isCloned the new checks if is cloned
	 */
	public void setIsCloned(Boolean isCloned) {
		this.isCloned = isCloned;
	}

	/**
	 * Gets the ticket linked counts.
	 *
	 * @return the ticketLinkedCounts
	 */
	public Object getTicketLinkedCounts() {
		return TicketLinkedCounts;
	}

	/**
	 * Sets the ticket linked counts.
	 *
	 * @param ticketLinkedCounts the ticketLinkedCounts to set
	 */
	public void setTicketLinkedCounts(Object ticketLinkedCounts) {
		TicketLinkedCounts = ticketLinkedCounts;
	}

	/**
	 * Gets the ticket month.
	 *
	 * @return the ticketMonth
	 */
	public String getTicketMonth() {
		return TicketMonth;
	}

	/**
	 * Sets the ticket month.
	 *
	 * @param ticketMonth the ticketMonth to set
	 */
	public void setTicketMonth(String ticketMonth) {
		TicketMonth = ticketMonth;
	}

	/**
	 * Gets the all incidentsmttr.
	 *
	 * @return the allIncidentsmttr
	 */
	public Object getAllIncidentsmttr() {
		return AllIncidentsmttr;
	}

	/**
	 * Sets the all incidentsmttr.
	 *
	 * @param allIncidentsmttr the allIncidentsmttr to set
	 */
	public void setAllIncidentsmttr(Object allIncidentsmttr) {
		AllIncidentsmttr = allIncidentsmttr;
	}

	/**
	 * Gets the link ticketsmttr.
	 *
	 * @return the linkTicketsmttr
	 */
	public Object getLinkTicketsmttr() {
		return LinkTicketsmttr;
	}

	/**
	 * Sets the link ticketsmttr.
	 *
	 * @param linkTicketsmttr the linkTicketsmttr to set
	 */
	public void setLinkTicketsmttr(Object linkTicketsmttr) {
		LinkTicketsmttr = linkTicketsmttr;
	}

	/** The dashboard frmdate. */
	Date dashboardFrmdate;

	/** The dashboardtodate. */
	Date dashboardtodate;

	/** The Max date. */
	@DateTimeFormat(pattern = "MM-dd-yyyy")
	@Temporal(TemporalType.DATE)
	Date Max_Date;

	/** The relatedko val. */
	private String relatedkoVal;

	/**
	 * Gets the relatedko val.
	 *
	 * @return the relatedko val
	 */
	public String getRelatedkoVal() {
		return relatedkoVal;
	}

	/**
	 * Sets the relatedko val.
	 *
	 * @param relatedkoVal the new relatedko val
	 */
	public void setRelatedkoVal(String relatedkoVal) {
		this.relatedkoVal = relatedkoVal;
	}

	/**
	 * Gets the max date.
	 *
	 * @return the max date
	 */
	public Date getMax_Date() {
		return Max_Date;
	}

	/**
	 * Sets the max date.
	 *
	 * @param max_Date the new max date
	 */
	public void setMax_Date(Date max_Date) {
		Max_Date = max_Date;
	}

	/** The ko file type. */
	private String koFileType;

	/**
	 * Gets the ko file type.
	 *
	 * @return the ko file type
	 */
	public String getKoFileType() {
		return koFileType;
	}

	/**
	 * Sets the ko file type.
	 *
	 * @param koFileType the new ko file type
	 */
	public void setKoFileType(String koFileType) {
		this.koFileType = koFileType;
	}

	/**
	 * Gets the inc month.
	 *
	 * @return the incMonth
	 */
	public String getIncMonth() {
		return IncMonth;
	}

	/**
	 * Sets the inc month.
	 *
	 * @param incMonth the incMonth to set
	 */
	public void setIncMonth(String incMonth) {
		IncMonth = incMonth;
	}

	/**
	 * Gets the ticket link count.
	 *
	 * @return the ticketLinkCount
	 */
	public Object getTicketLinkCount() {
		return TicketLinkCount;
	}

	/**
	 * Sets the ticket link count.
	 *
	 * @param ticketLinkCount the ticketLinkCount to set
	 */
	public void setTicketLinkCount(Object ticketLinkCount) {
		TicketLinkCount = ticketLinkCount;
	}

	/**
	 * Gets the ko linked count.
	 *
	 * @return the koLinkedCount
	 */
	public Object getKoLinkedCount() {
		return KoLinkedCount;
	}

	/**
	 * Sets the ko linked count.
	 *
	 * @param koLinkedCount the koLinkedCount to set
	 */
	public void setKoLinkedCount(Object koLinkedCount) {
		KoLinkedCount = koLinkedCount;
	}

	/**
	 * Gets the ko linked month.
	 *
	 * @return the koLinkedMonth
	 */
	public String getKoLinkedMonth() {
		return KoLinkedMonth;
	}

	/**
	 * Sets the ko linked month.
	 *
	 * @param koLinkedMonth the koLinkedMonth to set
	 */
	public void setKoLinkedMonth(String koLinkedMonth) {
		KoLinkedMonth = koLinkedMonth;
	}

	/**
	 * Gets the ko ID count.
	 *
	 * @return the koIDCount
	 */
	public Object getKoIDCount() {
		return KoIDCount;
	}

	/**
	 * Sets the ko ID count.
	 *
	 * @param koIDCount the koIDCount to set
	 */
	public void setKoIDCount(Object koIDCount) {
		KoIDCount = koIDCount;
	}

	/**
	 * Gets the komonth.
	 *
	 * @return the komonth
	 */
	public String getKomonth() {
		return komonth;
	}

	/**
	 * Sets the komonth.
	 *
	 * @param komonth the komonth to set
	 */
	public void setKomonth(String komonth) {
		this.komonth = komonth;
	}

	/**
	 * Gets the KO info bean list value.
	 *
	 * @return the kOInfoBeanList_value
	 */
	public String getKOInfoBeanList_value() {
		return KOInfoBeanList_value;
	}

	/**
	 * Sets the KO info bean list value.
	 *
	 * @param kOInfoBeanList_value the kOInfoBeanList_value to set
	 */
	public void setKOInfoBeanList_value(String kOInfoBeanList_value) {
		KOInfoBeanList_value = kOInfoBeanList_value;
	}

	/**
	 * Gets the varkoid.
	 *
	 * @return the varkoid
	 */
	public String getVarkoid() {
		return varkoid;
	}

	/**
	 * Sets the varkoid.
	 *
	 * @param varkoid the varkoid to set
	 */
	public void setVarkoid(String varkoid) {
		this.varkoid = varkoid;
	}

	/**
	 * Gets the approver user ID.
	 *
	 * @return the approverUserID
	 */
	public String getApproverUserID() {
		return ApproverUserID;
	}

	/**
	 * Sets the approver user ID.
	 *
	 * @param approverUserID the approverUserID to set
	 */
	public void setApproverUserID(String approverUserID) {
		ApproverUserID = approverUserID;
	}

	/**
	 * Gets the approver email.
	 *
	 * @return the approverEmail
	 */
	public String getApproverEmail() {
		return ApproverEmail;
	}

	/**
	 * Sets the approver email.
	 *
	 * @param approverEmail the approverEmail to set
	 */
	public void setApproverEmail(String approverEmail) {
		ApproverEmail = approverEmail;
	}

	/**
	 * Gets the creater email.
	 *
	 * @return the createrEmail
	 */
	public String getCreaterEmail() {
		return CreaterEmail;
	}

	/**
	 * Sets the creater email.
	 *
	 * @param createrEmail the createrEmail to set
	 */
	public void setCreaterEmail(String createrEmail) {
		CreaterEmail = createrEmail;
	}

	/**
	 * Gets the ko stage.
	 *
	 * @return the koStage
	 */
	public String getKoStage() {
		return koStage;
	}

	/**
	 * Sets the ko stage.
	 *
	 * @param koStage the koStage to set
	 */
	public void setKoStage(String koStage) {
		this.koStage = koStage;
	}

	/**
	 * Gets the ticketorko.
	 *
	 * @return the ticketorko
	 */
	public String getTicketorko() {
		return ticketorko;
	}

	/**
	 * Sets the ticketorko.
	 *
	 * @param ticketorko the new ticketorko
	 */
	public void setTicketorko(String ticketorko) {
		this.ticketorko = ticketorko;
	}

	/**
	 * Gets the linked date.
	 *
	 * @return the linked date
	 */
	public Date getLinkedDate() {
		return LinkedDate;
	}

	/**
	 * Sets the linked date.
	 *
	 * @param linkedDate the new linked date
	 */
	public void setLinkedDate(Date linkedDate) {
		LinkedDate = linkedDate;
	}

	/**
	 * Gets the relev perc.
	 *
	 * @return the relev perc
	 */
	public String getRelevPerc() {
		return RelevPerc;
	}

	/**
	 * Sets the relev perc.
	 *
	 * @param relevPerc the new relev perc
	 */
	public void setRelevPerc(String relevPerc) {
		RelevPerc = relevPerc;
	}

	/**
	 * Gets the usage perc.
	 *
	 * @return the usage perc
	 */
	public String getUsagePerc() {
		return UsagePerc;
	}

	/**
	 * Sets the usage perc.
	 *
	 * @param usagePerc the new usage perc
	 */
	public void setUsagePerc(String usagePerc) {
		UsagePerc = usagePerc;
	}

	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Sets the status.
	 *
	 * @param status the new status
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Gets the summary.
	 *
	 * @return the summary
	 */
	public String getSummary() {
		return Summary;
	}

	/**
	 * Sets the summary.
	 *
	 * @param summary the new summary
	 */
	public void setSummary(String summary) {
		Summary = summary;
	}

	/**
	 * Gets the reported date.
	 *
	 * @return the reported date
	 */
	public Date getReportedDate() {
		return ReportedDate;
	}

	/**
	 * Sets the reported date.
	 *
	 * @param reportedDate the new reported date
	 */
	public void setReportedDate(Date reportedDate) {
		ReportedDate = reportedDate;
	}

	/**
	 * Gets the feedback perc.
	 *
	 * @return the feedback perc
	 */
	public String getFeedbackPerc() {
		return FeedbackPerc;
	}

	/**
	 * Sets the feedback perc.
	 *
	 * @param feedbackPerc the new feedback perc
	 */
	public void setFeedbackPerc(String feedbackPerc) {
		FeedbackPerc = feedbackPerc;
	}

	/**
	 * Gets the master rel.
	 *
	 * @return the master rel
	 */
	public String getMasterRel() {
		return MasterRel;
	}

	/**
	 * Sets the master rel.
	 *
	 * @param masterRel the new master rel
	 */
	public void setMasterRel(String masterRel) {
		MasterRel = masterRel;
	}

	/**
	 * Gets the serial number.
	 *
	 * @return the serial number
	 */
	public int getSerialNumber() {
		return SerialNumber;
	}

	/**
	 * Sets the serial number.
	 *
	 * @param serialNumber the new serial number
	 */
	public void setSerialNumber(int serialNumber) {
		SerialNumber = serialNumber;
	}

	/**
	 * Gets the service type.
	 *
	 * @return the service type
	 */
	public String getServiceType() {
		return serviceType;
	}

	/**
	 * Sets the service type.
	 *
	 * @param serviceType the new service type
	 */
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	/**
	 * Gets the priority.
	 *
	 * @return the priority
	 */
	public String getPriority() {
		return priority;
	}

	/**
	 * Sets the priority.
	 *
	 * @param priority the new priority
	 */
	public void setPriority(String priority) {
		this.priority = priority;
	}

	/**
	 * Gets the assignee name.
	 *
	 * @return the assignee name
	 */
	public String getAssigneeName() {
		return assigneeName;
	}

	/**
	 * Sets the assignee name.
	 *
	 * @param assigneeName the new assignee name
	 */
	public void setAssigneeName(String assigneeName) {
		this.assigneeName = assigneeName;
	}

	/**
	 * Gets the KO percentage.
	 *
	 * @return the KO percentage
	 */
	public int getKOPercentage() {
		return KOPercentage;
	}

	/**
	 * Sets the KO percentage.
	 *
	 * @param kOPercentage the new KO percentage
	 */
	public void setKOPercentage(int kOPercentage) {
		KOPercentage = kOPercentage;
	}

	/**
	 * Gets the KO usage percentage.
	 *
	 * @return the KO usage percentage
	 */
	public int getKOUsagePercentage() {
		return KOUsagePercentage;
	}

	/**
	 * Sets the KO usage percentage.
	 *
	 * @param kOUsagePercentage the new KO usage percentage
	 */
	public void setKOUsagePercentage(int kOUsagePercentage) {
		KOUsagePercentage = kOUsagePercentage;
	}

	/**
	 * Gets the cause code 1.
	 *
	 * @return the cause code 1
	 */
	public String getCauseCode1() {
		return causeCode1;
	}

	/**
	 * Sets the cause code 1.
	 *
	 * @param causeCode1 the new cause code 1
	 */
	public void setCauseCode1(String causeCode1) {
		this.causeCode1 = causeCode1;
	}

	/**
	 * Gets the attachment number.
	 *
	 * @return the attachment number
	 */
	public Integer getAttachmentNumber() {
		return AttachmentNumber;
	}

	/**
	 * Sets the attachment number.
	 *
	 * @param attachmentNumber the new attachment number
	 */
	public void setAttachmentNumber(Integer attachmentNumber) {
		AttachmentNumber = attachmentNumber;
	}

	/**
	 * Gets the kosearchbox.
	 *
	 * @return the kosearchbox
	 */
	public String getKosearchbox() {
		return kosearchbox;
	}

	/**
	 * Sets the kosearchbox.
	 *
	 * @param kosearchbox the new kosearchbox
	 */
	public void setKosearchbox(String kosearchbox) {
		this.kosearchbox = kosearchbox;
	}

	/**
	 * Gets the resolution category.
	 *
	 * @return the resolution category
	 */
	public String getResolutionCategory() {
		return ResolutionCategory;
	}

	/**
	 * Sets the resolution category.
	 *
	 * @param resolutionCategory the new resolution category
	 */
	public void setResolutionCategory(String resolutionCategory) {
		ResolutionCategory = resolutionCategory;
	}

	/**
	 * Gets the var ko.
	 *
	 * @return the var ko
	 */
	public String getVar_ko() {
		return var_ko;
	}

	/**
	 * Sets the var ko.
	 *
	 * @param var_ko the new var ko
	 */
	public void setVar_ko(String var_ko) {
		this.var_ko = var_ko;
	}

	/**
	 * Gets the ko upload file.
	 *
	 * @return the ko upload file
	 */
	public String getKoUploadFile() {
		return koUploadFile;
	}

	/**
	 * Sets the ko upload file.
	 *
	 * @param koUploadFile the new ko upload file
	 */
	public void setKoUploadFile(String koUploadFile) {
		this.koUploadFile = koUploadFile;
	}

	/**
	 * Gets the resoultion category.
	 *
	 * @return the resoultion category
	 */
	public String getResoultionCategory() {
		return ResoultionCategory;
	}

	/**
	 * Sets the resoultion category.
	 *
	 * @param resoultionCategory the new resoultion category
	 */
	public void setResoultionCategory(String resoultionCategory) {
		ResoultionCategory = resoultionCategory;
	}

	/**
	 * Gets the cause code.
	 *
	 * @return the cause code
	 */
	public String getCauseCode() {
		return causeCode;
	}

	/**
	 * Sets the cause code.
	 *
	 * @param causeCode the new cause code
	 */
	public void setCauseCode(String causeCode) {
		this.causeCode = causeCode;
	}

	/**
	 * Gets the ticketsearchbox.
	 *
	 * @return the ticketsearchbox
	 */
	public String getTicketsearchbox() {
		return ticketsearchbox;
	}

	/**
	 * Sets the ticketsearchbox.
	 *
	 * @param ticketsearchbox the new ticketsearchbox
	 */
	public void setTicketsearchbox(String ticketsearchbox) {
		this.ticketsearchbox = ticketsearchbox;
	}

	/**
	 * Gets the created by.
	 *
	 * @return the created by
	 */
	public String getCreatedBy() {
		return CreatedBy;
	}

	/**
	 * Sets the created by.
	 *
	 * @param createdBy the new created by
	 */
	public void setCreatedBy(String createdBy) {
		CreatedBy = createdBy;
	}

	/**
	 * Gets the attachment name.
	 *
	 * @return the attachment name
	 */
	public String getAttachmentName() {
		return AttachmentName;
	}

	/**
	 * Sets the attachment name.
	 *
	 * @param attachmentName the new attachment name
	 */
	public void setAttachmentName(String attachmentName) {
		AttachmentName = attachmentName;
	}

	/**
	 * Gets the attachment path.
	 *
	 * @return the attachment path
	 */
	
	public String getAttachmentPath() {
		return AttachmentPath;
	}

	/**
	 * Sets the attachment path.
	 *
	 * @param attachmentPath the new attachment path
	 */
	public void setAttachmentPath(String attachmentPath) {
		AttachmentPath = attachmentPath;
	}

	/**
	 * Gets the KO serial no.
	 *
	 * @return the KO serial no
	 */
	public int getKOSerialNo() {
		return KOSerialNo;
	}

	/**
	 * Sets the KO serial no.
	 *
	 * @param kOSerialNo the new KO serial no
	 */
	public void setKOSerialNo(int kOSerialNo) {
		KOSerialNo = kOSerialNo;
	}

	/**
	 * Gets the account ID.
	 *
	 * @return the account ID
	 */
	public int getAccountID() {
		return accountID;
	}

	/**
	 * Sets the account ID.
	 *
	 * @param accountID the new account ID
	 */
	public void setAccountID(int accountID) {
		this.accountID = accountID;
	}

	/**
	 * Gets the ko ID.
	 *
	 * @return the ko ID
	 */
	public String getKoID() {
		return koID;
	}

	/**
	 * Sets the ko ID.
	 *
	 * @param koID the new ko ID
	 */
	public void setKoID(String koID) {
		this.koID = koID;
	}

	/**
	 * Gets the short description.
	 *
	 * @return the short description
	 */
	public String getShortDescription() {
		return shortDescription;
	}

	/**
	 * Sets the short description.
	 *
	 * @param shortDescription the new short description
	 */
	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}

	/**
	 * Gets the created in IKON.
	 *
	 * @return the created in IKON
	 */
	public Integer getCreatedInIKON() {
		return CreatedInIKON;
	}

	/**
	 * Sets the created in IKON.
	 *
	 * @param createdInIKON the new created in IKON
	 */
	public void setCreatedInIKON(Integer createdInIKON) {
		CreatedInIKON = createdInIKON;
	}

	/**
	 * Gets the attachment present.
	 *
	 * @return the attachment present
	 */
	public int getAttachmentPresent() {
		return attachmentPresent;
	}

	/**
	 * Sets the attachment present.
	 *
	 * @param attachmentPresent1 the new attachment present
	 */
	public void setAttachmentPresent(int attachmentPresent1) {
		this.attachmentPresent = attachmentPresent1;
	}

	/**
	 * Gets the application name.
	 *
	 * @return the application name
	 */
	public String getApplicationName() {
		return applicationName;
	}

	/**
	 * Sets the application name.
	 *
	 * @param applicationName the new application name
	 */
	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}

	/**
	 * Gets the assignment group.
	 *
	 * @return the assignment group
	 */
	public String getAssignmentGroup() {
		return assignmentGroup;
	}

	/**
	 * Sets the assignment group.
	 *
	 * @param assignmentGroup the new assignment group
	 */
	public void setAssignmentGroup(String assignmentGroup) {
		this.assignmentGroup = assignmentGroup;
	}

	/**
	 * Gets the publication status.
	 *
	 * @return the publication status
	 */
	public String getPublicationStatus() {
		return publicationStatus;
	}

	/**
	 * Sets the publication status.
	 *
	 * @param publicationStatus the new publication status
	 */
	public void setPublicationStatus(String publicationStatus) {
		this.publicationStatus = publicationStatus;
	}

	/**
	 * Gets the KO status.
	 *
	 * @return the KO status
	 */
	public int getKOStatus() {
		return KOStatus;
	}

	/**
	 * Sets the KO status.
	 *
	 * @param kOStatus the new KO status
	 */
	public void setKOStatus(int kOStatus) {
		KOStatus = kOStatus;
	}

	/**
	 * Gets the it SM tool.
	 *
	 * @return the it SM tool
	 */
	public String getItSMTool() {
		return itSMTool;
	}

	/**
	 * Sets the it SM tool.
	 *
	 * @param itSMTool the new it SM tool
	 */
	public void setItSMTool(String itSMTool) {
		this.itSMTool = itSMTool;
	}

	/**
	 * Gets the topic.
	 *
	 * @return the topic
	 */
	public String getTopic() {
		return topic;
	}

	/**
	 * Sets the topic.
	 *
	 * @param topic the new topic
	 */
	public void setTopic(String topic) {
		this.topic = topic;
	}

	/**
	 * Gets the KO category.
	 *
	 * @return the KO category
	 */
	public String getKOCategory() {
		return KOCategory;
	}

	/**
	 * Sets the KO category.
	 *
	 * @param kOCategory the new KO category
	 */
	public void setKOCategory(String kOCategory) {
		KOCategory = kOCategory;
	}

	/**
	 * Gets the long description.
	 *
	 * @return the long description
	 */
	public String getLongDescription() {
		return longDescription;
	}

	/**
	 * Sets the long description.
	 *
	 * @param longDescription the new long description
	 */
	public void setLongDescription(String longDescription) {
		this.longDescription = longDescription;
	}

	/**
	 * Gets the meta keywords.
	 *
	 * @return the meta keywords
	 */
	public String getMetaKeywords() {
		return metaKeywords;
	}

	/**
	 * Sets the meta keywords.
	 *
	 * @param metaKeywords the new meta keywords
	 */
	public void setMetaKeywords(String metaKeywords) {
		this.metaKeywords = metaKeywords;
	}

	/**
	 * Gets the feed ID.
	 *
	 * @return the feed ID
	 */
	public Integer getFeedID() {
		return feedID;
	}

	/**
	 * Sets the feed ID.
	 *
	 * @param feedID the new feed ID
	 */
	public void setFeedID(Integer feedID) {
		this.feedID = feedID;
	}

	/**
	 * Gets the symptoms.
	 *
	 * @return the symptoms
	 */
	public String getSymptoms() {
		return symptoms;
	}

	/**
	 * Sets the symptoms.
	 *
	 * @param symptoms the new symptoms
	 */
	public void setSymptoms(String symptoms) {
		this.symptoms = symptoms;
	}

	/**
	 * Gets the resolution.
	 *
	 * @return the resolution
	 */
	public String getResolution() {
		return resolution;
	}

	/**
	 * Sets the resolution.
	 *
	 * @param resolution the new resolution
	 */
	public void setResolution(String resolution) {
		this.resolution = resolution;
	}

	/**
	 * Gets the cause.
	 *
	 * @return the cause
	 */
	public String getCause() {
		return cause;
	}

	/**
	 * Sets the cause.
	 *
	 * @param cause the new cause
	 */
	public void setCause(String cause) {
		this.cause = cause;
	}

	/**
	 * Gets the question.
	 *
	 * @return the question
	 */
	public String getQuestion() {
		return question;
	}

	/**
	 * Sets the question.
	 *
	 * @param question the new question
	 */
	public void setQuestion(String question) {
		this.question = question;
	}

	/**
	 * Gets the answer.
	 *
	 * @return the answer
	 */
	public String getAnswer() {
		return answer;
	}

	/**
	 * Sets the answer.
	 *
	 * @param answer the new answer
	 */
	public void setAnswer(String answer) {
		this.answer = answer;
	}

	/**
	 * Gets the technotes.
	 *
	 * @return the technotes
	 */
	public String getTechnotes() {
		return technotes;
	}

	/**
	 * Sets the technotes.
	 *
	 * @param technotes the new technotes
	 */
	public void setTechnotes(String technotes) {
		this.technotes = technotes;
	}

	/**
	 * Gets the ITSM tool.
	 *
	 * @return the ITSM tool
	 */
	public String getITSMTool() {
		return ITSMTool;
	}

	/**
	 * Sets the ITSM tool.
	 *
	 * @param iTSMTool the new ITSM tool
	 */
	public void setITSMTool(String iTSMTool) {
		ITSMTool = iTSMTool;
	}

	/**
	 * Gets the ticket ID.
	 *
	 * @return the ticket ID
	 */
	public String getTicketID() {
		return TicketID;
	}

	/**
	 * Sets the ticket ID.
	 *
	 * @param ticketID the new ticket ID
	 */
	public void setTicketID(String ticketID) {
		TicketID = ticketID;
	}

	/**
	 * Gets the resolution note.
	 *
	 * @return the resolution note
	 */
	public String getResolutionNote() {
		return resolutionNote;
	}

	/**
	 * Sets the resolution note.
	 *
	 * @param resolutionNote the new resolution note
	 */
	public void setResolutionNote(String resolutionNote) {
		this.resolutionNote = resolutionNote;
	}

	/**
	 * Gets the created date.
	 *
	 * @return the created date
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * Sets the created date.
	 *
	 * @param createdDate the new created date
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * Gets the reviewed date.
	 *
	 * @return the reviewed date
	 */
	public Date getReviewedDate() {
		return reviewedDate;
	}

	/**
	 * Sets the reviewed date.
	 *
	 * @param reviewedDate the new reviewed date
	 */
	public void setReviewedDate(Date reviewedDate) {
		this.reviewedDate = reviewedDate;
	}

	/**
	 * Gets the reviewed by.
	 *
	 * @return the reviewed by
	 */
	public String getReviewedBy() {
		return reviewedBy;
	}

	/**
	 * Sets the reviewed by.
	 *
	 * @param reviewedBy the new reviewed by
	 */
	public void setReviewedBy(String reviewedBy) {
		this.reviewedBy = reviewedBy;
	}

	/**
	 * Gets the published date.
	 *
	 * @return the published date
	 */
	public Date getPublishedDate() {
		return publishedDate;
	}

	/**
	 * Sets the published date.
	 *
	 * @param publishedDate the new published date
	 */
	public void setPublishedDate(Date publishedDate) {
		this.publishedDate = publishedDate;
	}

	/**
	 * Gets the published by.
	 *
	 * @return the published by
	 */
	public String getPublishedBy() {
		return publishedBy;
	}

	/**
	 * Sets the published by.
	 *
	 * @param publishedBy the new published by
	 */
	public void setPublishedBy(String publishedBy) {
		this.publishedBy = publishedBy;
	}

	/**
	 * Gets the review comments.
	 *
	 * @return the review comments
	 */
	public String getReviewComments() {
		return reviewComments;
	}

	/**
	 * Sets the review comments.
	 *
	 * @param reviewComments the new review comments
	 */
	public void setReviewComments(String reviewComments) {
		this.reviewComments = reviewComments;
	}

	/**
	 * Gets the rework area.
	 *
	 * @return the rework area
	 */
	public String getReworkArea() {
		return reworkArea;
	}

	/**
	 * Sets the rework area.
	 *
	 * @param reworkArea the new rework area
	 */
	public void setReworkArea(String reworkArea) {
		this.reworkArea = reworkArea;
	}

	/**
	 * Gets the action required.
	 *
	 * @return the action required
	 */
	public int getActionRequired() {
		return actionRequired;
	}

	/**
	 * Sets the action required.
	 *
	 * @param actionRequired the new action required
	 */
	public void setActionRequired(int actionRequired) {
		this.actionRequired = actionRequired;
	}

	/**
	 * Gets the KO single tags.
	 *
	 * @return the KO single tags
	 */
	public String getKOSingleTags() {
		return KOSingleTags;
	}

	/**
	 * Sets the KO single tags.
	 *
	 * @param kOSingleTags the new KO single tags
	 */
	public void setKOSingleTags(String kOSingleTags) {
		KOSingleTags = kOSingleTags;
	}

	/**
	 * Gets the KO bigram tags.
	 *
	 * @return the KO bigram tags
	 */
	public String getKOBigramTags() {
		return KOBigramTags;
	}

	/**
	 * Sets the KO bigram tags.
	 *
	 * @param kOBigramTags the new KO bigram tags
	 */
	public void setKOBigramTags(String kOBigramTags) {
		KOBigramTags = kOBigramTags;
	}

	/**
	 * Gets the KO trigram tags.
	 *
	 * @return the KO trigram tags
	 */
	public String getKOTrigramTags() {
		return KOTrigramTags;
	}

	/**
	 * Sets the KO trigram tags.
	 *
	 * @param kOTrigramTags the new KO trigram tags
	 */
	public void setKOTrigramTags(String kOTrigramTags) {
		KOTrigramTags = kOTrigramTags;
	}

	/**
	 * Gets the new review comment.
	 *
	 * @return the new review comment
	 */
	public String getNewReviewComment() {
		return newReviewComment;
	}

	/**
	 * Sets the new review comment.
	 *
	 * @param newReviewComment the new new review comment
	 */
	public void setNewReviewComment(String newReviewComment) {
		this.newReviewComment = newReviewComment;
	}

	/**
	 * Gets the new rework area.
	 *
	 * @return the new rework area
	 */
	public String getNewReworkArea() {
		return newReworkArea;
	}

	/**
	 * Sets the new rework area.
	 *
	 * @param newReworkArea the new new rework area
	 */
	public void setNewReworkArea(String newReworkArea) {
		this.newReworkArea = newReworkArea;
	}

	/**
	 * Gets the new action required.
	 *
	 * @return the new action required
	 */
	public int getNewActionRequired() {
		return newActionRequired;
	}

	/**
	 * Sets the new action required.
	 *
	 * @param newActionRequired the new new action required
	 */
	public void setNewActionRequired(int newActionRequired) {
		this.newActionRequired = newActionRequired;
	}

	/**
	 * Gets the review ID.
	 *
	 * @return the review ID
	 */
	public int getReviewID() {
		return reviewID;
	}

	/**
	 * Sets the review ID.
	 *
	 * @param reviewID the new review ID
	 */
	public void setReviewID(int reviewID) {
		this.reviewID = reviewID;
	}

	/**
	 * Gets the attachment document name.
	 *
	 * @return the attachment document name
	 */
	public String getAttachmentDocumentName() {
		return attachmentDocumentName;
	}

	/**
	 * Sets the attachment document name.
	 *
	 * @param attachmentDocumentName the new attachment document name
	 */
	public void setAttachmentDocumentName(String attachmentDocumentName) {
		this.attachmentDocumentName = attachmentDocumentName;
	}

	/**
	 * Gets the ko view serial num.
	 *
	 * @return the ko view serial num
	 */
	public int getKoViewSerialNum() {
		return koViewSerialNum;
	}

	/**
	 * Sets the ko view serial num.
	 *
	 * @param koViewSerialNum the new ko view serial num
	 */
	public void setKoViewSerialNum(int koViewSerialNum) {
		this.koViewSerialNum = koViewSerialNum;
	}

	/**
	 * Gets the reviewed yor N.
	 *
	 * @return the reviewedYorN
	 */
	public String getReviewedYorN() {
		return reviewedYorN;
	}

	/**
	 * Sets the reviewed yor N.
	 *
	 * @param reviewedYorN the reviewedYorN to set
	 */
	public void setReviewedYorN(String reviewedYorN) {
		this.reviewedYorN = reviewedYorN;
	}

	/**
	 * Gets the review comments yor N.
	 *
	 * @return the reviewCommentsYorN
	 */
	public String getReviewCommentsYorN() {
		return reviewCommentsYorN;
	}

	/**
	 * Sets the review comments yor N.
	 *
	 * @param reviewCommentsYorN the reviewCommentsYorN to set
	 */
	public void setReviewCommentsYorN(String reviewCommentsYorN) {
		this.reviewCommentsYorN = reviewCommentsYorN;
	}

	/**
	 * Gets the rework completed yor N.
	 *
	 * @return the reworkCompletedYorN
	 */
	public String getReworkCompletedYorN() {
		return reworkCompletedYorN;
	}

	/**
	 * Sets the rework completed yor N.
	 *
	 * @param reworkCompletedYorN the reworkCompletedYorN to set
	 */
	public void setReworkCompletedYorN(String reworkCompletedYorN) {
		this.reworkCompletedYorN = reworkCompletedYorN;
	}

	/**
	 * Gets the approved yor N.
	 *
	 * @return the approvedYorN
	 */
	public String getApprovedYorN() {
		return approvedYorN;
	}

	/**
	 * Sets the approved yor N.
	 *
	 * @param approvedYorN the approvedYorN to set
	 */
	public void setApprovedYorN(String approvedYorN) {
		this.approvedYorN = approvedYorN;
	}

	/**
	 * Gets the ticket linked count.
	 *
	 * @return the ticketLinkedCount
	 */
	public Long getTicketLinkedCount() {
		return ticketLinkedCount;
	}

	/**
	 * Sets the ticket linked count.
	 *
	 * @param ticketLinkedCount the ticketLinkedCount to set
	 */
	public void setTicketLinkedCount(Long ticketLinkedCount) {
		this.ticketLinkedCount = ticketLinkedCount;
	}

	/**
	 * Gets the seperated ko ID.
	 *
	 * @return the seperatedKoID
	 */
	public String getSeperatedKoID() {
		return seperatedKoID;
	}

	/**
	 * Sets the seperated ko ID.
	 *
	 * @param seperatedKoID the seperatedKoID to set
	 */
	public void setSeperatedKoID(String seperatedKoID) {
		this.seperatedKoID = seperatedKoID;
	}

	/**
	 * Gets the seperated ko perc.
	 *
	 * @return the seperatedKoPerc
	 */
	public String getSeperatedKoPerc() {
		return seperatedKoPerc;
	}

	/**
	 * Sets the seperated ko perc.
	 *
	 * @param seperatedKoPerc the seperatedKoPerc to set
	 */
	public void setSeperatedKoPerc(String seperatedKoPerc) {
		this.seperatedKoPerc = seperatedKoPerc;
	}

	/**
	 * Gets the tower.
	 *
	 * @return the tower
	 */
	public String getTower() {
		return Tower;
	}

	/**
	 * Sets the tower.
	 *
	 * @param tower the tower to set
	 */
	public void setTower(String tower) {
		Tower = tower;
	}

	/**
	 * Gets the cc.
	 *
	 * @return the cC
	 */
	public String getCC() {
		return CC;
	}

	/**
	 * Sets the cc.
	 *
	 * @param cC the cC to set
	 */
	public void setCC(String cC) {
		CC = cC;
	}

	/**
	 * Gets the cluster.
	 *
	 * @return the cluster
	 */
	public String getCluster() {
		return Cluster;
	}

	/**
	 * Sets the cluster.
	 *
	 * @param cluster the cluster to set
	 */
	public void setCluster(String cluster) {
		Cluster = cluster;
	}

	/**
	 * Gets the ko count.
	 *
	 * @return the koCount
	 */
	public Object getKoCount() {
		return KoCount;
	}

	/**
	 * Sets the ko count.
	 *
	 * @param koCount the koCount to set
	 */
	public void setKoCount(Object koCount) {
		KoCount = koCount;
	}

	/**
	 * Gets the ticket count.
	 *
	 * @return the ticketCount
	 */
	public Object getTicketCount() {
		return TicketCount;
	}

	/**
	 * Sets the ticket count.
	 *
	 * @param ticketCount the ticketCount to set
	 */
	public void setTicketCount(Object ticketCount) {
		TicketCount = ticketCount;
	}

	/**
	 * Gets the dashboard frmdate.
	 *
	 * @return the dashboardFrmdate
	 */
	public Date getDashboardFrmdate() {
		return dashboardFrmdate;
	}

	/**
	 * Sets the dashboard frmdate.
	 *
	 * @param dashboardFrmdate the dashboardFrmdate to set
	 */
	public void setDashboardFrmdate(Date dashboardFrmdate) {
		this.dashboardFrmdate = dashboardFrmdate;
	}

	/**
	 * Gets the dashboardtodate.
	 *
	 * @return the dashboardtodate
	 */
	public Date getDashboardtodate() {
		return dashboardtodate;
	}

	/**
	 * Sets the dashboardtodate.
	 *
	 * @param dashboardtodate the dashboardtodate to set
	 */
	public void setDashboardtodate(Date dashboardtodate) {
		this.dashboardtodate = dashboardtodate;
	}

	/**
	 * Gets the linked.
	 *
	 * @return the linked
	 */
	public Object getLinked() {
		return Linked;
	}

	/**
	 * Sets the linked.
	 *
	 * @param linked the linked to set
	 */
	public void setLinked(Object linked) {
		Linked = linked;
	}

	/**
	 * Gets the non linked.
	 *
	 * @return the non_Linked
	 */
	public Object getNon_Linked() {
		return Non_Linked;
	}

	/**
	 * Sets the non linked.
	 *
	 * @param non_Linked the non_Linked to set
	 */
	public void setNon_Linked(Object non_Linked) {
		Non_Linked = non_Linked;
	}

	/**
	 * Gets the modified date.
	 *
	 * @return the modified date
	 */
	public Date getModifiedDate() {
		return modifiedDate;
	}

	/**
	 * Sets the modified date.
	 *
	 * @param modifiedDate the new modified date
	 */
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	/**
	 * Gets the modified by.
	 *
	 * @return the modified by
	 */
	public String getModifiedBy() {
		return modifiedBy;
	}

	/**
	 * Sets the modified by.
	 *
	 * @param modifiedBy the new modified by
	 */
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	/**
	 * Gets the checks if is selected for resolution.
	 *
	 * @return the checks if is selected for resolution
	 */
	public String getIsSelectedForResolution() {
		return isSelectedForResolution;
	}

	/**
	 * Sets the checks if is selected for resolution.
	 *
	 * @param isSelectedForResolution the new checks if is selected for resolution
	 */
	public void setIsSelectedForResolution(String isSelectedForResolution) {
		this.isSelectedForResolution = isSelectedForResolution;
	}

	/**
	 * Gets the selected ko for resolution.
	 *
	 * @return the selected ko for resolution
	 */
	public String getSelectedKoForResolution() {
		return selectedKoForResolution;
	}

	/**
	 * Sets the selected ko for resolution.
	 *
	 * @param selectedKoForResolution the new selected ko for resolution
	 */
	public void setSelectedKoForResolution(String selectedKoForResolution) {
		this.selectedKoForResolution = selectedKoForResolution;
	}

	/**
	 * Gets the processed search string.
	 *
	 * @return the processed search string
	 */
	public String getProcessedSearchString() {
		return processedSearchString;
	}

	/**
	 * Sets the processed search string.
	 *
	 * @param processedSearchString the new processed search string
	 */
	public void setProcessedSearchString(String processedSearchString) {
		this.processedSearchString = processedSearchString;
	}

	/**
	 * Gets the ko reviewers list.
	 *
	 * @return the ko reviewers list
	 */
	public List<KOReviewerBean> getKoReviewersList() {
		return koReviewersList;
	}

	/**
	 * Sets the ko reviewers list.
	 *
	 * @param koReviewersList the new ko reviewers list
	 */
	public void setKoReviewersList(List<KOReviewerBean> koReviewersList) {
		this.koReviewersList = koReviewersList;
	}

	/**
	 * Gets the seperatedKOrel Id.
	 *
	 * @return the seperated ko rel ID
	 */
	public String getSeperatedKoRelID() {
		return seperatedKoRelID;
	}

	/**
	 * Sets the seperatedKoRelID.
	 *
	 * @param seperatedKoRelID the new seperated ko rel ID
	 */
	public void setSeperatedKoRelID(String seperatedKoRelID) {
		this.seperatedKoRelID = seperatedKoRelID;
	}

	/**
	 * Gets the seperatedKOrel Per.
	 *
	 * @return the seperated ko rel per
	 */
	public String getSeperatedKoRelPer() {
		return seperatedKoRelPer;
	}

	/**
	 * Sets the seperatedKoRelPer.
	 *
	 * @param seperatedKoRelPer the new seperated ko rel per
	 */
	public void setSeperatedKoRelPer(String seperatedKoRelPer) {
		this.seperatedKoRelPer = seperatedKoRelPer;
	}

	/**
	 * Gets the business process levelid.
	 *
	 * @return the business process levelid
	 */
	public int getBusinessProcessLevelid() {
		return businessProcessLevelid;
	}

	/**
	 * Sets the business process levelid.
	 *
	 * @param businessProcessLevelid the new business process levelid
	 */
	public void setBusinessProcessLevelid(int businessProcessLevelid) {
		this.businessProcessLevelid = businessProcessLevelid;
	}

	/**
	 * Gets the bns pro L 1.
	 *
	 * @return the bns pro L 1
	 */
	public String getBnsProL1() {
		return bnsProL1;
	}

	/**
	 * Sets the bns pro L 1.
	 *
	 * @param bnsProL1 the new bns pro L 1
	 */
	public void setBnsProL1(String bnsProL1) {
		this.bnsProL1 = bnsProL1;
	}

	/**
	 * Gets the bns pro L 2.
	 *
	 * @return the bns pro L 2
	 */
	public String getBnsProL2() {
		return bnsProL2;
	}

	/**
	 * Sets the bns pro L 2.
	 *
	 * @param bnsProL2 the new bns pro L 2
	 */
	public void setBnsProL2(String bnsProL2) {
		this.bnsProL2 = bnsProL2;
	}

	/**
	 * Gets the bns pro L 3.
	 *
	 * @return the bns pro L 3
	 */
	public String getBnsProL3() {
		return bnsProL3;
	}

	/**
	 * Sets the bns pro L 3.
	 *
	 * @param bnsProL3 the new bns pro L 3
	 */
	public void setBnsProL3(String bnsProL3) {
		this.bnsProL3 = bnsProL3;
	}

	/**
	 * Gets the ko type.
	 *
	 * @return the ko type
	 */
	public Integer getKoType() {
		return koType;
	}

	/**
	 * Sets the ko type.
	 *
	 * @param koType the new ko type
	 */
	public void setKoType(Integer koType) {
		this.koType = koType;
	}

	/**
	 * Gets the kotype.
	 *
	 * @return the kotype
	 */
	public String getKotype() {
		return kotype;
	}

	/**
	 * Sets the kotype.
	 *
	 * @param koType the new kotype
	 */
	public void setKotype(String koType) {
		this.kotype = koType;
	}

	/**
	 * Gets the generic ko ID.
	 *
	 * @return the generic ko ID
	 */
	public String getGenericKoID() {
		return genericKoID;
	}

	/**
	 * Sets the generic ko ID.
	 *
	 * @param genericKoID the new generic ko ID
	 */
	public void setGenericKoID(String genericKoID) {
		this.genericKoID = genericKoID;
	}

	public BigInteger getLinkedCount() {
		return linkedCount;
	}

	public void setLinkedCount(BigInteger linkedCount) {
		this.linkedCount = linkedCount;
	}

	
	

	
	
	
	

}