package com.ikon.dto;

/**
 * The Class KoDataAttribute.
 */
public class KoDataAttribute {
	
	/** The kocreated. */
	private String kocreated;
	
	/** The ko id. */
	private String koId;
	
	/** The kopublished. */
	private String kopublished;
	
	/** The korelevancy. */
	private String korelevancy;
	
	/** The kousage. */
	private String kousage;
	
	/** The publication status. */
	private String publicationStatus;
	
	/** The review comments. */
	private String reviewComments;
	
	/** The reviewed by. */
	private String reviewedBy;
	
	/** The rework complete. */
	private String reworkComplete;
	
	/** The created by. */
	private String createdBy;
	
	/** The ko type. */
	private Integer koType;
	
	
	
	/**
	 * Instantiates a new ko data attribute.
	 *
	 * @param koId the ko id
	 * @param kopublished the kopublished
	 * @param korelevancy the korelevancy
	 * @param kousage the kousage
	 * @param createdBy the created by
	 * @param koType the ko type
	 */
	public KoDataAttribute(String koId, String kopublished, String korelevancy, String kousage, String createdBy,
			Integer koType) {
		super();
		this.koId = koId;
		this.kopublished = kopublished;
		this.korelevancy = korelevancy;
		this.kousage = kousage;
		this.createdBy = createdBy;
		this.koType = koType;
	}
	
	/**
	 * Instantiates a new ko data attribute.
	 */
	public KoDataAttribute() {
		super();
	}
	
	/**
	 * Gets the ko type.
	 *
	 * @return the ko type
	 */
	public Integer getKoType() {
		return koType;
	}
	
	/**
	 * Sets the ko type.
	 *
	 * @param koType the new ko type
	 */
	public void setKoType(Integer koType) {
		this.koType = koType;
	}
	
	/**
	 * Gets the created by.
	 *
	 * @return the created by
	 */
	public String getCreatedBy() {
		return createdBy;
	}
	
	/**
	 * Sets the created by.
	 *
	 * @param createdBy the new created by
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	/**
	 * Gets the kocreated.
	 *
	 * @return the kocreated
	 */
	public String getKocreated() {
		return kocreated;
	}
	
	/**
	 * Sets the kocreated.
	 *
	 * @param kocreated the new kocreated
	 */
	public void setKocreated(String kocreated) {
		this.kocreated = kocreated;
	}
	
	/**
	 * Gets the kopublished.
	 *
	 * @return the kopublished
	 */
	public String getKopublished() {
		return kopublished;
	}
	
	/**
	 * Gets the ko id.
	 *
	 * @return the ko id
	 */
	public String getKoId() {
		return koId;
	}
	
	/**
	 * Sets the ko id.
	 *
	 * @param koId the new ko id
	 */
	public void setKoId(String koId) {
		this.koId = koId;
	}
	
	/**
	 * Sets the kopublished.
	 *
	 * @param kopublished the new kopublished
	 */
	public void setKopublished(String kopublished) {
		this.kopublished = kopublished;
	}
	
	/**
	 * Gets the korelevancy.
	 *
	 * @return the korelevancy
	 */
	public String getKorelevancy() {
		return korelevancy;
	}
	
	/**
	 * Sets the korelevancy.
	 *
	 * @param korelevancy the new korelevancy
	 */
	public void setKorelevancy(String korelevancy) {
		this.korelevancy = korelevancy;
	}
	
	/**
	 * Gets the kousage.
	 *
	 * @return the kousage
	 */
	public String getKousage() {
		return kousage;
	}
	
	/**
	 * Sets the kousage.
	 *
	 * @param kousage the new kousage
	 */
	public void setKousage(String kousage) {
		this.kousage = kousage;
	}
	
	/**
	 * Gets the publication status.
	 *
	 * @return the publication status
	 */
	public String getPublicationStatus() {
		return publicationStatus;
	}
	
	/**
	 * Sets the publication status.
	 *
	 * @param publicationStatus the new publication status
	 */
	public void setPublicationStatus(String publicationStatus) {
		this.publicationStatus = publicationStatus;
	}
	
	/**
	 * Gets the review comments.
	 *
	 * @return the review comments
	 */
	public String getReviewComments() {
		return reviewComments;
	}
	
	/**
	 * Sets the review comments.
	 *
	 * @param reviewComments the new review comments
	 */
	public void setReviewComments(String reviewComments) {
		this.reviewComments = reviewComments;
	}
	
	/**
	 * Gets the reviewed by.
	 *
	 * @return the reviewed by
	 */
	public String getReviewedBy() {
		return reviewedBy;
	}
	
	/**
	 * Sets the reviewed by.
	 *
	 * @param reviewedBy the new reviewed by
	 */
	public void setReviewedBy(String reviewedBy) {
		this.reviewedBy = reviewedBy;
	}
	
	/**
	 * Gets the rework complete.
	 *
	 * @return the rework complete
	 */
	public String getReworkComplete() {
		return reworkComplete;
	}
	
	/**
	 * Sets the rework complete.
	 *
	 * @param reworkComplete the new rework complete
	 */
	public void setReworkComplete(String reworkComplete) {
		this.reworkComplete = reworkComplete;
	}
	
	

}
