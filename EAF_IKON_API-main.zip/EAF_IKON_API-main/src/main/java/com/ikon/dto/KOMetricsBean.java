package com.ikon.dto;

import javax.validation.constraints.NotBlank;

/**
 * The Class KOMetricsBean.
 */
public class KOMetricsBean {
	
	/** The timeline. */
	private String timeline;
	
	/** The ko created. */
	private String koCreated;
	
	/** The ko linked. */
	private String koLinked;
	
	/** The tickets resolved. */
	private String ticketsResolved;
	
	/** The application name. */
	private String applicationName;

	/** The assignment group. */
	private String assignmentGroup;
	
	/** The tower. */
	private String tower;
	
	/** The cc. */
	private String cc;
	
	/** The cluster. */
	private String cluster;
	
	/**
	 * Gets the timeline.
	 *
	 * @return the timeline
	 */
	public String getTimeline() {
		return timeline;
	}
	
	/**
	 * Sets the timeline.
	 *
	 * @param timeline the new timeline
	 */
	public void setTimeline(String timeline) {
		this.timeline = timeline;
	}
	
	/**
	 * Gets the ko created.
	 *
	 * @return the ko created
	 */
	public String getKoCreated() {
		return koCreated;
	}
	
	/**
	 * Sets the ko created.
	 *
	 * @param koCreated the new ko created
	 */
	public void setKoCreated(String koCreated) {
		this.koCreated = koCreated;
	}
	
	/**
	 * Gets the ko linked.
	 *
	 * @return the ko linked
	 */
	public String getKoLinked() {
		return koLinked;
	}
	
	/**
	 * Sets the ko linked.
	 *
	 * @param koLinked the new ko linked
	 */
	public void setKoLinked(String koLinked) {
		this.koLinked = koLinked;
	}
	
	/**
	 * Gets the tickets resolved.
	 *
	 * @return the tickets resolved
	 */
	public String getTicketsResolved() {
		return ticketsResolved;
	}
	
	/**
	 * Sets the tickets resolved.
	 *
	 * @param ticketsResolved the new tickets resolved
	 */
	public void setTicketsResolved(String ticketsResolved) {
		this.ticketsResolved = ticketsResolved;
	}
	
	/**
	 * Gets the application name.
	 *
	 * @return the application name
	 */
	public String getApplicationName() {
		return applicationName;
	}

	/**
	 * Sets the application name.
	 *
	 * @param applicationName the new application name
	 */
	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}

	/**
	 * Gets the assignment group.
	 *
	 * @return the assignment group
	 */
	public String getAssignmentGroup() {
		return assignmentGroup;
	}

	/**
	 * Sets the assignment group.
	 *
	 * @param assignmentGroup the new assignment group
	 */
	public void setAssignmentGroup(String assignmentGroup) {
		this.assignmentGroup = assignmentGroup;
	}
	/**
	 * Gets the tower.
	 *
	 * @return the tower
	 */
	public String getTower() {
		return tower;
	}

	/**
	 * Sets the tower.
	 *
	 * @param tower the new tower
	 */
	public void setTower(String tower) {
		this.tower = tower;
	}

	/**
	 * Gets the cc.
	 *
	 * @return the cc
	 */
	public String getCc() {
		return cc;
	}

	/**
	 * Sets the cc.
	 *
	 * @param cc the new cc
	 */
	public void setCc(String cc) {
		this.cc = cc;
	}

	/**
	 * Gets the cluster.
	 *
	 * @return the cluster
	 */
	public String getCluster() {
		return cluster;
	}

	/**
	 * Sets the cluster.
	 *
	 * @param cluster the new cluster
	 */
	public void setCluster(String cluster) {
		this.cluster = cluster;
	}
}
