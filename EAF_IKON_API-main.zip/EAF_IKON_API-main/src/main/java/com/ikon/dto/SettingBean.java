package com.ikon.dto;

/**
 * The Class SettingBean.
 */
public class SettingBean {

	/** The id. */
	int ID;

	/** The account ID. */
	int accountID;

	/** The account name. */
	String accountName;

	/** The page ID. */
	int pageID;

	/** The page name. */
	String pageName;

	/** The User ID. */
	String UserID;

	/** The default account ID. */
	int defaultAccountID;

	/** The default account name. */
	String defaultAccountName;

	/** The Landing page. */
	String LandingPage;

	/** The ticket resolved. */
	Integer ticketResolved;

	/** The ko created. */
	Integer koCreated;

	/** The ko used. */
	Integer koUsed;

	/** The Help desk ID. */
	int HelpDeskID;

	/** The Help desk pages. */
	String HelpDeskPages;

	/** The Help desk options. */
	String HelpDeskOptions;
	
	/** The is generic. */
	private Integer isGeneric = 0;

	/**
	 * Gets the help desk options.
	 *
	 * @return the helpDeskOptions
	 */
	public String getHelpDeskOptions() {
		return HelpDeskOptions;
	}

	/**
	 * Sets the help desk options.
	 *
	 * @param helpDeskOptions the helpDeskOptions to set
	 */
	public void setHelpDeskOptions(String helpDeskOptions) {
		HelpDeskOptions = helpDeskOptions;
	}

	/**
	 * Gets the help desk ID.
	 *
	 * @return the helpDeskID
	 */
	public int getHelpDeskID() {
		return HelpDeskID;
	}

	/**
	 * Sets the help desk ID.
	 *
	 * @param helpDeskID the helpDeskID to set
	 */
	public void setHelpDeskID(int helpDeskID) {
		HelpDeskID = helpDeskID;
	}

	/**
	 * Gets the help desk pages.
	 *
	 * @return the helpDeskPages
	 */
	public String getHelpDeskPages() {
		return HelpDeskPages;
	}

	/**
	 * Sets the help desk pages.
	 *
	 * @param helpDeskPages the helpDeskPages to set
	 */
	public void setHelpDeskPages(String helpDeskPages) {
		HelpDeskPages = helpDeskPages;
	}

	/**
	 * Gets the ticket resolved.
	 *
	 * @return the ticket resolved
	 */
	public Integer getTicketResolved() {
		return ticketResolved;
	}

	/**
	 * Sets the ticket resolved.
	 *
	 * @param ticketResolved the new ticket resolved
	 */
	public void setTicketResolved(Integer ticketResolved) {
		this.ticketResolved = ticketResolved;
	}

	/**
	 * Gets the ko created.
	 *
	 * @return the ko created
	 */
	public Integer getKoCreated() {
		return koCreated;
	}

	/**
	 * Sets the ko created.
	 *
	 * @param koCreated the new ko created
	 */
	public void setKoCreated(Integer koCreated) {
		this.koCreated = koCreated;
	}

	/**
	 * Gets the ko used.
	 *
	 * @return the ko used
	 */
	public Integer getKoUsed() {
		return koUsed;
	}

	/**
	 * Sets the ko used.
	 *
	 * @param koUsed the new ko used
	 */
	public void setKoUsed(Integer koUsed) {
		this.koUsed = koUsed;
	}

	/**
	 * Gets the landing page.
	 *
	 * @return the landing page
	 */
	public String getLandingPage() {
		return LandingPage;
	}

	/**
	 * Sets the landing page.
	 *
	 * @param landingPage the new landing page
	 */
	public void setLandingPage(String landingPage) {
		LandingPage = landingPage;
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getID() {
		return ID;
	}

	/**
	 * Sets the id.
	 *
	 * @param iD the new id
	 */
	public void setID(int iD) {
		ID = iD;
	}

	/**
	 * Gets the default account ID.
	 *
	 * @return the default account ID
	 */
	public int getDefaultAccountID() {
		return defaultAccountID;
	}

	/**
	 * Sets the default account ID.
	 *
	 * @param defaultAccountID the new default account ID
	 */
	public void setDefaultAccountID(int defaultAccountID) {
		this.defaultAccountID = defaultAccountID;
	}

	/**
	 * Gets the default account name.
	 *
	 * @return the default account name
	 */
	public String getDefaultAccountName() {
		return defaultAccountName;
	}

	/**
	 * Sets the default account name.
	 *
	 * @param defaultAccountName the new default account name
	 */
	public void setDefaultAccountName(String defaultAccountName) {
		this.defaultAccountName = defaultAccountName;
	}

	/**
	 * Gets the user ID.
	 *
	 * @return the user ID
	 */
	public String getUserID() {
		return UserID;
	}

	/**
	 * Sets the user ID.
	 *
	 * @param userID the new user ID
	 */
	public void setUserID(String userID) {
		UserID = userID;
	}

	/**
	 * Gets the account ID.
	 *
	 * @return the account ID
	 */
	public int getAccountID() {
		return accountID;
	}

	/**
	 * Sets the account ID.
	 *
	 * @param accountID the new account ID
	 */
	public void setAccountID(int accountID) {
		this.accountID = accountID;
	}

	/**
	 * Gets the account name.
	 *
	 * @return the account name
	 */
	public String getAccountName() {
		return accountName;
	}

	/**
	 * Sets the account name.
	 *
	 * @param accountName the new account name
	 */
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	/**
	 * Gets the page ID.
	 *
	 * @return the page ID
	 */
	public int getPageID() {
		return pageID;
	}

	/**
	 * Sets the page ID.
	 *
	 * @param pageID the new page ID
	 */
	public void setPageID(int pageID) {
		this.pageID = pageID;
	}

	/**
	 * Gets the page name.
	 *
	 * @return the page name
	 */
	public String getPageName() {
		return pageName;
	}

	/**
	 * Sets the page name.
	 *
	 * @param pageName the new page name
	 */
	public void setPageName(String pageName) {
		this.pageName = pageName;
	}

	/**
	 * Gets the checks if is generic.
	 *
	 * @return the checks if is generic
	 */
	public Integer getIsGeneric() {
		return isGeneric;
	}

	/**
	 * Sets the checks if is generic.
	 *
	 * @param isGeneric the new checks if is generic
	 */
	public void setIsGeneric(Integer isGeneric) {
		this.isGeneric = isGeneric;
	}
	
	

}
