package com.ikon.dto;

/**
 * The Class KoDataAttributeVO.
 */
public class KoDataAttributeVO {
	
	/** The master dt attr vo. */
	private MasterDataAttributeVO masterDtAttrVo = new MasterDataAttributeVO();
	
	/** The ko dt attr. */
	private KoDataAttribute koDtAttr = new KoDataAttribute();
	
	/** The freq. */
	private String freq;
	
	/** The group. */
	private String group;
	
	/**
	 * Gets the master dt attr vo.
	 *
	 * @return the master dt attr vo
	 */
	public MasterDataAttributeVO getMasterDtAttrVo() {
		return masterDtAttrVo;
	}
	
	/**
	 * Sets the master dt attr vo.
	 *
	 * @param masterDtAttrVo the new master dt attr vo
	 */
	public void setMasterDtAttrVo(MasterDataAttributeVO masterDtAttrVo) {
		this.masterDtAttrVo = masterDtAttrVo;
	}
	
	/**
	 * Gets the ko dt attr.
	 *
	 * @return the ko dt attr
	 */
	public KoDataAttribute getKoDtAttr() {
		return koDtAttr;
	}
	
	/**
	 * Sets the ko dt attr.
	 *
	 * @param koDtAttr the new ko dt attr
	 */
	public void setKoDtAttr(KoDataAttribute koDtAttr) {
		this.koDtAttr = koDtAttr;
	}
	
	/**
	 * Gets the freq.
	 *
	 * @return the freq
	 */
	public String getFreq() {
		return freq;
	}
	
	/**
	 * Sets the freq.
	 *
	 * @param freq the new freq
	 */
	public void setFreq(String freq) {
		this.freq = freq;
	}
	
	/**
	 * Gets the group.
	 *
	 * @return the group
	 */
	public String getGroup() {
		return group;
	}
	
	/**
	 * Sets the group.
	 *
	 * @param group the new group
	 */
	public void setGroup(String group) {
		this.group = group;
	}
	
	
	
}
