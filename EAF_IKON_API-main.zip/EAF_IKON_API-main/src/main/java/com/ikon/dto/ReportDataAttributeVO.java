package com.ikon.dto;

/**
 * The Class ReportDataAttributeVO.
 */
public class ReportDataAttributeVO {
	
	/** The report id. */
	private String reportId;
	
	/** The is favorite report. */
	private String isFavoriteReport;
	
	/** The account id. */
	private String accountId;
	
	/** The user id. */
	private String userId;
	
	
	/**
	 * Instantiates a new report data attribute VO.
	 *
	 * @param accountId the account id
	 * @param userId the user id
	 * @param reportId the report id
	 * @param isFavoriteReport the is favorite report
	 */
	public ReportDataAttributeVO(String accountId, String userId,String reportId, String isFavoriteReport) {
		super();
		this.reportId = reportId;
		this.isFavoriteReport = isFavoriteReport;
		this.accountId = accountId;
		this.userId = userId;
	}
	
	/**
	 * Gets the account id.
	 *
	 * @return the account id
	 */
	public String getAccountId() {
		return accountId;
	}
	
	/**
	 * Sets the account id.
	 *
	 * @param accountId the new account id
	 */
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	
	/**
	 * Gets the user id.
	 *
	 * @return the user id
	 */
	public String getUserId() {
		return userId;
	}
	
	/**
	 * Sets the user id.
	 *
	 * @param userId the new user id
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	/**
	 * Gets the report id.
	 *
	 * @return the report id
	 */
	public String getReportId() {
		return reportId;
	}
	
	/**
	 * Sets the report id.
	 *
	 * @param reportId the new report id
	 */
	public void setReportId(String reportId) {
		this.reportId = reportId;
	}
	
	/**
	 * Gets the checks if is favorite report.
	 *
	 * @return the checks if is favorite report
	 */
	public String getIsFavoriteReport() {
		return isFavoriteReport;
	}
	
	/**
	 * Sets the checks if is favorite report.
	 *
	 * @param isFavoriteReport the new checks if is favorite report
	 */
	public void setIsFavoriteReport(String isFavoriteReport) {
		this.isFavoriteReport = isFavoriteReport;
	}

	

}
