package com.ikon.dto;

import java.math.BigDecimal;
import java.math.BigInteger;

/**
 * The Class DashboardBean.
 *
 * @author narakeri
 */
public class DashboardBean {

	/** ticketsToday. */
	private Integer ticketsToday;
	
	/** openIncidents. */
	private Integer openIncidents;
	
	/** inprogress. */
	private Integer inprogress;
	
	/** ticket. */
	private String ticket;
	
	/** koCount. */
	private Integer koCount;
	
	/** draftCount. */
	private Integer draftCount;
	
	/** reviewCount. */
	private Integer reviewCount;
	
	/** publishCount. */
	private Integer publishCount;
	
	/** applicationName. */
	private String applicationName;
	
	/** userName. */
	private String userName;
	
	/** koID. */
	private String koID;
	
	/** rank. */
	private Integer rank;
	
	/** name. */
	private String name;
	
	/** totalPoints. */
	private Integer totalPoints;
	
	/** rankToday. */
	private Integer rankToday;
	
	/** rankYesterday. */
	private Integer rankYesterday;
	
	/** rankLastWeek. */
	private Integer rankLastWeek;
	
	/** yesterdayPosition. */
	private Integer yesterdayPosition;
	
	/** userID. */
	private String userID;
	
	/** score. */
	private Byte score;
	
	/** lastWeekPosition. */
	private Byte lastWeekPosition;
	
	/** profile. */
	private String profile;
	
	/** AccountID. */
	private String AccountID;
	
	/** scoreSerialNumber. */
	private Integer scoreSerialNumber;
    
    /** selectedVals. */
    private String selectedVals;
    
    /** accountName. */
    private String accountName;
    
    /** assignmentGroup. */
    private String assignmentGroup;
    
    /** assigneeName. */
    private String assigneeName;
    
    /** STATUS. */
    private String STATUS;
    
    /** publicationStatus. */
    private String publicationStatus;
    
    /** ticketIDCount. */
    private BigInteger ticketIDCount;
    
    /** openedTicketIDCount. */
    private BigInteger openedTicketIDCount;
    
    /** koIDCount. */
    private BigInteger koIDCount;
    
    /** serialNumber. */
    private Integer serialNumber;
    
    /** scenarioID. */
    private Integer scenarioID;
    
    /** statusCount. */
    private Integer statusCount;
    
    /** koLinked. */
    private BigInteger koLinked;
    
    /** points. */
    private Integer points;
    
    /** mttrValueForAllIncidents. */
    private BigDecimal mttrValueForAllIncidents;
    
    /** total ticketCount. */
    private BigInteger ticketCount;
    
    /** mttrValue in hrs. */
    private BigDecimal mttrValue;
    
    /** INc priority. */
    private String priority;
    
    /** The from date. */
    private String fromDate;
	
	/** The to date. */
	private String toDate;
	
	/** The tower. */
	private String tower;
	
	/** The cc. */
	private String CC;
	
	/** The Cluster. */
	private String Cluster;
	
	/** The ticket linked count. */
	private Integer ticketLinkedCount;
	
	/** The linked ticketsmttr. */
	private Integer linkedTicketsmttr;
	
	

	/**
	 * Gets the linked ticketsmttr.
	 *
	 * @return the linked ticketsmttr
	 */
	public Integer getLinkedTicketsmttr() {
		return linkedTicketsmttr;
	}

	/**
	 * Sets the linked ticketsmttr.
	 *
	 * @param linkedTicketsmttr the new linked ticketsmttr
	 */
	public void setLinkedTicketsmttr(Integer linkedTicketsmttr) {
		this.linkedTicketsmttr = linkedTicketsmttr;
	}

	/**
	 * Gets the ticket linked count.
	 *
	 * @return the ticket linked count
	 */
	public Integer getTicketLinkedCount() {
		return ticketLinkedCount;
	}

	/**
	 * Sets the ticket linked count.
	 *
	 * @param ticketLinkedCount the new ticket linked count
	 */
	public void setTicketLinkedCount(Integer ticketLinkedCount) {
		this.ticketLinkedCount = ticketLinkedCount;
	}

	/**
	 * Gets the tower.
	 *
	 * @return the tower
	 */
	public String getTower() {
		return tower;
	}

	/**
	 * Sets the tower.
	 *
	 * @param tower the new tower
	 */
	public void setTower(String tower) {
		this.tower = tower;
	}

	/**
	 * Gets the cc.
	 *
	 * @return the cc
	 */
	public String getCC() {
		return CC;
	}

	/**
	 * Sets the cc.
	 *
	 * @param cC the new cc
	 */
	public void setCC(String cC) {
		CC = cC;
	}

	/**
	 * Gets the cluster.
	 *
	 * @return the cluster
	 */
	public String getCluster() {
		return Cluster;
	}

	/**
	 * Sets the cluster.
	 *
	 * @param cluster the new cluster
	 */
	public void setCluster(String cluster) {
		Cluster = cluster;
	}

	/**
	 * Gets the from date.
	 *
	 * @return the from date
	 */
	public String getFromDate() {
		return fromDate;
	}

	/**
	 * Sets the from date.
	 *
	 * @param fromDate the new from date
	 */
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
    
	/**
	 * Gets the to date.
	 *
	 * @return the to date
	 */
	public String getToDate() {
		return toDate;
	}

	/**
	 * Sets the to date.
	 *
	 * @param toDate the new to date
	 */
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	/**
	 * Gets the points.
	 *
	 * @return the points
	 */
	public Integer getPoints() {
		return points;
	}

	/**
	 * Sets the points.
	 *
	 * @param points the new points
	 */
	public void setPoints(Integer points) {
		this.points = points;
	}

	/**
	 * Gets the ko linked.
	 *
	 * @return the ko linked
	 */
	public BigInteger getKoLinked() {
		return koLinked;
	}

	/**
	 * Sets the ko linked.
	 *
	 * @param koLinked the new ko linked
	 */
	public void setKoLinked(BigInteger koLinked) {
		this.koLinked = koLinked;
	}

	/**
	 * Gets the status count.
	 *
	 * @return the status count
	 */
	public Integer getStatusCount() {
		return statusCount;
	}

	/**
	 * Sets the status count.
	 *
	 * @param statusCount the new status count
	 */
	public void setStatusCount(Integer statusCount) {
		this.statusCount = statusCount;
	}

	/**
	 * Gets the scenario ID.
	 *
	 * @return the scenario ID
	 */
	public Integer getScenarioID() {
		return scenarioID;
	}

	/**
	 * Sets the scenario ID.
	 *
	 * @param scenarioID the new scenario ID
	 */
	public void setScenarioID(Integer scenarioID) {
		this.scenarioID = scenarioID;
	}

	/**
	 * Gets the user ID.
	 *
	 * @return the user ID
	 */
	public String getUserID() {
		return userID;
	}

	/**
	 * Sets the user ID.
	 *
	 * @param userID the new user ID
	 */
	public void setUserID(String userID) {
		this.userID = userID;
	}

	/**
	 * Gets the serial number.
	 *
	 * @return the serial number
	 */
	public Integer getSerialNumber() {
		return serialNumber;
	}

	/**
	 * Sets the serial number.
	 *
	 * @param serialNumber the new serial number
	 */
	public void setSerialNumber(Integer serialNumber) {
		this.serialNumber = serialNumber;
	}

	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getSTATUS() {
		return STATUS;
	}

	/**
	 * Sets the status.
	 *
	 * @param sTATUS the new status
	 */
	public void setSTATUS(String sTATUS) {
		STATUS = sTATUS;
	}

	/**
	 * Gets the ticket ID count.
	 *
	 * @return the ticket ID count
	 */
	public BigInteger getTicketIDCount() {
		return ticketIDCount;
	}

	/**
	 * Sets the ticket ID count.
	 *
	 * @param ticketIDCount the new ticket ID count
	 */
	public void setTicketIDCount(BigInteger ticketIDCount) {
		this.ticketIDCount = ticketIDCount;
	}

	/**
	 * Gets the opened ticket ID count.
	 *
	 * @return the opened ticket ID count
	 */
	public BigInteger getOpenedTicketIDCount() {
		return openedTicketIDCount;
	}

	/**
	 * Sets the opened ticket ID count.
	 *
	 * @param openedTicketIDCount the new opened ticket ID count
	 */
	public void setOpenedTicketIDCount(BigInteger openedTicketIDCount) {
		this.openedTicketIDCount = openedTicketIDCount;
	}

	/**
	 * Gets the publication status.
	 *
	 * @return the publication status
	 */
	public String getPublicationStatus() {
		return publicationStatus;
	}

	/**
	 * Sets the publication status.
	 *
	 * @param publicationStatus the new publication status
	 */
	public void setPublicationStatus(String publicationStatus) {
		this.publicationStatus = publicationStatus;
	}

	/**
	 * Gets the account name.
	 *
	 * @return the account name
	 */
	public String getAccountName() {
		return accountName;
	}

	/**
	 * Sets the account name.
	 *
	 * @param accountName the new account name
	 */
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	/**
	 * Gets the assignment group.
	 *
	 * @return the assignment group
	 */
	public String getAssignmentGroup() {
		return assignmentGroup;
	}

	/**
	 * Sets the assignment group.
	 *
	 * @param assignmentGroup the new assignment group
	 */
	public void setAssignmentGroup(String assignmentGroup) {
		this.assignmentGroup = assignmentGroup;
	}

	/**
	 * Gets the assignee name.
	 *
	 * @return the assignee name
	 */
	public String getAssigneeName() {
		return assigneeName;
	}

	/**
	 * Sets the assignee name.
	 *
	 * @param assigneeName the new assignee name
	 */
	public void setAssigneeName(String assigneeName) {
		this.assigneeName = assigneeName;
	}

	/**
	 * Gets the selected vals.
	 *
	 * @return the selected vals
	 */
	public String getSelectedVals() {
		return selectedVals;
	}

	/**
	 * Sets the selected vals.
	 *
	 * @param selectedVals the new selected vals
	 */
	public void setSelectedVals(String selectedVals) {
		this.selectedVals = selectedVals;
	}

	/**
	 * Gets the account ID.
	 *
	 * @return the account ID
	 */
	public String getAccountID() {
		return AccountID;
	}

	/**
	 * Sets the account ID.
	 *
	 * @param accountID the new account ID
	 */
	public void setAccountID(String accountID) {
		AccountID = accountID;
	}

	/**
	 * Gets the profile.
	 *
	 * @return the profile
	 */
	public String getProfile() {
		return profile;
	}

	/**
	 * Sets the profile.
	 *
	 * @param profile the new profile
	 */
	public void setProfile(String profile) {
		this.profile = profile;
	}

	/**
	 * Gets the score serial number.
	 *
	 * @return the score serial number
	 */
	public Integer getScoreSerialNumber() {
		return scoreSerialNumber;
	}

	/**
	 * Sets the score serial number.
	 *
	 * @param scoreSerialNumber the new score serial number
	 */
	public void setScoreSerialNumber(Integer scoreSerialNumber) {
		this.scoreSerialNumber = scoreSerialNumber;
	}

	/**
	 * Gets the score.
	 *
	 * @return the score
	 */
	public Byte getScore() {
		return score;
	}

	/**
	 * Sets the score.
	 *
	 * @param score the new score
	 */
	public void setScore(Byte score) {
		this.score = score;
	}

	/**
	 * Gets the last week position.
	 *
	 * @return the last week position
	 */
	public Byte getLastWeekPosition() {
		return lastWeekPosition;
	}

	/**
	 * Sets the last week position.
	 *
	 * @param lastWeekPosition the new last week position
	 */
	public void setLastWeekPosition(Byte lastWeekPosition) {
		this.lastWeekPosition = lastWeekPosition;
	}

	/**
	 * Gets the total points.
	 *
	 * @return the total points
	 */
	public Integer getTotalPoints() {
		return totalPoints;
	}

	/**
	 * Sets the total points.
	 *
	 * @param totalPoints the new total points
	 */
	public void setTotalPoints(Integer totalPoints) {
		this.totalPoints = totalPoints;
	}

	/**
	 * Gets the rank today.
	 *
	 * @return the rank today
	 */
	public Integer getRankToday() {
		return rankToday;
	}

	/**
	 * Sets the rank today.
	 *
	 * @param rankToday the new rank today
	 */
	public void setRankToday(Integer rankToday) {
		this.rankToday = rankToday;
	}

	/**
	 * Gets the rank yesterday.
	 *
	 * @return the rank yesterday
	 */
	public Integer getRankYesterday() {
		return rankYesterday;
	}

	/**
	 * Sets the rank yesterday.
	 *
	 * @param rankYesterday the new rank yesterday
	 */
	public void setRankYesterday(Integer rankYesterday) {
		this.rankYesterday = rankYesterday;
	}

	/**
	 * Gets the rank last week.
	 *
	 * @return the rank last week
	 */
	public Integer getRankLastWeek() {
		return rankLastWeek;
	}

	/**
	 * Sets the rank last week.
	 *
	 * @param rankLastWeek the new rank last week
	 */
	public void setRankLastWeek(Integer rankLastWeek) {
		this.rankLastWeek = rankLastWeek;
	}

	/**
	 * Gets the yesterday position.
	 *
	 * @return the yesterday position
	 */
	public Integer getYesterdayPosition() {
		return yesterdayPosition;
	}

	/**
	 * Sets the yesterday position.
	 *
	 * @param yesterdayPosition the new yesterday position
	 */
	public void setYesterdayPosition(Integer yesterdayPosition) {
		this.yesterdayPosition = yesterdayPosition;
	}

	/**
	 * Gets the rank.
	 *
	 * @return the rank
	 */
	public Integer getRank() {
		return rank;
	}

	/**
	 * Sets the rank.
	 *
	 * @param rank the new rank
	 */
	public void setRank(Integer rank) {
		this.rank = rank;
	}

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Gets the user name.
	 *
	 * @return the user name
	 */
	// Get username
	public String getUserName() {
		return userName;
	}

	/**
	 * Sets the user name.
	 *
	 * @param userName the new user name
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * Gets the tickets today.
	 *
	 * @return the tickets today
	 */
	public Integer getTicketsToday() {
		return ticketsToday;
	}

	/**
	 * Sets the tickets today.
	 *
	 * @param ticketsToday the new tickets today
	 */
	public void setTicketsToday(Integer ticketsToday) {
		this.ticketsToday = ticketsToday;
	}

	/**
	 * Gets the open incidents.
	 *
	 * @return the open incidents
	 */
	public Integer getOpenIncidents() {
		return openIncidents;
	}

	/**
	 * Sets the open incidents.
	 *
	 * @param openIncidents the new open incidents
	 */
	public void setOpenIncidents(Integer openIncidents) {
		this.openIncidents = openIncidents;
	}

	/**
	 * Gets the inprogress.
	 *
	 * @return the inprogress
	 */
	public Integer getInprogress() {
		return inprogress;
	}

	/**
	 * Sets the inprogress.
	 *
	 * @param inprogress the new inprogress
	 */
	public void setInprogress(Integer inprogress) {
		this.inprogress = inprogress;
	}

	/**
	 * Gets the ticket.
	 *
	 * @return the ticket
	 */
	public String getTicket() {
		return ticket;
	}

	/**
	 * Sets the ticket.
	 *
	 * @param ticket the new ticket
	 */
	public void setTicket(String ticket) {
		this.ticket = ticket;
	}

	/**
	 * Gets the ko count.
	 *
	 * @return the ko count
	 */
	public Integer getKoCount() {
		return koCount;
	}

	/**
	 * Sets the ko count.
	 *
	 * @param koCount the new ko count
	 */
	public void setKoCount(Integer koCount) {
		this.koCount = koCount;
	}

	/**
	 * Gets the draft count.
	 *
	 * @return the draft count
	 */
	public Integer getDraftCount() {
		return draftCount;
	}

	/**
	 * Sets the draft count.
	 *
	 * @param draftCount the new draft count
	 */
	public void setDraftCount(Integer draftCount) {
		this.draftCount = draftCount;
	}

	/**
	 * Gets the review count.
	 *
	 * @return the review count
	 */
	public Integer getReviewCount() {
		return reviewCount;
	}

	/**
	 * Sets the review count.
	 *
	 * @param reviewCount the new review count
	 */
	public void setReviewCount(Integer reviewCount) {
		this.reviewCount = reviewCount;
	}

	/**
	 * Gets the publish count.
	 *
	 * @return the publish count
	 */
	public Integer getPublishCount() {
		return publishCount;
	}

	/**
	 * Sets the publish count.
	 *
	 * @param publishCount the new publish count
	 */
	public void setPublishCount(Integer publishCount) {
		this.publishCount = publishCount;
	}

	/**
	 * Gets the application name.
	 *
	 * @return the application name
	 */
	public String getApplicationName() {
		return applicationName;
	}

	/**
	 * Sets the application name.
	 *
	 * @param applicationName the new application name
	 */
	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}

	/**
	 * Gets the ko ID.
	 *
	 * @return the ko ID
	 */
	public String getKoID() {
		return koID;
	}

	/**
	 * Sets the ko ID.
	 *
	 * @param koID the new ko ID
	 */
	public void setKoID(String koID) {
		this.koID = koID;
	}

	/**
	 * Gets the ko ID count.
	 *
	 * @return the koIDCount
	 */
	public BigInteger getKoIDCount() {
		return koIDCount;
	}

	/**
	 * Sets the ko ID count.
	 *
	 * @param koIDCount the koIDCount to set
	 */
	public void setKoIDCount(BigInteger koIDCount) {
		this.koIDCount = koIDCount;
	}



	/**
	 * Gets the mttr value for all incidents.
	 *
	 * @return the mttr value for all incidents
	 */
	public BigDecimal getMttrValueForAllIncidents() {
		return mttrValueForAllIncidents;
	}

	/**
	 * Sets the mttr value for all incidents.
	 *
	 * @param mttrValueForAllIncidents the new mttr value for all incidents
	 */
	public void setMttrValueForAllIncidents(BigDecimal mttrValueForAllIncidents) {
		this.mttrValueForAllIncidents = mttrValueForAllIncidents;
	}

	/**
	 * Gets the ticket count.
	 *
	 * @return the ticket count
	 */
	public BigInteger getTicketCount() {
		return ticketCount;
	}

	/**
	 * Sets the ticket count.
	 *
	 * @param ticketCount the new ticket count
	 */
	public void setTicketCount(BigInteger ticketCount) {
		this.ticketCount = ticketCount;
	}

	/**
	 * Gets the mttr value.
	 *
	 * @return the mttr value
	 */
	public BigDecimal getMttrValue() {
		return mttrValue;
	}

	/**
	 * Sets the mttr value.
	 *
	 * @param mttrValue the new mttr value
	 */
	public void setMttrValue(BigDecimal mttrValue) {
		this.mttrValue = mttrValue;
	}

	/**
	 * Gets the priority.
	 *
	 * @return the priority
	 */
	public String getPriority() {
		return priority;
	}

	/**
	 * Sets the priority.
	 *
	 * @param priority the new priority
	 */
	public void setPriority(String priority) {
		this.priority = priority;
	}

  
}
