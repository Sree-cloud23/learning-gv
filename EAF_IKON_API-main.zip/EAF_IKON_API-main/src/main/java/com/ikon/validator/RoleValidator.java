package com.ikon.validator;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.ikon.model.Role;

/**
 * The Class RoleValidator.
 */
@Component
public class RoleValidator implements Validator {

	/**
	 * Supports.
	 *
	 * @param aClass the a class
	 * @return true, if successful
	 */
	@Override
	public boolean supports(Class<?> aClass) {

		return Role.class.equals(aClass);
	}

	/**
	 * Validate.
	 *
	 * @param o      the o
	 * @param errors the errors
	 */
	@Override
	public void validate(Object o, Errors errors) {
		@SuppressWarnings("unused")
		Role appBean = (Role) o;
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "Role_Name", "NotEmptyRoleName");
	}

}
