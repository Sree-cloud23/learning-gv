package com.ikon.validator;

import java.util.Objects;

import javax.inject.Inject;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.ikon.model.UserMaster;
import com.ikon.service.UserService;

/**
 * The Class UserValidator.
 */
@Component
public class UserValidator implements Validator {
    
    /** The user service. */
	@Inject
    private transient UserService userService;

    /**
     * Supports.
     *
     * @param aClass the a class
     * @return true, if successful
     */
    @Override
    public boolean supports(Class<?> aClass) {
        return UserMaster.class.equals(aClass);
    }

    /**
     * Validate.
     *
     * @param o the o
     * @param errors the errors
     */
    @Override
    public void validate(Object o, Errors errors) {
    	UserMaster user = (UserMaster) o;

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "NotEmpty");
        if (user.getName().length() < 2 || user.getName().length() > 32) {
            errors.rejectValue("name", "Size.userForm.name");
        }
        if (Objects.nonNull(userService.findByUsername(user.getName()))) {
            errors.rejectValue("name", "Duplicate.userForm.name");
        }

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "NotEmpty");
        if (user.getPassword().length() < 2 || user.getPassword().length() > 32) {
            errors.rejectValue("password", "Size.userForm.password");
        }

        if (!user.getPasswordConfirm().equals(user.getPassword())) {
            errors.rejectValue("passwordConfirm", "Diff.userForm.passwordConfirm");
        }
    }
}
