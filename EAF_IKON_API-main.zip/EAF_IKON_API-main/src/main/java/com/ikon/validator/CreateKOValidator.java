package com.ikon.validator;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.ikon.dto.KOInfoBean;

/**
 * The Class CreateKOValidator.
 */
@Component
public class CreateKOValidator implements Validator {
	
	/** The constant NOT_EMPTY */
	private static final String NOT_EMPTY ="NotEmpty";

	/**
	 * Supports.
	 *
	 * @param aClass the a class
	 * @return true, if successful
	 */
	@Override
	public boolean supports(Class<?> aClass) {

		return KOInfoBean.class.equals(aClass);
	}

	/**
	 * Validate.
	 *
	 * @param o the o
	 * @param errors the errors
	 */
	@Override
	public void validate(Object o, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "longDescription", NOT_EMPTY);
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "symptoms", NOT_EMPTY);
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "answer", NOT_EMPTY);
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "resolution", NOT_EMPTY);
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "ticketsearchbox", NOT_EMPTY);
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "assignmentGroup", NOT_EMPTY);
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "applicationName", NOT_EMPTY);
	}
}
