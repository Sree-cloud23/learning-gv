/**
 * 
 */
package com.ikon.validator;

import java.util.Objects;

/**
 * @author Tools n Methods
 *
 */
public class IKONUtils {
	
	/**
	 * check Null.
	 *
	 * @param obj the obj
	 * @return Object obj
	 */
	public static Object checkNull(Object obj) {
		return Objects.nonNull(obj)?obj:"";
	}
	
	/**
	 * check Null.
	 *
	 * @param obj the obj
	 * @return Object obj
	 */
	public static Object checkNullInteger(Object obj) {
		return Objects.nonNull(obj)?obj:0;
	}
	
	/**
	 * Checks if is null or empty.
	 *
	 * @param toTest the to test
	 * @return true, if is null or empty
	 */
	public static boolean isNullOrEmpty(String str) {
        return (Objects.isNull(str) || str.isEmpty());
    }

}
