package com.ikon.web;

import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.ikon.dto.KOInfoBean;
import com.ikon.dto.MasterDataAttributeVO;
import com.ikon.dto.ReportDataAttributeVO;
import com.ikon.dto.TicketDataAttributeVO;
import com.ikon.dto.TicketDataBean;
import com.ikon.dto.UserBean;
import com.ikon.model.KOUsage;
import com.ikon.model.TicketDataHistory;
import com.ikon.repository.KOInfoRepository;
import com.ikon.repository.KOUsageRepository;
import com.ikon.rest.web.models.Authentication;
import com.ikon.rest.web.models.SecurityContext;
import com.ikon.rest.web.models.SecurityContextHolder;
import com.ikon.service.AccessControlService;
import com.ikon.service.KOInfoService;
import com.ikon.service.MLDBProcess;
import com.ikon.service.ReportService;
import com.ikon.service.TicketDataService;
import com.ikon.service.UserService;
import com.ikon.validator.IKONUtils;

import lombok.extern.slf4j.Slf4j;


/**
 * The Class IKONController.
 */
@Controller
@Slf4j
public class IKONController implements ErrorController {

	/** The Constant OPEN_INCIDENT_REPORT_ID. */
	private static final String OPEN_INCIDENT_REPORT_ID = "1";

	/** The Constant INC_MISSING_KO_REPORT_ID. */
	private static final String INC_MISSING_KO_REPORT_ID = "2";

	/** The Constant VIEW_ACTION_ID. */
	private static final String VIEW_ACTION_ID = "1";

	/** The ticket data service. */
	@Inject
	private transient TicketDataService ticketDataService;

	/** The report service. */
	@Inject
	private transient ReportService reportService;

	/** The access control service. */
	@Inject
	private transient AccessControlService accessControlService;

	/** The k O usage repository. */
	@Inject
	private transient KOUsageRepository kOUsageRepository;

	/** The k O info repository. */
	@Inject
	private transient KOInfoRepository kOInfoRepository;

	/** The user service. */
	@Inject
	private transient UserService userService;
	
	/** The ko info service. */
	@Autowired
	private transient KOInfoService koInfoService;
	
	/** The ikon controller. */
	@Inject
	private transient HelpDeskController helpdeskController;
	/** The ikon controller. */
	@Inject
	private transient KOController koController;

	/** The Constant log. */
	//private static final log log = LogManager.getlog(IKONController.class);

	/** The Constant TICKET_ID. */
	private static final String TICKET_ID = "Ticket ID";

	/** The Constant TICKET_SUMMARY_FORM_DETAIL. */
	private static final String TICKET_SUMMARY_FORM_DETAIL = "ticketSummaryFormDetail";

	/** The Constant COLLAPSE. */
	private static final String COLLAPSE = "collapse";

	/** The Constant ASSIGNEE. */
	private static final String ASSIGNEE = "Assignee";

	/** The Constant STATUS. */
	private static final String STATUS = "Status";

	/** The Constant SUMMARY. */
	private static final String SUMMARY = "Summary";

	/** The Constant TICKET_TYPE. */
	private static final String TICKET_TYPE = "Ticket Type";

	/** The Constant ASSIGNMENT_GROUP. */
	private static final String ASSIGNMENT_GROUP = "Assignment Group";

	/** The Constant APPLICATION. */
	private static final String APPLICATION = "Application";

	/** The Constant REPORT_CAT. */
	private static final String REPORT_CAT = "reportCategorization";

	/** The Constant BADGE_WARNING. */
	private static final String BADGE_WARNING = "badge-warning";

	/** The Constant COMPONENT_TYPE. */
	private static final String COMPONENT_TYPE = "componentType";

	/** The Constant SELECTED_SEARCH_TYPE_VAL. */
	private static final String SELECTED_SEARCH_TYPE_VAL = "selectedSearchTypeVal";

	/** The Constant FROM_LOGIN. */
	private static final String FROM_LOGIN = "fromLogin";

	/** The Constant REPORT_TYPE. */
	private static final String REPORT_TYPE = "reportType";

	/** The Constant REPORT_NAME. */
	private static final String REPORT_NAME = "reportName";

	/** The Constant TO_DATE. */
	private static final String TO_DATE = "toDate";

	/** The Constant FILTER_SELECTION. */
	private static final String FILTER_SELECTION = "filterSelection";

	/** The Constant INCIDENT. */
	private static final String INCIDENT = "Incident";

	/** The Constant BADGE_SUCCESS. */
	private static final String BADGE_SUCCESS = "badge-success";

	/** The Constant REPORT_FREQUENCY. */
	private static final String REPORT_FREQUENCY = "reportFrequency";

	/** The Constant FROM_DATE. */
	private static final String FROM_DATE = "fromDate";

	/** The Constant TRUE. */
	private static final String TRUE = "true";

	/** The Constant SEARCH_TYPE_CHOSEN. */
	private static final String SEARCH_TYPE_CHOSEN = "searchTypeChosen";

	/** The Constant YES. */
	private static final String YES = "yes";

	/** The Constant TICKET_SUMMARY_FORM. */
	private static final String TICKET_SUMMARY_FORM = "ticketSummaryForm";

	/** The Constant THREE. */
	private static final int THREE = 3;
	
	/** The Constant IS_GENERIC. */
	private static final String IS_GENERIC = "isGeneric";
	
	/** The ml DB process. */
	@Inject
	private transient MLDBProcess mlDBProcess;

	/**
	 * Ticket summary.
	 *
	 * @param ticketDataBean the ticket data bean
	 * @param model          the model
	 * @param request        the request
	 * @return the string
	 */
	@GetMapping("/ticketSummary")
	public String ticketSummary(@ModelAttribute(TICKET_SUMMARY_FORM_DETAIL) TicketDataBean ticketDataBean, Model model,
			HttpServletRequest request) {
		log.info("Start: ticketSummary");
		String userId = getLoggedUser();
		switch (getUserAccount()) {
		case 0:
			log.info("User belongs to normal account");
			break;
		case 2:
			log.info("User belongs to Generic enabled account");
			break;
		default:
			return "permissionDenied";
		}
		setModelfromRequest(model, request);
		String fromDate = request.getParameter(FROM_DATE);
		if (!IKONUtils.isNullOrEmpty(fromDate)) {
			ticketDataBean.setFromDate(fromDate);
		}
		String toDate = request.getParameter(TO_DATE);
		if (!IKONUtils.isNullOrEmpty(toDate)) {
			ticketDataBean.setToDate(toDate);
		}

		String selectedSearchType = request.getParameter(SEARCH_TYPE_CHOSEN);
		if (!IKONUtils.isNullOrEmpty(selectedSearchType)) {
			model.addAttribute(SELECTED_SEARCH_TYPE_VAL, selectedSearchType);
			ticketDataBean.setSearchType(selectedSearchType);
		}
		String filterSelection = request.getParameter(FILTER_SELECTION);
		if (!IKONUtils.isNullOrEmpty(filterSelection)) {
			model.addAttribute(FILTER_SELECTION, filterSelection);
		}
		String accountId = getDefaultAccountId();
		ticketSummaryExtract(ticketDataBean, request);
		String fromReport = request.getParameter("fromReport");
		if (!IKONUtils.isNullOrEmpty(fromReport)) {
			ReportDataAttributeVO reportDataAttributeVO = new ReportDataAttributeVO(accountId, userId, OPEN_INCIDENT_REPORT_ID,VIEW_ACTION_ID);
			reportService.insertReportUsage(reportDataAttributeVO);
		}

		List<TicketDataBean> ticketDataBean_lastupdatedate = ticketDataService.getStartTimeOfLastFeed();
		SimpleDateFormat dateformater_Java = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
		String lastUpdatedTime = dateformater_Java
				.format(ticketDataBean_lastupdatedate.get(0).getStartTimeOfLastFeed());
		model.addAttribute("lastUpdatedTime", lastUpdatedTime);

		List<TicketDataBean> ticketDataBeanList = new ArrayList<TicketDataBean>();
		String showLinkedTickets = request.getParameter("showLinkedTickets");
		String koId = request.getParameter("KoID");
		if(IKONUtils.isNullOrEmpty(showLinkedTickets)) {
			ticketDataBeanList = getAllTicketDataExtract(ticketDataBean, userId);
		}else {
			if(!IKONUtils.isNullOrEmpty(showLinkedTickets)) {
			ticketDataBeanList = ticketDataService.getLinkedTickets(koId,accountId);
			}else {
				return null;
			}
		}
		Set<String> allApplicationNameList = new TreeSet<String>();
		Set<String> allAssignmentGroupList = new TreeSet<String>();
		Set<String> allTicketTypeList = new TreeSet<String>();
		Set<String> allPriorityList = new TreeSet<String>();
		Set<String> allStatusList = new TreeSet<String>();
		Set<String> allAssigneeList = new TreeSet<String>();
		Set<String> allTowerList = new TreeSet<String>();
		Set<String> allCCList = new TreeSet<String>();
		Set<String> allClusterList = new TreeSet<String>();
		for (TicketDataBean tdb : ticketDataBeanList) {
			addToSet(allApplicationNameList,tdb.getApplicationName());
			addToSet(allAssignmentGroupList,tdb.getAssignmentGroup());
			addToSet(allTicketTypeList,tdb.getServiceType());
			addToSet(allPriorityList,tdb.getPriority());
			addToSet(allStatusList,tdb.getStatus());
			addToSet(allAssigneeList,tdb.getAssigneeName());
			addToSet(allTowerList,tdb.getTower());
			addToSet(allCCList,tdb.getCc());
			addToSet(allClusterList,tdb.getCluster());			
		}

		populateBreadCrumb(accountId, ticketDataBean, model);
		

		int serialNum = 1;

		List<KOUsage> koUsageList = kOUsageRepository.findAll();
		List<TicketDataHistory> ticketDataHistoryList = null;
		List<KOInfoBean> koInfoList = koInfoService.getAllKos(accountId);

		for (TicketDataBean tdb : ticketDataBeanList) {
			serialNum = setTicketLinkedCountExtract(model, accountId, serialNum, koUsageList, ticketDataHistoryList,
					koInfoList, tdb);
			addToSet(allApplicationNameList,tdb.getApplicationName());
			addToSet(allAssignmentGroupList,tdb.getAssignmentGroup());
			addToSet(allTicketTypeList,tdb.getServiceType());
			addToSet(allPriorityList,tdb.getPriority());
			addToSet(allStatusList,tdb.getStatus());
			addToSet(allAssigneeList,tdb.getAssigneeName());
			addToSet(allTowerList,tdb.getTower());
			addToSet(allCCList,tdb.getCc());
			addToSet(allClusterList,tdb.getCluster());
		}
		List<String> selectedValsArr = new ArrayList<String>(
				Arrays.asList(TICKET_ID, SUMMARY, TICKET_TYPE, ASSIGNMENT_GROUP, APPLICATION, "Priority", ASSIGNEE,
						STATUS, "KO Rel%", "KO Usage", "# Inc Linked", "Reported Date"));
		UserBean ubean = userService.getUserAccountType(accountId);
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		
		int isGeneric = ubean.getIsGeneric();
		model.addAttribute(IS_GENERIC, isGeneric);
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		log.info("End: ticketSummary");
		return returnTicketSummary(model, ticketDataBeanList, allApplicationNameList, allAssignmentGroupList,
				allTicketTypeList, allPriorityList, allStatusList, allAssigneeList, selectedValsArr);
	}

	/**
	 * Sets the modelfrom request.
	 *
	 * @param model the model
	 * @param request the request
	 */
	private void setModelfromRequest(Model model, HttpServletRequest request) {
		model.addAttribute(FROM_LOGIN, request.getParameter(FROM_LOGIN));
		model.addAttribute(REPORT_CAT, request.getParameter(REPORT_CAT));
		model.addAttribute(COMPONENT_TYPE, request.getParameter(COMPONENT_TYPE));
		model.addAttribute(REPORT_TYPE, request.getParameter(REPORT_TYPE));
		model.addAttribute(REPORT_NAME, request.getParameter(REPORT_NAME));
		model.addAttribute(REPORT_FREQUENCY, request.getParameter(REPORT_FREQUENCY));
		model.addAttribute(FROM_DATE, request.getParameter(FROM_DATE));
		model.addAttribute(TO_DATE, request.getParameter(TO_DATE));

	}

	/**
	 * Return ticket summary.
	 *
	 * @param model                  the model
	 * @param ticketDataBeanList     the ticket data bean list
	 * @param allApplicationNameList the all application name list
	 * @param allAssignmentGroupList the all assignment group list
	 * @param allTicketTypeList      the all ticket type list
	 * @param allPriorityList        the all priority list
	 * @param allStatusList          the all status list
	 * @param allAssigneeList        the all assignee list
	 * @param selectedValsList       the selected vals list
	 * @return the string
	 */
	private String returnTicketSummary(Model model, List<TicketDataBean> ticketDataBeanList,
			Set<String> allApplicationNameList, Set<String> allAssignmentGroupList, Set<String> allTicketTypeList,
			Set<String> allPriorityList, Set<String> allStatusList, Set<String> allAssigneeList,
			List<String> selectedValsList) {

		model.addAttribute("selectedValsList", selectedValsList);
		Collections.sort(ticketDataBeanList);
		model.addAttribute("allApplicationNameList", allApplicationNameList);
		model.addAttribute("allAssignmentGroupList", allAssignmentGroupList);
		model.addAttribute("allTicketTypeList", allTicketTypeList);
		model.addAttribute("allPriorityList", allPriorityList);
		model.addAttribute("allStatusList", allStatusList);

		allAssigneeList.remove("");
		model.addAttribute("allAssigneeList", allAssigneeList);
		model.addAttribute(TICKET_SUMMARY_FORM, ticketDataBeanList);
		List<String> checkList = Arrays.asList("KO DB", "Final Score", "External Link", "Company", "Category",
				"Urgency", "Impact", "WorkNotes", "LastModifiedBy", "LastModifiedDate", "OpenedBy", "Location");
		checkList.forEach(checkString -> {
			if (selectedValsList.contains(checkString)) {
				model.addAttribute(checkString.replace(' ', '_'), TRUE);
			}
		});
		
		String accountId = getDefaultAccountId();
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		
		UserBean ubean = userService.getUserAccountType(accountId);
		int isGeneric = ubean.getIsGeneric();
		model.addAttribute(IS_GENERIC, isGeneric);
		model.addAttribute("formheading", "Ticket Summary");
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		return "ticketSummary";
	}

	/**
	 * Sets the ticket linked count extract.
	 *
	 * @param model                 the model
	 * @param accountId             the account id
	 * @param serialNum             the serial num
	 * @param koUsageList           the ko usage list
	 * @param ticketDataHistoryList the ticket data history list
	 * @param koInfoList            the ko info list
	 * @param tdb                   the tdb
	 * @return the int
	 */
	private int setTicketLinkedCountExtract(Model model, String accountId, int serialNum, List<KOUsage> koUsageList,
			List<TicketDataHistory> ticketDataHistoryList, List<KOInfoBean> koInfoList, TicketDataBean tdb) {
		processRelevUsagePerc(koUsageList, koInfoList, tdb);
		tdb.setSerialNumber(serialNum);
		if (!IKONUtils.isNullOrEmpty(tdb.getPriority())) {
			tdb.setPriorityNum(Integer.parseInt(tdb.getPriority().split("-")[0].trim()));
		}
		return serialNum + 1;
	}

	/**
	 * Process relev usage perc.
	 *
	 * @param koUsageList the ko usage list
	 * @param koInfoList  the ko info list
	 * @param tdb         the tdb
	 */
	public void processRelevUsagePerc(List<KOUsage> koUsageList, List<KOInfoBean> koInfoList, TicketDataBean tdb) {
		String[] relevPercStrArr;
		String[] usagePercStrArr;
		if (!IKONUtils.isNullOrEmpty(tdb.getRelevPerc())) {
			relevPercStrArr = tdb.getRelevPerc().split(";");
			if (Objects.nonNull(relevPercStrArr) && relevPercStrArr.length > 0) {
				String relevPercStr = koInfoService.strConcat(relevPercStrArr[0].replace(":", "<br/>") , "%");
				tdb.setSeperatedKoRelPer(tdb.getRelevPerc().split(";")[0].split(":")[1]);
				tdb.setSeperatedKoRelID(tdb.getRelevPerc().split(";")[0].split(":")[0]);
				tdb.setKoID(tdb.getRelevPerc().split(";")[0].split(":")[0]);
				tdb.setRelevPerc(relevPercStr);
				tdb.setTicketLinkedCount(getTotalTicketCount(koUsageList, koInfoList, tdb.getKoID()));
			}
		}
		if (!IKONUtils.isNullOrEmpty(tdb.getUsagePerc())) {
			usagePercStrArr = tdb.getUsagePerc().split(";");
			if (Objects.nonNull(usagePercStrArr) && usagePercStrArr.length > 0) {
				String usagePercStr = koInfoService.strConcat(usagePercStrArr[0].replace(":", "<br/>") , "%");
				tdb.setSeperatedKoPerc(tdb.getUsagePerc().split(";")[0].split(":")[1]);
				tdb.setSeperatedKoID(tdb.getUsagePerc().split(";")[0].split(":")[0]);
				tdb.setKoID(tdb.getUsagePerc().split(";")[0].split(":")[0]);
				tdb.setUsagePerc(usagePercStr);
				tdb.setTicketLinkedCount(getTotalTicketCount(koUsageList, koInfoList, tdb.getKoID()));
			}
		}
	}

	/**
	 * Gets the all ticket data extract.
	 *
	 * @param ticketDataBean the ticket data bean
	 * @param userId         the user id
	 * @return the all ticket data extract
	 */
	private List<TicketDataBean> getAllTicketDataExtract(TicketDataBean ticketDataBean, String userId) {
		TicketDataAttributeVO tktDtAttrVO = new TicketDataAttributeVO();
		MasterDataAttributeVO masterDataAttributeVO = new MasterDataAttributeVO("", ticketDataBean.getApplicationName(), ticketDataBean.getAssignmentGroup(), "", "", "", userId);
		masterDataAttributeVO.setFromDateTodate(ticketDataBean.getFromDate(), ticketDataBean.getToDate());
		tktDtAttrVO.setMasterDtAttrVo(masterDataAttributeVO);
		tktDtAttrVO.setStatus(ticketDataBean.getStatus());
		tktDtAttrVO.setServiceType(ticketDataBean.getServiceType());
		tktDtAttrVO.setPriority(ticketDataBean.getPriority());
		tktDtAttrVO.setAssigneeName(ticketDataBean.getAssigneeName());
		tktDtAttrVO.setKoValue(ticketDataBean.getKoValue());
		tktDtAttrVO.setSearchType(ticketDataBean.getSearchType());
		List<TicketDataBean> ticketDataBeanList = ticketDataService.getAllTicketData(tktDtAttrVO);
		return ticketDataBeanList;
	}

	/**
	 * Ticket summary extract.
	 *
	 * @param ticketDataBean the ticket data bean
	 * @param request        the request
	 * @return the string
	 */
	private String ticketSummaryExtract(TicketDataBean ticketDataBean, HttpServletRequest request) {
		if (IKONUtils.isNullOrEmpty(ticketDataBean.getSearchType())) {
			ticketDataBean.setSearchType("1");
		}
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String loginusrname = auth.getName();

		String appName = request.getParameter("appName");
		String assignmentGroup = request.getParameter("assignmentGroup");

		if (!IKONUtils.isNullOrEmpty(appName)) {
			ticketDataBean.setApplicationName(appName);
		}
		if (!IKONUtils.isNullOrEmpty(assignmentGroup)) {
			ticketDataBean.setAssignmentGroup(assignmentGroup);
		}
		String assigneeName = request.getParameter("assigneeName");
		if (!IKONUtils.isNullOrEmpty(assigneeName)) {
			ticketDataBean.setAssigneeName(assigneeName);
		}

		String serviceType = request.getParameter("serviceType");
		if (!IKONUtils.isNullOrEmpty(serviceType)) {
			ticketDataBean.setServiceType(serviceType);
		}
		return loginusrname;
	}

	/**
	 * Gets the total ticket count.
	 *
	 * @param koUsageList the ko usage list
	 * @param koInfoList  the ko info list
	 * @param koId        the ko id
	 * @return the total ticket count
	 */
	private Long getTotalTicketCount(List<KOUsage> koUsageList, List<KOInfoBean> koInfoList, String koId) {
		if (!IKONUtils.isNullOrEmpty(koId)) {
			Long ticketCount = ticketDataService.getAllKOIncCount(koUsageList, koInfoList, koId);
			return ticketCount;
		}
		return 0L;
	}

	/**
	 * Gets the default account id.
	 *
	 * @return the default account id
	 */
	private String getDefaultAccountId() {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String loginusrname = auth.getName();

		String accountId = String.valueOf(accessControlService.getAccessDetailByUserId(loginusrname).getAccountId());
		return accountId;
	}

	/**
	 * Ticket summary post.
	 *
	 * @param ticketDataBean the ticket data bean
	 * @param model          the model
	 * @param request        the request
	 * @return the string
	 */
	@PostMapping("/ticketSummary")
	public String ticketSummaryPost(@ModelAttribute(TICKET_SUMMARY_FORM_DETAIL) TicketDataBean ticketDataBean,
			Model model, HttpServletRequest request) {
		log.info("Start: ticketSummaryPost");
		model.addAttribute(REPORT_CAT, request.getParameter(REPORT_CAT));
		model.addAttribute(COMPONENT_TYPE, request.getParameter(COMPONENT_TYPE));
		model.addAttribute(REPORT_TYPE, request.getParameter(REPORT_TYPE));
		model.addAttribute(REPORT_NAME, request.getParameter(REPORT_NAME));
		model.addAttribute(REPORT_FREQUENCY, request.getParameter(REPORT_FREQUENCY));
		model.addAttribute(FROM_DATE, request.getParameter(FROM_DATE));
		model.addAttribute(TO_DATE, request.getParameter(TO_DATE));

		String selectedSearchType = request.getParameter(SEARCH_TYPE_CHOSEN);
		String filterSelection = request.getParameter(FILTER_SELECTION);
		String fromDate = request.getParameter(FROM_DATE);
		if (!IKONUtils.isNullOrEmpty(fromDate)) {
			ticketDataBean.setFromDate(fromDate);
		}

		String toDate = request.getParameter(TO_DATE);
		if (!IKONUtils.isNullOrEmpty(toDate)) {
			ticketDataBean.setToDate(toDate);
		}

		if (!IKONUtils.isNullOrEmpty(filterSelection)
				&& (!Objects.isNull(ticketDataBean) && (!IKONUtils.isNullOrEmpty(ticketDataBean.getServiceType())
						|| !IKONUtils.isNullOrEmpty(ticketDataBean.getAssignmentGroup())
						|| !IKONUtils.isNullOrEmpty(ticketDataBean.getApplicationName())
						|| !IKONUtils.isNullOrEmpty(ticketDataBean.getPriority())
						|| !IKONUtils.isNullOrEmpty(ticketDataBean.getAssigneeName())
						|| !IKONUtils.isNullOrEmpty(ticketDataBean.getStatus())
						|| (!IKONUtils.isNullOrEmpty(ticketDataBean.getKoValue())
								&& !"0".equalsIgnoreCase(ticketDataBean.getKoValue()))))) {
			model.addAttribute(FILTER_SELECTION, filterSelection);
		}

		if (!IKONUtils.isNullOrEmpty(selectedSearchType)) {
			model.addAttribute(SELECTED_SEARCH_TYPE_VAL, selectedSearchType);
			ticketDataBean.setSearchType(selectedSearchType);
		}

		String accountId = getDefaultAccountId();
		String loginusrname = ticketSummaryExtract(ticketDataBean, request);
		String userId = loginusrname;
		List<TicketDataBean> ticketDataBean_lastupdatedate = ticketDataService.getStartTimeOfLastFeed();
		SimpleDateFormat dateformater_Java = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
		String lastUpdatedTime = dateformater_Java
				.format(ticketDataBean_lastupdatedate.get(0).getStartTimeOfLastFeed());
		model.addAttribute("lastUpdatedTime", lastUpdatedTime);

		List<TicketDataBean> ticketDataBeanList = getAllTicketDataExtract(ticketDataBean, userId);
		Set<String> allApplicationNameList = new TreeSet<String>();
		Set<String> allAssignmentGroupList = new TreeSet<String>();
		Set<String> allTicketTypeList = new TreeSet<String>();
		Set<String> allPriorityList = new TreeSet<String>();
		Set<String> allStatusList = new TreeSet<String>();
		Set<String> allAssigneeList = new TreeSet<String>();
		Set<String> allTowerList = new HashSet<String>();
		Set<String> allCCList = new HashSet<String>();
		Set<String> allClusterList = new HashSet<String>();
		for (TicketDataBean tdb : ticketDataBeanList) {
			addToSet(allApplicationNameList,tdb.getApplicationName());
			addToSet(allAssignmentGroupList,tdb.getAssignmentGroup());
			addToSet(allTicketTypeList,tdb.getServiceType());
			addToSet(allPriorityList,tdb.getPriority());
			addToSet(allStatusList,tdb.getStatus());
			addToSet(allAssigneeList,tdb.getAssigneeName());
			addToSet(allTowerList,tdb.getTower());
			addToSet(allCCList,tdb.getCc());
			addToSet(allClusterList,tdb.getCluster());			
		}

		populateBreadCrumb(accountId, ticketDataBean, model);
		

		int serialNum = 1;
		List<KOUsage> koUsageList = kOUsageRepository.findAll();
		List<TicketDataHistory> ticketDataHistoryList = null;
		List<KOInfoBean> koInfoList = koInfoService.getAllKos(accountId);

		for (TicketDataBean tdb : ticketDataBeanList) {
			serialNum = setTicketLinkedCountExtract(model, accountId, serialNum, koUsageList, ticketDataHistoryList,
					koInfoList, tdb);
		}
		List<String> selectedValsArr = getSelectedValsArr(ticketDataBean.getSelectedVals());
		log.info("End: ticketSummaryPost");
		return returnTicketSummary(model, ticketDataBeanList, allApplicationNameList, allAssignmentGroupList,
				allTicketTypeList, allPriorityList, allStatusList, allAssigneeList, selectedValsArr);
	}

	/**
	 * Gets the selected vals arr.
	 *
	 * @param string the string
	 * @return the selected vals arr
	 */
	private List<String> getSelectedValsArr(String string) {

		List<String> selectedValsArr = new ArrayList<String>(
				Arrays.asList(TICKET_ID, SUMMARY, TICKET_TYPE, ASSIGNMENT_GROUP, APPLICATION, "Priority", ASSIGNEE,
						STATUS, "KO Rel%", "KO Usage", "# Inc Linked", "Reported Date"));

		List<String> selectedValsNew = new ArrayList<String>(Arrays.asList(string.split(",")));
		selectedValsNew.removeAll(selectedValsArr);

		List<String> notPresentList = selectedValsNew;
		Collections.sort(notPresentList);
		if (Objects.nonNull(notPresentList) && !notPresentList.isEmpty()) {
			selectedValsArr.addAll(notPresentList);
		}
		return selectedValsArr;
	}

	/**
	 * Populate bread crumb.
	 *
	 * @param acctId         the acct id
	 * @param ticketDataBean the ticket data bean
	 * @param model          the model
	 */
	private void populateBreadCrumb(String acctId, TicketDataBean ticketDataBean, Model model) {
		String acctName = "";
		int accountId = 0;
		if (!IKONUtils.isNullOrEmpty(acctId)) {
			accountId = Integer.parseInt(acctId);
		}
		acctName = ticketDataService.getAccountNameByAccountId(accountId);

		Map<String, String> navigationMap = null;
		navigationMap = new LinkedHashMap<String, String>();

		if (!IKONUtils.isNullOrEmpty(acctName)) {
			navigationMap.put(acctName, "ticketSummary?acctName=" + acctName);
		}

		String serviceType = (IKONUtils.isNullOrEmpty(ticketDataBean.getServiceType())
				|| ticketDataBean.getServiceType().equalsIgnoreCase(INCIDENT)) ? INCIDENT : "Service Request";
		if (!IKONUtils.isNullOrEmpty(ticketDataBean.getApplicationName())) {
			navigationMap.put(serviceType,
					"ticketSummary?serviceType=" + serviceType + "&searchTypeChosen=" + ticketDataBean.getSearchType());
			navigationMap.put(
					ticketDataService.getAssignmentGroupByApplicationName(ticketDataBean.getApplicationName()),
					"ticketSummary?assignmentGroup="
							+ ticketDataService.getAssignmentGroupByApplicationName(ticketDataBean.getApplicationName())
							+ "&searchTypeChosen=" + ticketDataBean.getSearchType());
			navigationMap.put(ticketDataBean.getApplicationName(), "0");
			model.addAttribute("navigationMapVal", navigationMap);
			model.addAttribute("navigationPresent", YES);
		} else if (!IKONUtils.isNullOrEmpty(ticketDataBean.getAssignmentGroup())) {
			navigationMap.put(serviceType,
					"ticketSummary?serviceType=" + serviceType + "&searchTypeChosen=" + ticketDataBean.getSearchType());
			if (IKONUtils.isNullOrEmpty(ticketDataBean.getAssignmentGroup())
					&& !IKONUtils.isNullOrEmpty(ticketDataBean.getApplicationName())) {
				navigationMap.put(
						ticketDataService.getAssignmentGroupByApplicationName(ticketDataBean.getApplicationName()),
						"0");
			} else if (!IKONUtils.isNullOrEmpty(ticketDataBean.getAssignmentGroup())) {
				navigationMap.put(ticketDataBean.getAssignmentGroup(), "0");
			}
			model.addAttribute("navigationMapVal", navigationMap);
			model.addAttribute("navigationPresent", YES);
		} else if (!IKONUtils.isNullOrEmpty(ticketDataBean.getServiceType())) {
			navigationMap.put(serviceType, "0");
			navigationMap.put(
					ticketDataService.getAssignmentGroupByApplicationName(ticketDataBean.getApplicationName()), "0");
			model.addAttribute("navigationMapVal", navigationMap);
			model.addAttribute("navigationPresent", YES);
		}
	}

	/**
	 * Ticket view.
	 *
	 * @param ticketId       the ticket id
	 * @param ticketDataBean the ticket data bean
	 * @param model          the model
	 * @param request        the request
	 * @return the string
	 */
	@GetMapping("/ticketView/{ticketId}")
	public String ticketView(@PathVariable String ticketId,
			@ModelAttribute("ticketViewFormDetail") TicketDataBean ticketDataBean, Model model,
			HttpServletRequest request) {
			log.info("Start: ticketView");
			List<TicketDataBean> similarIncidentsBeanKOListModel = new ArrayList<TicketDataBean>();
			setTicketLink(model, request);
			List<TicketDataBean> incidentTagsList = ticketDataService.getIncidentTags(ticketId);
			if(Objects.isNull(incidentTagsList)) {
				List<TicketDataBean> ticketDataBeanList = ticketDataService.getTicketData(ticketId);
				TicketDataBean tdb = null;
				if (Objects.nonNull(ticketDataBeanList) && ticketDataBeanList.size() > 0) {
					tdb = ticketDataBeanList.get(0);
				}
				model.addAttribute(TICKET_SUMMARY_FORM, tdb);
				log.error("ticketView: incidentTagsList is null");
				return "ticketView";
			}
			List<TicketDataBean> ticketDataBeanList = ticketDataService.getTicketData(ticketId);
			List<TicketDataBean> kOTagsList = null;
			TicketDataBean tdb = new TicketDataBean();
			TicketDataBean tdbVal = null;

			if (!Objects.isNull(ticketDataBeanList) && ticketDataBeanList.size() > 0) {
				tdb = ticketDataBeanList.get(0);
				kOTagsList = getAllKOTags(ticketDataBeanList);// ticketDataService.getkotagsincidentList(tdb.getKoID());
				String selectedSearchType = request.getParameter(SEARCH_TYPE_CHOSEN);
				if (!IKONUtils.isNullOrEmpty(selectedSearchType)) {
					model.addAttribute(SELECTED_SEARCH_TYPE_VAL, selectedSearchType);
					tdb.setSearchType(selectedSearchType);
				}
				setTicketExpireHours(tdb);
				similarIncidentsBeanKOListModel = getThreeSimilarInc(ticketId, model, kOTagsList);
				// Similar Incident detail fetch ends here

				// Fetching incident tags
				getIncidentTags(tdb, ticketId, model, incidentTagsList);
				// Fetching incident tags ends here

				// Tracking detail fetch starts here

				List<TicketDataBean> trackingList = ticketDataService.getTicketTrackingList(ticketId);
				model.addAttribute("ticketTrackingList", trackingList);
				model.addAttribute("ticketDataBean", tdb);
				// Tracking detail fetch ends here
				if (!IKONUtils.isNullOrEmpty(tdb.getTicketID())) {
					tdbVal = ticketDataService.getSubjectMatterSpecialist(tdb.getTicketID());
				}
			}
			if (!Objects.isNull(tdb) && !Objects.isNull(tdbVal)) {
				tdb.setSubjectMatterSpecialist(tdbVal.getSubjectMatterSpecialist());
				tdb.setTicketCount(tdbVal.getTicketCount());
			}
			List<TicketDataBean> ticketDataBeanKOListValModel = getTktDtKo(model, ticketDataBeanList, kOTagsList);
			TicketDataBean ticketSummaryFormModel = tdb;
			setTags(ticketSummaryFormModel, ticketDataBeanKOListValModel, similarIncidentsBeanKOListModel);

			// True - Incident Tag, False -KO Tag
			ticketSummaryFormModel = setIncidentKoTags(true, ticketSummaryFormModel);
			// Right side Ko solution Tags Calculation
			ticketDataBeanKOListValModel = setIncidentKoTagsList(false, ticketDataBeanKOListValModel);
			// Right side Similar incidents Tags Calculation
			similarIncidentsBeanKOListModel = setIncidentKoTagsList(true, similarIncidentsBeanKOListModel);
			String accountId = getDefaultAccountId();
			int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
			int koEnabledStatus = koController.getKOEnabledStatus(Integer.parseInt(accountId));
			UserBean ubean = userService.getUserAccountType(accountId);
			
			int isGeneric = ubean.getIsGeneric();
			model.addAttribute(IS_GENERIC, isGeneric);
			model.addAttribute(TICKET_SUMMARY_FORM, ticketSummaryFormModel);
			model.addAttribute("ticketDataBeanKOListVal", ticketDataBeanKOListValModel);
			model.addAttribute("similarIncidentsKOList", similarIncidentsBeanKOListModel);
			model.addAttribute("isHelpdeskVisible", helpdeskStatus);
			model.addAttribute("isKOEnabled", koEnabledStatus);
			
			log.info("End: ticketView");

			return "ticketView";		
	}

	/**
	 * Gets the all KO tags.
	 *
	 * @param ticketDataBeanList the ticket data bean list
	 * @return the all KO tags
	 */
	private List<TicketDataBean> getAllKOTags(List<TicketDataBean> ticketDataBeanList) {
		List<TicketDataBean> kOTagsList = new ArrayList<TicketDataBean>();
		ticketDataBeanList.forEach(tdb -> {
			List<TicketDataBean> kOTagsListTemp = ticketDataService.getkotagsincidentList(tdb.getKoID());
			if (Objects.nonNull(kOTagsListTemp) && kOTagsListTemp.size() > 0 && Objects.nonNull(kOTagsListTemp.get(0))) {
				kOTagsList.add(kOTagsListTemp.get(0));
			}
		});
		return kOTagsList;
	}

	/**
	 * Sets the ticket link.
	 *
	 * @param model the model
	 * @param request the request
	 */
	private void setTicketLink(Model model, HttpServletRequest request) {

		if (!IKONUtils.isNullOrEmpty(request.getParameter("firstTicketLink"))) {
			model.addAttribute("firstTicketLink", request.getParameter("firstTicketLink"));
		}
		if (!IKONUtils.isNullOrEmpty(request.getParameter("secondTicketLink"))) {
			model.addAttribute("secondTicketLink", request.getParameter("secondTicketLink"));
		}
		if (!IKONUtils.isNullOrEmpty(request.getParameter("thirdTicketLink"))) {
			model.addAttribute("thirdTicketLink", request.getParameter("thirdTicketLink"));
		}

	}

	/**
	 * Gets the tkt dt ko.
	 *
	 * @param model the model
	 * @param ticketDataBeanList the ticket data bean list
	 * @param kOTagsList the k O tags list
	 * @return the tkt dt ko
	 */
	private List<TicketDataBean> getTktDtKo(Model model, List<TicketDataBean> ticketDataBeanList,
			List<TicketDataBean> kOTagsList) {

		model.addAttribute("formheading", "Ticket View");
		List<TicketDataBean> ticketDataBeanKOList = new ArrayList<TicketDataBean>();
		List<String> koListOrder = new LinkedList<String>();
		List<TicketDataBean> tdBeanList = new LinkedList<TicketDataBean>();
		if (Objects.isNull(ticketDataBeanList) || ticketDataBeanList.size() <= 0) {
			return tdBeanList;
		}
		List<TicketDataBean> reverseTdb;
		if (ticketDataBeanList.size() > THREE) {
			reverseTdb = new ArrayList<TicketDataBean>(ticketDataBeanList.subList(0, 3));
		} else {
			reverseTdb = new ArrayList<TicketDataBean>(ticketDataBeanList);
		}
		Collections.reverse(reverseTdb);
		final int reverseTdbSize = reverseTdb.size();
		for (int i = 0; i < reverseTdbSize; i++) {
			TicketDataBean tdb1 = reverseTdb.get(i);
			if (Objects.nonNull(tdb1) && !IKONUtils.isNullOrEmpty(tdb1.getKoID())) {
				tdb1.setHeadingCollapseShow(COLLAPSE);
				tdb1.setHeadingCollapseId(koInfoService.strConcat("collapse" , numToText(i)));
				getRelevancyNKoOrder(tdb1, koListOrder);
				getKOTags(model, tdb1, kOTagsList);
				model.addAttribute(koInfoService.strConcat("ticketDataBeanListVal" , String.valueOf(i)), tdb1);
				ticketDataBeanKOList.add(tdb1);
			}
		}

		// getting Distinct KOs - so that we can rmove a for loop
		koListOrder = koListOrder.stream().distinct().collect(Collectors.toList());
		for (String koList : koListOrder) {
			TicketDataBean tdBean = ticketDataBeanKOList.stream().filter(td1 -> koList.equalsIgnoreCase(td1.getKoID()))
					.findAny().orElse(null);
			if (Objects.nonNull(tdBean)) {
				if (Objects.equals(koListOrder.indexOf(koList), 0)) {
					tdBean.setBestMatchFlag(TRUE);
				}
				tdBeanList.add(tdBean);
			}
		}
		return tdBeanList;
	}

	/**
	 * Num to text.
	 *
	 * @param i the i
	 * @return the string
	 */
	private String numToText(int i) {
		switch (i) {
		case 1:
			return "One";
		case 2:
			return "Two";
		case 3:
			return "Three";
		default:
			return "";
		}
	}

	/**
	 * Gets the relevancy N ko order.
	 *
	 * @param tdb1 the tdb 1
	 * @param koListOrder the ko list order
	 * @return the relevancy N ko order
	 */
	private void getRelevancyNKoOrder(TicketDataBean tdb1, List<String> koListOrder) {

		if (!IKONUtils.isNullOrEmpty(tdb1.getRelevPerc())) {
			String[] relevPercStrArr = tdb1.getRelevPerc().split(";");
			final int relevPercLength = relevPercStrArr.length;
			for (int percStr = 0; percStr < relevPercLength; percStr++) {
				if (relevPercStrArr[percStr].split(":")[0].equalsIgnoreCase(tdb1.getKoID())) {
					String[] koIdWithPerc = relevPercStrArr[percStr].split(":");
					tdb1.setRelevPerc(koInfoService.strConcat(koIdWithPerc[1] , "%"));
				}
			}
		}
		if (!IKONUtils.isNullOrEmpty(tdb1.getUsagePerc())) {
			String[] usagePercStrArr = tdb1.getUsagePerc().split(";");
			final int usagePercLength = usagePercStrArr.length;
			for (int percStr = 0; percStr < usagePercLength; percStr++) {
				if (usagePercStrArr[percStr].split(":")[0].equalsIgnoreCase(tdb1.getKoID())) {
					String[] koIdWithPerc = usagePercStrArr[percStr].split(":");
					tdb1.setUsagePerc(koInfoService.strConcat(koIdWithPerc[1] , "%"));
					tdb1.setTicketLinkedCount(ticketDataService.getNoOfIncLinkedForKO(tdb1.getKoID(),getDefaultAccountId()));
				}
				koListOrder.add(usagePercStrArr[percStr].split(":")[0]);
			}

		} else {
			if (!IKONUtils.isNullOrEmpty(tdb1.getKoID())) {
				koListOrder.add(tdb1.getKoID());
				tdb1.setTicketLinkedCount(ticketDataService.getNoOfIncLinkedForKO(tdb1.getKoID(),getDefaultAccountId()));
			}
		}
		if (!IKONUtils.isNullOrEmpty(tdb1.getSelectedKoForResolution())
				&& tdb1.getSelectedKoForResolution().equalsIgnoreCase(tdb1.getKoID())) {
			tdb1.setIsSelectedForResolution(YES);
			koListOrder.add(tdb1.getKoID());
			tdb1.setTicketLinkedCount(ticketDataService.getNoOfIncLinkedForKO(tdb1.getKoID(),getDefaultAccountId()));
			if(!IKONUtils.isNullOrEmpty(tdb1.getRelevPerc()) && !tdb1.getRelevPerc().contains("%") && tdb1.getRelevPerc().contains(":")) {
				tdb1.setRelevPerc("");
				tdb1.setUsagePerc("");
			}
		}
	}

	/**
	 * Gets the three similar inc.
	 *
	 * @param ticketId the ticket id
	 * @param model the model
	 * @param kOTagsList the k O tags list
	 * @return the three similar inc
	 */
	private List<TicketDataBean> getThreeSimilarInc(String ticketId, Model model, List<TicketDataBean> kOTagsList) {

		List<TicketDataBean> similarIncidentsList = ticketDataService.getSimilarIncidentList(ticketId);
		List<TicketDataBean> similarIncidentsBeanKOList = new ArrayList<TicketDataBean>();
		if (Objects.isNull(similarIncidentsList) || similarIncidentsList.size() <= 0) {
			return similarIncidentsBeanKOList;
		}
		if (similarIncidentsList.size() > 0 && Objects.nonNull(similarIncidentsList.get(0))) {
			TicketDataBean tdb = similarIncidentsList.get(0);
			tdb.setHeadingCollapseShow(COLLAPSE);
			tdb.setHeadingCollapseId("similarcollapseOne");
			getRelvancy(tdb);
			getKOTags(model, tdb, kOTagsList);
			if (!IKONUtils.isNullOrEmpty(tdb.getTicketID())) {
				getIncidentTags(tdb, tdb.getTicketID(), model, ticketDataService.getIncidentTags(tdb.getTicketID()));
			}
			model.addAttribute("similarIncidentsList0", tdb);
			similarIncidentsBeanKOList.add(tdb);
		}
		if (similarIncidentsList.size() > 1 && Objects.nonNull(similarIncidentsList.get(1))) {
			TicketDataBean tdb = similarIncidentsList.get(1);
			tdb.setHeadingCollapseShow(COLLAPSE);
			tdb.setHeadingCollapseId("similarcollapseTwo");
			getRelvancy(tdb);
			getKOTags(model, tdb, kOTagsList);
			if (!IKONUtils.isNullOrEmpty(tdb.getTicketID())) {
				getIncidentTags(tdb, tdb.getTicketID(), model, ticketDataService.getIncidentTags(tdb.getTicketID()));
			}
			model.addAttribute("similarIncidentsList1", tdb);
			similarIncidentsBeanKOList.add(tdb);
		}
		if (similarIncidentsList.size() > 2 && Objects.nonNull(similarIncidentsList.get(2))) {
			TicketDataBean tdb = similarIncidentsList.get(2);
			tdb.setHeadingCollapseShow(COLLAPSE);
			tdb.setHeadingCollapseId("similarcollapseThree");
			getRelvancy(tdb);
			getKOTags(model, tdb, kOTagsList);
			if (!IKONUtils.isNullOrEmpty(tdb.getTicketID())) {
				getIncidentTags(tdb, tdb.getTicketID(), model, ticketDataService.getIncidentTags(tdb.getTicketID()));
			}
			model.addAttribute("similarIncidentsList2", similarIncidentsList.get(2));
			similarIncidentsBeanKOList.add(tdb);
		}
		return similarIncidentsBeanKOList;
	}

	/**
	 * Gets the relvancy.
	 *
	 * @param tdb1 the tdb 1
	 * @return the relvancy
	 */
	private void getRelvancy(TicketDataBean tdb1) {
		if (!IKONUtils.isNullOrEmpty(tdb1.getRelevPerc())) {
			String[] relevPercStrArr = tdb1.getRelevPerc().split(";");
			if (Objects.nonNull(relevPercStrArr) && relevPercStrArr.length > 0) {
				String[] koIdWithPerc = relevPercStrArr[0].split(":");
				tdb1.setRelevPerc(koIdWithPerc[1] + "%");
				tdb1.setKoID(koIdWithPerc[0]);
			}
		}
		if (!IKONUtils.isNullOrEmpty(tdb1.getUsagePerc())) {
			String[] usagePercStrArr = tdb1.getUsagePerc().split(";");
			String[] koIdWithPerc = usagePercStrArr[0].split(":");
			tdb1.setUsagePerc(koIdWithPerc[1] + "%");
			tdb1.setKoID(koIdWithPerc[0]);
		}
	}

	/**
	 * Sets the ticket expire hours.
	 *
	 * @param tdb the new ticket expire hours
	 */
	private void setTicketExpireHours(TicketDataBean tdb) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
		Date d1 = null;
		Date d2 = null;
		try {
			d1 = new Date();
			if (Objects.nonNull(tdb.getBreachTime())) {
				String dateStop = tdb.getBreachTime().toString();
				d2 = format.parse(dateStop);
				long diff = d2.getTime() - d1.getTime();
				long expireHours = diff / (60 * 60 * 1000);

				if (expireHours > 0) {
					tdb.setExpireHours("Breaches in " + expireHours + " hours");
				} else {
					tdb.setExpireHours("Breached");
				}
			} else {
				tdb.setExpireHours("Breachtime is not available");
			}

		} catch (ParseException e) {
			log.error(e.getMessage());
		}
	}

	/**
	 * Sets the tags.
	 *
	 * @param ticketSummaryFormModel the ticket summary form model
	 * @param ticketDataBeanKOListValModel the ticket data bean KO list val model
	 * @param similarIncidentsBeanKOListModel the similar incidents bean KO list model
	 */
	private void setTags(TicketDataBean ticketSummaryFormModel, List<TicketDataBean> ticketDataBeanKOListValModel,
			List<TicketDataBean> similarIncidentsBeanKOListModel) {

		// removing null Objects so that we can remove null checks
		ticketDataBeanKOListValModel.removeIf(Objects::isNull);
		similarIncidentsBeanKOListModel.removeIf(Objects::isNull);

		if (Objects.nonNull(ticketSummaryFormModel.getIncidentTags()) && ticketSummaryFormModel.getIncidentTags().size() > 0) {
			for (TicketDataBean tdBean : ticketDataBeanKOListValModel) {
				setSuccessTags(ticketSummaryFormModel.getIncidentTags(), tdBean.getKotags());
			}
			for (TicketDataBean tdBean : similarIncidentsBeanKOListModel) {
				setSuccessTags(ticketSummaryFormModel.getIncidentTags(), tdBean.getIncidentTags());

			}
			for (Entry<String, String> ticketSummaryFormModelEntry : ticketSummaryFormModel.getIncidentTags()
					.entrySet()) {
				for (TicketDataBean tdBean : similarIncidentsBeanKOListModel) {
					if (Objects.nonNull(tdBean.getIncidentTags())
							&& tdBean.getIncidentTags().containsKey(ticketSummaryFormModelEntry.getKey())) {
						ticketSummaryFormModelEntry.setValue(BADGE_SUCCESS);
					}
				}
				for (TicketDataBean tdBean : ticketDataBeanKOListValModel) {
					if (Objects.nonNull(tdBean.getKotags())
							&& tdBean.getKotags().containsKey(ticketSummaryFormModelEntry.getKey())) {
						ticketSummaryFormModelEntry.setValue(BADGE_SUCCESS);
					}
				}
			}
		}
	}

	/**
	 * Sets the success tags.
	 *
	 * @param ticketModelTags the ticket model tags
	 * @param incKoBeantags the inc ko beantags
	 */
	private void setSuccessTags(Map<String, String> ticketModelTags, Map<String, String> incKoBeantags) {

		if (Objects.nonNull(incKoBeantags)) {
			for (Map.Entry<String, String> ticketDataBeanKOListValModelEntry : incKoBeantags.entrySet()) {
				if (ticketModelTags.containsKey(ticketDataBeanKOListValModelEntry.getKey())) {
					ticketDataBeanKOListValModelEntry.setValue(BADGE_SUCCESS);
				}
			}
		}

	}

	/**
	 * Sets the incident ko tags list.
	 *
	 * @param isIncidentTag the is incident tag
	 * @param ticketDataBean the ticket data bean
	 * @return the list
	 */
	private List<TicketDataBean> setIncidentKoTagsList(boolean isIncidentTag, List<TicketDataBean> ticketDataBean) {
		List<TicketDataBean> tkBean = new ArrayList<TicketDataBean>();
		for (TicketDataBean kos : ticketDataBean) {
			tkBean.add(setIncidentKoTags(isIncidentTag, kos));
		}
		return tkBean;

	}

	/**
	 * Sets the incident ko tags.
	 *
	 * @param isIncidentTag the is incident tag
	 * @param ticketDataBean the ticket data bean
	 * @return the ticket data bean
	 */
	private TicketDataBean setIncidentKoTags(boolean isIncidentTag, TicketDataBean ticketDataBean) {

		Map<String, String> tags = new LinkedHashMap<>();
		String cnt = "16;12;8";
		// Left side Incident Tags Calculation
		if (isIncidentTag) {
			cnt = addIncidentTags(ticketDataBean, tags, cnt, BADGE_SUCCESS);
			addIncidentTags(ticketDataBean, tags, cnt, BADGE_WARNING);
			ticketDataBean.setIncidentTags(tags);
		} else {
			cnt = addKoTags(ticketDataBean, tags, cnt, BADGE_SUCCESS);
			addKoTags(ticketDataBean, tags, cnt, BADGE_WARNING);
			ticketDataBean.setKotags(tags);
		}
		return ticketDataBean;
	}

	/**
	 * Adds the incident tags.
	 *
	 * @param ticketDataBean the ticket data bean
	 * @param tags the tags
	 * @param count the count
	 * @param badge the badge
	 * @return the string
	 */
	private String addIncidentTags(TicketDataBean ticketDataBean, Map<String, String> tags, String count,
			String badge) {
		int singlecount = Integer.parseInt(count.split(";")[0]);
		int bicount = Integer.parseInt(count.split(";")[1]);
		int tricount = Integer.parseInt(count.split(";")[2]);
		if (Objects.nonNull(ticketDataBean.getIncidentTags()))
			for (Entry<String, String> tagMap : ticketDataBean.getIncidentTags().entrySet()) {
				if (tagMap.getValue().equalsIgnoreCase(badge)) {
					int tagCount = tagMap.getKey().split(" ").length;
					if (Objects.equals(tagCount, 1) && !Objects.equals(singlecount, 0)) {
						tags.put(tagMap.getKey(), tagMap.getValue());
						--singlecount;

					}
					if (Objects.equals(tagCount, 2) && !Objects.equals(bicount, 0)) {
						tags.put(tagMap.getKey(), tagMap.getValue());
						--bicount;
					}
					if (Objects.equals(tagCount, 3) && !Objects.equals(tricount, 0)) {
						tags.put(tagMap.getKey(), tagMap.getValue());
						--tricount;
					}

				}
			}
		String singlecountStr = String.valueOf(singlecount);
		String bicountStr = String.valueOf(bicount);
		String tricountStr = String.valueOf(tricount);
		return String.join(";",singlecountStr, bicountStr, tricountStr);
	}

	/**
	 * Adds the ko tags.
	 *
	 * @param ticketDataBean the ticket data bean
	 * @param tags the tags
	 * @param count the count
	 * @param badge the badge
	 * @return the string
	 */
	private String addKoTags(TicketDataBean ticketDataBean, Map<String, String> tags, String count, String badge) {
		int singlecount = Integer.parseInt(count.split(";")[0]);
		int bicount = Integer.parseInt(count.split(";")[1]);
		int tricount = Integer.parseInt(count.split(";")[2]);
		if (Objects.nonNull(ticketDataBean.getKotags()))
			for (Entry<String, String> tagMap : ticketDataBean.getKotags().entrySet()) {
				if (tagMap.getValue().equalsIgnoreCase(badge)) {
					int tagCount = tagMap.getKey().split(" ").length;
					if (Objects.equals(tagCount, 1) && !Objects.equals(singlecount, 0)) {
						tags.put(tagMap.getKey(), tagMap.getValue());
						--singlecount;

					}
					if (Objects.equals(tagCount, 2) && !Objects.equals(bicount, 0)) {
						tags.put(tagMap.getKey(), tagMap.getValue());
						--bicount;
					}
					if (Objects.equals(tagCount, 3) && !Objects.equals(tricount, 0)) {
						tags.put(tagMap.getKey(), tagMap.getValue());
						--tricount;
					}

				}
			}
		String singlecountStr = String.valueOf(singlecount);
		String bicountStr = String.valueOf(bicount);
		String tricountStr = String.valueOf(tricount);
		return String.join(";",singlecountStr, bicountStr, tricountStr);

	}

	/**
	 * Gets the incident tags.
	 *
	 * @param tdb1             the tdb 1
	 * @param ticketId         the ticket id
	 * @param model            the model
	 * @param incidentTagsList the incident tags list
	 * @return the incident tags
	 */
	private void getIncidentTags(TicketDataBean tdb1, String ticketId, Model model,
			List<TicketDataBean> incidentTagsList) {
		TicketDataBean ticketDataIncTagBean = new TicketDataBean();
		for (TicketDataBean tags : incidentTagsList) {
			if (!IKONUtils.isNullOrEmpty(tags.getTicketID()) && tags.getTicketID().equalsIgnoreCase(ticketId)) {
				ticketDataIncTagBean.setINCSingleTags(tags.getINCSingleTags());
				ticketDataIncTagBean.setINCBigramTags(tags.getINCBigramTags());
				ticketDataIncTagBean.setINCTrigramTags(tags.getINCTrigramTags());
			}
		}
		if (!IKONUtils.isNullOrEmpty(ticketDataIncTagBean.getINCSingleTags())
				|| !IKONUtils.isNullOrEmpty(ticketDataIncTagBean.getINCBigramTags())
				|| !IKONUtils.isNullOrEmpty(ticketDataIncTagBean.getINCTrigramTags())) {

			Map<String, String> tagsMap = new LinkedHashMap<String, String>();
			if (!IKONUtils.isNullOrEmpty(ticketDataIncTagBean.getINCSingleTags())) {
				String singleTags = ticketDataIncTagBean.getINCSingleTags();
				List<String> singleTagsArr = Arrays.asList(singleTags.split(","));
				singleTagsArr.forEach(tag -> {
					tagsMap.put(tag, BADGE_WARNING);
				});
			}
			if (!IKONUtils.isNullOrEmpty(ticketDataIncTagBean.getINCBigramTags())) {
				String bigramTags = ticketDataIncTagBean.getINCBigramTags();
				List<String> bigramTagsArr = Arrays.asList(bigramTags.split(","));
				bigramTagsArr.forEach(tag -> {
					tagsMap.put(tag, BADGE_WARNING);
				});
			}
			if (!IKONUtils.isNullOrEmpty(ticketDataIncTagBean.getINCTrigramTags())) {
				String trigramTags = ticketDataIncTagBean.getINCTrigramTags();
				List<String> trigramTagsArr = Arrays.asList(trigramTags.split(","));
				trigramTagsArr.forEach(tag -> {
					tagsMap.put(tag, BADGE_WARNING);
				});
			}
			tdb1.setIncidentTags(tagsMap);
		} else {
			model.addAttribute("tagsListVal", "No tags to display");
		}

	}

	/**
	 * Gets the KO tags.
	 *
	 * @param model      the model
	 * @param tdb1       the tdb 1
	 * @param koTagsList the ko tags list
	 * @return the KO tags
	 */
	private void getKOTags(Model model, TicketDataBean tdb1, List<TicketDataBean> koTagsList) {

		TicketDataBean getkotagsincBean = new TicketDataBean();
		koTagsList.forEach(tags -> {
			if (!IKONUtils.isNullOrEmpty(tags.getKoID()) && tags.getKoID().equalsIgnoreCase(tdb1.getKoID())) {
				getkotagsincBean.setKOSingleTags(tags.getKOSingleTags());
				getkotagsincBean.setKOBigramTags(tags.getKOBigramTags());
				getkotagsincBean.setKOTrigramTags(tags.getKOTrigramTags());
			}
		});

		if (!IKONUtils.isNullOrEmpty(getkotagsincBean.getKOSingleTags())
				|| !IKONUtils.isNullOrEmpty(getkotagsincBean.getKOBigramTags())
				|| !IKONUtils.isNullOrEmpty(getkotagsincBean.getKOTrigramTags())) {

			Map<String, String> koTagsMap = new LinkedHashMap<String, String>();

			if (!IKONUtils.isNullOrEmpty(getkotagsincBean.getKOSingleTags())) {

				String ko_singleTags = getkotagsincBean.getKOSingleTags();
				List<String> ko_singleTagsArr = Arrays.asList(ko_singleTags.split(","));
				ko_singleTagsArr.forEach(tag -> {
					koTagsMap.put(tag, BADGE_WARNING);
				});
			}
			if (!IKONUtils.isNullOrEmpty(getkotagsincBean.getKOBigramTags())) {

				String ko_bigramTags = getkotagsincBean.getKOBigramTags();
				List<String> ko_bigramTagsArr = Arrays.asList(ko_bigramTags.split(","));
				ko_bigramTagsArr.forEach(tag -> {
					koTagsMap.put(tag, BADGE_WARNING);
				});
			}
			if (!IKONUtils.isNullOrEmpty(getkotagsincBean.getKOTrigramTags())) {

				String ko_trigramTags = getkotagsincBean.getKOTrigramTags();
				List<String> ko_trigramTagsArr = Arrays.asList(ko_trigramTags.split(","));
				ko_trigramTagsArr.forEach(tag -> {
					koTagsMap.put(tag, BADGE_WARNING);
				});
			}

			tdb1.setKotags(koTagsMap);
		} else {
			model.addAttribute("kotagsListVal", "No tags to display");
		}
	}

	/**
	 * Select for resolution.
	 *
	 * @param modelAndView       the model and view
	 * @param ticketID           the ticket ID
	 * @param koID               the ko ID
	 * @param isResolutionExists the is resolution exists
	 * @param model              the model
	 * @param linkedincident     the linkedincident
	 * @param response           the response
	 * @param koInfo             the ko info
	 * @return the response entity
	 * @throws UnsupportedEncodingException the unsupported encoding exception
	 */
	@JsonIgnoreProperties
	@RequestMapping(value = "/selectForResolution/{ticketID}/{koID}/{isResolutionExists}")
	public ResponseEntity<?> selectForResolution(ModelAndView modelAndView, @PathVariable String ticketID,
			@PathVariable String koID, @PathVariable String isResolutionExists, Model model, String linkedincident,
			HttpServletResponse response, @ModelAttribute("createKOForm") KOInfoBean koInfo) throws UnsupportedEncodingException {
		log.info("Start: selectForResolution");
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String loginusrname = auth.getName();
		String accountId = getDefaultAccountId();
		TicketDataAttributeVO ticketDataAttributeVO = new TicketDataAttributeVO();
		ticketDataAttributeVO.getKoDtAttr().setKoId(koID);
		ticketDataAttributeVO.setTicketId(ticketID);
		ticketDataAttributeVO.setMasterDtAttrVo(new MasterDataAttributeVO(accountId, "", "", "", "", "", loginusrname));
		String result = ticketDataService.insertKOForResolution(ticketDataAttributeVO,
				isResolutionExists);
		//MongoDBprocess.insertData(koInfo, accountId, koID, "ticketview");
		mlDBProcess.insertDataIntoPostgres(koInfo, accountId, koID, "ticketview","");
		log.info("End: selectForResolution");
		return ResponseEntity.ok(result);
	}

	/**
	 * Gets the error path.
	 *
	 * @return the error path
	 */
	@Override
	@RequestMapping("/error")
	public String getErrorPath() {
		return "errorPage";
	}

	/**
	 * Inc missing ko report post.
	 *
	 * @param ticketDataBean the ticket data bean
	 * @param model          the model
	 * @param request        the request
	 * @return the string
	 */
	@PostMapping("/incMissingKoReport")
	public String incMissingKoReportPost(@ModelAttribute(TICKET_SUMMARY_FORM_DETAIL) TicketDataBean ticketDataBean,
			Model model, HttpServletRequest request) {
		model.addAttribute(FROM_LOGIN, request.getParameter(FROM_LOGIN));
		model.addAttribute(REPORT_CAT, request.getParameter(REPORT_CAT));
		model.addAttribute(COMPONENT_TYPE, request.getParameter(COMPONENT_TYPE));
		model.addAttribute(REPORT_TYPE, request.getParameter(REPORT_TYPE));
		model.addAttribute(REPORT_NAME, request.getParameter(REPORT_NAME));
		model.addAttribute(REPORT_FREQUENCY, request.getParameter(REPORT_FREQUENCY));
		model.addAttribute(FROM_DATE, request.getParameter(FROM_DATE));
		model.addAttribute(TO_DATE, request.getParameter(TO_DATE));

		String selectedSearchType = request.getParameter(SEARCH_TYPE_CHOSEN);
		if (!IKONUtils.isNullOrEmpty(selectedSearchType)) {
			model.addAttribute(SELECTED_SEARCH_TYPE_VAL, selectedSearchType);
			ticketDataBean.setSearchType(selectedSearchType);
		}

		String fromDate = request.getParameter(FROM_DATE);
		if (!IKONUtils.isNullOrEmpty(fromDate)) {
			ticketDataBean.setFromDate(fromDate);
		}

		String toDate = request.getParameter(TO_DATE);
		if (!IKONUtils.isNullOrEmpty(toDate)) {
			ticketDataBean.setToDate(toDate);
		}

		String accountId = getDefaultAccountId();
		String loginusrname = ticketSummaryExtract(ticketDataBean, request);
		String userId = loginusrname;
		UserBean ubean = userService.getUserAccountType(accountId);
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		
		int isGeneric = ubean.getIsGeneric();
		model.addAttribute(IS_GENERIC, isGeneric);
		List<TicketDataBean> ticketDataBeanList = getAllIncMissingKo(ticketDataBean, accountId);
		Set<String> allApplicationNameList = new TreeSet<String>();
		Set<String> allAssignmentGroupList = new TreeSet<String>();
		Set<String> allTicketTypeList = new TreeSet<String>();
		Set<String> allPriorityList = new TreeSet<String>();
		Set<String> allStatusList = new TreeSet<String>();
		Set<String> allAssigneeList = new TreeSet<String>();
		Set<String> allTowerList = new TreeSet<String>();
		Set<String> allCCList = new TreeSet<String>();
		Set<String> allClusterList = new TreeSet<String>();
		for (TicketDataBean tdb : ticketDataBeanList) {
			addToSet(allApplicationNameList,tdb.getApplicationName());
			addToSet(allAssignmentGroupList,tdb.getAssignmentGroup());
			addToSet(allTicketTypeList,tdb.getServiceType());
			addToSet(allPriorityList,tdb.getPriority());
			addToSet(allStatusList,tdb.getStatus());
			addToSet(allAssigneeList,tdb.getAssigneeName());
			addToSet(allTowerList,tdb.getTower());
			addToSet(allCCList,tdb.getCc());
			addToSet(allClusterList,tdb.getCluster());			
		}

		populateBreadCrumb(accountId, ticketDataBean, model);
		

		int serialNum = 1;
		List<KOUsage> koUsageList = kOUsageRepository.findAll();
		List<TicketDataHistory> ticketDataHistoryList = null;
		List<KOInfoBean> koInfoList = koInfoService.getAllKos(accountId);

		for (TicketDataBean tdb : ticketDataBeanList) {
			serialNum = setTicketLinkedCountExtract(model, accountId, serialNum, koUsageList, ticketDataHistoryList,
					koInfoList, tdb);
			addToSet(allApplicationNameList,tdb.getApplicationName());
			addToSet(allAssignmentGroupList,tdb.getAssignmentGroup());
			addToSet(allTicketTypeList,tdb.getServiceType());
			addToSet(allPriorityList,tdb.getPriority());
			addToSet(allStatusList,tdb.getStatus());
			addToSet(allAssigneeList,tdb.getAssigneeName());
			addToSet(allTowerList,tdb.getTower());
			addToSet(allCCList,tdb.getCc());
			addToSet(allClusterList,tdb.getCluster());
			
		}

		model.addAttribute("allApplicationNameList", allApplicationNameList);
		model.addAttribute("allAssignmentGroupList", allAssignmentGroupList);
		model.addAttribute("allTicketTypeList", allTicketTypeList);
		model.addAttribute("allPriorityList", allPriorityList);
		model.addAttribute("allStatusList", allStatusList);
		model.addAttribute("allTowerList", allTowerList);
		model.addAttribute("allCCList", allCCList);
		model.addAttribute("allClusterList", allClusterList);
		allAssigneeList.remove("");
		model.addAttribute("allAssigneeList", allAssigneeList);

		return returnIncMissingKoReport(model, ticketDataBeanList);
	}

	/**
	 * Inc missing ko report get.
	 *
	 * @param ticketDataBean the ticket data bean
	 * @param model          the model
	 * @param request        the request
	 * @return the string
	 */
	@GetMapping("/incMissingKoReport")
	public String incMissingKoReportGet(@ModelAttribute(TICKET_SUMMARY_FORM_DETAIL) TicketDataBean ticketDataBean,
			Model model, HttpServletRequest request) {
		model.addAttribute(FROM_LOGIN, request.getParameter(FROM_LOGIN));
		model.addAttribute(REPORT_CAT, request.getParameter(REPORT_CAT));
		model.addAttribute(COMPONENT_TYPE, request.getParameter(COMPONENT_TYPE));
		model.addAttribute(REPORT_TYPE, request.getParameter(REPORT_TYPE));
		model.addAttribute(REPORT_NAME, request.getParameter(REPORT_NAME));
		model.addAttribute(REPORT_FREQUENCY, request.getParameter(REPORT_FREQUENCY));
		model.addAttribute(FROM_DATE, request.getParameter(FROM_DATE));
		model.addAttribute(TO_DATE, request.getParameter(TO_DATE));
		ReportDataAttributeVO reportDataAttributeVO = new ReportDataAttributeVO(getDefaultAccountId(), SecurityContextHolder.getContext().getAuthentication().getName(), INC_MISSING_KO_REPORT_ID,VIEW_ACTION_ID);
		reportService.insertReportUsage(reportDataAttributeVO);
		String selectedSearchType = request.getParameter(SEARCH_TYPE_CHOSEN);
		if (!IKONUtils.isNullOrEmpty(selectedSearchType)) {
			model.addAttribute(SELECTED_SEARCH_TYPE_VAL, selectedSearchType);
			ticketDataBean.setSearchType(selectedSearchType);
		}

		String fromDate = request.getParameter(FROM_DATE);
		if (!IKONUtils.isNullOrEmpty(fromDate)) {
			ticketDataBean.setFromDate(fromDate);
		}

		String toDate = request.getParameter(TO_DATE);
		if (!IKONUtils.isNullOrEmpty(toDate)) {
			ticketDataBean.setToDate(toDate);
		}

		String accountId = getDefaultAccountId();
		String loginusrname = ticketSummaryExtract(ticketDataBean, request);
		String userId = loginusrname;
		UserBean ubean = userService.getUserAccountType(accountId);
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		
		int isGeneric = ubean.getIsGeneric();
		model.addAttribute(IS_GENERIC, isGeneric);
		List<TicketDataBean> ticketDataBeanList = getAllIncMissingKo(ticketDataBean, accountId);
		Set<String> allApplicationNameList = new TreeSet<String>();
		Set<String> allAssignmentGroupList = new TreeSet<String>();
		Set<String> allTicketTypeList = new TreeSet<String>();
		Set<String> allPriorityList = new TreeSet<String>();
		Set<String> allStatusList = new TreeSet<String>();
		Set<String> allAssigneeList = new TreeSet<String>();
		Set<String> allTowerList = new TreeSet<String>();
		Set<String> allCCList = new TreeSet<String>();
		Set<String> allClusterList = new TreeSet<String>();
		for (TicketDataBean tdb : ticketDataBeanList) {
			addToSet(allApplicationNameList,tdb.getApplicationName());
			addToSet(allAssignmentGroupList,tdb.getAssignmentGroup());
			addToSet(allTicketTypeList,tdb.getServiceType());
			addToSet(allPriorityList,tdb.getPriority());
			addToSet(allStatusList,tdb.getStatus());
			addToSet(allAssigneeList,tdb.getAssigneeName());
			addToSet(allTowerList,tdb.getTower());
			addToSet(allCCList,tdb.getCc());
			addToSet(allClusterList,tdb.getCluster());			
		}

		populateBreadCrumb(accountId, ticketDataBean, model);

		int serialNum = 1;
		List<KOUsage> koUsageList = kOUsageRepository.findAll();
		List<TicketDataHistory> ticketDataHistoryList = null;
		List<KOInfoBean> koInfoList = koInfoService.getAllKos(accountId);

		for (TicketDataBean tdb : ticketDataBeanList) {
			serialNum = setTicketLinkedCountExtract(model, accountId, serialNum, koUsageList, ticketDataHistoryList,
					koInfoList, tdb);
			addToSet(allApplicationNameList,tdb.getApplicationName());
			addToSet(allAssignmentGroupList,tdb.getAssignmentGroup());
			addToSet(allTicketTypeList,tdb.getServiceType());
			addToSet(allPriorityList,tdb.getPriority());
			addToSet(allStatusList,tdb.getStatus());
			addToSet(allAssigneeList,tdb.getAssigneeName());
			addToSet(allTowerList,tdb.getTower());
			addToSet(allCCList,tdb.getCc());
			addToSet(allClusterList,tdb.getCluster());
		}

		model.addAttribute("allApplicationNameList", allApplicationNameList);
		model.addAttribute("allAssignmentGroupList", allAssignmentGroupList);
		model.addAttribute("allTicketTypeList", allTicketTypeList);
		model.addAttribute("allPriorityList", allPriorityList);
		model.addAttribute("allStatusList", allStatusList);
		model.addAttribute("allTowerList", allTowerList);
		model.addAttribute("allCCList", allCCList);
		model.addAttribute("allClusterList", allClusterList);

		allAssigneeList.remove("");
		model.addAttribute("allAssigneeList", allAssigneeList);
		
		return returnIncMissingKoReport(model, ticketDataBeanList);
	}

	/**
	 * Return inc missing ko report.
	 *
	 * @param model                  the model
	 * @param ticketDataBeanList     the ticket data bean list
	 * @return the string
	 */
	private String returnIncMissingKoReport(Model model, List<TicketDataBean> ticketDataBeanList) {
		
		String[] selectedValsArr = { TICKET_ID, SUMMARY, TICKET_TYPE, "Tower", "CC", "Cluster", ASSIGNMENT_GROUP,
				APPLICATION, ASSIGNEE, STATUS };		
		List<String> selectedValsList = new ArrayList<String>(Arrays.asList(selectedValsArr));

		model.addAttribute("selectedValsList", selectedValsList);

		Collections.sort(ticketDataBeanList);

		model.addAttribute(TICKET_SUMMARY_FORM, ticketDataBeanList);

		if (selectedValsList.contains("KO DB")) {
			model.addAttribute("KO_DB", TRUE);
		}
		if (selectedValsList.contains("Final Score")) {
			model.addAttribute("Final_Score", TRUE);
		}
		if (selectedValsList.contains("External Link")) {
			model.addAttribute("External_Link", TRUE);
		}
		String accountId = getDefaultAccountId();
		UserBean ubean = userService.getUserAccountType(accountId);
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		
		int isGeneric = ubean.getIsGeneric();
		model.addAttribute(IS_GENERIC, isGeneric);
		model.addAttribute("formheading", "Incident Missing KO Report");
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		return "incMissingKoReport";
	}

	/**
	 * Gets the all inc missing ko.
	 *
	 * @param ticketDataBean the ticket data bean
	 * @param accountId      the account id
	 * @return the all inc missing ko
	 */
	private List<TicketDataBean> getAllIncMissingKo(TicketDataBean ticketDataBean, String accountId) {
		TicketDataAttributeVO tktDtAttrVO = new TicketDataAttributeVO();
		MasterDataAttributeVO masterDataAttributeVO = new MasterDataAttributeVO(accountId, ticketDataBean.getApplicationName(), ticketDataBean.getAssignmentGroup(), ticketDataBean.getTower(), ticketDataBean.getCc(), ticketDataBean.getCluster(), "");
		masterDataAttributeVO.setFromDateTodate(ticketDataBean.getFromDate(), ticketDataBean.getToDate());
		tktDtAttrVO.setMasterDtAttrVo(masterDataAttributeVO);
		tktDtAttrVO.setServiceType(ticketDataBean.getServiceType());
		tktDtAttrVO.setAssigneeName(ticketDataBean.getAssigneeName());
		List<TicketDataBean> ticketDataBeanList = ticketDataService.getIncMissingKoData(tktDtAttrVO, ticketDataBean.getIsSearchByResolvedDate());
		return ticketDataBeanList;
	}

	/**
	 * Gets the user account.
	 *
	 * @return the user account
	 */
	private int getUserAccount() {
		String accountId = getDefaultAccountId();
		UserBean ub = userService.getUserAccountType(accountId);
		return Objects.nonNull(ub) ? ub.getIsGeneric() : -1;
	}

	/**
	 * Gets the logged user.
	 *
	 * @return the logged user
	 */
	private String getLoggedUser() {
		SecurityContext sc = SecurityContextHolder.getContext();
		Authentication auth = sc.getAuthentication();
		return auth.getName();
	}
	
	/**
	 * Adds the to set.
	 *
	 * @param set the set
	 * @param string the string
	 */
	private void addToSet(Set<String> set, String string) {
		if (!IKONUtils.isNullOrEmpty(string)) {
			set.add(string);
		}
	}

}
