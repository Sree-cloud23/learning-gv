package com.ikon.web;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ikon.dto.RoleBean;
import com.ikon.model.Role;
import com.ikon.rest.web.models.SecurityContextHolder;
import com.ikon.service.RoleService;
import com.ikon.validator.RoleValidator;

/**
 * The Class RoleController.
 */
@Controller
public class RoleController {

	/** The role service. */
	@Inject
	private transient RoleService roleService;

	/** The role validator. */
	@Inject
	private transient RoleValidator roleValidator;

	/**
	 * User details.
	 *
	 * @param model the model
	 * @return the model and view
	 */
	@RequestMapping(value = "/addRole", method = RequestMethod.GET)
	public ModelAndView userDetails(Model model) {
		Role role = new Role();
		model.addAttribute("roleForm", role);
		setUnameAndMaxRecDisplay(model);
		return new ModelAndView("addRole");
	}

	/**
	 * User details.
	 *
	 * @param roleForm      the role form
	 * @param bindingResult the binding result
	 * @param model         the model
	 * @return the model and view
	 */
	@RequestMapping(value = "/addRole", method = RequestMethod.POST)
	public ModelAndView userDetails(@ModelAttribute("roleForm") Role roleForm, BindingResult bindingResult,
			Model model) {

		roleValidator.validate(roleForm, bindingResult);
		if (bindingResult.hasErrors()) {
			setUnameAndMaxRecDisplay(model);
			return new ModelAndView("addRole");
		}
		roleService.save(roleForm);
		List<RoleBean> roleBeanList = new ArrayList<>();
		List<Role> roleList = roleService.findAll();
		for (Role roleListDataBean : roleList) {
			roleBeanList.add(roleDetailExtract(roleListDataBean));
		}
		model.addAttribute("roleBeanList", roleBeanList);
		setUnameAndMaxRecDisplay(model);
		return new ModelAndView("viewRole");

	}

	/**
	 * View user.
	 *
	 * @param roleForm      the role form
	 * @param bindingResult the binding result
	 * @param model         the model
	 * @return the model and view
	 */
	@RequestMapping(value = "/viewRole", method = RequestMethod.GET)
	public ModelAndView viewUser(@ModelAttribute("roleForm") Role roleForm, BindingResult bindingResult, Model model) {

		List<RoleBean> roleBeanList = new ArrayList<>();
		List<Role> roleList = roleService.findAll();
		for (Role roleListDataBean : roleList) {
			roleBeanList.add(roleDetailExtract(roleListDataBean));
		}
		model.addAttribute("roleBeanList", roleBeanList);
		model.addAttribute("maxRecDisplay", getMaxRecDisplay());
		model.addAttribute("loggedInUname", SecurityContextHolder.getContext().getAuthentication().getName());
		return new ModelAndView("viewRole");
	}

	/**
	 * Edits the.
	 *
	 * @param id       the id
	 * @param roleBean the role bean
	 * @param model    the model
	 * @return the model and view
	 */
	@RequestMapping(value = "/editRole/{id}", method = RequestMethod.GET)
	public ModelAndView edit(@PathVariable Long id, @ModelAttribute("roleBean") RoleBean roleBean, Model model) {
		Role role = roleService.findById(id);
		roleDetailExtract(roleBean, role);
		model.addAttribute("roleBean", roleBean);
		setUnameAndMaxRecDisplay(model);
		return new ModelAndView("editRole");
	}

	/**
	 * Sets the uname and max rec display.
	 *
	 * @param model the new uname and max rec display
	 */
	private void setUnameAndMaxRecDisplay(Model model) {
		model.addAttribute("loggedInUname", SecurityContextHolder.getContext().getAuthentication().getName());
		model.addAttribute("maxRecDisplay", getMaxRecDisplay());
	}

	/**
	 * Role detail extract.
	 *
	 * @param roleBean the role bean
	 * @param role     the role
	 */
	private void roleDetailExtract(RoleBean roleBean, Role role) {
		roleBean.setRolecategoryID(role.getRolecategoryID());
		roleBean.setRoleCategoryName(role.getRoleCategoryName());
		roleBean.setStatus(role.getStatus());
	}

	/**
	 * Role detail extract.
	 *
	 * @param role the role
	 * @return the roleBean
	 */
	private RoleBean roleDetailExtract(Role role) {
		RoleBean roleBean = new RoleBean();
		roleBean.setRolecategoryID(role.getRolecategoryID());
		roleBean.setRoleCategoryName(role.getRoleCategoryName());
		roleBean.setStatus(role.getStatus());
		return roleBean;
	}

	/**
	 * Edits the user data save.
	 *
	 * @param id            the id
	 * @param roleBean      the role bean
	 * @param bindingResult the binding result
	 * @param model         the model
	 * @return the model and view
	 */
	@RequestMapping(value = "/editRole/{id}", method = RequestMethod.POST)
	public ModelAndView editUserDataSave(@PathVariable Long id, @ModelAttribute("roleBean") RoleBean roleBean,
			BindingResult bindingResult, Model model) {
		Role role = new Role();
		role.addRolecatIdPub(roleBean.getRolecategoryID());
		role.setRoleCategoryName(roleBean.getRoleCategoryName());
		role.setStatus(roleBean.getStatus());
		roleService.save(role);

		List<RoleBean> roleBeanList = new ArrayList<>();
		List<Role> roleList = roleService.findAll();
		for (Role roleListDataBean : roleList) {
			roleBeanList.add(roleDetailExtract(roleListDataBean));
		}
		model.addAttribute("roleBeanList", roleBeanList);
		setUnameAndMaxRecDisplay(model);
		return new ModelAndView("viewRole");
	}

	/**
	 * Gets the max rec display.
	 *
	 * @return the max rec display
	 */
	public String getMaxRecDisplay() {
		return "10";
	}

}
