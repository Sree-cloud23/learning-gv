package com.ikon.web;

import java.util.List;
import java.util.Objects;
import java.util.Set;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.ikon.dto.LandingScreenBean;
import com.ikon.dto.SettingBean;
import com.ikon.dto.UserBean;
import com.ikon.model.AccountInfo;
import com.ikon.model.HelpDesk;
import com.ikon.model.ProfileMaster;
import com.ikon.model.Setting;
import com.ikon.repository.AccountInfoRepository;
import com.ikon.rest.web.models.Authentication;
import com.ikon.rest.web.models.SecurityContextHolder;
import com.ikon.service.AccessControlService;
import com.ikon.service.AccountInfoService;
import com.ikon.service.EmailService;
import com.ikon.service.HelpDeskService;
import com.ikon.service.ProfileMasterService;
import com.ikon.service.UserService;

import lombok.extern.slf4j.Slf4j;


/**
 * The Class HelpDeskController.
 */
@Controller
@Slf4j
public class HelpDeskController {

	/** The help service. */
	@Inject
	private transient HelpDeskService helpService;

	/** The email service. */
	@Inject
	private transient EmailService emailService;

	/** The user service. */
	@Inject
	private transient UserService userService;

	/** The profmast service. */
	@Inject
	private transient ProfileMasterService profmastService;

	/** The access control service. */
	@Inject
	private transient AccessControlService accessControlService;

	/** The session. */
	private static HttpSession session;

	/** The Constant log. */
	//private static final log log = LogManager.getlog(HelpDeskController.class);

	/** The Constant formheadingString. */
	private static final String FORM_HEADING = "formheading";

	/** The Constant IS_GENERIC. */
	private static final String IS_GENERIC = "isGeneric";
	
	/** The account info service. */
	@Autowired
	private transient AccountInfoService accInfoService;
	
	/** The AccountInfoRepository controller. */
	@Inject
	private transient AccountInfoRepository accInfoRepo;
	
	/** The flag for the message. */
	private boolean flag = false;

	/**
	 * Help desk.
	 *
	 * @param model       the model
	 * @param formheading the formheading
	 * @param request     the request
	 * @return the string
	 */
	@GetMapping("/helpDesk/{formheading}")
	public String helpDesk(Model model, @PathVariable String formheading, HttpServletRequest request) {

		log.info("Start:Get helpDesk");
		String userEmailID = "";
		int isGeneric = 0;
		String userID = getUserId();
		LandingScreenBean accessControlBean = userService.getUserDetail(userID);
		if (Objects.nonNull(accessControlBean) && Objects.nonNull(accessControlBean.getEmail())) {
			userEmailID = accessControlBean.getEmail();
		}
		
		if(!userID.isEmpty()) {
		 isGeneric = getUserAccount();
		}
		model.addAttribute("helpDeskForm", new HelpDesk());
		model.addAttribute("userEmailID", userEmailID);
		model.addAttribute(FORM_HEADING, "Helpdesk");
		model.addAttribute("urlformheading", formheading);
		model.addAttribute("userID", "userID");

		Set<String> HelpdeskOptionsList = helpService.helpdeskOptionsListing(formheading);
		model.addAttribute("HelpdeskOptionsList", HelpdeskOptionsList);
		String referer = request.getHeader("Referer");
		model.addAttribute("goBackURL", referer);
//		START:May Deployment-SPRINT1
		if(!flag) {
			model.addAttribute("message", "");
		}
		else {
			model.addAttribute("message", "Your query recevied.IKON-2 team will reach you soon");
		}
//		END:May Deployment-SPRINT1
		model.addAttribute(IS_GENERIC, isGeneric);
		
		int accountId = 1;
		List<AccountInfo> accountInfoList = accInfoRepo.findAll();
		for(AccountInfo accountInfo:accountInfoList){
			 accountId = accountInfo.getAccountId();
		}
		int helpdeskStatus = getDisplayStatus(accountId);
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		flag=false;
		 
		log.info("End:Get helpDesk");
		return "helpDesk";
	}

	/**
	 * Registration.
	 *
	 * @param model    the model
	 * @param helpForm the help form
	 * @param request  the request
	 * @param error    the error
	 * @param session  the session
	 * @return the string
	 */
	/*
	 * @PostMapping("/helpDesk") public String registration(ModelMap
	 * model, @ModelAttribute("helpDeskForm") HelpDesk helpForm, HttpServletRequest
	 * request, String error, HttpSession session) {
	 * 
	 * log.info("Start :Post helpDesk"); helpService.save(helpForm, request,
	 * session); String requesteremail = request.getParameter("requesteremail");
	 * String subject = request.getParameter("subject"); String recipientsto =
	 * request.getParameter("recipientsto"); String recipientscc =
	 * request.getParameter("recipientscc"); String shortdescription =
	 * request.getParameter("shortdescription"); String description =
	 * request.getParameter("description"); String requesterRaisedFor =
	 * request.getParameter("requesterRaisedFor"); String areaofconcern1 =
	 * request.getParameter("areaOfConcern"); String accountname = (String)
	 * session.getAttribute("accountname"); String recipientsCC = recipientscc + ","
	 * + requesteremail; int accountid = (int) session.getAttribute("accountid");
	 * String areaofconcern; if (areaofconcern1.equalsIgnoreCase("other"))
	 * areaofconcern = request.getParameter("otherarea"); else areaofconcern =
	 * request.getParameter("areaOfConcern");
	 * 
	 * // Email message SimpleMailMessage passwordResetEmail = new
	 * SimpleMailMessage(); passwordResetEmail.setFrom(requesteremail);
	 * passwordResetEmail.setTo(recipientsto);
	 * passwordResetEmail.setCc(recipientsCC); String subjectHelp = "IKON-2: " +
	 * subject; passwordResetEmail.setSubject(subjectHelp); String openingMsg =
	 * "Hi Team,"; String endingMsg = "\n Regards,\n" +
	 * "Capgemini IKON Support Team"; String mailmsg = openingMsg +
	 * ("\n Please find the details below\n " + "\nShortDescrption:" +
	 * shortdescription + "\n" + "\nDescription:" + description + "\n" +
	 * "\nRequester raised for:" + requesterRaisedFor + "\n" + "\nArea of concern:"
	 * + areaofconcern + "\n" + "\nCaller:" + accountname + "\n") + endingMsg;
	 * passwordResetEmail.setText(mailmsg); try {
	 * emailService.sendEmail(passwordResetEmail); //model.addAttribute("message",
	 * "Your query recevied.IKON-2 team will reach you soon"); } catch
	 * (MailException e) { model.addAttribute("message",
	 * "Error in sending email.Please contact to support team @ natools_ikon.in@capgemini.com."
	 * ); //START:May Deployment-SPRINT1 String br_mailmsg =
	 * mailmsg.replaceAll(openingMsg, ""); br_mailmsg =
	 * br_mailmsg.replaceAll(endingMsg, ""); br_mailmsg =
	 * br_mailmsg.replaceAll("\n", "<br/>"); //END:May Deployment-SPRINT1
	 * helpService.infomailsave(requesteremail, recipientsto, recipientsCC,
	 * subjectHelp, br_mailmsg, accountid);
	 * 
	 * } // START:May Deployment-SPRINT1 String helpdeskMsg =
	 * "Your query recevied.IKON-2 team will reach you soon";
	 * model.addAttribute("message", helpdeskMsg); flag=true;
	 * model.addAttribute("flag", flag); // END:May Deployment-SPRINT1 String
	 * referer = request.getHeader("Referer");
	 * 
	 * model.addAttribute("goBackURL", referer);
	 * 
	 * log.info("End:Post helpDesk"); return "redirect:" + referer; }
	 */

	/**
	 * Setting.
	 *
	 * @param model       the model
	 * @param settingbean the settingbean
	 * @return the string
	 */
	@GetMapping("/setting")
	public String setting(Model model, @ModelAttribute("settingFormId") SettingBean settingbean) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		log.info("Start: Setting");
		int defaultAccountName = 0;
		int defaultLandingPageName = 0;
		String userID = auth.getName();
		int accid = 0;
		LandingScreenBean accessControlBean = userService.getUserDetail(userID);
		if (Objects.nonNull(accessControlBean))
			accid = accessControlBean.getDefaultAccountID();
		List<SettingBean> accountAccesslist = helpService.accountAccess(userID);
		List<SettingBean> defaultAccountlist = helpService.defaultAccount(userID);
		List<SettingBean> landingPageList = helpService.landingPageListing(userID);
		List<SettingBean> defaultlandingPageList = helpService.defaultLandingPage(userID, accid);

		for (SettingBean settingBean1 : defaultAccountlist) {
			defaultAccountName = settingBean1.getDefaultAccountID();
		}
		for (SettingBean settingBean3 : defaultlandingPageList) {
			defaultLandingPageName = settingBean3.getID();
		}
		int isGeneric = getUserAccount();
		int helpdeskStatus = getDisplayStatus(accid);
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		model.addAttribute("accountAccesslist", accountAccesslist);
		model.addAttribute("defaultAccountName", defaultAccountName);
		model.addAttribute("landingPageList", landingPageList);
		model.addAttribute("defaultLandingPageName", defaultLandingPageName);
		model.addAttribute(FORM_HEADING, "Setting");
		model.addAttribute(IS_GENERIC,isGeneric);
		log.info("End: Setting");
		return "setting";
	}

	/**
	 * Save setting.
	 *
	 * @param settab  the settab
	 * @param request the request
	 * @param model   the model
	 * @return the model and view
	 */
	@PostMapping(value = "/setting")
	public ModelAndView saveSetting(@ModelAttribute("settingFormId") Setting settab, HttpServletRequest request,
			Model model) {
		log.info("Start: Post Setting");
		String userID = getUserId();
		helpService.settingacc_save(settab, request, session);
		helpService.settinglanpage_save(settab, request, session);
		int defaultAccountName = 0;
		int defaultLandingPageName = 0;
		int accid = 0;

		LandingScreenBean accessControlBean = userService.getUserDetail(userID);
		if (Objects.nonNull(accessControlBean))
			accid = accessControlBean.getDefaultAccountID();
		List<SettingBean> accountAccesslist = helpService.accountAccess(userID);
		List<SettingBean> defaultAccountlist = helpService.defaultAccount(userID);
		List<SettingBean> landingPageList = helpService.landingPageListing(userID);
		List<SettingBean> defaultlandingPageList = helpService.defaultLandingPage(userID, accid);

		for (SettingBean settingBean1 : defaultAccountlist) {
			defaultAccountName = settingBean1.getDefaultAccountID();
		}
		for (SettingBean settingBean3 : defaultlandingPageList) {
			defaultLandingPageName = settingBean3.getID();
		}
		int isGeneric = getUserAccount();
		int helpdeskStatus = getDisplayStatus(accid);
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		model.addAttribute("displayresult", "Successfully updated");
		model.addAttribute("accountAccesslist", accountAccesslist);
		model.addAttribute("defaultAccountName", defaultAccountName);
		model.addAttribute("landingPageList", landingPageList);
		model.addAttribute("defaultLandingPageName", defaultLandingPageName);
		model.addAttribute(IS_GENERIC, isGeneric);
		model.addAttribute(FORM_HEADING, "Setting");
		log.info("End: Post Setting");
		return new ModelAndView("setting");
	}

	/**
	 * Gets the user id.
	 *
	 * @return the user id
	 */
	private String getUserId() {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String userID = auth.getName();
		return userID;
	}

	/**
	 * Gets the default account id.
	 *
	 * @return the default account id
	 */
	private int getAccountId() {
		String loginusrname = getUserId();

		int accountId = Integer
				.parseInt(String.valueOf(accessControlService.getAccessDetailByUserId(loginusrname).getAccountId()));
		return accountId;
	}

	/**
	 * View profile.
	 *
	 * @param model the model
	 * @return the string
	 */
	@GetMapping("/viewProfile")
	public String viewProfile(Model model) {

		return viewProfilePopulate(model);
	}

	/**
	 * View profile data.
	 *
	 * @param model the model
	 * @return the string
	 */
	@PostMapping("/viewProfile")
	public String viewProfileData(Model model) {

		return viewProfilePopulate(model);
	}

	/**
	 * View profile populate.
	 *
	 * @param model the model
	 * @return the string
	 */
	private String viewProfilePopulate(Model model) {
		String userID = getUserId();
		int accountId = getAccountId();
		int isGeneric = getUserAccount();
		LandingScreenBean accessControlBean = userService.getUserDetail(userID);
		long profileID = accessControlBean.getProfileID();
		ProfileMaster profile = profmastService.findById(profileID);
		int helpdeskStatus = getDisplayStatus(accountId);
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		if (Objects.nonNull(accessControlBean)) {
			model.addAttribute("userName", accessControlBean.getName());
			model.addAttribute("userEmailID", accessControlBean.getEmail());
		}
		if (Objects.nonNull(profile))
			model.addAttribute("userRole", profile.getProfileName());
		List<SettingBean> accountAccesslist = helpService.accountAccess(userID);
		SettingBean statisticlist = helpService.getStatisticData(accountId);
		model.addAttribute("accountAccesslist", accountAccesslist);
		model.addAttribute("statisticlist", statisticlist);
		model.addAttribute(FORM_HEADING, "View Profile");
		model.addAttribute(IS_GENERIC, isGeneric);
		return "viewProfile";
	}

	
	
	/**
	 * Gets the user account.
	 *
	 * @return the user account
	 */
	private int getUserAccount() {
		String accountId = getDefaultAccountId();
		UserBean ub = userService.getUserAccountType(accountId);
		return Objects.nonNull(ub) ? ub.getIsGeneric() : -1;
	}
	/**
	 * Gets the default account id.
	 *
	 * @return the default account id
	 */
	private String getDefaultAccountId() {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String loginusrname = auth.getName();

		String accountId = String.valueOf(accessControlService.getAccessDetailByUserId(loginusrname).getAccountId());
		return Objects.isNull(accountId)?"":accountId;
	}
	
	/**
	 * Populate data.
	 *
	 * @param model       the model
	 * @param response    the response
	 * @param settingBean the setting bean
	 * @param accountID   the account ID
	 * @return the response entity
	 */
	@JsonIgnoreProperties
	@RequestMapping(value = "/searchAccount/{accountID}")
	public ResponseEntity<?> populateData(Model model, HttpServletResponse response, SettingBean settingBean,
			@PathVariable int accountID){
		SettingBean statisticlistResult = helpService.getStatisticData(accountID);
		settingBean.setTicketResolved(statisticlistResult.getTicketResolved());
		settingBean.setKoCreated(statisticlistResult.getKoCreated());
		settingBean.setKoUsed(statisticlistResult.getKoUsed());
		model.addAttribute(FORM_HEADING, "View Profile");
		return ResponseEntity.ok(statisticlistResult);
	}
	
	/**
	 * Gets the display status.
	 *
	 * @param accountID the account ID
	 * @return the display status
	 */
	public int getDisplayStatus(int accountID) {
		
		return accInfoService.getDisplaypage(accountID);
	}

}