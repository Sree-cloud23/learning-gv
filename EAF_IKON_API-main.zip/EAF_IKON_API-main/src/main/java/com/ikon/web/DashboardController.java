package com.ikon.web;

import java.math.BigInteger;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;


import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.ikon.dto.AgeingWorkinfoBean;
import com.ikon.dto.ComplianceBean;
import com.ikon.dto.DashboardBean;
import com.ikon.dto.KOInfoBean;
import com.ikon.dto.KOMetricsBean;
import com.ikon.dto.MasterDataAttributeVO;
import com.ikon.dto.ReportBean;
import com.ikon.dto.ReportDataAttributeVO;
import com.ikon.dto.SettingBean;
import com.ikon.dto.UserBean;
import com.ikon.model.AccessControl;
import com.ikon.model.ApplicationMaster;
import com.ikon.model.UserMaster;
import com.ikon.rest.web.models.Authentication;
import com.ikon.rest.web.models.SecurityContext;
import com.ikon.rest.web.models.SecurityContextHolder;
import com.ikon.service.AccessControlService;
import com.ikon.service.AccountInfoService;
import com.ikon.service.ApplicationMasterService;
import com.ikon.service.HelpDeskService;
import com.ikon.service.ReportService;
import com.ikon.service.TMDashboardService;
import com.ikon.service.TicketDataService;
import com.ikon.service.UserService;
import com.ikon.validator.IKONUtils;

import lombok.extern.slf4j.Slf4j;


/**
 * The Class DashboardController.
 */
@Controller
@Slf4j
public class DashboardController {

	/** The access control service. */
	@Inject
	private transient AccessControlService accessControlService;

	/** The tm dashboard service. */
	@Inject
	private transient TMDashboardService tmDashboardService;

	/** The ticket data service. */
	@Inject
	private transient TicketDataService ticketDataService;

	/** The help service. */
	@Inject
	private transient HelpDeskService helpService;

	/** The user service. */
	@Inject
	private transient UserService userService;

	/** The account info service. */
	@Inject
	private transient AccountInfoService accountInfoService;

	/** The application master service. */
	@Inject
	private transient ApplicationMasterService applicationMasterService;

	/** The report service. */
	@Inject
	private transient ReportService reportService;

	/** The Constant log. */
	//private static final log log = LogManager.getlog(DashboardController.class);

	/** The Constant LEADERBOARD_REPORT_ID. */
	private static final String LEADERBOARD_REPORT_ID = "12";

	/** The Constant LEADERBOARD_TOP_CONTRIBUTOR_REPORT_ID. */
	private static final String LEADERBOARD_TOP_CONTRIBUTOR_REPORT_ID = "13";

	/** The Constant LEADERBOARD_TOP_ANALYST_REPORT_ID. */
	private static final String LEADERBOARD_TOP_ANALYST_REPORT_ID = "14";

	/** The Constant LEADERBOARD_TOP_REVIEWER_REPORT_ID. */
	private static final String LEADERBOARD_TOP_REVIEWER_REPORT_ID = "15";

	/** The Constant VIEW_ACTION_ID. */
	private static final String VIEW_ACTION_ID = "1";

	/** The Constant TM_PROFILE_ID_LIST. */
	private static final List<Long> TM_PROFILE_ID_LIST = new ArrayList<Long>(Arrays.asList(1L, 3L, 4L, 5L));

	/** The Constant TL_PROFILE_ID_LIST. */
	private static final List<Long> TL_PROFILE_ID_LIST = new ArrayList<Long>(Arrays.asList(2L, 6L));

	/** The Constant DASHBOARD_SUMMARY_DETAIL. */
	private static final String DASHBOARD_SUMMARY_DETAIL = "dashboardSummaryDetail";

	/** The Constant VIEW_TYPE. */
	private static final String VIEW_TYPE = "viewType";

	/** The Constant USER_PROFILE_ID. */
	private static final String USER_PROFILE_ID = "userProfileId";

	/** The Constant DASHBOARD. */
	private static final String DASHBOARD = "Dashboard";

	/** The Constant FORM_HEADING. */
	private static final String FORM_HEADING = "formheading";

	/** The Constant LOGIN_NAME. */
	private static final String LOGIN_NAME = "loginName";

	/** The Constant GET_DASHBOARD_SUMMARY. */
	private static final String GET_DASHBOARD_SUMMARY = "End: getDashboardSummary";

	/** The Constant LEADERBOARD_DATALIST. */
	private static final String LEADERBOARD_DATALIST = "leaderboardDataList";

	/** The Constant TOP_ANALYS_DATATM. */
	private static final String TOP_ANALYS_DATATM = "topAnalystDataTM";

	/** The Constant TOP_REVIEWER_DATATM. */
	private static final String TOP_REVIEWER_DATATM = "topReviewerDataTM";

	/** The Constant TOP_CONTRIBUTOR_DATATM. */
	private static final String TOP_CONTRIBUTOR_DATATM = "topContributorDataTM";

	/** The Constant REPORTS_CHARTS. */
	private static final String REPORTS_CHARTS = "ReportsCharts";

	/** The Constant TM_DASHBOARD_REPORT_CHART. */
	private static final String TM_DASHBOARD_REPORT_CHART = "tmdashboard-report-chart";

	/** The Constant TM_INCIDENTS_KOS. */
	private static final String TM_INCIDENTS_KOS = "TMIncidentsKOs";

	/** The Constant TM_DASHBOARD_INCIDENTS_KOS. */
	private static final String TM_DASHBOARD_INCIDENTS_KOS = "tmdashboard-incidentsandkos";

	/** The Constant TM_DASHBOARD_LEADERBOARD. */
	private static final String TM_DASHBOARD_LEADERBOARD = "tmdashboard-leaderboard";

	/** The Constant TL_INCIDENTS_KOS. */
	private static final String TL_INCIDENTS_KOS = "TLIncidentsKOs";

	/** The Constant TL_DASHBOARD_INCIDENTS_KOS. */
	private static final String TL_DASHBOARD_INCIDENTS_KOS = "tldashboard-incidentsandkos";

	/** The Constant TL_DASHBOARD_LEADERBOARD. */
	private static final String TL_DASHBOARD_LEADERBOARD = "tldashboard-leaderboard";

	/** The Constant LEAD_RTZ_COUNT. */
	private static final String LEAD_RTZ_COUNT = "leadRTZCount";

	/** The Constant REPORT_CAT. */
	private static final String REPORT_CAT = "reportCategorization";

	/** The Constant COMPONENT_TYPE. */
	private static final String COMPONENT_TYPE = "componentType";

	/** The Constant REPORT_TYPE. */
	private static final String REPORT_TYPE = "reportType";

	/** The Constant REPORT_NAME. */
	private static final String REPORT_NAME = "reportName";

	/** The Constant REPORT_FREQ. */
	private static final String REPORT_FREQ = "reportFrequency";

	/** The Constant FROM_DATE. */
	private static final String FROM_DATE = "fromDate";

	/** The Constant TO_DATE. */
	private static final String TO_DATE = "toDate";

	/** The Constant KO_USGRPT_FROMDETAIL. */
	private static final String KO_USGRPT_FROMDETAIL = "koUsageReportFormDetail";

	/** The Constant TEN. */
	private static final int TEN = 10;

	/** The Constant THREE. */
	private static final int THREE = 3;
	/** The Constant IS_GENERIC. */
	private static final String IS_GENERIC = "isGeneric";
	
	/** The helpdesk controller. */
	@Inject
	private transient HelpDeskController helpdeskController;
	
	/**
	 * Gets the dashboard.
	 *
	 * @param dashboardBean the dashboard bean
	 * @param settingBean   the setting bean
	 * @param model         the model
	 * @param request       the request
	 * @return the dashboard
	 */
	@GetMapping("/dashboard")
	public String getDashboard(@ModelAttribute(DASHBOARD_SUMMARY_DETAIL) DashboardBean dashboardBean,
			SettingBean settingBean, Model model, HttpServletRequest request) {
		log.info("Start: Dashboard");
		String accountId = getDefaultAccountId();
		String accountName = getDefalutAccountName(accountId);
		String viewType = request.getParameter(VIEW_TYPE);
		String userId = getLoggedUser();
		switch (getUserAccount()) {
		case 0:
			log.info("User belongs to normal account");
			break;
		case 2:
			log.info("User belongs to normal account");
			break;
		default:
			return "permissionDenied";
		}
		UserMaster usermaster = userService.getdetailsByuserid(userId);
		String name = usermaster.getUserId();
		AccessControl accessControlBean = accessControlService.getAccessDetailByUserId(userId);
		long profileId = accessControlBean.getProfileId();
		model.addAttribute(USER_PROFILE_ID, profileId);
		DashboardBean dbeanAnalyst = null;
		DashboardBean dbeanReviewer = null;
		DashboardBean dbeanContributor = null;

		// Leader board code starts
		List<DashboardBean> leaderBoardDataBeanList = tmDashboardService.getLeaderBoardData(accountName);
		List<DashboardBean> topAnalystDataBean = tmDashboardService.getTopAnalystData(accountName);
		List<DashboardBean> topContributorDataBean = tmDashboardService.getTopContributorData(accountName);
		List<DashboardBean> topReviewerDataBean = tmDashboardService.getTopReviewerData(accountName);
		dbeanAnalyst = (DashboardBean) firstElementOfList(topAnalystDataBean);
		dbeanContributor = (DashboardBean) firstElementOfList(topContributorDataBean);
		dbeanReviewer = (DashboardBean) firstElementOfList(topReviewerDataBean);
		// Leader board code ends
		UserBean ubean = userService.getUserAccountType(accountId);
		int isGeneric = ubean.getIsGeneric();
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		model.addAttribute(IS_GENERIC, isGeneric);
		model.addAttribute(FORM_HEADING, DASHBOARD);
		model.addAttribute(LOGIN_NAME, name);
		log.info(GET_DASHBOARD_SUMMARY);

		// Added logged in user to leader board if not in top 10 list
		if (Objects.nonNull(leaderBoardDataBeanList) && leaderBoardDataBeanList.size() > 0) {
			List<DashboardBean> topTenList = topTenList(leaderBoardDataBeanList, name);
			model.addAttribute(LEADERBOARD_DATALIST, topTenList);
		}

		if (TM_PROFILE_ID_LIST.contains(profileId)) {
			model.addAttribute(TOP_ANALYS_DATATM, dbeanAnalyst);
			model.addAttribute(TOP_REVIEWER_DATATM, dbeanReviewer);
			model.addAttribute(TOP_CONTRIBUTOR_DATATM, dbeanContributor);

			return tmDashboardViewTypeReturn(viewType);
		}

		if (TL_PROFILE_ID_LIST.contains(profileId)) {
			// display top 3 users only for TL in dashboard page changes added
			model.addAttribute("topAnalystData",
					topAnalystDataBean.subList(0, topAnalystDataBean.size() <= 3 ? topAnalystDataBean.size() : 3));
			model.addAttribute("topReviewerData",
					topReviewerDataBean.subList(0, topReviewerDataBean.size() <= 3 ? topReviewerDataBean.size() : 3));
			model.addAttribute("topContributorData", topContributorDataBean.subList(0,
					topContributorDataBean.size() <= 3 ? topContributorDataBean.size() : 3));
			return tlDashboardViewTypeReturn(viewType);
		}

		model.addAttribute(FORM_HEADING, "Testing Dashboard");
		log.info(GET_DASHBOARD_SUMMARY);
		return null;

	}

	/**
	 * Top ten list.
	 *
	 * @param leaderBoardDataBeanList the leader board data bean list
	 * @param name the name
	 * @return the list
	 */
	private List<DashboardBean> topTenList(List<DashboardBean> leaderBoardDataBeanList, String name) {
		List<DashboardBean> topTenList = null;
		DashboardBean loggedUserDashboardBean = null;
		if (leaderBoardDataBeanList.size() < TEN) {
			topTenList = leaderBoardDataBeanList;
			for (DashboardBean dataBean : leaderBoardDataBeanList) {
				if (dataBean.getName().equalsIgnoreCase(name)) {
					loggedUserDashboardBean = dataBean;
				}
			}
			if (Objects.nonNull(loggedUserDashboardBean) && !topTenList.contains(loggedUserDashboardBean)) {
				topTenList.add(loggedUserDashboardBean);
			}

		} else {
			topTenList = leaderBoardDataBeanList.subList(0, 10);
			for (DashboardBean dataBean : leaderBoardDataBeanList) {
				if (dataBean.getName().equalsIgnoreCase(name)) {
					loggedUserDashboardBean = dataBean;
				}
			}
			if (Objects.nonNull(loggedUserDashboardBean) && !topTenList.contains(loggedUserDashboardBean)) {
				topTenList.add(loggedUserDashboardBean);
			}

		}
		return topTenList;
	}

	/**
	 * First element of list.
	 *
	 * @param list the list
	 * @return the object
	 */
	private Object firstElementOfList(List list) {
		return Objects.nonNull(list) && list.size() > 0 ? list.get(0) : null;
	}

	/**
	 * Gets the INCK odashboard.
	 *
	 * @param dashboardBean the dashboard bean
	 * @param settingBean   the setting bean
	 * @param model         the model
	 * @param request       the request
	 * @return the INCK odashboard
	 */
	@GetMapping("/INCKOdashboard")
	public String getINCKOdashboard(@ModelAttribute(DASHBOARD_SUMMARY_DETAIL) DashboardBean dashboardBean,
			SettingBean settingBean, Model model, HttpServletRequest request) {
			log.info("Start: getINCKOdashboard");
			String accountId = getDefaultAccountId();
			String viewType = request.getParameter(VIEW_TYPE);
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userId = auth.getName();
			AccessControl accessControlBean = accessControlService.getAccessDetailByUserId(userId);// condition for dashboard based on profile
			long profileId = accessControlBean.getProfileId();
			model.addAttribute(USER_PROFILE_ID, profileId);
			LocalDate monthBegin = LocalDate.now().withDayOfMonth(1);// getting current month
			LocalDate monthEnd = LocalDate.now().plusMonths(1).withDayOfMonth(1).minusDays(1);

			List<DashboardBean> avgMTTRPerMonth = tmDashboardService.getMttrAvgHoursPerMon(monthBegin.toString(),
					monthEnd.toString());
			List<DashboardBean> mttrByPriority = tmDashboardService.getMttrByPriority(monthBegin.toString(),
					monthEnd.toString());
			if (Objects.nonNull(avgMTTRPerMonth) && avgMTTRPerMonth.size() > 0) {
				model.addAttribute("avgMTTRHoursPerMonth", avgMTTRPerMonth.get(0));
			}
			if (Objects.nonNull(mttrByPriority) && mttrByPriority.size() > 0) {
				model.addAttribute("mttrByPriorityVal", mttrByPriority);
			}
			UserBean ubean = userService.getUserAccountType(accountId);
			int isGeneric = ubean.getIsGeneric();
			int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
			model.addAttribute("isHelpdeskVisible", helpdeskStatus);
			model.addAttribute(IS_GENERIC, isGeneric);
			if (TM_PROFILE_ID_LIST.contains(profileId)) {
				
				
				return tmDashboardDetails(model,userId,accountId,viewType);
			}

			if (TL_PROFILE_ID_LIST.contains(profileId)) {
				
				
				return tlDashboardDetails(model,userId,viewType);
			}
			
			model.addAttribute(FORM_HEADING, DASHBOARD);
			log.info(GET_DASHBOARD_SUMMARY);
			return null;
	}

	/**
	 * Tl dashboard details.
	 *
	 * @param model the model
	 * @param userId the user id
	 * @param viewType the view type
	 * @return the string
	 */
	private String tlDashboardDetails(Model model, String userId, String viewType) {

		MasterDataAttributeVO masterDataAttributeVO = new MasterDataAttributeVO("", "", "", "", "", "", userId);
		List<DashboardBean> leadIncidentsDataBeanList = tmDashboardService.getAllTLInciedentsDashboardData(masterDataAttributeVO, "");
		List<DashboardBean> leadRTZDataBeanList = tmDashboardService.getAllTLRunToZeroData(masterDataAttributeVO, "");
		List<DashboardBean> leadKOStatus = tmDashboardService.getAllTLKoStatusData(masterDataAttributeVO, "");
		List<DashboardBean> koIncLinkCount = tmDashboardService.getKOIncLinkCountTL(masterDataAttributeVO, "");

		// Incidents By Status tab
		int incSum = 0;
		for (DashboardBean dbean : leadIncidentsDataBeanList) {
			incSum += dbean.getTicketIDCount().intValue();
			model.addAttribute("totalIncidentsVal", incSum);
		}
		model.addAttribute("leadIncidentsDataByStatus", leadIncidentsDataBeanList);

		// Run to Zero tab starts
		int sum = 0;
		for (DashboardBean dbean : leadRTZDataBeanList) {
			sum += dbean.getOpenedTicketIDCount().intValue();
			model.addAttribute("leadRTZTotalCount", sum);
		}
		if (leadRTZDataBeanList.size() >= THREE) {
			model.addAttribute(LEAD_RTZ_COUNT, leadRTZDataBeanList.subList(0, 3));
		} else {
			model.addAttribute(LEAD_RTZ_COUNT, leadRTZDataBeanList);
		}
		// Run to Zero ends
		// Ko Status tab starts

		if (Objects.nonNull(koIncLinkCount) && koIncLinkCount.size() > 0) {
			model.addAttribute("koIncLinkCountVal", koIncLinkCount.get(0));
		}

		if (Objects.nonNull(leadKOStatus) && leadKOStatus.size() > 0) {
			model.addAttribute("leadKoListval", leadKOStatus);
		}
		// Ko Status tab ends
		return tlDashboardViewTypeReturn(viewType);

	}

	/**
	 * Tl dashboard view type return.
	 *
	 * @param viewType the view type
	 * @return the string
	 */
	private String tlDashboardViewTypeReturn(String viewType) {

		if (!IKONUtils.isNullOrEmpty(viewType) && viewType.equalsIgnoreCase(REPORTS_CHARTS)) {
			return TM_DASHBOARD_REPORT_CHART;
		} else if (!IKONUtils.isNullOrEmpty(viewType) && viewType.equalsIgnoreCase(TL_INCIDENTS_KOS)) {
			return TL_DASHBOARD_INCIDENTS_KOS;
		} else {
			return TL_DASHBOARD_LEADERBOARD;
		}
	}

	/**
	 * Tm dashboard details.
	 *
	 * @param model the model
	 * @param userId the user id
	 * @param accountId the account id
	 * @param viewType the view type
	 * @return the string
	 */
	private String tmDashboardDetails(Model model, String userId, String accountId, String viewType) {
		DashboardBean dashboardForOpenIncidents = null;
		List<DashboardBean> dashboardDataBeanList = tmDashboardService.getTMDashboardData(userId, accountId);
		dashboardForOpenIncidents = dashboardDataBeanList.get(0);
		dashboardDataBeanList.forEach(dashboardBeanVal -> {
			setDashboardNullsToDefaults(dashboardBeanVal);
		});
		UserBean ubean = userService.getUserAccountType(accountId);
		int isGeneric = ubean.getIsGeneric();
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		model.addAttribute(IS_GENERIC, isGeneric);
		model.addAttribute(FORM_HEADING, DASHBOARD);
		model.addAttribute("dashboardDataBeanListForm", dashboardForOpenIncidents);
		model.addAttribute("dashboardDataBeanListVal", dashboardDataBeanList);

		return tmDashboardViewTypeReturn(viewType);
	}

	/**
	 * Tm dashboard view type return.
	 *
	 * @param viewType the view type
	 * @return the string
	 */
	private String tmDashboardViewTypeReturn(String viewType) {

		if (!IKONUtils.isNullOrEmpty(viewType) && viewType.equalsIgnoreCase(REPORTS_CHARTS)) {
			return TM_DASHBOARD_REPORT_CHART;
		} else if (!IKONUtils.isNullOrEmpty(viewType) && viewType.equalsIgnoreCase(TM_INCIDENTS_KOS)) {
			return TM_DASHBOARD_INCIDENTS_KOS;
		} else {
			return TM_DASHBOARD_LEADERBOARD;
		}
	}

	/**
	 * Sets the dashboard nulls to defaults.
	 *
	 * @param dashboardBeanVal the new dashboard nulls to defaults
	 */
	private void setDashboardNullsToDefaults(DashboardBean dashboardBeanVal) {

		if (Objects.isNull(dashboardBeanVal.getOpenIncidents())) {
			dashboardBeanVal.setOpenIncidents(0);
		}
		if (Objects.isNull(dashboardBeanVal.getTicketsToday())) {
			dashboardBeanVal.setTicketsToday(0);
		}
		if (Objects.isNull(dashboardBeanVal.getInprogress())) {
			dashboardBeanVal.setInprogress(0);
		}
		if (Objects.isNull(dashboardBeanVal.getKoCount())) {
			dashboardBeanVal.setKoCount(0);
		}
		if (Objects.isNull(dashboardBeanVal.getDraftCount())) {
			dashboardBeanVal.setDraftCount(0);
		}
		if (Objects.isNull(dashboardBeanVal.getPublishCount())) {
			dashboardBeanVal.setPublishCount(0);
		}
		if (Objects.isNull(dashboardBeanVal.getReviewCount())) {
			dashboardBeanVal.setReviewCount(0);
		}

	}

	/**
	 * Gets the dashboard summary.
	 *
	 * @param dashboardBean the dashboard bean
	 * @param settingBean   the setting bean
	 * @param model         the model
	 * @param request       the request
	 * @return the dashboard summary
	 */
	@GetMapping("/teamMemberDashboard")
	public String getDashboardSummary(@ModelAttribute(DASHBOARD_SUMMARY_DETAIL) DashboardBean dashboardBean,
			SettingBean settingBean, Model model, HttpServletRequest request) {
		log.info("Start: getDashboardSummary");
		String accountId = getDefaultAccountId();
		String accountName = getDefalutAccountName(accountId);
		String viewType = request.getParameter(VIEW_TYPE);
		UserBean ubean = userService.getUserAccountType(accountId);
		int isGeneric = ubean.getIsGeneric();
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		model.addAttribute(IS_GENERIC, isGeneric);
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String userId = auth.getName();
		UserMaster usermaster = userService.getdetailsByuserid(userId);
		String name = usermaster.getUserId(); 

		AccessControl accessControlBean = accessControlService.getAccessDetailByUserId(userId);
		long profileId = accessControlBean.getProfileId();
		model.addAttribute(USER_PROFILE_ID, profileId);
		model.addAttribute(LOGIN_NAME, name);
		model.addAttribute(FORM_HEADING, DASHBOARD);

		// if user is team member
		if (TM_PROFILE_ID_LIST.contains(profileId)) {
			List<DashboardBean> dashboardDataBeanList = tmDashboardService.getTMDashboardData(userId, accountId);
			DashboardBean dashboardForOpenIncidents = dashboardDataBeanList.get(0);
			dashboardDataBeanList.forEach(dashboardBeanVal -> {
				setDashboardNullsToDefaults(dashboardBeanVal);
			});

			// Leader board code starts
			List<DashboardBean> leaderBoardDataBeanList = tmDashboardService.getLeaderBoardData(accountName);
			List<DashboardBean> topAnalystDataBean = tmDashboardService.getTopAnalystData(accountName);
			List<DashboardBean> topContributorDataBean = tmDashboardService.getTopContributorData(accountName);
			List<DashboardBean> topReviewerDataBean = tmDashboardService.getTopReviewerData(accountName);

			DashboardBean dbeanAnalyst = (DashboardBean) firstElementOfList(topAnalystDataBean);
			DashboardBean dbeanContributor = (DashboardBean) firstElementOfList(topContributorDataBean);
			DashboardBean dbeanReviewer = (DashboardBean) firstElementOfList(topReviewerDataBean);

			model.addAttribute(TOP_ANALYS_DATATM, dbeanAnalyst);
			model.addAttribute(TOP_REVIEWER_DATATM, dbeanReviewer);
			model.addAttribute(TOP_CONTRIBUTOR_DATATM, dbeanContributor);
			model.addAttribute(LEADERBOARD_DATALIST, leaderBoardDataBeanList);
			// Leader board code ends

			model.addAttribute("dashboardDataBeanListForm", dashboardForOpenIncidents);
			model.addAttribute("dashboardDataBeanListVal", dashboardDataBeanList);
			return tmDashboardViewTypeReturn(viewType);

		}
		// if user is team lead
		else if (TL_PROFILE_ID_LIST.contains(profileId)) {
			String appName = request.getParameter("appName");
			String assignmentGroup = request.getParameter("assignmentGroup");
			String assigneeName = request.getParameter("assigneeName");
			String accountNames = request.getParameter("accountName");

			// dashboardBean is not used anywhere or added to model..
			if (!IKONUtils.isNullOrEmpty(appName)) {
				dashboardBean.setApplicationName(appName);
			}
			if (!IKONUtils.isNullOrEmpty(assignmentGroup)) {
				dashboardBean.setAssignmentGroup(assignmentGroup);
			}
			if (!IKONUtils.isNullOrEmpty(assigneeName)) {
				dashboardBean.setAssigneeName(userId);
			}
			if (!IKONUtils.isNullOrEmpty(accountNames)) {
				dashboardBean.setAccountName(accountNames);
			} else {
				dashboardBean.setAccountName(accountName);
			}
			getDashboardModelData(model, userId, accountId, accountName);
			return tlDashboardViewTypeReturn(viewType);
		}
		log.info(GET_DASHBOARD_SUMMARY);
		return null;
	}

	/**
	 * Gets the dashboard model data.
	 *
	 * @param model the model
	 * @param userId the user id
	 * @param accountId the account id
	 * @param accountName the account name
	 * @return the dashboard model data
	 */
	private void getDashboardModelData(Model model, String userId, String accountId, String accountName) {

		MasterDataAttributeVO masterDataAttributeVO = new MasterDataAttributeVO("", "", "", "", "", "", userId);
		List<DashboardBean> leadIncidentsDataBeanList = tmDashboardService.getAllTLInciedentsDashboardData(masterDataAttributeVO, "");
		List<DashboardBean> leadRTZDataBeanList = tmDashboardService.getAllTLRunToZeroData(masterDataAttributeVO, "");
		List<DashboardBean> leadKOStatus = tmDashboardService.getAllTLKoStatusData(masterDataAttributeVO, "");
		List<DashboardBean> koIncLinkCount = tmDashboardService.getKOIncLinkCountTL(masterDataAttributeVO, "");
		// For dropdown value populate starts here */
		Set<String> appNameLists = ticketDataService.getAllApplicationName(userId, accountId);
		Set<String> assignmentGrpLists = ticketDataService.getAllAssignmentGroup(userId, accountId);
		Set<String> assigneeNameList = tmDashboardService.getAllAssigneeName(assignmentGrpLists, appNameLists, userId);
		List<SettingBean> accountNamelist = helpService.accountAccess(userId);

		model.addAttribute("accountNamelist", accountNamelist);
		model.addAttribute("assignmentGrpLists", assignmentGrpLists);
		model.addAttribute("assigneeNameList", assigneeNameList);
		model.addAttribute("appNameLists", appNameLists);
		// For dropdown value populate ends here

		// Incidents By Status tab
		int incSum = leadIncidentsDataBeanList.stream().mapToInt(x -> x.getTicketIDCount().intValue()).sum();
		model.addAttribute("totalIncidentsVal", incSum);
		model.addAttribute("leadIncidentsDataByStatus", leadIncidentsDataBeanList);

		// Run to Zero tab starts
		// int sum = 0;
		int sum = leadRTZDataBeanList.stream().mapToInt(x -> x.getOpenedTicketIDCount().intValue()).sum();
		model.addAttribute("leadRTZTotalCount", sum);
		if (leadRTZDataBeanList.size() >= THREE) {
			model.addAttribute(LEAD_RTZ_COUNT, leadRTZDataBeanList.subList(0, 3));
		} else {
			model.addAttribute(LEAD_RTZ_COUNT, leadRTZDataBeanList);
		}
		// Run to Zero ends
		// Ko Status tab starts
		if (Objects.nonNull(koIncLinkCount) && koIncLinkCount.size() > 0) {
			model.addAttribute("koIncLinkCountVal", koIncLinkCount.get(0));
		}
		if (Objects.nonNull(leadKOStatus) && leadKOStatus.size() > 0) {
			model.addAttribute("leadKoListval", leadKOStatus);
		}
		// Ko Status tab ends

		// Leader board code starts
		List<DashboardBean> leaderBoardDataBeanList = tmDashboardService.getLeaderBoardData(accountName);
		List<DashboardBean> topAnalystDataBean = tmDashboardService.getTopAnalystData(accountName);
		List<DashboardBean> topContributorDataBean = tmDashboardService.getTopContributorData(accountName);
		List<DashboardBean> topReviewerDataBean = tmDashboardService.getTopReviewerData(accountName);
		model.addAttribute("topAnalystData", topAnalystDataBean);
		model.addAttribute("topReviewerData", topReviewerDataBean);
		model.addAttribute("topContributorData", topContributorDataBean);
		model.addAttribute(LEADERBOARD_DATALIST, leaderBoardDataBeanList);

	}

	/**
	 * Reports charts view.
	 *
	 * @param koInfoBean  the ko info bean
	 * @param settingBean the setting bean
	 * @param model       the model
	 * @param request     the request
	 * @return the string
	 */
	@GetMapping("/reportsChartsView")
	public String reportsChartsView(@ModelAttribute("koInfoBean") KOInfoBean koInfoBean, SettingBean settingBean,
			Model model, HttpServletRequest request) {
		log.info("Start: reportsChartsView");
		model.addAttribute(FORM_HEADING, "Reports and Charts");

		model.addAttribute(REPORT_CAT, request.getParameter(REPORT_CAT));
		model.addAttribute(COMPONENT_TYPE, request.getParameter(COMPONENT_TYPE));
		model.addAttribute(REPORT_TYPE, request.getParameter(REPORT_TYPE));
		model.addAttribute(REPORT_NAME, request.getParameter(REPORT_NAME));
		model.addAttribute(REPORT_FREQ, request.getParameter(REPORT_FREQ));
		model.addAttribute(FROM_DATE, request.getParameter(FROM_DATE));
		model.addAttribute(TO_DATE, request.getParameter(TO_DATE));

		String userId = fetchReportData(model);
		int isGeneric = getUserAccount();
		String accountId = getDefaultAccountId();

		List<ApplicationMaster> filtersDataList = applicationMasterService.getFiltersData(accountId, userId);
		Gson gson = new Gson();
		String filtersDataListJson = gson.toJson(filtersDataList);
		
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		model.addAttribute("reportsChartsView", new KOInfoBean());
		model.addAttribute("filtersDataListJson", filtersDataListJson);
		model.addAttribute("isGeneric", isGeneric);
		log.info("End: reportsChartsView");
		return TM_DASHBOARD_REPORT_CHART;
	}

	/**
	 * Fetch report data.
	 *
	 * @param model the model
	 * @return the string
	 */
	private String fetchReportData(Model model) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String userId = auth.getName();
		List<ReportBean> reportBeanList = new LinkedList<ReportBean>();
		List<ReportBean> reportBeanListCopy = null;
		reportBeanListCopy = reportService.getReportListView(getDefaultAccountId(), userId);
		reportBeanListCopy.forEach(reportBean -> {
			if (String.valueOf(reportBean.getComponentTypeID()).equalsIgnoreCase("1"))
				reportBeanList.add(reportBean);
		});

		Gson gson = new Gson();
		String reportBeanListJson = gson.toJson(reportBeanList);
		model.addAttribute("reportBeanList", reportBeanListJson);

		List<ReportBean> myFavoriteReportsList = new LinkedList<ReportBean>();
		List<ReportBean> recentlyUsedReportsList = new ArrayList<ReportBean>();
		List<ReportBean> mostFrequentlyUsedReportsList = new ArrayList<ReportBean>();
		List<ReportBean> recommendedReportsList = new ArrayList<ReportBean>();
		List<ReportBean> newlyAddedReportsList = new ArrayList<ReportBean>();
		List<ReportBean> allReportsList = new LinkedList<ReportBean>();
		List<ReportBean> leaderBoardsReportsList = new LinkedList<ReportBean>();
		List<ReportBean> othersReportsList = new LinkedList<ReportBean>();

		reportBeanList.forEach(reportBean -> {
			setReportBeanListDetails(reportBean, myFavoriteReportsList, leaderBoardsReportsList, othersReportsList,
					recentlyUsedReportsList, mostFrequentlyUsedReportsList);
		});
		recentlyUsedReportsList.sort(Comparator.comparing(ReportBean::getLastUsedReportDate).reversed());
		Collections.sort(mostFrequentlyUsedReportsList, new Comparator<ReportBean>() {
			@Override
			public int compare(ReportBean lhs, ReportBean rhs) {
				int n1 = Integer.parseInt(lhs.getUsageCount());
				int n2 = Integer.parseInt(rhs.getUsageCount());
				if (n1 >= n2) {
					return 1;
				}
				return -1;
			}
		}.reversed());

		reportBeanList.sort(Comparator.comparing(ReportBean::getCreatedDate).reversed());
		newlyAddedReportsList = reportBeanList;

		// Recommended report list logic starts here
		boolean isReportExists = false;
		reportBeanList.forEach(reportBean -> {
			reportBeanListLogic(isReportExists, reportBean, myFavoriteReportsList, recentlyUsedReportsList,
					mostFrequentlyUsedReportsList, recommendedReportsList);
		});

		// Recommended report list logic ends here
		allReportsList = reportBeanList;
		model.addAttribute("favReportsList", gson.toJson(myFavoriteReportsList));
		model.addAttribute("recentlyUsedReportsList", gson.toJson(recentlyUsedReportsList));
		model.addAttribute("freqUsedReportsList", gson.toJson(mostFrequentlyUsedReportsList));
		model.addAttribute("recommendedReportsList", gson.toJson(recommendedReportsList));
		model.addAttribute("newlyAddedReportsList", gson.toJson(newlyAddedReportsList));
		model.addAttribute("allReportsList", gson.toJson(allReportsList));

		/**************************************
		 * charts code starts here
		 ***************************************************/

		List<ReportBean> chartBeanList = new LinkedList<ReportBean>();
		reportBeanListCopy.forEach(chartBean -> {
			if (String.valueOf(chartBean.getComponentTypeID()).equalsIgnoreCase("2"))
				chartBeanList.add(chartBean);
		});

		String chartBeanListJson = gson.toJson(chartBeanList);
		model.addAttribute("chartBeanList", chartBeanListJson);

		List<ReportBean> myFavoriteChartsList = new LinkedList<ReportBean>();
		List<ReportBean> recentlyUsedChartsList = new LinkedList<ReportBean>();
		List<ReportBean> mostFrequentlyUsedChartsList = new LinkedList<ReportBean>();
		List<ReportBean> recommendedChartsList = new LinkedList<ReportBean>();

		setChartBeanListDetails(chartBeanList, myFavoriteChartsList, recentlyUsedChartsList,
				mostFrequentlyUsedChartsList);
		recentlyUsedChartsList.sort(Comparator.comparing(ReportBean::getLastUsedReportDate).reversed());
		Collections.sort(mostFrequentlyUsedChartsList, new Comparator<ReportBean>() {
			@Override
			public int compare(ReportBean lhs, ReportBean rhs) {
				int n1 = Integer.parseInt(lhs.getUsageCount());
				int n2 = Integer.parseInt(rhs.getUsageCount());
				if (n1 >= n2) {
					return 1;
				}
				return -1;
			}
		}.reversed());

		chartBeanList.sort(Comparator.comparing(ReportBean::getCreatedDate).reversed());
		List<ReportBean> newlyAddedChartsList = new LinkedList<ReportBean>(chartBeanList);

		// Recommended chart list logic starts here
		boolean isChartExists = false;
		chartBeanList.forEach(chartBean -> {
			reportBeanListLogic(isChartExists, chartBean, myFavoriteChartsList, recentlyUsedChartsList,
					mostFrequentlyUsedChartsList, recommendedChartsList);

		});
		// Recommended chart list logic ends here

		List<ReportBean> allChartsList = new LinkedList<ReportBean>(chartBeanList);
		model.addAttribute("favChartsList", gson.toJson(myFavoriteChartsList));
		model.addAttribute("recentlyUsedChartsList", gson.toJson(recentlyUsedChartsList));
		model.addAttribute("freqUsedChartsList", gson.toJson(mostFrequentlyUsedChartsList));
		model.addAttribute("recommendedChartsList", gson.toJson(recommendedChartsList));
		model.addAttribute("newlyAddedChartsList", gson.toJson(newlyAddedChartsList));
		model.addAttribute("allChartsList", gson.toJson(allChartsList));
		// charts code end here

		// Get user profile detail starts here
		AccessControl accessControlBean = accessControlService.getAccessDetailByUserId(userId);
		long profileId = accessControlBean.getProfileId();
		model.addAttribute(USER_PROFILE_ID, profileId);
		// Get user profile detail ends here

		return userId;
	}

	/**
	 * Select favorite report.
	 *
	 * @param reportId         the report id
	 * @param isFavoriteReport the is favorite report
	 * @return the response entity
	 */
	@RequestMapping(value = "/selectFavoriteReport", headers = "Accept=*/*", method = RequestMethod.GET)
	public @ResponseBody ResponseEntity<String> selectFavoriteReport(@RequestParam(value = "reportId") String reportId,
			@RequestParam("isFavoriteReport") String isFavoriteReport) {
		log.info("Start: selectFavoriteReport");
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String userId = auth.getName();
		String accountId = getDefaultAccountId();
		ReportDataAttributeVO reportDataAttributeVO = new ReportDataAttributeVO(accountId, userId, reportId,
				!IKONUtils.isNullOrEmpty(isFavoriteReport) && isFavoriteReport.equalsIgnoreCase("Y") ? "N" : "Y");
		String result = reportService.updateFavoriteReport(reportDataAttributeVO);
		List<ReportBean> reportBeanList = new LinkedList<ReportBean>();
		List<ReportBean> reportBeanListCopy = reportService.getReportListView(getDefaultAccountId(), userId);
		reportBeanListCopy.forEach(reportBean -> {
			if (String.valueOf(reportBean.getComponentTypeID()).equalsIgnoreCase("1"))
				reportBeanList.add(reportBean);
		});

		Gson gson = new Gson();
		List<ReportBean> myFavoriteReportsList = new LinkedList<ReportBean>();
		List<ReportBean> recentlyUsedReportsList = new ArrayList<ReportBean>();
		List<ReportBean> mostFrequentlyUsedReportsList = new ArrayList<ReportBean>();
		List<ReportBean> recommendedReportsList = new ArrayList<ReportBean>();
		List<ReportBean> newlyAddedReportsList = new ArrayList<ReportBean>();
		List<ReportBean> allReportsList = new LinkedList<ReportBean>(reportBeanList);
		List<ReportBean> leaderBoardsReportsList = new LinkedList<ReportBean>();
		List<ReportBean> othersReportsList = new LinkedList<ReportBean>();
		reportBeanList.forEach(reportBean -> {
			setReportBeanListDetails(reportBean, myFavoriteReportsList, leaderBoardsReportsList, othersReportsList,
					recentlyUsedReportsList, mostFrequentlyUsedReportsList);
		});

		recentlyUsedReportsList.sort(Comparator.comparing(ReportBean::getLastUsedReportDate).reversed());
		Collections.sort(mostFrequentlyUsedReportsList, new Comparator<ReportBean>() {
			@Override
			public int compare(ReportBean lhs, ReportBean rhs) {
				int n1 = Integer.parseInt(lhs.getUsageCount());
				int n2 = Integer.parseInt(rhs.getUsageCount());
				if (n1 >= n2) {
					return 1;
				}
				return -1;
			}
		}.reversed());
		reportBeanList.sort(Comparator.comparing(ReportBean::getCreatedDate).reversed());
		newlyAddedReportsList = reportBeanList;
		// Recommended report list logic starts here
		boolean isReportExists = false;
		reportBeanList.forEach(reportBean -> {

			reportBeanListLogic(isReportExists, reportBean, myFavoriteReportsList, recentlyUsedReportsList,
					mostFrequentlyUsedReportsList, recommendedReportsList);
		});
		// Recommended report list logic ends here

		HashMap<String, String> convertThis = new HashMap<>();
		convertThis.put("reportBeanList", gson.toJson(reportBeanList));
		convertThis.put("allReportsList", gson.toJson(allReportsList));
		convertThis.put("recentlyUsedReportsList", gson.toJson(recentlyUsedReportsList));
		convertThis.put("freqUsedReportsList", gson.toJson(mostFrequentlyUsedReportsList));
		convertThis.put("recommendedReportsList", gson.toJson(recommendedReportsList));
		convertThis.put("newlyAddedReportsList", gson.toJson(newlyAddedReportsList));
		convertThis.put("favReportsList", gson.toJson(myFavoriteReportsList));

		/**************************************
		 * charts code starts here
		 ***************************************************/
		List<ReportBean> chartBeanList = new LinkedList<ReportBean>();

		reportBeanListCopy.forEach(chartBean -> {
			if (String.valueOf(chartBean.getComponentTypeID()).equalsIgnoreCase("2"))
				chartBeanList.add(chartBean);
		});

		List<ReportBean> myFavoriteChartsList = new LinkedList<ReportBean>();
		List<ReportBean> recentlyUsedChartsList = new LinkedList<ReportBean>();
		List<ReportBean> mostFrequentlyUsedChartsList = new LinkedList<ReportBean>();
		List<ReportBean> recommendedChartsList = new LinkedList<ReportBean>();
		List<ReportBean> newlyAddedChartsList = new LinkedList<ReportBean>();
		List<ReportBean> allChartsList = new LinkedList<ReportBean>(chartBeanList);
		setChartBeanListDetails(chartBeanList, myFavoriteChartsList, recentlyUsedChartsList,
				mostFrequentlyUsedChartsList);

		recentlyUsedChartsList.sort(Comparator.comparing(ReportBean::getLastUsedReportDate).reversed());
		Collections.sort(mostFrequentlyUsedChartsList, new Comparator<ReportBean>() {
			@Override
			public int compare(ReportBean lhs, ReportBean rhs) {
				int n1 = Integer.parseInt(lhs.getUsageCount());
				int n2 = Integer.parseInt(rhs.getUsageCount());
				if (n1 >= n2) {
					return 1;
				}
				return -1;
			}
		}.reversed());

		chartBeanList.sort(Comparator.comparing(ReportBean::getCreatedDate).reversed());
		newlyAddedChartsList = chartBeanList;
		// Recommended chart list logic starts here

		boolean isChartExists = false;
		chartBeanList.forEach(chartBean -> {
			reportBeanListLogic(isChartExists, chartBean, myFavoriteChartsList, recentlyUsedChartsList,
					mostFrequentlyUsedChartsList, recommendedChartsList);
		});

		// Recommended chart list logic ends here
		gson = new Gson();
		convertThis.put("chartBeanList", gson.toJson(chartBeanList));
		convertThis.put("allChartsList", gson.toJson(allChartsList));
		convertThis.put("recentlyUsedChartsList", gson.toJson(recentlyUsedChartsList));
		convertThis.put("freqUsedChartsList", gson.toJson(mostFrequentlyUsedChartsList));
		convertThis.put("recommendedChartsList", gson.toJson(recommendedChartsList));
		convertThis.put("newlyAddedChartsList", gson.toJson(newlyAddedChartsList));
		convertThis.put("favChartsList", gson.toJson(myFavoriteChartsList));
		result = gson.toJson(convertThis);

		log.info("End: selectFavoriteReport");
		return ResponseEntity.ok(gson.toJson(result));
	}

	/**
	 * Sets the chart bean list details.
	 *
	 * @param chartBeanList the chart bean list
	 * @param myFavoriteChartsList the my favorite charts list
	 * @param recentlyUsedChartsList the recently used charts list
	 * @param mostFrequentlyUsedChartsList the most frequently used charts list
	 */
	private void setChartBeanListDetails(List<ReportBean> chartBeanList, List<ReportBean> myFavoriteChartsList,
			List<ReportBean> recentlyUsedChartsList, List<ReportBean> mostFrequentlyUsedChartsList) {

		for (ReportBean chartBean : chartBeanList) {
			if (IKONUtils.isNullOrEmpty(chartBean.getFavourite())) {
				chartBean.setFavourite("N");
			}
			if (!IKONUtils.isNullOrEmpty(chartBean.getFavourite())
					&& chartBean.getFavourite().equalsIgnoreCase("Y")) {
				myFavoriteChartsList.add(chartBean);
			}
			if (Objects.nonNull(chartBean.getLastUsedReportDate())) {
				recentlyUsedChartsList.add(chartBean);
			}
			if (!IKONUtils.isNullOrEmpty(chartBean.getUsageCount())
					&& Integer.parseInt(chartBean.getUsageCount()) > 0) {
				mostFrequentlyUsedChartsList.add(chartBean);
			}
		}

	}

	/**
	 * Sets the report bean list details.
	 *
	 * @param reportBean the report bean
	 * @param myFavoriteReportsList the my favorite reports list
	 * @param leaderBoardsReportsList the leader boards reports list
	 * @param othersReportsList the others reports list
	 * @param recentlyUsedReportsList the recently used reports list
	 * @param mostFrequentlyUsedReportsList the most frequently used reports list
	 */
	private void setReportBeanListDetails(ReportBean reportBean, List<ReportBean> myFavoriteReportsList,
			List<ReportBean> leaderBoardsReportsList, List<ReportBean> othersReportsList,
			List<ReportBean> recentlyUsedReportsList, List<ReportBean> mostFrequentlyUsedReportsList) {

		if (IKONUtils.isNullOrEmpty(reportBean.getFavourite())) {
			reportBean.setFavourite("N");
		} else if (reportBean.getFavourite().equalsIgnoreCase("Y")) {
			myFavoriteReportsList.add(reportBean);
		}
		if (!IKONUtils.isNullOrEmpty(reportBean.getReportChartType())) {
			if (reportBean.getReportChartType().equalsIgnoreCase("Leaderboard")) {
				leaderBoardsReportsList.add(reportBean);
			} else if (reportBean.getReportChartType().equalsIgnoreCase("Others")) {
				othersReportsList.add(reportBean);
			}
		}
		if (Objects.nonNull(reportBean.getLastUsedReportDate())) {
			recentlyUsedReportsList.add(reportBean);
		}
		if (!IKONUtils.isNullOrEmpty(reportBean.getUsageCount())
				&& Integer.parseInt(reportBean.getUsageCount()) > 0) {
			mostFrequentlyUsedReportsList.add(reportBean);
		}
	}

	/**
	 * Report bean list logic.
	 *
	 * @param isReportExists the is report exists
	 * @param reportBean the report bean
	 * @param myFavoriteList the my favorite list
	 * @param recentlyUsedList the recently used list
	 * @param mostFrequentlyUsedList the most frequently used list
	 * @param recommendedList the recommended list
	 */
	private void reportBeanListLogic(boolean isReportExists, ReportBean reportBean, List<ReportBean> myFavoriteList,
			List<ReportBean> recentlyUsedList, List<ReportBean> mostFrequentlyUsedList,
			List<ReportBean> recommendedList) {

		if (!IKONUtils.isNullOrEmpty(reportBean.getRecommendedPriority())) {
			for (ReportBean repBean : myFavoriteList) {
				if (!IKONUtils.isNullOrEmpty(repBean.getFavourite()) && !isReportExists
						&& Objects.equals(repBean.getReportChartID(), reportBean.getReportChartID())) {
					isReportExists = true;
				}
			}
			for (ReportBean repBean : recentlyUsedList) {
				if (!isReportExists && Objects.equals(repBean.getReportChartID(), reportBean.getReportChartID())) {
					isReportExists = true;
				}
			}
			for (ReportBean repBean : mostFrequentlyUsedList) {
				if (!isReportExists && Objects.equals(repBean.getReportChartID(), reportBean.getReportChartID())) {
					isReportExists = true;
				}
			}
			if (!isReportExists) {
				recommendedList.add(reportBean);
				isReportExists = false;
			}
		}

	}

	/**
	 * Gets the default account id.
	 *
	 * @return the default account id
	 */
	private String getDefaultAccountId() {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String userId = auth.getName();

		String accountId = String.valueOf(accessControlService.getAccessDetailByUserId(userId).getAccountId());
		return accountId;
	}

	/**
	 * Gets the defalut account name.
	 *
	 * @param accountId the account id
	 * @return the defalut account name
	 */
	private String getDefalutAccountName(String accountId) {
		String accountName = String.valueOf(accountInfoService.getAccountNameByAccountId(accountId).getAccountName());
		return accountName;
	}

	/**
	 * Dashboard summary.
	 *
	 * @param reqDashboardBean the req dashboard bean
	 * @param settingBean   the setting bean
	 * @param model         the model
	 * @param request       the request
	 * @return the string
	 */
	@PostMapping("/teamMemberDashboard")
	public String dashboardSummary(@ModelAttribute(DASHBOARD_SUMMARY_DETAIL) DashboardBean reqDashboardBean,
			SettingBean settingBean, Model model, HttpServletRequest request) {
		DashboardBean dashboardBean = reqDashboardBean;
		log.info("Start: dashboardSummary");
		String accountId = getDefaultAccountId();
		String accountName = getDefalutAccountName(accountId);
		String viewType = request.getParameter(VIEW_TYPE);
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String userId = auth.getName();
		String accountNameList = dashboardBean.getAccountName();
		String assignmentGroupList = dashboardBean.getAssignmentGroup();
		String applicationName = dashboardBean.getApplicationName();
		String assigneeNameLists = dashboardBean.getAssigneeName();
		UserBean ubean = userService.getUserAccountType(accountId);
		int isGeneric = ubean.getIsGeneric();
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		model.addAttribute(IS_GENERIC, isGeneric);
		UserMaster usermaster = userService.getdetailsByuserid(userId);
		String name = usermaster.getName();

		AccessControl accessControlBean = accessControlService.getAccessDetailByUserId(userId);
		long profileId = accessControlBean.getProfileId();
		model.addAttribute(USER_PROFILE_ID, profileId);
		// if user is team member
		if (TM_PROFILE_ID_LIST.contains(profileId)) {
			DashboardBean dashboardBeanVal = null;
			List<DashboardBean> dashboardDataBeanList = tmDashboardService.getTMDashboardData(userId, accountId);
			if (Objects.nonNull(dashboardDataBeanList) && dashboardDataBeanList.size() > 0) {
				dashboardBeanVal = dashboardDataBeanList.get(0);
			}
			model.addAttribute("dashboardDataBeanListForm", dashboardBeanVal);
			model.addAttribute("dashboardDataBeanListVal", dashboardDataBeanList);
			tmDashboardDetailsList(model, accountNameList, name);

			return tmDashboardViewTypeReturn(viewType);

		}
		// if user is team lead
		else if (TL_PROFILE_ID_LIST.contains(profileId)) {

			String appName = request.getParameter("appName");
			String assignmentGroup = request.getParameter("assignmentGroup");
			String assigneeName = request.getParameter("assigneeName");
			String accountNames = request.getParameter("accountName");
			dashboardBean.setApplicationName(getNotNullString(dashboardBean.getAssigneeName(), appName));
			dashboardBean.setAssignmentGroup(getNotNullString(dashboardBean.getAssignmentGroup(), assignmentGroup));
			dashboardBean.setAssignmentGroup(getNotNullString(dashboardBean.getAssigneeName(), assigneeName));
			if (!IKONUtils.isNullOrEmpty(accountNames)) {
				dashboardBean.setAccountName(accountNames);
			} else {
				dashboardBean.setAccountName(accountName);
			}
			MasterDataAttributeVO masterDataAttributeVO = new MasterDataAttributeVO("", applicationName, assignmentGroupList, "", "", "", userId);
			masterDataAttributeVO.setAccountName(accountNameList);
			List<DashboardBean> leadIncidentsDataBeanList = tmDashboardService.getAllTLInciedentsDashboardData(masterDataAttributeVO, assigneeNameLists);
			List<DashboardBean> leadRTZDataBeanList = tmDashboardService.getAllTLRunToZeroData(masterDataAttributeVO, assigneeNameLists);
			List<DashboardBean> leadKOStatus = tmDashboardService.getAllTLKoStatusData(masterDataAttributeVO, assigneeNameLists);
			List<DashboardBean> koIncLinkCount = tmDashboardService.getKOIncLinkCountTL(masterDataAttributeVO, assigneeNameLists);

			setTlDashboardLists(model, leadIncidentsDataBeanList, leadRTZDataBeanList, userId, accountId,
					accountNameList);
			// Leader board code ends

			// Ko Status tab starts
			if (Objects.nonNull(koIncLinkCount) && koIncLinkCount.size() > 0) {
				dashboardBean = koIncLinkCount.get(0);
				model.addAttribute("koIncLinkCountVal", dashboardBean);
			} else if (Objects.isNull(dashboardBean.getKoLinked())) {
				dashboardBean.setKoLinked(BigInteger.valueOf(0));
			}
			if (Objects.nonNull(leadKOStatus) && leadKOStatus.size() > 0) {
				model.addAttribute("leadKoListval", leadKOStatus);
			}
			// Ko Status tab ends
			model.addAttribute("LoginName", name);
			return tlDashboardViewTypeReturn(viewType);
		}
		model.addAttribute(FORM_HEADING, DASHBOARD);
		log.info("End: dashboardSummary");
		return null;
	}

	/**
	 * Gets the not null string.
	 *
	 * @param actualString the actual string
	 * @param newString the new string
	 * @return the not null string
	 */
	private String getNotNullString(String actualString, String newString) {

		return !IKONUtils.isNullOrEmpty(newString) ? newString : (Objects.nonNull(actualString) ? actualString : null);
	}

	/**
	 * Sets the tl dashboard lists.
	 *
	 * @param model the model
	 * @param leadIncidentsDataBeanList the lead incidents data bean list
	 * @param leadRTZDataBeanList the lead RTZ data bean list
	 * @param userId the user id
	 * @param accountId the account id
	 * @param accountNameList the account name list
	 */
	private void setTlDashboardLists(Model model, List<DashboardBean> leadIncidentsDataBeanList,
			List<DashboardBean> leadRTZDataBeanList, String userId, String accountId, String accountNameList) {

		// For dropdown value populate starts here
		Set<String> appNameLists = ticketDataService.getAllApplicationName(userId, accountId);
		Set<String> assignmentGrpLists = ticketDataService.getAllAssignmentGroup(userId, accountId);
		Set<String> assigneeNameList = tmDashboardService.getAllAssigneeName(assignmentGrpLists, appNameLists, userId);
		List<SettingBean> accountNamelist = helpService.accountAccess(userId);

		model.addAttribute("accountNamelist", accountNamelist);
		model.addAttribute("assignmentGrpLists", assignmentGrpLists);
		model.addAttribute("assigneeNameList", assigneeNameList);
		model.addAttribute("appNameLists", appNameLists);
		// For dropdown value populate ends here

		// Incidents By Status tab
		int incSum = 0;
		for (DashboardBean dbean : leadIncidentsDataBeanList) {

			incSum += dbean.getTicketIDCount().intValue();
			model.addAttribute("totalIncidentsVal", incSum);
		}
		model.addAttribute("leadIncidentsDataByStatus", leadIncidentsDataBeanList);

		// Run to Zero tab starts
		int sum = 0;
		for (DashboardBean dbean : leadRTZDataBeanList) {
			sum += dbean.getOpenedTicketIDCount().intValue();
			model.addAttribute("leadRTZTotalCount", sum);
		}
		if (leadRTZDataBeanList.size() >= THREE) {
			model.addAttribute(LEAD_RTZ_COUNT, leadRTZDataBeanList.subList(0, 3));
		} else {
			model.addAttribute(LEAD_RTZ_COUNT, leadRTZDataBeanList);
		}
		// Run to Zero ends

		// check if both Assignment name and assignment group not null,if not null set other as default
		List<DashboardBean> leaderBoardDataBeanList = tmDashboardService.getLeaderBoardData(accountNameList);
		List<DashboardBean> topAnalystDataBean = tmDashboardService.getTopAnalystData(accountNameList);
		List<DashboardBean> topContributorDataBean = tmDashboardService.getTopContributorData(accountNameList);
		List<DashboardBean> topReviewerDataBean = tmDashboardService.getTopReviewerData(accountNameList);
		model.addAttribute("topAnalystData", topAnalystDataBean);
		model.addAttribute("topReviewerData", topReviewerDataBean);
		model.addAttribute("topContributorData", topContributorDataBean);
		model.addAttribute(LEADERBOARD_DATALIST, leaderBoardDataBeanList);
		model.addAttribute(FORM_HEADING, DASHBOARD);

	}

	/**
	 * Tm dashboard details list.
	 *
	 * @param model the model
	 * @param accountNameList the account name list
	 * @param name the name
	 */
	private void tmDashboardDetailsList(Model model, String accountNameList, String name) {

		DashboardBean dbeanAnalyst = null;
		DashboardBean dbeanReviewer = null;
		DashboardBean dbeanContributor = null;
		// Leader board code starts
		List<DashboardBean> leaderBoardDataBeanList = tmDashboardService.getLeaderBoardData(accountNameList);
		List<DashboardBean> topAnalystDataBean = tmDashboardService.getTopAnalystData(accountNameList);
		List<DashboardBean> topContributorDataBean = tmDashboardService.getTopContributorData(accountNameList);
		List<DashboardBean> topReviewerDataBean = tmDashboardService.getTopReviewerData(accountNameList);

		if (Objects.nonNull(topAnalystDataBean) && topAnalystDataBean.size() > 0) {
			dbeanAnalyst = topAnalystDataBean.get(0);
		}
		if (Objects.nonNull(topContributorDataBean) && topContributorDataBean.size() > 0) {
			dbeanContributor = topContributorDataBean.get(0);
		}
		if (Objects.nonNull(topReviewerDataBean) && topReviewerDataBean.size() > 0) {
			dbeanReviewer = topReviewerDataBean.get(0);
		}
		model.addAttribute(LEADERBOARD_DATALIST, leaderBoardDataBeanList);
		model.addAttribute(TOP_ANALYS_DATATM, dbeanAnalyst);
		model.addAttribute(TOP_REVIEWER_DATATM, dbeanReviewer);
		model.addAttribute(TOP_CONTRIBUTOR_DATATM, dbeanContributor);
		model.addAttribute(LOGIN_NAME, name);
		// Leader board code ends
		model.addAttribute(FORM_HEADING, DASHBOARD);

	}

	/**
	 * Leaderboard list report.
	 *
	 * @param koInfo  the ko info
	 * @param model   the model
	 * @param request the request
	 * @return the string
	 */
	@GetMapping("/leaderboardListReport")
	public String leaderboardListReport(@ModelAttribute(KO_USGRPT_FROMDETAIL) KOInfoBean koInfo, Model model,
			HttpServletRequest request) {

		model.addAttribute(REPORT_CAT, request.getParameter(REPORT_CAT));
		model.addAttribute(COMPONENT_TYPE, request.getParameter(COMPONENT_TYPE));
		model.addAttribute(REPORT_TYPE, request.getParameter(REPORT_TYPE));
		model.addAttribute(REPORT_NAME, request.getParameter(REPORT_NAME));
		model.addAttribute(REPORT_FREQ, request.getParameter(REPORT_FREQ));
		model.addAttribute(FROM_DATE, request.getParameter(FROM_DATE));
		model.addAttribute(TO_DATE, request.getParameter(TO_DATE));
		model.addAttribute(FORM_HEADING, "Leaderboard List Report");

		String accountId = getDefaultAccountId();
		String accountName = getDefalutAccountName(accountId);
		UserBean ubean = userService.getUserAccountType(accountId);
		int isGeneric = ubean.getIsGeneric();
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		model.addAttribute(IS_GENERIC, isGeneric);
		List<DashboardBean> leaderBoardDataBeanList = tmDashboardService.getLeaderBoardData(accountName);

		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String userId = auth.getName();
		ReportDataAttributeVO reportDataAttributeVO = new ReportDataAttributeVO(accountId, userId, LEADERBOARD_REPORT_ID,VIEW_ACTION_ID);
		reportService.insertReportUsage(reportDataAttributeVO);

		model.addAttribute(LEADERBOARD_DATALIST, leaderBoardDataBeanList);
		return "tm-leaderboard-table";
	}

	/**
	 * Leaderboard top analyst report.
	 *
	 * @param koInfo  the ko info
	 * @param model   the model
	 * @param request the request
	 * @return the string
	 */
	@GetMapping("/leaderboardTopAnalystReport")
	public String leaderboardTopAnalystReport(@ModelAttribute(KO_USGRPT_FROMDETAIL) KOInfoBean koInfo, Model model,
			HttpServletRequest request) {

		model.addAttribute(REPORT_CAT, request.getParameter(REPORT_CAT));
		model.addAttribute(COMPONENT_TYPE, request.getParameter(COMPONENT_TYPE));
		model.addAttribute(REPORT_TYPE, request.getParameter(REPORT_TYPE));
		model.addAttribute(REPORT_NAME, request.getParameter(REPORT_NAME));
		model.addAttribute(REPORT_FREQ, request.getParameter(REPORT_FREQ));
		model.addAttribute(FROM_DATE, request.getParameter(FROM_DATE));
		model.addAttribute(TO_DATE, request.getParameter(TO_DATE));
		model.addAttribute(FORM_HEADING, "Leaderboard Top Analyst Report");

		String accountId = getDefaultAccountId();
		String accountName = getDefalutAccountName(accountId);
		String roleType = request.getParameter("roleType");
		if (!IKONUtils.isNullOrEmpty(roleType) && roleType.equalsIgnoreCase("TM")) {
			roleType = "TM";
		} else {
			roleType = "TL";
		}
		// role based condition commented
		List<DashboardBean> topAnalystDataBean = tmDashboardService.getTopAnalystData(accountName);
		if (Objects.nonNull(topAnalystDataBean) && topAnalystDataBean.size() > 0 && !IKONUtils.isNullOrEmpty(roleType)) {
			model.addAttribute(TOP_ANALYS_DATATM, topAnalystDataBean);
		}
		UserBean ubean = userService.getUserAccountType(accountId);
		int isGeneric = ubean.getIsGeneric();
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		model.addAttribute(IS_GENERIC, isGeneric);
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String userId = auth.getName();
		ReportDataAttributeVO reportDataAttributeVO = new ReportDataAttributeVO(accountId, userId, LEADERBOARD_TOP_ANALYST_REPORT_ID,VIEW_ACTION_ID);
		reportService.insertReportUsage(reportDataAttributeVO);

		return "tl-leaderboard-topanalyst-table";
	}

	/**
	 * Leaderboard top contributor report.
	 *
	 * @param koInfo  the ko info
	 * @param model   the model
	 * @param request the request
	 * @return the string
	 */
	@GetMapping("/leaderboardTopContributorReport")
	public String leaderboardTopContributorReport(@ModelAttribute(KO_USGRPT_FROMDETAIL) KOInfoBean koInfo, Model model,
			HttpServletRequest request) {

		model.addAttribute(REPORT_CAT, request.getParameter(REPORT_CAT));
		model.addAttribute(COMPONENT_TYPE, request.getParameter(COMPONENT_TYPE));
		model.addAttribute(REPORT_TYPE, request.getParameter(REPORT_TYPE));
		model.addAttribute(REPORT_NAME, request.getParameter(REPORT_NAME));
		model.addAttribute(REPORT_FREQ, request.getParameter(REPORT_FREQ));
		model.addAttribute(FROM_DATE, request.getParameter(FROM_DATE));
		model.addAttribute(TO_DATE, request.getParameter(TO_DATE));
		model.addAttribute(FORM_HEADING, "Leaderboard Top Contributer Report");

		String accountId = getDefaultAccountId();
		String accountName = getDefalutAccountName(accountId);
		String roleType = request.getParameter("roleType");
		if (!IKONUtils.isNullOrEmpty(roleType) && roleType.equalsIgnoreCase("TM")) {
			roleType = "TM";

		} else {
			roleType = "TL";
		}

		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String userId = auth.getName();
		ReportDataAttributeVO reportDataAttributeVO = new ReportDataAttributeVO(accountId, userId, LEADERBOARD_TOP_CONTRIBUTOR_REPORT_ID,VIEW_ACTION_ID);
		reportService.insertReportUsage(reportDataAttributeVO);
		UserBean ubean = userService.getUserAccountType(accountId);
		int isGeneric = ubean.getIsGeneric();
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		model.addAttribute(IS_GENERIC, isGeneric);
		List<DashboardBean> topContributorDataBean = tmDashboardService.getTopContributorData(accountName);
		// role based condition commented
		if (Objects.nonNull(topContributorDataBean) && topContributorDataBean.size() > 0
				&& !IKONUtils.isNullOrEmpty(roleType)) {
			model.addAttribute(TOP_CONTRIBUTOR_DATATM, topContributorDataBean);
		}

		return "tl-leaderboard-topcontributor-table";
	}

	/**
	 * Leaderboard top reviewer report.
	 *
	 * @param koInfo  the ko info
	 * @param model   the model
	 * @param request the request
	 * @return the string
	 */
	@GetMapping("/leaderboardTopReviewerReport")
	public String leaderboardTopReviewerReport(@ModelAttribute(KO_USGRPT_FROMDETAIL) KOInfoBean koInfo, Model model,
			HttpServletRequest request) {

		model.addAttribute(REPORT_CAT, request.getParameter(REPORT_CAT));
		model.addAttribute(COMPONENT_TYPE, request.getParameter(COMPONENT_TYPE));
		model.addAttribute(REPORT_TYPE, request.getParameter(REPORT_TYPE));
		model.addAttribute(REPORT_NAME, request.getParameter(REPORT_NAME));
		model.addAttribute(REPORT_FREQ, request.getParameter(REPORT_FREQ));
		model.addAttribute(FROM_DATE, request.getParameter(FROM_DATE));
		model.addAttribute(TO_DATE, request.getParameter(TO_DATE));
		model.addAttribute(FORM_HEADING, "Leaderboard Top Reviewer Report");

		String accountId = getDefaultAccountId();
		String accountName = getDefalutAccountName(accountId);
		String roleType = request.getParameter("roleType");
		if (!IKONUtils.isNullOrEmpty(roleType) && roleType.equalsIgnoreCase("TM")) {
			roleType = "TM";
		} else {
			roleType = "TL";
		}

		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String userId = auth.getName();
		ReportDataAttributeVO reportDataAttributeVO = new ReportDataAttributeVO(accountId, userId, LEADERBOARD_TOP_REVIEWER_REPORT_ID,VIEW_ACTION_ID);
		reportService.insertReportUsage(reportDataAttributeVO);
		// role based condition commented
		List<DashboardBean> topReviewerDataBean = tmDashboardService.getTopReviewerData(accountName);
		if (Objects.nonNull(topReviewerDataBean) && topReviewerDataBean.size() > 0 && !IKONUtils.isNullOrEmpty(roleType)) {
			model.addAttribute(TOP_REVIEWER_DATATM, topReviewerDataBean);
		}
		UserBean ubean = userService.getUserAccountType(accountId);
		int isGeneric = ubean.getIsGeneric();
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		model.addAttribute(IS_GENERIC, isGeneric);
		return "tl-leaderboard-topreviewer-table";
	}

	/**
	 * Mttr report.
	 *
	 * @param dashboardBean the dashboard bean
	 * @param model         the model
	 * @param request       the request
	 * @return the string
	 */
	@GetMapping("/mttrReport")
	public String mttrReport(@ModelAttribute("mttrReportDetail") DashboardBean dashboardBean, Model model,
			HttpServletRequest request) {
		log.info("Starts: MttrReport");
		String accountId = getDefaultAccountId();
		List<DashboardBean> avgMTTRPerMonth = tmDashboardService.getMttrAvgHoursPerMon(dashboardBean.getFromDate(),
				dashboardBean.getToDate());
		if (Objects.nonNull(avgMTTRPerMonth) && avgMTTRPerMonth.size() > 0) {
			model.addAttribute("avgMTTRHoursPerMonth", avgMTTRPerMonth.get(0));
		}
		UserBean ubean = userService.getUserAccountType(accountId);
		int isGeneric = ubean.getIsGeneric();
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		model.addAttribute(IS_GENERIC, isGeneric);
		List<DashboardBean> mttrInDetails = null;
		mttrInDetails = tmDashboardService.getMttrReport(dashboardBean.getFromDate(), dashboardBean.getToDate());

		model.addAttribute(REPORT_CAT, request.getParameter(REPORT_CAT));
		model.addAttribute(COMPONENT_TYPE, request.getParameter(COMPONENT_TYPE));
		model.addAttribute(REPORT_TYPE, request.getParameter(REPORT_TYPE));
		model.addAttribute(REPORT_NAME, request.getParameter(REPORT_NAME));
		model.addAttribute(REPORT_FREQ, request.getParameter(REPORT_FREQ));
		model.addAttribute(FROM_DATE, request.getParameter(FROM_DATE));
		model.addAttribute(TO_DATE, request.getParameter(TO_DATE));
		model.addAttribute("mttrInDetails", mttrInDetails);
		model.addAttribute(FORM_HEADING, "MTTR Report");
		log.info("End: MttrReport");

		return "mttrReport";
	}

	/**
	 * Mttr report by priority.
	 *
	 * @param dashboardBean the dashboard bean
	 * @param model         the model
	 * @param request       the request
	 * @return the string
	 */
	@GetMapping("/mttrReportByPriority")
	public String mttrReportByPriority(@ModelAttribute("mttrReportDetail") DashboardBean dashboardBean, Model model,
			HttpServletRequest request) {
		log.info("Start: MttrReportByPriority");
		List<DashboardBean> mttrByPriority = tmDashboardService.getMttrByPriority(dashboardBean.getFromDate(),
				dashboardBean.getToDate());

		if (Objects.nonNull(mttrByPriority) && mttrByPriority.size() > 0) {
			model.addAttribute("mttrByPriorityVal", mttrByPriority);
		}

		List<DashboardBean> mttrByPrioritys = null;
		mttrByPrioritys = tmDashboardService.getMttrReportByPriority(dashboardBean.getFromDate(),
				dashboardBean.getToDate());
		String accountId = getDefaultAccountId();
		UserBean ubean = userService.getUserAccountType(accountId);
		int isGeneric = ubean.getIsGeneric();
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		model.addAttribute(IS_GENERIC, isGeneric);
		model.addAttribute(REPORT_CAT, request.getParameter(REPORT_CAT));
		model.addAttribute(COMPONENT_TYPE, request.getParameter(COMPONENT_TYPE));
		model.addAttribute(REPORT_TYPE, request.getParameter(REPORT_TYPE));
		model.addAttribute(REPORT_NAME, request.getParameter(REPORT_NAME));
		model.addAttribute(REPORT_FREQ, request.getParameter(REPORT_FREQ));
		model.addAttribute(FROM_DATE, request.getParameter(FROM_DATE));
		model.addAttribute(TO_DATE, request.getParameter(TO_DATE));
		model.addAttribute("mttrByPriority", mttrByPrioritys);
		model.addAttribute(FORM_HEADING, "MTTR Report By Priority");
		log.info("End: MttrReportByPriority");
		return "mttrReportByPriority";
	}

	/**
	 * Gets the logged user.
	 *
	 * @return the logged user
	 */
	private String getLoggedUser() {
		SecurityContext sc = SecurityContextHolder.getContext();
		Authentication auth = sc.getAuthentication();
		return auth.getName();
	}

	/**
	 * Gets the user account.
	 *
	 * @return the user account
	 */
	private int getUserAccount() {
		String accountId = getDefaultAccountId();
		UserBean ub = userService.getUserAccountType(accountId);
		return Objects.nonNull(ub) ? ub.getIsGeneric() : -1;
	}
	
	
	/**
	 * Compliance report.
	 *
	 * @param dashboardBean the dashboard bean
	 * @param model the model
	 * @param request the request
	 * @return the string
	 */
	@GetMapping("/complianceReport")
	public String complianceReport(@ModelAttribute("complianceReport") DashboardBean dashboardBean, Model model,
			HttpServletRequest request) {
		log.info("Starts: Compliance Report");
		String accountId = getDefaultAccountId();
		UserBean ubean = userService.getUserAccountType(accountId);
		int isGeneric = ubean.getIsGeneric();
		model.addAttribute(IS_GENERIC, isGeneric);
		List<ComplianceBean> complianceReportList = tmDashboardService.getComplianceReport(dashboardBean.getFromDate(), dashboardBean.getToDate());
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		model.addAttribute(REPORT_CAT, request.getParameter(REPORT_CAT));
		model.addAttribute(COMPONENT_TYPE, request.getParameter(COMPONENT_TYPE));
		model.addAttribute(REPORT_TYPE, request.getParameter(REPORT_TYPE));
		model.addAttribute(REPORT_NAME, request.getParameter(REPORT_NAME));
		model.addAttribute(REPORT_FREQ, request.getParameter(REPORT_FREQ));
		model.addAttribute(FROM_DATE, request.getParameter(FROM_DATE));
		model.addAttribute(TO_DATE, request.getParameter(TO_DATE));
		model.addAttribute("complianceReportList", complianceReportList);
		model.addAttribute(FORM_HEADING, "Compliance Report");
		log.info("End: Compliance Report");

		return "complianceReport";
	}
	
	/**
	 * Compliance report.
	 *
	 * @param dashboardBean the dashboard bean
	 * @param model the model
	 * @param request the request
	 * @return the string
	 */
	@GetMapping("/kometricschrtdispload")
	public @ResponseBody String kometricschrtdispload(@ModelAttribute("kometricschrtdispload") MasterDataAttributeVO masterDataAttributeVO, 
			@RequestParam(value = "freq") String freq,
			Model model, HttpServletRequest request) {
		log.info("Starts: KO Metrics Chart");
		String accountId = getDefaultAccountId();
		masterDataAttributeVO.setAccId(accountId);
		masterDataAttributeVO.setUserId(getLoggedUser());
		List<KOMetricsBean> koMetricsChartList = tmDashboardService.getKOMetricsChart(masterDataAttributeVO, freq);
		Gson gson =new Gson();
		log.info("End:  KO Metrics Chart");
		return gson.toJson(koMetricsChartList);
	}
	
	@GetMapping("/ageingWorkinfoReport")
	public String ageingWorkinfoReport(@ModelAttribute("ageingWorkinfoReport") MasterDataAttributeVO masterDataAttributeVO, 
			Model model, HttpServletRequest request) {
		log.info("Starts: Ageing Workinfo Report");
		String accountId = getDefaultAccountId();
		masterDataAttributeVO.setAccId(accountId);
		masterDataAttributeVO.setUserId(getLoggedUser());
		List<AgeingWorkinfoBean> ageingWorkinfoReportList = tmDashboardService.getAgeingWorkinfoReport(masterDataAttributeVO);
		int totalOpenInc=0,incWithUpdates=0;
		for(AgeingWorkinfoBean ageing : ageingWorkinfoReportList){
			if(!IKONUtils.isNullOrEmpty(ageing.getTower()) && IKONUtils.isNullOrEmpty(ageing.getCc()) && IKONUtils.isNullOrEmpty(ageing.getCluster())) {
				totalOpenInc=totalOpenInc+ageing.getTotalTicketCount().intValue();
				incWithUpdates=incWithUpdates+ageing.getIncUpdateCount().intValue();
			}
		}
		float updatedPerc;
		if(Objects.equals(totalOpenInc, 0)){
			updatedPerc= 0;
		}else {
			updatedPerc= Math.round(((incWithUpdates * 100)/totalOpenInc) * 100.0)/100;
		}
		model.addAttribute("updatedPerc", updatedPerc);
		model.addAttribute("ageingWorkinfoReportList", ageingWorkinfoReportList);
		model.addAttribute(FORM_HEADING, "Ageing Workinfo Report");
		
		
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		UserBean ubean = userService.getUserAccountType(accountId);
		int isGeneric = ubean.getIsGeneric();
		model.addAttribute(IS_GENERIC, isGeneric);
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		model.addAttribute(REPORT_CAT, request.getParameter(REPORT_CAT));
		model.addAttribute(COMPONENT_TYPE, request.getParameter(COMPONENT_TYPE));
		model.addAttribute(REPORT_TYPE, request.getParameter(REPORT_TYPE));
		model.addAttribute(REPORT_NAME, request.getParameter(REPORT_NAME));
		model.addAttribute(REPORT_FREQ, request.getParameter(REPORT_FREQ));
		model.addAttribute(FROM_DATE, request.getParameter(FROM_DATE));
		model.addAttribute(TO_DATE, request.getParameter(TO_DATE));
		
		log.info("End:  Ageing Workinfo Report");
		return "ageingWorkinfoReport";
	}
	
	@GetMapping("/ageingWorkinfoReportDetail")
	public String ageingWorkinfoReportDetail(@ModelAttribute("ageingWorkinfoReportDetail") MasterDataAttributeVO masterDataAttributeVO, 
			Model model, HttpServletRequest request) {
		log.info("Starts: Ageing Workinfo Detail Report");
		String accountId = getDefaultAccountId();
		masterDataAttributeVO.setAccId(accountId);
		masterDataAttributeVO.setUserId(getLoggedUser());
		List<AgeingWorkinfoBean> ageingWorkinfoReportDetailList = tmDashboardService.getAgeingWorkinfoReportDetail(masterDataAttributeVO);
		model.addAttribute("ageingWorkinfoReportDetailList", ageingWorkinfoReportDetailList);
		model.addAttribute(FORM_HEADING, "Ageing Workinfo Report Detail");
		
		
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		UserBean ubean = userService.getUserAccountType(accountId);
		int isGeneric = ubean.getIsGeneric();
		model.addAttribute(IS_GENERIC, isGeneric);
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		model.addAttribute(REPORT_CAT, request.getParameter(REPORT_CAT));
		model.addAttribute(COMPONENT_TYPE, request.getParameter(COMPONENT_TYPE));
		model.addAttribute(REPORT_TYPE, request.getParameter(REPORT_TYPE));
		model.addAttribute(REPORT_NAME, request.getParameter(REPORT_NAME));
		model.addAttribute(REPORT_FREQ, request.getParameter(REPORT_FREQ));
		model.addAttribute(FROM_DATE, request.getParameter(FROM_DATE));
		model.addAttribute(TO_DATE, request.getParameter(TO_DATE));
		
		log.info("End:  Ageing Workinfo Detail Report");
		return "ageingWorkinfoReportDetail";
	}
}
