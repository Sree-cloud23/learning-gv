package com.ikon.web;

import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Properties;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.google.gson.Gson;
import com.ikon.dto.ComplianceBean;
import com.ikon.dto.ComplianceItem;
import com.ikon.dto.Item;
import com.ikon.dto.KOInfoBean;
import com.ikon.dto.KOMetricsBean;
import com.ikon.dto.KOReviewerBean;
import com.ikon.dto.KOusageItem;
import com.ikon.dto.KoDataAttribute;
import com.ikon.dto.KoDataAttributeVO;
import com.ikon.dto.MasterDataAttributeVO;
import com.ikon.dto.ReportDataAttributeVO;
import com.ikon.dto.SearchDataAttributeVO;
import com.ikon.dto.SettingBean;
import com.ikon.dto.TicketDataAttributeVO;
import com.ikon.dto.TicketDataBean;
import com.ikon.dto.UserBean;
import com.ikon.model.KOUsage;
import com.ikon.repository.KOInfoRepository;
import com.ikon.repository.KOUsageRepository;
import com.ikon.rest.web.models.Authentication;
import com.ikon.rest.web.models.SecurityContext;
import com.ikon.rest.web.models.SecurityContextHolder;
import com.ikon.service.AccessControlService;
import com.ikon.service.AccountInfoService;
import com.ikon.service.HelpDeskService;
import com.ikon.service.KOInfoService;
import com.ikon.service.MLDBProcess;
import com.ikon.service.ReportService;
import com.ikon.service.TicketDataService;
import com.ikon.service.UserService;
import com.mongodb.MongoException;

import lombok.extern.slf4j.Slf4j;


/**
 * The Class KOController.
 */
@Controller
@Slf4j
public class KOController {

	/** The Constant KO_USAGE_REPORT_ID. */
	private static final String KO_USAGE_REPORT_ID = "10";

	/** The Constant KO_APPROVAL_CYCLE_REPORT_ID. */
	private static final String KO_APPROVAL_CYCLE_REPORT_ID = "11";

	/** The Constant VIEW_ACTION_ID. */
	private static final String VIEW_ACTION_ID = "1";

	/** The Constant KO_USAGE_CHART_ID. */
	private static final String KO_USAGE_CHART_ID = "19";

	/** The Constant KO_PUBLISHED_CHART_ID. */
	private static final String KO_PUBLISHED_CHART_ID = "20";

	/** The Constant KO_RESOLVED_CHART_ID. */
	private static final String KO_RESOLVED_CHART_ID = "17";

	/** The Constant KO_LINK_DIST_CHART_ID. */
	private static final String KO_LINK_DIST_CHART_ID = "22";
	
	/** The Constant COMPLIANCE_CHART_ID. */
	private static final String COMPLIANCE_CHART_ID = "23";

	/** The Constant INC_LINK_DIST_CHART_ID. */
	private static final String INC_LINK_DIST_CHART_ID = "18";

	/** The Constant KO_AVAIL_DIST_CHART_ID. */
	private static final String KO_AVAIL_DIST_CHART_ID = "21";

	/** The Constant CHART_VIEW_ACTION_ID. */
	private static final String CHART_VIEW_ACTION_ID = "1";

	/** The Constant CREATE_KO. */
	private static final Integer CREATE_KO = 1;

	/** The Constant EDIT_KO. */
	private static final Integer EDIT_KO = 0;

	/** The ko info service. */
	@Inject
	private transient KOInfoService koInfoService;

	/** The user service. */
	@Inject
	private UserService userService;

	/** The report service. */
	@Inject
	private transient ReportService reportService;

	/** The access control service. */
	@Inject
	private transient AccessControlService accessControlService;

	/** The ticket data service. */
	@Inject
	private transient TicketDataService ticketDataService;

	/** The ikon controller. */
	@Inject
	private transient IKONController ikonController;
	
	/** The helpdesk controller. */
	@Inject
	private transient HelpDeskController helpdeskController;

	/** The k O usage repository. */
	@Inject
	private transient KOUsageRepository kOUsageRepository;

	/** The k O info repository. */
	@Inject
	private transient KOInfoRepository kOInfoRepository;
	
	/** The help service. */
	@Inject
	private transient HelpDeskService helpService;
	
	/** The access control service. */
	@Inject
	private transient AccountInfoService accInfoService;

	/** The Constant HEADER_CREATE_KO. */
	private static final String HEADER_CREATE_KO = "Create KO";

	/** The Constant log. */
//	private static final log log = LogManager.getlog(KOController.class);

	/** The Constant SHOW_RELATED_KO_STRING. */
	private static final String SHOW_RELATED_KO_STRING = "showRelatedKOs";

	/** The Constant CLUSTER_STRING. */
	private static final String CLUSTER_STRING = "cluster";

	/** The Constant CREATED_BY_STRING. */
	private static final String CREATED_BY_STRING = "createdBy";

	/** The Constant ALL_CREATED_BY_LIST. */
	private static final String ALL_CREATED_BY_LIST = "allCreatedByList";

	/** The Constant REPORT_TYPE_STRING. */
	private static final String REPORT_TYPE_STRING = "reportType";

	/** The Constant LONG_DESCRIPTION_STRING. */
	private static final String LONG_DESCRIPTION_STRING = "Long Description";

	/** The Constant SHORT_DESCRIPTION_STRING. */
	private static final String SHORT_DESCRIPTION_STRING = "Short Description";

	/** The Constant STRCULSTER_SUM_MONTHSLIST. */
	private static final String STRCULSTER_SUM_MONTHSLIST = "strCulster_sum_monthsList";

	/** The Constant ASGMTGRP_KOLINKED_DATALIST. */
	private static final String ASGMTGRP_KOLINKED_DATALIST = "strAsgmtgrp_sum_koLinkedDataList";

	/** The Constant TOWER_MONTHS_LIST. */
	private static final String TOWER_MONTHS_LIST = "strTower_sum_monthsList";

	/** The Constant CC_MONTHS_LIST. */
	private static final String CC_MONTHS_LIST = "strCC_sum_monthsList";

	/** The Constant TOWER_KOLINKED_DATALIST. */
	private static final String TOWER_KOLINKED_DATALIST = "strTower_sum_koLinkedDataList";

	/** The Constant COMPONENT_TYPE. */
	private static final String COMPONENT_TYPE = "componentType";

	/** The Constant TOWER. */
	private static final String TOWER = "tower";

	/** The Constant ASGNGRP. */
	private static final String ASGNGRP = "asgngrp";

	/** The Constant ASSIGNMENT_GROUP. */
	private static final String ASSIGNMENT_GROUP = "Assignment Group";

	/** The Constant FROM_DATE. */
	private static final String FROM_DATE = "fromdate";

	/** The Constant FROM_DATE_STRING. */
	private static final String FROM_DATE_STRING = "fromDate";

	/** The Constant TO_DATE. */
	private static final String TO_DATE = "toDate";

	/** The Constant APPLICATION_NAME. */
	private static final String APPLICATION_NAME = "Application Name";

	/** The Constant APPLICATION_NAMELIST. */
	private static final String APPLICATION_NAMELIST = "allApplicationNameList";

	/** The Constant CREATEKO_FORM. */
	private static final String CREATEKO_FORM = "createKOForm";

	/** The Constant TRUE. */
	private static final String TRUE = "true";

	/** The Constant REPORT_CATEGORIZATION. */
	private static final String REPORT_CATEGORIZATION = "reportCategorization";

	/** The Constant SYMPTOMS. */
	private static final String SYMPTOMS = "Symptoms";

	/** The Constant FILTER_SELECTION. */
	private static final String FILTER_SELECTION = "filterSelection";

	/** The Constant ALL_ASSIGNMENT_GROUPLIST. */
	private static final String ALL_ASSIGNMENT_GROUPLIST = "allAssignmentGroupList";

	/** The Constant REPORT_NAME. */
	private static final String REPORT_NAME = "reportName";

	/** The Constant REPORT_FREQUENCY. */
	private static final String REPORT_FREQUENCY = "reportFrequency";

	/** The Constant ALL_PUBLICATION_STATUSLIST. */
	private static final String ALL_PUBLICATION_STATUSLIST = "allPublicationStatusList";

	/** The Constant STATUS. */
	private static final String STATUS = "Status";

	/** The Constant CC_KOLINKED_DATALIST. */
	private static final String CC_KOLINKED_DATALIST = "strCC_sum_koLinkedDataList";

	/** The Constant YYYMMDD. */
	private static final String YYYMMDD = "yyyy/MM/dd";

	/** The Constant FROM_HEADING. */
	private static final String FROM_HEADING = "formheading";

	/** The Constant APPROVED. */
	private static final String APPROVED = "Approved";

	/** The Constant KO_CREATED_BY. */
	private static final String KO_CREATED_BY = "KO Created By";

	/** The Constant DEFAULT_ACCOUNTNAME. */
	private static final String DEFAULT_ACCOUNTNAME = "defaultAccountName";

	/** The Constant READONLY_KO. */
	private static final String READONLY_KO = "readonlyko";

	/** The Constant KOLINK_FORM_DETAIL. */
	private static final String KOLINK_FORM_DETAIL = "kolinkFormDetail";

	/** The Constant APPNAME. */
	private static final String APPNAME = "appName";

	/** The Constant ATTACHMENT_PRESENT. */
	private static final String ATTACHMENT_PRESENT = "attachmentPresent";

	/** The Constant KO_ID. */
	private static final String KO_ID = "KO ID";

	/** The Constant RESOLUTION_NOTES. */
	private static final String RESOLUTION_NOTES = "Resolution Notes";

	/** The Constant KO_INFO_LIST. */
	private static final String KO_INFO_LIST = "koInfoList";

	/** The Constant TICKETID_FROMVIEW. */
	private static final String TICKETID_FROMVIEW = "ticketIdFromView";

	/** The Constant PUBLISHED. */
	private static final String PUBLISHED = "Published";

	/** The Constant FREQ. */
	private static final String FREQ = "freq";

	/** The Constant TO_DATE_STRING. */
	private static final String TO_DATE_STRING = "todate";

	/** The Constant APPSNAME. */
	private static final String APPSNAME = "appsname";

	/** The Constant CULSTER_KOLINKED_DATALIST. */
	private static final String CULSTER_KOLINKED_DATALIST = "strCulster_sum_koLinkedDataList";

	/** The Constant ASGMTGRP_MONTHSLIST. */
	private static final String ASGMTGRP_MONTHSLIST = "strAsgmtgrp_sum_monthsList";

	/** The Constant ACCEPT_TYPES. */
	private static final String ACCEPT_TYPES = "Accept=*/*";

	/** The Constant CREATEKO_REQ. */
	private static final String CREATEKO_REQ = "/createKO";

	/** The Constant ONE. */
	private static final int ONE = 1;

	/** The Constant REVIEW_SUBMIT. */
	private static final String REVIEW_SUBMIT = "ReviewSubmit";

	/** The Constant KO_TYPE. */
	private static final String KO_TYPE = "koType";

	/** The Constant IS_GENERIC. */
	private static final String IS_GENERIC = "isGeneric";
	/** The Constant FROM_PAGE. */
	private static final String FROM_PAGE ="fromPage";
	
	/** The Constant INTERNAL_REQ. */
	private static final String INTERNAL_REQ ="internal";
	/** The Constant EXTERNAL_REQ. */
	private static final String EXTERNAL_REQ ="external";
	
	/** The ml DB process. */
	@Inject
	private transient MLDBProcess mlDBProcess;
	
	/** The Constant INDRAFT. */
	private static final String INDRAFT = "InDraft";


	/**
	 * Search.
	 *
	 * @param model   the model
	 * @param koInfo  the ko info
	 * @param request the request
	 * @param session the session
	 * @return the string
	 */
	@GetMapping("/search")
	public String search(Model model, @ModelAttribute("searchFormDetail") KOInfoBean koInfo, HttpServletRequest request,
			HttpSession session) {
			log.info("Start: search");
			loadSearchTypeAheadURLs(model,request);
			String accountId = getDefaultAccountId();
			UserBean ubean = userService.getUserAccountType(accountId);
			int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
			model.addAttribute("isHelpdeskVisible", helpdeskStatus);
			
			int isGeneric = ubean.getIsGeneric();
			model.addAttribute(IS_GENERIC, isGeneric);
			model.addAttribute(FROM_HEADING, "Search Page");
			log.info("End: search");
			return "searchPage";
		
	}

	/**
	 * Load search type ahead UR ls.
	 *
	 * @param model the model
	 */
	private void loadSearchTypeAheadURLs(Model model, HttpServletRequest request) {
		ClassLoader loader = Thread.currentThread().getContextClassLoader();
		try(InputStream reader = loader.getResourceAsStream("application.properties");) {
			Properties prop = new Properties();
			prop.load(reader);
			model.addAttribute("searchTypeAheadHost", prop.getProperty("searchTypeAheadHost"));
			
			String serverName = prop.getProperty("ikon2.login.external.url");
			StringBuffer url = request.getRequestURL();
			
			 if(!url.toString().contains(serverName)) {
				 model.addAttribute("requestType", INTERNAL_REQ);
			 }
			 else {
				 model.addAttribute("requestType", EXTERNAL_REQ);
			 }
		} catch (IOException e) {
			log.error(e.getMessage());
		} 
	}

	/**
	 * Search tickets and K os.
	 *
	 * @param koInfo  the ko info
	 * @param model   the model
	 * @param request the request
	 * @param session the session
	 * @return the string
	 */
	@PostMapping(value = "/search")
	public String searchTicketsAndKOs(@ModelAttribute("searchFormDetail") KOInfoBean koInfo, Model model,
			HttpServletRequest request, HttpSession session) {
			log.info("Start: searchTicketsAndKOs for input string - " + koInfo.getKosearchbox());
			List<KOInfoBean> simplesearchkolistList = null;
			loadSearchTypeAheadURLs(model,request);
			String searchString = koInfo.getProcessedSearchString();
			String ticketorkoval = koInfo.getTicketorko();
			String searchid = "1";

			if (!StringUtils.isEmpty(searchString) && !StringUtils.isEmpty(ticketorkoval)) {
				TicketDataAttributeVO tktDtAttrVO = new TicketDataAttributeVO();
				tktDtAttrVO.setMasterDtAttrVo(new MasterDataAttributeVO("", koInfo.getApplicationName(), koInfo.getAssignmentGroup(), "", "", "", ""));
				tktDtAttrVO.setKoDtAttr(new KoDataAttribute("", koInfo.getPublicationStatus(), "", "", koInfo.getCreatedBy(), 0));
				SearchDataAttributeVO searchDtAttrVo = new SearchDataAttributeVO();
				searchDtAttrVo.setSearch(searchString);
				searchDtAttrVo.setSearchid(searchid);
				tktDtAttrVO.setSearchDtAttrVo(searchDtAttrVo);
				if (ticketorkoval.equalsIgnoreCase("Ticket")) {
					simplesearchkolistList = koInfoService.simpleTicketSearch(tktDtAttrVO);

				} else if (ticketorkoval.equalsIgnoreCase("KO")) {
					simplesearchkolistList = koInfoService.simpleKOSearch(tktDtAttrVO);
				}
				Set<String> applicationNameList = new HashSet<String>();
				Set<String> assignmentGroupList = new HashSet<String>();
				Set<String> publicationstatusList = new HashSet<String>();
				Set<String> createdbyList = new HashSet<String>();
				if (Objects.nonNull(simplesearchkolistList)) {
					for (KOInfoBean koInfoBean : simplesearchkolistList) {
						applicationNameList.add(koInfoBean.getApplicationName());
						assignmentGroupList.add(koInfoBean.getAssignmentGroup());
						publicationstatusList.add(koInfoBean.getPublicationStatus());
						createdbyList.add(koInfoBean.getCreatedBy());
					}
				}
				String accountId = getDefaultAccountId();
				UserBean ubean = userService.getUserAccountType(accountId);
				int isGeneric = ubean.getIsGeneric();
				int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
				model.addAttribute("isHelpdeskVisible", helpdeskStatus);
				model.addAttribute(IS_GENERIC, isGeneric);
				model.addAttribute("searchCategory", ticketorkoval);
				model.addAttribute(APPLICATION_NAMELIST, applicationNameList);
				model.addAttribute(ALL_ASSIGNMENT_GROUPLIST, assignmentGroupList);
				model.addAttribute(ALL_PUBLICATION_STATUSLIST, publicationstatusList);
				model.addAttribute(ALL_CREATED_BY_LIST, createdbyList);
				model.addAttribute("simplesearchkolistList", simplesearchkolistList);
				model.addAttribute(FROM_HEADING, "Search Page");
				model.addAttribute("searchFormDetail", koInfo);

			}

			log.info("End: searchTicketsAndKOs for processed string - " + koInfo.getProcessedSearchString());
			return "searchPage";
	}

	/**
	 * Tm dashboard.
	 *
	 * @return the string
	 */
	@RequestMapping("/tmDashboard")
	public String tmDashboard() {
		return "tmDashboard";
	}

	/**
	 * Ko list.
	 *
	 * @param koInfo  the ko info
	 * @param model   the model
	 * @param request the request
	 * @return the string
	 */
	@GetMapping("/koList")
	public String koList(@ModelAttribute(KOLINK_FORM_DETAIL) KOInfoBean koInfo, Model model,
			HttpServletRequest request) {
		log.info("Start: koList");
		String accountId = getDefaultAccountId();
		String userId = getLoggedUser();
		switch (getUserAccount()) {
		case 1:
			log.info("User belongs to Generic account");
			return "redirect:/koListGeneric";
		case 2:
			log.info("User belongs to Generic enabled account");
			break;
		case 0:
			log.info("User does not belongs to Generic account");
			break;
		case -1:
			log.info("User does not exists");
			return null;
		default:
			return "permissionDenied";
		}
		koInfo.setCreatedBy(getStringOrNull(request.getParameter(CREATED_BY_STRING)));
		String appName = request.getParameter(APPNAME);
		koInfo.setApplicationName(getStringOrNull(appName));
		List<KOInfoBean> koInfoBeanList = null;
		List<String> koListOrder = new LinkedList<String>();
		boolean relatedko = false;
		if (!StringUtils.isEmpty(request.getParameter(SHOW_RELATED_KO_STRING))) {
			koInfoBeanList = koInfoService.showAllRelatedKOs(request.getParameter(SHOW_RELATED_KO_STRING));
			koInfoBeanList.forEach(koib -> {
				getRelevancyNKoOrder(koib, koListOrder);
				if (!StringUtils.isEmpty(koib.getSelectedKoForResolution())
						&& koib.getSelectedKoForResolution().equalsIgnoreCase(koib.getKoID())) {
					koib.setIsSelectedForResolution("yes");
				}
			});
			koInfoBeanList = getReversedTen(koInfoBeanList);
			model.addAttribute("relatedko", TRUE);
			model.addAttribute(READONLY_KO, TRUE);
			model.addAttribute(SHOW_RELATED_KO_STRING, request.getParameter(SHOW_RELATED_KO_STRING));
			relatedko = true;
		} else {
			KoDataAttributeVO KoAttrVo= new KoDataAttributeVO();
			KoAttrVo.setMasterDtAttrVo(new MasterDataAttributeVO(accountId,koInfo.getApplicationName(), koInfo.getAssignmentGroup(), "", "", "", userId));
			KoAttrVo.setKoDtAttr(new KoDataAttribute("", koInfo.getPublicationStatus(), "", "", koInfo.getCreatedBy(), koInfo.getKoType()));
			koInfoBeanList = koInfoService.kolistviewSP(KoAttrVo);
		}
		String filterSelection = request.getParameter(FILTER_SELECTION);
		if (!StringUtils.isEmpty(filterSelection)) {
			model.addAttribute(FILTER_SELECTION, filterSelection);
		}
		addKoInfoListstoModel(model, koInfoBeanList);
		addViewSerialNumToKoBean(koInfoBeanList);
		List<String> selectedValsArr = getKoValueArray(relatedko);
		model.addAttribute(KO_INFO_LIST, koInfoBeanList);
		UserBean ubean = userService.getUserAccountType(accountId);
		int isGeneric = ubean.getIsGeneric();
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		int koEnabledStatus = getKOEnabledStatus(Integer.parseInt(accountId));
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		model.addAttribute("isKOEnabled", koEnabledStatus);
		model.addAttribute(IS_GENERIC, isGeneric);
		model.addAttribute(KO_TYPE, koInfo.getKoType());
		log.info("End: koList");
		return returnKOSummary(model, koInfoBeanList, selectedValsArr);
	}

	/**
	 * Gets the KO enabled status.
	 *
	 * @param accountId the account id
	 * @return the KO enabled status
	 */
	public int getKOEnabledStatus(int accountId) {
		
		return accInfoService.getKOEnabledStatus(accountId);
	}

	/**
	 * Gets the relevancy N ko order.
	 *
	 * @param tdb1 the tdb 1
	 * @param koListOrder the ko list order
	 * @return the relevancy N ko order
	 */
	public void getRelevancyNKoOrder(KOInfoBean tdb1, List<String> koListOrder) {
		if (!StringUtils.isEmpty(tdb1.getRelevPerc())) {
			String[] relevPercStrArr = tdb1.getRelevPerc().split(";");
			final int relevPercLength = relevPercStrArr.length;
			for (int percStr = 0; percStr < relevPercLength; percStr++) {
				if (relevPercStrArr[percStr].split(":")[0].equalsIgnoreCase(tdb1.getKoID())) {
					String[] koIdWithPerc = relevPercStrArr[percStr].split(":");
					tdb1.setRelevPerc(koIdWithPerc[1]);
				}
			}
		}
		if (!StringUtils.isEmpty(tdb1.getUsagePerc())) {
			String[] usagePercStrArr = tdb1.getUsagePerc().split(";");
			final int usagePercLength = usagePercStrArr.length;
			for (int percStr = 0; percStr < usagePercLength; percStr++) {
				if (usagePercStrArr[percStr].split(":")[0].equalsIgnoreCase(tdb1.getKoID())) {
					String[] koIdWithPerc = usagePercStrArr[percStr].split(":");
					tdb1.setUsagePerc(koIdWithPerc[1]);
					tdb1.setTicketLinkedCount(ticketDataService.getNoOfIncLinkedForKO(tdb1.getKoID(),getDefaultAccountId()));
				}
				koListOrder.add(usagePercStrArr[percStr].split(":")[0]);
			}
		} else {
			if (!StringUtils.isEmpty(tdb1.getKoID())) {
				koListOrder.add(tdb1.getKoID());
				tdb1.setTicketLinkedCount(ticketDataService.getNoOfIncLinkedForKO(tdb1.getKoID(),getDefaultAccountId()));
			}
		}
		if (!StringUtils.isEmpty(tdb1.getSelectedKoForResolution())
				&& tdb1.getSelectedKoForResolution().equalsIgnoreCase(tdb1.getKoID())) {
			tdb1.setIsSelectedForResolution("yes");
		}
	}

	/**
	 * Gets the reversed ten.
	 *
	 * @param koInfoBeanList the ko info bean list
	 * @return the reversed ten
	 */
	private List<KOInfoBean> getReversedTen(List<KOInfoBean> koInfoBeanList) {
		List<KOInfoBean> tdbList = new ArrayList<KOInfoBean>();
		if (Objects.nonNull(koInfoBeanList) && koInfoBeanList.size() > 0) {
			tdbList = new ArrayList<KOInfoBean>(
					koInfoBeanList.subList(0, koInfoBeanList.size() > 10 ? 10 : koInfoBeanList.size()));
		}
		Collections.reverse(tdbList);
		return tdbList;
	}

	/**
	 * Adds the ko info liststo model.
	 *
	 * @param model the model
	 * @param koInfoBeanList the ko info bean list
	 */
	private void addKoInfoListstoModel(Model model, List<KOInfoBean> koInfoBeanList) {
		Set<String> allApplicationNameList = new TreeSet<String>();
		Set<String> allAssignmentGroupList = new TreeSet<String>();
		Set<String> allCreatedByList = new TreeSet<String>();
		Set<String> allPublicationStatusList = new TreeSet<String>();
		koInfoBeanList.forEach(koInfoBean -> {
			if (Objects.equals(koInfoBean.getAttachmentPresent(), ONE)) {
				model.addAttribute(ATTACHMENT_PRESENT, "Y");
			} else {
				model.addAttribute(ATTACHMENT_PRESENT, "N");
			}

			if (!StringUtils.isEmpty(koInfoBean.getApplicationName())) {
				allApplicationNameList.add(koInfoBean.getApplicationName());
			}
			if (!StringUtils.isEmpty(koInfoBean.getAssignmentGroup())) {
				allAssignmentGroupList.add(koInfoBean.getAssignmentGroup());
			}
			if (!StringUtils.isEmpty(koInfoBean.getCreatedBy())) {
				allCreatedByList.add(koInfoBean.getCreatedBy());
			}
			if (!StringUtils.isEmpty(koInfoBean.getPublicationStatus())) {
				allPublicationStatusList.add(koInfoBean.getPublicationStatus());
			}

		});

		model.addAttribute(APPLICATION_NAMELIST, allApplicationNameList);
		model.addAttribute(ALL_ASSIGNMENT_GROUPLIST, allAssignmentGroupList);
		model.addAttribute(ALL_CREATED_BY_LIST, allCreatedByList);
		model.addAttribute(ALL_PUBLICATION_STATUSLIST, allPublicationStatusList);
	}

	/**
	 * Gets the ko value array.
	 *
	 * @param relatedko the relatedko
	 * @return the ko value array
	 */
	private List<String> getKoValueArray(boolean relatedko) {
		List<String> selectedValsArr = new ArrayList<>();
		if (relatedko) {
			selectedValsArr = Arrays.asList(KO_ID, SHORT_DESCRIPTION_STRING, LONG_DESCRIPTION_STRING, ASSIGNMENT_GROUP,
					APPLICATION_NAME, KO_CREATED_BY, SYMPTOMS, RESOLUTION_NOTES, STATUS, "KO Rel%", "KO Usage",
					"# Inc Linked");
		} else {
			selectedValsArr = Arrays.asList(KO_ID, SHORT_DESCRIPTION_STRING, LONG_DESCRIPTION_STRING, ASSIGNMENT_GROUP,
					APPLICATION_NAME, KO_CREATED_BY, SYMPTOMS, RESOLUTION_NOTES, STATUS);
		}
		return selectedValsArr;
	}

	/**
	 * Return KO summary.
	 *
	 * @param model            the model
	 * @param koInfoBeanList   the ko info bean list
	 * @param selectedValsList the selected vals list
	 * @return the string
	 */
	private String returnKOSummary(Model model, List<KOInfoBean> koInfoBeanList, List<String> selectedValsList) {
		model.addAttribute("selectedValsList", selectedValsList);

		if (selectedValsList.contains("ITSM Tool")) {
			model.addAttribute("ITSM_Tool", TRUE);
		}
		if (selectedValsList.contains("Attachment Present")) {
			model.addAttribute("Attachment_Present", TRUE);
		}
		if (selectedValsList.contains("KoFileType")) {
			model.addAttribute("KoFileType", TRUE);
		}

		if (selectedValsList.contains("AttachmentName")) {
			model.addAttribute("AttachmentName", TRUE);
		}
		if (selectedValsList.contains("KO Create Date")) {
			model.addAttribute("KO_Create_Date", TRUE);
		}

		model.addAttribute(FROM_HEADING, "KO List");
		return "koList";
	}

	/**
	 * Gets the default account id.
	 *
	 * @return the default account id
	 */
	private String getDefaultAccountId() {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String loginusrname = auth.getName();

		String accountId = String.valueOf(accessControlService.getAccessDetailByUserId(loginusrname).getAccountId());
		return accountId;
	}

	/**
	 * Ko list post.
	 *
	 * @param koInfo  the ko info
	 * @param model   the model
	 * @param request the request
	 * @return the string
	 */
	@PostMapping("/koList")
	public String koListPost(@ModelAttribute(KOLINK_FORM_DETAIL) KOInfoBean koInfo, Model model,
			HttpServletRequest request) {
		log.info("Start: koListPost");
		String accountId = getDefaultAccountId();
		String koID = request.getParameter("kosearchbox");
		String relatedko = request.getParameter("relatedko");
		koInfo.setCreatedBy(getStringOrNull(request.getParameter(CREATED_BY_STRING)));
		KoDataAttributeVO koDtAttrVo = new KoDataAttributeVO();
		koDtAttrVo.setMasterDtAttrVo(new MasterDataAttributeVO(accountId,koInfo.getApplicationName(), koInfo.getAssignmentGroup(), "", "", "", ""));
		koDtAttrVo.setKoDtAttr(new KoDataAttribute(koID, koInfo.getPublicationStatus(), "", "", koInfo.getCreatedBy(), koInfo.getKoType()));
		List<KOInfoBean> koInfoBeanList = koInfoService.kolistviewSP(koDtAttrVo);

		String filterSelection = request.getParameter(FILTER_SELECTION);

		if (!StringUtils.isEmpty(filterSelection)) {
			model.addAttribute(FILTER_SELECTION, filterSelection);
		}
		addKoInfoListstoModel(model, koInfoBeanList);
		if (!StringUtils.isEmpty(koInfo.getCreatedBy())) {
			removeOtherUserKos(koInfo.getCreatedBy(), koInfoBeanList);
		}
		addViewSerialNumToKoBean(koInfoBeanList);
		List<KOUsage> koUsageList = kOUsageRepository.findAll();
		List<KOInfoBean> koInfoList = koInfoService.getAllKos(accountId);

		if (!StringUtils.isEmpty(request.getParameter(SHOW_RELATED_KO_STRING))) {

			koInfoBeanList = koInfoService.showAllRelatedKOs(request.getParameter(SHOW_RELATED_KO_STRING));
			koInfoBeanList.forEach(koib -> {
				TicketDataBean tdb = new TicketDataBean();
				tdb.setRelevPerc(koib.getRelevPerc());
				tdb.setUsagePerc(koib.getUsagePerc());
				ikonController.processRelevUsagePerc(koUsageList, koInfoList, tdb);
				koib.setRelevPerc(tdb.getRelevPerc());
				koib.setUsagePerc(tdb.getUsagePerc());
				koib.setTicketLinkedCount(tdb.getTicketLinkedCount());
				koib.setSeperatedKoID(tdb.getSeperatedKoID());
				koib.setSeperatedKoPerc(tdb.getSeperatedKoPerc());
			});
			model.addAttribute("relatedko", TRUE);
			model.addAttribute(READONLY_KO, TRUE);
			model.addAttribute(SHOW_RELATED_KO_STRING, request.getParameter(SHOW_RELATED_KO_STRING));
		}

		model.addAttribute(KO_INFO_LIST, koInfoBeanList);
		log.info("End: koListPost");
		ArrayList<String> selectedValsArr = new ArrayList<String>();
		ArrayList<String> selectedValsNew = new ArrayList<String>();
		if (Objects.nonNull(koInfo) && Objects.nonNull(koInfo.getSelectedVals())) {
			selectedValsNew = new ArrayList<String>(Arrays.asList(koInfo.getSelectedVals().split(",")));
		}
		if (relatedko.equalsIgnoreCase(TRUE)) {
			selectedValsArr = new ArrayList<String>(Arrays.asList(KO_ID, SHORT_DESCRIPTION_STRING,
					LONG_DESCRIPTION_STRING, ASSIGNMENT_GROUP, APPLICATION_NAME, KO_CREATED_BY,SYMPTOMS, RESOLUTION_NOTES, STATUS,
					 "KO Rel%", "KO Usage", "# Inc Linked"));
		} else {
			selectedValsArr = new ArrayList<String>(
					Arrays.asList(KO_ID, SHORT_DESCRIPTION_STRING, LONG_DESCRIPTION_STRING, ASSIGNMENT_GROUP,
							 APPLICATION_NAME,KO_CREATED_BY, SYMPTOMS, RESOLUTION_NOTES, STATUS));
		}
		selectedValsNew.removeAll(selectedValsArr);
		List<String> notPresentList = selectedValsNew;
		Collections.sort(notPresentList);
		if (Objects.nonNull(notPresentList) && !notPresentList.isEmpty()) {
			selectedValsArr.addAll(notPresentList);
		}
		UserBean ubean = userService.getUserAccountType(accountId);
		int isGeneric = ubean.getIsGeneric();
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		int koEnabledStatus = getKOEnabledStatus(Integer.parseInt(accountId));
		model.addAttribute("isKOEnabled", koEnabledStatus);
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		model.addAttribute(IS_GENERIC, isGeneric);
		model.addAttribute(KO_TYPE, koInfo.getKoType());
		return returnKOSummary(model, koInfoBeanList, selectedValsArr);
	}

	/**
	 * Removes the other user kos.
	 *
	 * @param createdBy the created by
	 * @param koInfoBeanList the ko info bean list
	 */
	private void removeOtherUserKos(String createdBy, List<KOInfoBean> koInfoBeanList) {
		List<KOInfoBean> koInfoBeanToBeDeleted = new ArrayList<KOInfoBean>();
		for (KOInfoBean koInfoBean : koInfoBeanList) {
			if (!createdBy.equalsIgnoreCase(koInfoBean.getCreatedBy())) {
				koInfoBeanToBeDeleted.add(koInfoBean);
			}
		}
		koInfoBeanList.removeAll(koInfoBeanToBeDeleted);
	}

	/**
	 * Adds the view serial num to ko bean.
	 *
	 * @param koInfoBeanList the ko info bean list
	 */
	private void addViewSerialNumToKoBean(List<KOInfoBean> koInfoBeanList) {
		int serialNum = 1;
		for (KOInfoBean koInfoBean : koInfoBeanList) {
			koInfoBean.setKoViewSerialNum(serialNum++);
		}

	}

	/**
	 * Creates the KO.
	 *
	 * @param modelAndView the model and view
	 * @param model        the model
	 * @param request      the request
	 * @param koInfo       the ko info
	 * @param session      the session
	 * @return the model and view
	 */
	@GetMapping(value = CREATEKO_REQ)
	public ModelAndView createKO(ModelAndView modelAndView, Model model, HttpServletRequest request,
			@ModelAttribute(CREATEKO_FORM) KOInfoBean koInfo, HttpSession session) {
		log.info("Start: createKO");
		String ticketId = request.getParameter("ticketId");
		if (!StringUtils.isEmpty(ticketId)) {
			koInfo.setTicketsearchbox(ticketId);
		}

		String incAppName = request.getParameter("incAppName");
		if (!StringUtils.isEmpty(incAppName)) {
			koInfo.setApplicationName(incAppName);
		}

		String incAppGroup = request.getParameter("incAppGroup");
		if (!StringUtils.isEmpty(incAppGroup)) {
			koInfo.setAssignmentGroup(incAppGroup);
		}

		String incidentCause = request.getParameter("incidentCause");
		if (!StringUtils.isEmpty(incidentCause)) {
			koInfo.setCauseCode(incidentCause);
		}
		String accountId = getDefaultAccountId();
		UserBean ubean = userService.getUserAccountType(accountId);
		int isGeneric = ubean.getIsGeneric();
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		model.addAttribute(IS_GENERIC, isGeneric);
		model.addAttribute(FROM_HEADING, HEADER_CREATE_KO);
		model.addAttribute(CREATEKO_FORM, koInfo);
		log.info("End: createKO");
		return new ModelAndView("createKO");
	}

	/**
	 * Populate data.
	 *
	 * @param modelAndView   the model and view
	 * @param id             the id
	 * @param model          the model
	 * @param linkedincident the linkedincident
	 * @param response       the response
	 * @param koInfo         the ko info
	 * @return the response entity
	 */
	@JsonIgnoreProperties
	@RequestMapping(value = "/searchticket/{id}")
	public ResponseEntity<?> populateData(ModelAndView modelAndView, @PathVariable String id, Model model,
			String linkedincident, HttpServletResponse response, @ModelAttribute(CREATEKO_FORM) KOInfoBean koInfo)
			{
		log.info("Start: populateData");
		List<KOReviewerBean> koReviewersList = null;
		KOInfoBean result = koInfoService.populateIncAppdetails(id, koInfo.getModuleName());
		if (Objects.nonNull(result)) {
			MasterDataAttributeVO masterDataAttributeVO = new MasterDataAttributeVO(getDefaultAccountId(), result.getAssignmentGroup(), "", "", "", "", getLoggedUser());
			koReviewersList = koInfoService.getKOReviewersByAssignmentGroup(masterDataAttributeVO, CREATE_KO);
			result.setKoReviewersList(koReviewersList);
			
			log.info("end: populateData");
			return ResponseEntity.ok(result);
		}
		log.info("end: populateData");
		return ResponseEntity.ok("");
	}

	/**
	 * Creates the KO.
	 *
	 * @param koInfo        the ko info
	 * @param bindingResult the binding result
	 * @param modelAndView  the model and view
	 * @param request       the request
	 * @param files         the files
	 * @param model         the model
	 * @param session       the session
	 * @param errors        the errors
	 * @return the string
	 */
	@PostMapping(value = CREATEKO_REQ)
	public String createKO(@Valid @ModelAttribute(CREATEKO_FORM) KOInfoBean koInfo, BindingResult bindingResult,
			ModelAndView modelAndView, HttpServletRequest request, @RequestParam("file") MultipartFile[] files,
			Model model, HttpSession session, Errors errors) {
		if (bindingResult.hasFieldErrors()) {
			return CREATEKO_REQ;
		}
		String isForSearch = request.getParameter("hidden_forsearch");
		if (isForSearch.equalsIgnoreCase("1")) {
			KOInfoBean result = koInfoService.populateIncAppdetails(koInfo.getTicketsearchbox(),
					koInfo.getModuleName());
			koInfo.setApplicationName(result.getApplicationName());
			koInfo.setAssignmentGroup(result.getAssignmentGroup());
			koInfo.setCauseCode(result.getResoultionCategory());
			String accountId = getDefaultAccountId();
			UserBean ubean = userService.getUserAccountType(accountId);
			int isGeneric = ubean.getIsGeneric();
			int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
			model.addAttribute("isHelpdeskVisible", helpdeskStatus);
			model.addAttribute(IS_GENERIC, isGeneric);
			model.addAttribute(FROM_HEADING, HEADER_CREATE_KO);
			return "redirect:/createKO";
		} else {
			List<KOInfoBean> koInfoBeanList;
			KOInfoBean koInfoBeanListvalue = null;
			try {
				koInfoBeanList = koInfoService.insertKODetail(koInfo, files);
			} catch (IllegalAccessException e) {
				session.setAttribute("displayerror",
						"Issue while inserting data in DB,Please contact IKON support Team");
				model.addAttribute(FROM_HEADING, HEADER_CREATE_KO);
				return CREATEKO_REQ;
			}

			// comment for redirecting to Ko Approval cycle page after successfully creation
			if (Objects.nonNull(koInfoBeanList) && koInfoBeanList.size() > 0) {
				koInfoBeanListvalue = koInfoBeanList.get(0);
			}
			model.addAttribute(FROM_HEADING, HEADER_CREATE_KO);
			// String createactionval = koInfo.getKoStage();

			// Send an email to
			if (Objects.nonNull(koInfoBeanListvalue) && Objects.nonNull(koInfo)) {
				if (!StringUtils.isEmpty(koInfo.getApproverUserID())
						&& REVIEW_SUBMIT.equalsIgnoreCase(koInfo.getKoStage())) {
					koInfoService.assignAndEmailReviewer(koInfoBeanListvalue.getVar_ko(), koInfo.getApproverUserID());
				} else {
					koInfoService.sendmailtoreviewer(koInfoBeanListvalue.getVar_ko(), koInfo.getKoStage());
				}

				try {
					//MongoDBprocess.insertData(koInfo, getDefaultAccountId(), koInfoBeanListvalue.getVar_ko(),koInfo.getKoStage());
					mlDBProcess.insertDataIntoPostgres(koInfo, getDefaultAccountId(), koInfoBeanListvalue.getVar_ko(),koInfo.getKoStage(),null);
				} catch (IOException | MongoException e) {
					session.setAttribute("displayerror",
							"Issue while inserting data in DB,Please contact IKON support Team");
					model.addAttribute(FROM_HEADING, HEADER_CREATE_KO);
					return CREATEKO_REQ;
				}
			}
			
			//June Deployment J_BG02 start
			if(koInfo.getKoStage().equalsIgnoreCase(INDRAFT)) {
				return "redirect:/koList";
			}
			else {
				return "redirect:/koApprovalCycleList";
			}
			//June Deployment J_BG02 end
		}
	}

	/**
	 * Edits the KO.
	 *
	 * @param koId         the ko id
	 * @param modelAndView the model and view
	 * @param model        the model
	 * @param request      the request
	 * @param koInfo       the ko info
	 * @return the model and view
	 */
	/*
	 * @GetMapping(value = "/editKO/{koId}") public ModelAndView
	 * editKO(@PathVariable String koId, ModelAndView modelAndView, Model model,
	 * HttpServletRequest request, @ModelAttribute(CREATEKO_FORM) KOInfoBean koInfo)
	 * { log.info("Start: editKO"); updateModel(request, model);
	 * modelAndView.addObject(FROM_HEADING, "Edit KO"); List<KOInfoBean>
	 * koInfoBeanList = koInfoService.editKODetail(koId);
	 * setKoBeanDocName(koInfoBeanList); KOInfoBean koInfoBean = (KOInfoBean)
	 * getFirstElement(koInfoBeanList); if (Objects.nonNull(koInfoBeanList) &&
	 * koInfoBeanList.size() > 0) { koInfoBean = koInfoBeanList.get(0); }
	 * 
	 * List<String> tagsList = getTagsList(koInfoBean);
	 * model.addAttribute("tagsListVal", ifNotNull(koInfoBean, tagsList,
	 * "No tags to display")); List<KOInfoBean> reviewCommentsList =
	 * koInfoService.retrieveReviewComments(koId);
	 * 
	 * List<KOInfoBean> reviewCommentsCopy = new ArrayList<KOInfoBean>(); int
	 * serialNum = addKOSerialNo(reviewCommentsList);
	 * 
	 * KOInfoBean koPublishStatusBean = null;
	 * 
	 * // get KO reviwerlist MasterDataAttributeVO masterDataAttributeVO = new
	 * MasterDataAttributeVO(getDefaultAccountId(), koInfoBean.getAssignmentGroup(),
	 * "", "", "", "", getLoggedUser()); List<KOReviewerBean> koReviewersList =
	 * koInfoService.getKOReviewersByAssignmentGroup(masterDataAttributeVO,
	 * EDIT_KO); model.addAttribute("koReviewersList", koReviewersList); if
	 * (Objects.nonNull(reviewCommentsList) && reviewCommentsList.size() > 0) {
	 * reviewCommentsCopy = reviewCommentsList.stream() .filter(tdb ->
	 * !StringUtils.isEmpty(tdb.getReviewComments())).collect(Collectors.toList());
	 * koPublishStatusBean = reviewCommentsList.get(0); koPublishStatusBean
	 * .setTicketLinkedCount(ticketDataService.getNoOfIncLinkedForKO(
	 * koPublishStatusBean.getKoID(),getDefaultAccountId()));
	 * model.addAttribute("koPublishStatus", koPublishStatusBean); } String
	 * accountName = getAccountName(); String accountId = getDefaultAccountId();
	 * UserBean ubean = userService.getUserAccountType(accountId); int isGeneric =
	 * ubean.getIsGeneric(); int helpdeskStatus =
	 * helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
	 * model.addAttribute("isHelpdeskVisible", helpdeskStatus);
	 * model.addAttribute(IS_GENERIC, isGeneric);
	 * model.addAttribute("accountName",accountName);
	 * model.addAttribute("reviewCommentsList", reviewCommentsCopy);
	 * model.addAttribute("nextSerialNum", serialNum);
	 * model.addAttribute(CREATEKO_FORM, koInfoBean);
	 * model.addAttribute("koPublicationStatusVal",
	 * koInfoBean.getPublicationStatus()); Authentication auth =
	 * SecurityContextHolder.getContext().getAuthentication();
	 * model.addAttribute("loggedInUserId", auth.getName()); if
	 * ((Objects.nonNull(auth) && !StringUtils.isEmpty(auth.getName()) &&
	 * Objects.nonNull(koPublishStatusBean))) updateEditKoModel(model,
	 * auth.getName(), koPublishStatusBean, koInfoBean);
	 * 
	 * if (!StringUtils.isEmpty(request.getParameter(SHOW_RELATED_KO_STRING))) {
	 * model.addAttribute(SHOW_RELATED_KO_STRING,
	 * request.getParameter(SHOW_RELATED_KO_STRING)); }
	 * 
	 * log.info("End: editKO"); return new ModelAndView("editKO"); }
	 */
	
	/**
	 * Gets the first element.
	 *
	 * @param koInfoBeanList the ko info bean list
	 * @return the first element
	 */
	@SuppressWarnings("rawtypes")
	private Object getFirstElement(List koInfoBeanList) {
		return Objects.nonNull(koInfoBeanList) && koInfoBeanList.size() > 0 && Objects.nonNull(koInfoBeanList.get(0))
				? koInfoBeanList.get(0)
				: null;
	}

	/**
	 * If not null.
	 *
	 * @param o1 the o 1
	 * @param o2 the o 2
	 * @param o3 the o 3
	 * @return the object
	 */
	private Object ifNotNull(Object o1, Object o2, Object o3) {
		return Objects.nonNull(o1) ? o2 : o3;
	}

	/**
	 * Adds the KO serial no.
	 *
	 * @param koInfoList the ko info list
	 * @return the int
	 */
	private int addKOSerialNo(List<KOInfoBean> koInfoList) {
		int serialNum = 1;
		for (KOInfoBean kb : koInfoList) {
			if (!StringUtils.isEmpty(kb.getReviewComments())) {
				kb.setKOSerialNo(serialNum++);
			}
		}
		return serialNum;
	}

	/**
	 * Gets the tags list.
	 *
	 * @param koInfoBean the ko info bean
	 * @return the tags list
	 */
	public  List<String> getTagsList(KOInfoBean koInfoBean) {

		List<String> tagsList = new ArrayList<String>();
		if (Objects.nonNull(koInfoBean) && !StringUtils.isEmpty(koInfoBean.getKOSingleTags())) {
			String singleTags = koInfoBean.getKOSingleTags();
			String[] singleTagsArr = singleTags.split(",");
			singleTagsArr = Arrays.copyOfRange(singleTagsArr, 0, singleTagsArr.length < 4 ? singleTagsArr.length : 4);
			tagsList.addAll(Arrays.asList(singleTagsArr));
		}
		if (Objects.nonNull(koInfoBean) && !StringUtils.isEmpty(koInfoBean.getKOBigramTags())) {
			String bigramTags = koInfoBean.getKOBigramTags();
			String[] bigramTagsArr = bigramTags.split(",");
			bigramTagsArr = Arrays.copyOfRange(bigramTagsArr, 0, bigramTagsArr.length < 3 ? bigramTagsArr.length : 3);
			tagsList.addAll(Arrays.asList(bigramTagsArr));
		}
		if (Objects.nonNull(koInfoBean) && !StringUtils.isEmpty(koInfoBean.getKOTrigramTags())) {
			String trigramTags = koInfoBean.getKOTrigramTags();
			String[] trigramTagsArr = trigramTags.split(",");
			trigramTagsArr = Arrays.copyOfRange(trigramTagsArr, 0,
					trigramTagsArr.length < 2 ? trigramTagsArr.length : 2);
			tagsList.addAll(Arrays.asList(trigramTagsArr));
		}
		return tagsList;
	}

	/**
	 * Update model.
	 *
	 * @param request the request
	 * @param model the model
	 */
	private void updateModel(HttpServletRequest request, Model model) {
		if (!StringUtils.isEmpty(request.getParameter(READONLY_KO))) {
			model.addAttribute(TICKETID_FROMVIEW, request.getParameter(TICKETID_FROMVIEW));
			model.addAttribute(READONLY_KO, TRUE);
		}
		if (!StringUtils.isEmpty(request.getParameter("fromPage"))) {
			model.addAttribute(FROM_PAGE, "koac");
		}
		if (!StringUtils.isEmpty(request.getParameter(TICKETID_FROMVIEW))
				|| !StringUtils.isEmpty(request.getParameter(READONLY_KO))) {
			model.addAttribute(FROM_HEADING, "View KO");
			model.addAttribute(TICKETID_FROMVIEW, request.getParameter(TICKETID_FROMVIEW));
		} else {
			model.addAttribute(FROM_HEADING, "Edit KO");
		}
		
		String accountId = getDefaultAccountId();
		int koEnabledStatus = getKOEnabledStatus(Integer.parseInt(accountId));
		
		if(koEnabledStatus==0) {
			model.addAttribute(READONLY_KO, TRUE);
		}

	}

	/**
	 * Update edit ko model.
	 *
	 * @param model the model
	 * @param userId the user id
	 * @param koPublishStatusBean the ko publish status bean
	 * @param koInfoBean the ko info bean
	 */
	private void updateEditKoModel(Model model, String userId, KOInfoBean koPublishStatusBean, KOInfoBean koInfoBean) {

		String accountId = getDefaultAccountId();
		int koEnabledStatus = getKOEnabledStatus(Integer.parseInt(accountId));
		
		if (!userId.equalsIgnoreCase(koPublishStatusBean.getReviewedBy()))
			if (!userId.equalsIgnoreCase(koPublishStatusBean.getCreatedBy()))
				model.addAttribute(READONLY_KO, TRUE);
			else if (Objects.nonNull(koInfoBean.getPublicationStatus())
					&& koInfoBean.getPublicationStatus().contains("Review")) {
				model.addAttribute(READONLY_KO, TRUE);
			}
		if ((userId.equalsIgnoreCase(koPublishStatusBean.getReviewedBy())
				&& !userId.equalsIgnoreCase(koPublishStatusBean.getCreatedBy())
				&& Objects.nonNull(koInfoBean.getPublicationStatus()))
				&& (koInfoBean.getPublicationStatus().contains("Rework")
						|| koInfoBean.getPublicationStatus().contains("Draft")
						|| koInfoBean.getPublicationStatus().contains(PUBLISHED))) {
			model.addAttribute(READONLY_KO, TRUE);
		}

		if ((Objects.nonNull(koInfoBean.getPublicationStatus()) && koInfoBean.getPublicationStatus().contains(APPROVED))) {
			model.addAttribute(READONLY_KO, TRUE);
		}
		
		if(koEnabledStatus ==0) {
			model.addAttribute(READONLY_KO, TRUE);
		}

	}

	/**
	 * Sets the ko bean doc name.
	 *
	 * @param koInfoBeanList the new ko bean doc name
	 */
	private void setKoBeanDocName(List<KOInfoBean> koInfoBeanList) {

		String[] fileNameStrArr = null;
		String fileName = "";
		for (KOInfoBean kobean : koInfoBeanList) {
			if (StringUtils.isEmpty(kobean.getAttachmentName())) {
				if (!StringUtils.isEmpty(kobean.getAttachmentPath())) {
					fileNameStrArr = kobean.getAttachmentPath().replace("\\", "/").split("/");
				}
				if (Objects.nonNull(fileNameStrArr) && fileNameStrArr.length > 0) {
					fileName = fileNameStrArr[fileNameStrArr.length - 1].replace("\\", "").replace("/", "");
				}
				kobean.setAttachmentDocumentName(fileName);
			} else {
				kobean.setAttachmentDocumentName(kobean.getAttachmentName());
				kobean.setAttachmentPath(kobean.getAttachmentPath() + "\\" + kobean.getAttachmentName());
			}
		}

	}

	/**
	 * Edits the KO.
	 *
	 * @param koInfo       the ko info
	 * @param modelAndView the model and view
	 * @param request      the request
	 * @param files        the files
	 * @param model        the model
	 * @return the string
	 */
	/*
	 * @PostMapping(value = "/editKO/{koId}") public String
	 * editKO(@ModelAttribute(CREATEKO_FORM) KOInfoBean koInfo, ModelAndView
	 * modelAndView, HttpServletRequest request, @RequestParam("file")
	 * MultipartFile[] files, Model model) { try { log.info("Start: editKO"); if
	 * (!StringUtils.isEmpty(request.getParameter(READONLY_KO))) {
	 * model.addAttribute(READONLY_KO, TRUE); } if
	 * (!StringUtils.isEmpty(request.getParameter(TICKETID_FROMVIEW)) ||
	 * !StringUtils.isEmpty(request.getParameter(READONLY_KO))) {
	 * model.addAttribute(FROM_HEADING, "View KO");
	 * model.addAttribute(TICKETID_FROMVIEW,
	 * request.getParameter(TICKETID_FROMVIEW)); } else {
	 * model.addAttribute(FROM_HEADING, "Edit KO"); } int totalExistingRec = 0; if
	 * (!StringUtils.isEmpty(request.getParameter("totalExistingRec"))) {
	 * totalExistingRec =
	 * Integer.parseInt(request.getParameter("totalExistingRec")); } String
	 * accountId = getDefaultAccountId(); UserBean ubean =
	 * userService.getUserAccountType(accountId); int isGeneric =
	 * ubean.getIsGeneric(); int helpdeskStatus =
	 * helpdeskController.getDisplayStatus(Integer.parseInt(accountId)); int
	 * koEnabledStatus = getKOEnabledStatus(Integer.parseInt(accountId));
	 * model.addAttribute("isKOEnabled", koEnabledStatus);
	 * model.addAttribute("isHelpdeskVisible", helpdeskStatus);
	 * model.addAttribute(IS_GENERIC, isGeneric); model.addAttribute(FROM_HEADING,
	 * "KO List");
	 * 
	 * String indexCountStr = request.getParameter("lastIndexVal"); int indexCount =
	 * 0; if (!StringUtils.isEmpty(indexCountStr)) { indexCount =
	 * Integer.parseInt(indexCountStr); } else { indexCount = totalExistingRec; }
	 * 
	 * String reviewComment = ""; String reworkArea = ""; String actionVal = ""; int
	 * newActionRequired = 0;
	 * 
	 * for (int recCnt = 1; recCnt < indexCount + 1; recCnt++) { String recCntStr =
	 * String.valueOf(recCnt); reviewComment =
	 * request.getParameter(koInfoService.strConcat("reviewcomments_" , recCntStr));
	 * reworkArea = request.getParameter(koInfoService.strConcat("reworkarea_" ,
	 * recCntStr)); actionVal =
	 * request.getParameter(koInfoService.strConcat("checkboxID_" , recCntStr)); if
	 * (!StringUtils.isEmpty(actionVal) && actionVal.equalsIgnoreCase("on")) {
	 * newActionRequired = 1; } else { newActionRequired = 0; }
	 * koInfo.setNewReviewComment(reviewComment);
	 * koInfo.setNewReworkArea(reworkArea);
	 * koInfo.setNewActionRequired(newActionRequired); if (recCnt >=
	 * totalExistingRec) { koInfoService.insertReviewComment(koInfo); } }
	 * model.addAttribute("koPublicationStatusVal", koInfo.getPublicationStatus());
	 * Authentication auth = SecurityContextHolder.getContext().getAuthentication();
	 * String loginusrname = auth.getName(); String userId = loginusrname;
	 * 
	 * koInfoService.updateKODetail(koInfo, files, userId);
	 * //MongoDBprocess.insertData(koInfo, getDefaultAccountId(), koInfo.getKoID(),
	 * koInfo.getPublicationStatus()); mlDBProcess.insertDataIntoPostgres(koInfo,
	 * getDefaultAccountId(), koInfo.getKoID(), koInfo.getPublicationStatus(),null);
	 * log.info("End: editKO"); return "redirect:../editKO/" + koInfo.getKoID(); }
	 * catch (IOException e) { log.error("editKO: " + e); return null; } }
	 */

	/**
	 * Insert review comment.
	 *
	 * @param koInfo       the ko info
	 * @param modelAndView the model and view
	 * @param model        the model
	 * @return the string
	 */
	@PostMapping(value = "/insertReviewComment")
	public String insertReviewComment(@ModelAttribute(CREATEKO_FORM) KOInfoBean koInfo, ModelAndView modelAndView,
			Model model) {
		koInfoService.insertReviewComment(koInfo);
		return "redirect:editKO/" + koInfo.getKoID();
	}

	/**
	 * Delete review comment.
	 *
	 * @param koInfo       the ko info
	 * @param modelAndView the model and view
	 * @param model        the model
	 * @param request      the request
	 * @return the string
	 */
	@PostMapping(value = "/deleteReviewComment")
	public String deleteReviewComment(@ModelAttribute(CREATEKO_FORM) KOInfoBean koInfo, ModelAndView modelAndView,
			Model model, HttpServletRequest request) {
		try {
			koInfoService.deleteReviewComment(Integer.parseInt(request.getParameter("paramReviewID")));
			return "redirect:editKO/" + koInfo.getKoID();
		} catch (NumberFormatException e) {
			log.error("deleteReviewComment: " + e);
			return null;
		}
	}

	/**
	 * Update review comment.
	 *
	 * @param modelAndView the model and view
	 * @param reviewId     the review id
	 * @param selectedVal  the selected val
	 * @param model        the model
	 * @param response     the response
	 * @param koInfo       the ko info
	 * @return the response entity
	 */
	@JsonIgnoreProperties
	@RequestMapping(value = "/updateReviewComment/{reviewId}/{selectedVal}")
	public ResponseEntity<?> updateReviewComment(ModelAndView modelAndView, @PathVariable String reviewId,
			@PathVariable String selectedVal, Model model, HttpServletResponse response,
			@ModelAttribute(CREATEKO_FORM) KOInfoBean koInfo) {
		getDefaultAccountId();
		int checkVal = 0;
		if (!StringUtils.isEmpty(selectedVal) && selectedVal.equalsIgnoreCase(TRUE)) {
			checkVal = 1;
		}
		String result = koInfoService.updateReviewComment(reviewId, checkVal);
		return ResponseEntity.ok(result);
	}

	/**
	 * Ko approval cycle list.
	 *
	 * @param koInfo  the ko info
	 * @param model   the model
	 * @param request the request
	 * @return the string
	 */
	@GetMapping("/koApprovalCycleList")
	public String koApprovalCycleList(@ModelAttribute(KOLINK_FORM_DETAIL) KOInfoBean koInfo, Model model,
			HttpServletRequest request) {
		log.info("Start: koApprovalCycleList");
		String accountId = getDefaultAccountId();

		model.addAttribute(REPORT_CATEGORIZATION, request.getParameter(REPORT_CATEGORIZATION));
		model.addAttribute(COMPONENT_TYPE, request.getParameter(COMPONENT_TYPE));
		model.addAttribute(REPORT_TYPE_STRING, request.getParameter(REPORT_TYPE_STRING));
		model.addAttribute(REPORT_NAME, request.getParameter(REPORT_NAME));
		model.addAttribute(REPORT_FREQUENCY, request.getParameter(REPORT_FREQUENCY));
		model.addAttribute(FROM_DATE_STRING, request.getParameter(FROM_DATE_STRING));
		model.addAttribute(TO_DATE, request.getParameter(TO_DATE));

		String fromDate = request.getParameter(FROM_DATE_STRING);
		koInfo.setFromDate(getStringOrNull(fromDate));

		String toDate = request.getParameter(TO_DATE);
		koInfo.setToDate(getStringOrNull(toDate));

		if (!StringUtils.isEmpty(accountId)) {
			model.addAttribute(DEFAULT_ACCOUNTNAME,
					ticketDataService.getAccountNameByAccountId(Integer.parseInt(accountId)));
		}

		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String loginusrname = auth.getName();
		if (!StringUtils.isEmpty(request.getParameter(CREATED_BY_STRING))) {
			koInfo.setCreatedBy(request.getParameter(CREATED_BY_STRING));
		}
		String fromReport = request.getParameter("fromReport");
		if (!StringUtils.isEmpty(fromReport)) {
			ReportDataAttributeVO reportDataAttributeVO = new ReportDataAttributeVO(accountId, loginusrname, KO_APPROVAL_CYCLE_REPORT_ID, VIEW_ACTION_ID);
			reportService.insertReportUsage(reportDataAttributeVO);
		}
		String appName = request.getParameter(APPNAME);

		if (!StringUtils.isEmpty(appName)) {
			koInfo.setApplicationName(appName);
		}
		List<KOInfoBean> koInfoBeanList = null;
		if (!StringUtils.isEmpty(request.getParameter(SHOW_RELATED_KO_STRING))) {
			koInfoBeanList = koInfoService.showAllRelatedKOs(request.getParameter(SHOW_RELATED_KO_STRING));
			model.addAttribute(READONLY_KO, TRUE);
		} else {
			KoDataAttributeVO koDtAttrVO= new KoDataAttributeVO();
			MasterDataAttributeVO masterDtAttrVo = new MasterDataAttributeVO(accountId,koInfo.getApplicationName(), koInfo.getAssignmentGroup(), "", "", "", "");
			masterDtAttrVo.setFromDateTodate(koInfo.getFromDate(), koInfo.getToDate());
			koDtAttrVO.setMasterDtAttrVo(masterDtAttrVo);
			KoDataAttribute koDtAtrr = new KoDataAttribute("", koInfo.getPublicationStatus(), "", "", koInfo.getCreatedBy(), 0);
			koDtAtrr.setReviewedBy(koInfo.getReviewedBy());
			koDtAtrr.setReworkComplete("3");
			koDtAtrr.setReviewComments("3");
			koDtAttrVO.setKoDtAttr(koDtAtrr);
			koInfoBeanList = koInfoService.koApprovalCycleListSP(koDtAttrVO);
		}
		String filterSelection = request.getParameter(FILTER_SELECTION);

		if (!StringUtils.isEmpty(filterSelection)) {
			model.addAttribute(FILTER_SELECTION, filterSelection);
		}
		UserBean ubean = userService.getUserAccountType(accountId);
		int isGeneric = ubean.getIsGeneric();
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		model.addAttribute(IS_GENERIC, isGeneric);
		addKOInfoDetailsToModel(model, koInfoBeanList);
		List<KOInfoBean> koInfoBeanListCopy = getKoInfoBeanCopy(koInfoBeanList);
		model.addAttribute(KO_INFO_LIST, koInfoBeanListCopy);
		model.addAttribute(FROM_HEADING, "KO Approval Cycle List");
		log.info("End: koApprovalCycleList");
		return "koApprovalCycleList";
	}

	/**
	 * Gets the string or null.
	 *
	 * @param string the string
	 * @return the string or null
	 */
	private String getStringOrNull(String string) {
		return !StringUtils.isEmpty(string) ? string : null;
	}

	/**
	 * Gets the ko info bean copy.
	 *
	 * @param koInfoBeanList the ko info bean list
	 * @return the ko info bean copy
	 */
	private List<KOInfoBean> getKoInfoBeanCopy(List<KOInfoBean> koInfoBeanList) {

		int serialNum = 1;
		boolean koIdExists = false;
		List<KOInfoBean> koInfoBeanListCopy = new ArrayList<KOInfoBean>();
		for (KOInfoBean koInfoBean : koInfoBeanList) {
			koIdExists = false;
			for (KOInfoBean koInfoBean1 : koInfoBeanListCopy) {
				if (!StringUtils.isEmpty(koInfoBean.getKoID())
						&& koInfoBean.getKoID().equalsIgnoreCase(koInfoBean1.getKoID())) {
					koIdExists = true;
				}
			}
			if (!koIdExists) {
				koInfoBean.setKoViewSerialNum(serialNum++);

				setKoInfoBeanYorN(koInfoBean);

				koInfoBeanListCopy.add(koInfoBean);
			}
		}
		return koInfoBeanListCopy;
	}

	/**
	 * Sets the ko info bean yor N.
	 *
	 * @param koInfoBean the new ko info bean yor N
	 */
	private void setKoInfoBeanYorN(KOInfoBean koInfoBean) {

		if (!StringUtils.isEmpty(koInfoBean.getPublicationStatus())
				&& (koInfoBean.getPublicationStatus().contains(APPROVED)
						|| koInfoBean.getPublicationStatus().contains(PUBLISHED))) {
			koInfoBean.setReviewedYorN("Y");
			koInfoBean.setApprovedYorN("Y");
			koInfoBean.setReworkCompletedYorN("Y");
		} else {
			koInfoBean.setReviewedYorN(koInfoBean.getPublicationStatus().contains("Rework") ? "Y" : "N");
			koInfoBean.setReworkCompletedYorN(koInfoBean.getPublicationStatus().contains("Review") ? "Y" : "N");
			koInfoBean.setApprovedYorN("N");
		}
		if (!StringUtils.isEmpty(koInfoBean.getReviewComments())) {
			koInfoBean.setReviewCommentsYorN("Y");
		} else {
			koInfoBean.setReviewCommentsYorN("N");
		}
	}

	/**
	 * Adds the KO info details to model.
	 *
	 * @param model the model
	 * @param koInfoBeanList the ko info bean list
	 */
	private void addKOInfoDetailsToModel(Model model, List<KOInfoBean> koInfoBeanList) {

		Set<String> allApplicationNameList = new TreeSet<String>();
		Set<String> allAssignmentGroupList = new TreeSet<String>();
		Set<String> allCreatedByList = new TreeSet<String>();
		Set<String> allReviewedByList = new TreeSet<String>();
		Set<String> allPublicationStatusList = new TreeSet<String>();
		koInfoBeanList.forEach(koList -> {
			if (!StringUtils.isEmpty(koList.getApplicationName())) {
				allApplicationNameList.add(koList.getApplicationName());
			}
			if (!StringUtils.isEmpty(koList.getAssignmentGroup())) {
				allAssignmentGroupList.add(koList.getAssignmentGroup());
			}
			if (!StringUtils.isEmpty(koList.getCreatedBy())) {
				allCreatedByList.add(koList.getCreatedBy());
			}
			if (!StringUtils.isEmpty(koList.getReviewedBy())) {
				allReviewedByList.add(koList.getReviewedBy());
			}
			if (!StringUtils.isEmpty(koList.getPublicationStatus())) {
				allPublicationStatusList.add(koList.getPublicationStatus());
			}
		});

		model.addAttribute(APPLICATION_NAMELIST, allApplicationNameList);
		model.addAttribute(ALL_ASSIGNMENT_GROUPLIST, allAssignmentGroupList);
		model.addAttribute(ALL_CREATED_BY_LIST, allCreatedByList);
		model.addAttribute("allReviewedByList", allReviewedByList);
		model.addAttribute(ALL_PUBLICATION_STATUSLIST, allPublicationStatusList);

	}

	/**
	 * Ko approval cycle list POST.
	 *
	 * @param koInfo  the ko info
	 * @param model   the model
	 * @param request the request
	 * @return the string
	 */
	@PostMapping("/koApprovalCycleList")
	public String koApprovalCycleListPOST(@ModelAttribute(KOLINK_FORM_DETAIL) KOInfoBean koInfo, Model model,
			HttpServletRequest request) {
		log.info("Start: koApprovalCycleListPOST");
		String accountId = getDefaultAccountId();

		model.addAttribute(REPORT_CATEGORIZATION, request.getParameter(REPORT_CATEGORIZATION));
		model.addAttribute(COMPONENT_TYPE, request.getParameter(COMPONENT_TYPE));
		model.addAttribute(REPORT_TYPE_STRING, request.getParameter(REPORT_TYPE_STRING));
		model.addAttribute(REPORT_NAME, request.getParameter(REPORT_NAME));
		model.addAttribute(REPORT_FREQUENCY, request.getParameter(REPORT_FREQUENCY));
		model.addAttribute(FROM_DATE_STRING, request.getParameter(FROM_DATE_STRING));
		model.addAttribute(TO_DATE, request.getParameter(TO_DATE));
		String fromDate = request.getParameter(FROM_DATE_STRING);
		if (!StringUtils.isEmpty(fromDate)) {
			koInfo.setFromDate(fromDate);
		}
		String toDate = request.getParameter(TO_DATE);
		if (!StringUtils.isEmpty(toDate)) {
			koInfo.setToDate(toDate);
		}
		if (!StringUtils.isEmpty(accountId)) {
			model.addAttribute(DEFAULT_ACCOUNTNAME,
					ticketDataService.getAccountNameByAccountId(Integer.parseInt(accountId)));
		}
		if (!StringUtils.isEmpty(request.getParameter(CREATED_BY_STRING))) {
			koInfo.setCreatedBy(request.getParameter(CREATED_BY_STRING));
		}
		String appName = request.getParameter(APPNAME);
		if (!StringUtils.isEmpty(appName)) {
			koInfo.setApplicationName(appName);
		}

		List<KOInfoBean> koInfoBeanList = null;
		if (!StringUtils.isEmpty(request.getParameter(SHOW_RELATED_KO_STRING))) {
			koInfoBeanList = koInfoService.showAllRelatedKOs(request.getParameter(SHOW_RELATED_KO_STRING));
			model.addAttribute(READONLY_KO, TRUE);
		} else {
			KoDataAttributeVO koDtAttrVO= new KoDataAttributeVO();
			MasterDataAttributeVO masterDtAttrVo = new MasterDataAttributeVO(accountId,koInfo.getApplicationName(), koInfo.getAssignmentGroup(), "", "", "", "");
			masterDtAttrVo.setFromDateTodate(koInfo.getFromDate(), koInfo.getToDate());
			koDtAttrVO.setMasterDtAttrVo(masterDtAttrVo);
			KoDataAttribute koDtAtrr = new KoDataAttribute("", koInfo.getPublicationStatus(), "", "", koInfo.getCreatedBy(), 0);
			koDtAtrr.setReviewedBy(koInfo.getReviewedBy());
			koDtAtrr.setReworkComplete(koInfo.getReworkCompletedYorN());
			koDtAtrr.setReviewComments(koInfo.getReviewCommentsYorN());
			koDtAttrVO.setKoDtAttr(koDtAtrr);
			koInfoBeanList = koInfoService.koApprovalCycleListSP(koDtAttrVO);
		}

		String filterSelection = request.getParameter(FILTER_SELECTION);

		if (!StringUtils.isEmpty(filterSelection)) {
			model.addAttribute(FILTER_SELECTION, filterSelection);
		}

		addKOInfoDetailsToModel(model, koInfoBeanList);
		List<KOInfoBean> koInfoBeanListCopy = getKoInfoBeanCopy(koInfoBeanList);
		UserBean ubean = userService.getUserAccountType(accountId);
		int isGeneric = ubean.getIsGeneric();
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		model.addAttribute(IS_GENERIC, isGeneric);
		model.addAttribute(KO_INFO_LIST, koInfoBeanListCopy);
		model.addAttribute(FROM_HEADING, "KO Approval Cycle List");
		log.info("End: koApprovalCycleListPOST");
		return "koApprovalCycleList";
	}

	/**
	 * Ko usage report.
	 *
	 * @param koInfo  the ko info
	 * @param model   the model
	 * @param request the request
	 * @return the string
	 */
	@GetMapping("/koUsageReport")
	public String koUsageReport(@ModelAttribute("koUsageReportFormDetail") KOInfoBean koInfo, Model model,
			HttpServletRequest request) {
		String accountId = getDefaultAccountId();
		model.addAttribute(REPORT_CATEGORIZATION, request.getParameter(REPORT_CATEGORIZATION));
		model.addAttribute(COMPONENT_TYPE, request.getParameter(COMPONENT_TYPE));
		model.addAttribute(REPORT_TYPE_STRING, request.getParameter(REPORT_TYPE_STRING));
		model.addAttribute(REPORT_NAME, request.getParameter(REPORT_NAME));
		model.addAttribute(REPORT_FREQUENCY, request.getParameter(REPORT_FREQUENCY));
		model.addAttribute(FROM_DATE_STRING, request.getParameter(FROM_DATE_STRING));
		model.addAttribute(TO_DATE, request.getParameter(TO_DATE));

		if (!StringUtils.isEmpty(accountId)) {
			model.addAttribute(DEFAULT_ACCOUNTNAME,
					ticketDataService.getAccountNameByAccountId(Integer.parseInt(accountId)));
		}

		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String loginusrname = auth.getName();
		String appName = request.getParameter(APPNAME);
		ReportDataAttributeVO reportDataAttributeVO = new ReportDataAttributeVO(accountId, loginusrname, KO_USAGE_REPORT_ID, VIEW_ACTION_ID);
		reportService.insertReportUsage(reportDataAttributeVO);
		koInfo.setApplicationName(getStringOrNull(appName));
		List<KOInfoBean> koInfoBeanListusage = null;
		MasterDataAttributeVO masterDataAttributeVO = new MasterDataAttributeVO(accountId, koInfo.getApplicationName(), koInfo.getAssignmentGroup(), koInfo.getTower(), koInfo.getCC(), koInfo.getCluster(), "");
		masterDataAttributeVO.setFromDateTodate(koInfo.getFromDate(), koInfo.getToDate());
		koInfoBeanListusage = koInfoService.koUsageReportSP(masterDataAttributeVO, koInfo.getKoType());

		Set<String> allApplicationNamesSet = new HashSet<String>();
		Set<String> allAssignmentGroupSet = new HashSet<String>();
		Set<String> allTowersSet = new HashSet<String>();
		Set<String> allCCsSet = new HashSet<String>();
		Set<String> allClustersSet = new HashSet<String>();

		koInfoBeanListusage.forEach(koList -> {
			allApplicationNamesSet.add(koList.getApplicationName());
			allAssignmentGroupSet.add(koList.getAssignmentGroup());
			if (!StringUtils.isEmpty(koList.getTower())) {
				allTowersSet.add(koList.getTower());
			}
			if (!StringUtils.isEmpty(koList.getCC())) {
				allCCsSet.add(koList.getCC());
			}
			if (!StringUtils.isEmpty(koList.getCluster())) {
				allClustersSet.add(koList.getCluster());
			}
		});

		UserBean ubean = userService.getUserAccountType(accountId);
		int isGeneric = ubean.getIsGeneric();
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		model.addAttribute(IS_GENERIC, isGeneric);
		model.addAttribute(KO_TYPE, koInfo.getKoType());
		model.addAttribute(APPLICATION_NAMELIST, allApplicationNamesSet);
		model.addAttribute(ALL_ASSIGNMENT_GROUPLIST, allAssignmentGroupSet);
		model.addAttribute("allTowersList", allTowersSet);
		model.addAttribute("allCCsList", allCCsSet);
		model.addAttribute("allClusters", allClustersSet);

		model.addAttribute("koUsageReportList", koInfoBeanListusage);
		model.addAttribute(FROM_HEADING, "KO Usage Report List");

		return "koUsageReport";
	}

	/**
	 * Ko usage report POST.
	 *
	 * @param koInfo  the ko info
	 * @param model   the model
	 * @param request the request
	 * @return the string
	 */
	@PostMapping("/koUsageReport")
	public String koUsageReportPOST(@ModelAttribute("koUsageReportFormDetail") KOInfoBean koInfo, Model model,
			HttpServletRequest request) {
		String accountId = getDefaultAccountId();
		model.addAttribute(REPORT_CATEGORIZATION, request.getParameter(REPORT_CATEGORIZATION));
		model.addAttribute(COMPONENT_TYPE, request.getParameter(COMPONENT_TYPE));
		model.addAttribute(REPORT_TYPE_STRING, request.getParameter(REPORT_TYPE_STRING));
		model.addAttribute(REPORT_NAME, request.getParameter(REPORT_NAME));
		model.addAttribute(REPORT_FREQUENCY, request.getParameter(REPORT_FREQUENCY));
		model.addAttribute(FROM_DATE_STRING, request.getParameter(FROM_DATE_STRING));
		model.addAttribute(TO_DATE, request.getParameter(TO_DATE));
		if (!StringUtils.isEmpty(accountId)) {
			model.addAttribute(DEFAULT_ACCOUNTNAME,
					ticketDataService.getAccountNameByAccountId(Integer.parseInt(accountId)));
		}

		List<KOInfoBean> koInfoBeanListusage = null;
		MasterDataAttributeVO masterDataAttributeVO = new MasterDataAttributeVO(accountId, koInfo.getApplicationName(), koInfo.getAssignmentGroup(), koInfo.getTower(), koInfo.getCC(), koInfo.getCluster(), "");
		masterDataAttributeVO.setFromDateTodate(koInfo.getFromDate(), koInfo.getToDate());
		koInfoBeanListusage = koInfoService.koUsageReportSP(masterDataAttributeVO, koInfo.getKoType());

		Set<String> allApplicationNamesSet = new HashSet<String>();
		Set<String> allAssignmentGroupSet = new HashSet<String>();
		Set<String> allTowersSet = new HashSet<String>();
		Set<String> allCCsSet = new HashSet<String>();
		Set<String> allClustersSet = new HashSet<String>();

		for (KOInfoBean koList : koInfoBeanListusage) {
			allApplicationNamesSet.add(koList.getApplicationName());
			allAssignmentGroupSet.add(koList.getAssignmentGroup());
			if (!StringUtils.isEmpty(koList.getTower())) {
				allTowersSet.add(koList.getTower());
			}
			if (!StringUtils.isEmpty(koList.getCC())) {
				allCCsSet.add(koList.getCC());
			}
			if (!StringUtils.isEmpty(koList.getCluster())) {
				allClustersSet.add(koList.getCluster());
			}
		}

		UserBean ubean = userService.getUserAccountType(accountId);
		int isGeneric = ubean.getIsGeneric();
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		model.addAttribute(IS_GENERIC, isGeneric);
		model.addAttribute(KO_TYPE, koInfo.getKoType());
		model.addAttribute(APPLICATION_NAMELIST, allApplicationNamesSet);
		model.addAttribute(ALL_ASSIGNMENT_GROUPLIST, allAssignmentGroupSet);
		model.addAttribute("allTowersList", allTowersSet);
		model.addAttribute("allCCsList", allCCsSet);
		model.addAttribute("allClusters", allClustersSet);

		model.addAttribute("koUsageReportList", koInfoBeanListusage);
		model.addAttribute(FROM_HEADING, "KO Usage Report List");

		return "koUsageReport";
	}

	/**
	 * Linkage dashboard get ajax.
	 *
	 * @param tower           the tower
	 * @param cc              the cc
	 * @param cluster         the cluster
	 * @param assignmentGroup the assignment group
	 * @param applicationName the application name
	 * @param fromDate        the from date
	 * @param toDate          the to date
	 * @param freq            the freq
	 * @param group           the group
	 * @return the string
	 */
	@RequestMapping(value = "/linkageDashboardAjax", headers = ACCEPT_TYPES, method = RequestMethod.GET)
	public @ResponseBody String linkageDashboardGetAjax(@RequestParam(value = TOWER) String tower,
			@RequestParam("cc") String cc, @RequestParam(value = CLUSTER_STRING) String cluster,
			@RequestParam("assignmentGroup") String assignmentGroup,
			@RequestParam("applicationName") String applicationName,
			@RequestParam(value = FROM_DATE_STRING) String fromDate, @RequestParam(TO_DATE) String toDate,
			@RequestParam(value = FREQ) String freq, @RequestParam("group") String group) {
		log.info("Start: linkageDashboardAjaxGet");
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String loginusrname = auth.getName();
		String userId = loginusrname;
		String accountId = getDefaultAccountId();
		List<KOInfoBean> koLinkageGraphList = null;

		KoDataAttributeVO KoAttrVo= new KoDataAttributeVO();
		MasterDataAttributeVO masterDtAttrVo = new MasterDataAttributeVO(accountId,applicationName, assignmentGroup, tower, cc, cluster, userId);
		masterDtAttrVo.setFromDateTodate(fromDate, toDate);
		KoAttrVo.setMasterDtAttrVo(masterDtAttrVo);
		KoAttrVo.setFreq(freq);
		KoAttrVo.setGroup(group);
		koLinkageGraphList = koInfoService.koLinkageGraphSP(KoAttrVo);
		ReportDataAttributeVO reportDataAttributeVO = new ReportDataAttributeVO(accountId, userId, KO_RESOLVED_CHART_ID, CHART_VIEW_ACTION_ID);
		reportService.insertReportUsage(reportDataAttributeVO);

		List<String> monthsList = new ArrayList<>();
		List<Object> ticketDataList = new ArrayList<>();
		List<Object> koDataList = new ArrayList<>();
		List<Object> ticketPredictionDataList = new ArrayList<>();
		List<Object> koPredictionDataList = new ArrayList<>();

		for (KOInfoBean x : koLinkageGraphList) {
			monthsList.add(x.getKomonth());
		}
		for (KOInfoBean x : koLinkageGraphList) {
			ticketDataList.add(x.getTicketLinkCount());
		}
		for (KOInfoBean x : koLinkageGraphList) {
			koDataList.add(x.getKoLinkedCount());
		}
		Gson gson = new Gson();
		String strmonthsList = gson.toJson(monthsList);
		String strkoResolvedDataList = gson.toJson(ticketDataList);
		String strkoLinkedDataList = gson.toJson(koDataList);
		String strkoResolvedPredictionDataList = gson.toJson(ticketPredictionDataList);
		String strkoLinkedPredictionDataList = gson.toJson(koPredictionDataList);

		String koLinkedDataListJson = strkoLinkedDataList.replaceAll("\"", "@@");
		String monthsListJson = strmonthsList.replaceAll("\"", "@@");
		String koResolvedDataListJson = strkoResolvedDataList.replaceAll("\"", "@@");
		String koResolvedPredDataListJson = strkoResolvedPredictionDataList.replaceAll("\"", "@@");
		String koLinkedPredDataListJson = strkoLinkedPredictionDataList.replaceAll("\"", "@@");

		List<HashMap<String, String>> listOfHashmap = new ArrayList<>();
		HashMap<String, String> convertThis = new HashMap<>();
		convertThis.put("monthsList", monthsListJson);
		convertThis.put("koResolvedDataListJson", koResolvedDataListJson);
		convertThis.put("koResolvedPredDataListJson", koResolvedPredDataListJson);
		convertThis.put("koLinkedPredDataListJson", koLinkedPredDataListJson);
		convertThis.put("koLinkedDataListJson", koLinkedDataListJson);
		listOfHashmap.add(convertThis);
		String allJson = gson.toJson(convertThis);
		log.info("End: linkageDashboardAjaxGet");
		return allJson;

	}

	/**
	 * Ko usage dashboard get ajax.
	 *
	 * @param tower           the tower
	 * @param cc              the cc
	 * @param cluster         the cluster
	 * @param assignmentGroup the assignment group
	 * @param applicationName the application name
	 * @param fromDate        the from date
	 * @param toDate          the to date
	 * @param freq            the freq
	 * @param group           the group
	 * @return the string
	 */
	@RequestMapping(value = "/koUsageDashboardAjax", headers = ACCEPT_TYPES, method = RequestMethod.GET)
	public @ResponseBody String koUsageDashboardGetAjax(@RequestParam(value = TOWER) String tower,
			@RequestParam("cc") String cc, @RequestParam(value = CLUSTER_STRING) String cluster,
			@RequestParam("assignmentGroup") String assignmentGroup,
			@RequestParam("applicationName") String applicationName,
			@RequestParam(value = FROM_DATE_STRING) String fromDate, @RequestParam(TO_DATE) String toDate,
			@RequestParam(value = FREQ) String freq, @RequestParam("group") String group) {
		log.info("Start: KoUsageDashboardAjaxGet");
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String loginusrname = auth.getName();
		String userId = loginusrname;
		String accountId = getDefaultAccountId();
		List<KOInfoBean> kousagegraphList = null;

		KoDataAttributeVO KoAttrVo= new KoDataAttributeVO();
		MasterDataAttributeVO masterDtAttrVo = new MasterDataAttributeVO(accountId,applicationName, assignmentGroup, tower, cc, cluster, userId);
		masterDtAttrVo.setFromDateTodate(fromDate, toDate);
		KoAttrVo.setMasterDtAttrVo(masterDtAttrVo);
		KoAttrVo.setFreq(freq);
		KoAttrVo.setGroup(group);
		kousagegraphList = koInfoService.koUsageGraphSP(KoAttrVo);
		ReportDataAttributeVO reportDataAttributeVO = new ReportDataAttributeVO(accountId, userId, KO_USAGE_CHART_ID, CHART_VIEW_ACTION_ID);
		reportService.insertReportUsage(reportDataAttributeVO);

		List<String> monthsList = new ArrayList<>();
		List<Object> koDataList = new ArrayList<>();
		List<Object> koPredDataList = new ArrayList<>();

		for (KOInfoBean x : kousagegraphList) {
			monthsList.add(x.getKoLinkedMonth());
		}
		for (KOInfoBean x : kousagegraphList) {
			koDataList.add(x.getKoIDCount());
		}

		Gson gson = new Gson();
		String strmonthsList = gson.toJson(monthsList);
		String strkoLinkedDataList = gson.toJson(koDataList);
		String strkoLinkedPredDataList = gson.toJson(koPredDataList);
		String monthsListJson = strmonthsList.replaceAll("\"", "@@");
		String koLinkedDataListJson = strkoLinkedDataList.replaceAll("\"", "@@");
		String koLinkedPredDataListJson = strkoLinkedPredDataList.replaceAll("\"", "@@");

		List<HashMap<String, String>> listOfHashmap = new ArrayList<>();
		HashMap<String, String> convertThis = new HashMap<>();
		convertThis.put("monthsList", monthsListJson);
		convertThis.put("koLinkedDataListJson", koLinkedDataListJson);
		convertThis.put("koLinkedPredDataListJson", koLinkedPredDataListJson);
		listOfHashmap.add(convertThis);
		String allJson = gson.toJson(convertThis);
		log.info("End: KoUsageDashboardAjaxGet");
		return allJson;
	}

	/**
	 * Ko published dashboard get ajax.
	 *
	 * @param tower           the tower
	 * @param cc              the cc
	 * @param cluster         the cluster
	 * @param assignmentGroup the assignment group
	 * @param applicationName the application name
	 * @param fromDate        the from date
	 * @param toDate          the to date
	 * @param freq            the freq
	 * @param group           the group
	 * @return the string
	 */
	@RequestMapping(value = "/koPublishedTrendDashboardAjax", headers = ACCEPT_TYPES, method = RequestMethod.GET)
	public @ResponseBody String koPublishedDashboardGetAjax(@RequestParam(value = TOWER) String tower,
			@RequestParam("cc") String cc, @RequestParam(value = CLUSTER_STRING) String cluster,
			@RequestParam("assignmentGroup") String assignmentGroup,
			@RequestParam("applicationName") String applicationName,
			@RequestParam(value = FROM_DATE_STRING) String fromDate, @RequestParam(TO_DATE) String toDate,
			@RequestParam(value = FREQ) String freq, @RequestParam("group") String group) {
		log.info("Start: koPublishedTrendDashboardAjax");
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String loginusrname = auth.getName();
		String userId = loginusrname;
		String accountId = getDefaultAccountId();
		List<KOInfoBean> kopubgraphList = null;
		List<KOInfoBean> kocreatedgraphList = null;

		KoDataAttributeVO KoAttrVo= new KoDataAttributeVO();
		KoAttrVo.setMasterDtAttrVo(new MasterDataAttributeVO(accountId,applicationName, assignmentGroup, tower, cc, cluster, userId));
		KoAttrVo.getMasterDtAttrVo().setFromDateTodate(fromDate, toDate);
		KoAttrVo.setFreq(freq);
		KoAttrVo.setGroup(group);
		kopubgraphList = koInfoService.kopubgraphSP(KoAttrVo);
		kocreatedgraphList = koInfoService.koCreatedGraphSP(KoAttrVo);
		ReportDataAttributeVO reportDataAttributeVO = new ReportDataAttributeVO(accountId, userId, KO_PUBLISHED_CHART_ID, CHART_VIEW_ACTION_ID);
		reportService.insertReportUsage(reportDataAttributeVO);

		List<String> pubMonthsList = new ArrayList<>();
		List<String> createdMonthsList = new ArrayList<>();

		List<Object> createdDataList = new ArrayList<>();
		List<Object> publishedDataList = new ArrayList<>();

		List<Object> createdPredDataList = new ArrayList<>();
		List<Object> publishedPredDataList = new ArrayList<>();

		for (KOInfoBean x : kopubgraphList) {
			pubMonthsList.add(x.getKomonth());
		}
		for (KOInfoBean x : kocreatedgraphList) {
			createdMonthsList.add(x.getKomonth());
		}
		for (KOInfoBean x : kocreatedgraphList) {
			createdDataList.add(x.getKoIDCount());
		}
		for (KOInfoBean x : kopubgraphList) {
			publishedDataList.add(x.getKoIDCount());
		}
		Gson gson = new Gson();
		String strpubMonthsList = gson.toJson(pubMonthsList);
		String strcreatedMonthsList = gson.toJson(createdMonthsList);
		String strkopublishedDataList = gson.toJson(publishedDataList);
		String strkoCreatedDataList = gson.toJson(createdDataList);
		String strkopublishedPredDataList = gson.toJson(publishedPredDataList);
		String strkoCreatedPredDataList = gson.toJson(createdPredDataList);

		String koCreatedDataListJson = strkoCreatedDataList.replaceAll("\"", "@@");
		String pubMonthsListJson = strpubMonthsList.replaceAll("\"", "@@");
		String createdMonthsListJson = strcreatedMonthsList.replaceAll("\"", "@@");
		String koLinkedDataListJson = strkopublishedDataList.replaceAll("\"", "@@");
		String koCreatedPredDataListJson = strkoCreatedPredDataList.replaceAll("\"", "@@");
		String koLinkedPredDataListJson = strkopublishedPredDataList.replaceAll("\"", "@@");

		List<HashMap<String, String>> listOfHashmap = new ArrayList<>();
		HashMap<String, String> convertThis = new HashMap<>();
		convertThis.put("createdMonthsList", createdMonthsListJson);
		convertThis.put("pubMonthsList", pubMonthsListJson);
		convertThis.put("koLinkedDataListJson", koLinkedDataListJson);
		convertThis.put("koCreatedDataListJson", koCreatedDataListJson);
		convertThis.put("koCreatedPredDataListJson", koCreatedPredDataListJson);
		convertThis.put("koLinkedPredDataListJson", koLinkedPredDataListJson);
		listOfHashmap.add(convertThis);

		String allJson = gson.toJson(convertThis);
		log.info("End: koPublishedTrendDashboardAjax");
		return allJson;
	}

	/**
	 * Koavaildistrchartdispgetload.
	 *
	 * @param freq          the freq
	 * @param fromDate the from date
	 * @param toDate the to date
	 * @param tower         the tower
	 * @param cc            the cc
	 * @param cluster       the cluster
	 * @param asgngrp       the asgngrp
	 * @param appsname      the appsname
	 * @return the string
	 */
	@RequestMapping(value = "/koavaildistrchartdispload", headers = ACCEPT_TYPES, method = RequestMethod.GET)
	public @ResponseBody String koavaildistrchartdispgetload(@RequestParam(value = FREQ) String freq,
			@RequestParam(value = FROM_DATE) String fromDate, @RequestParam(value = TO_DATE_STRING) String toDate,
			@RequestParam(value = TOWER) String tower, @RequestParam(value = "cc") String cc,
			@RequestParam(value = CLUSTER_STRING) String cluster, @RequestParam(value = ASGNGRP) String asgngrp,
			@RequestParam(value = APPSNAME) String appsname) {

		DateTimeFormatter newPattern = DateTimeFormatter.ofPattern(YYYMMDD);
		LocalDate today = LocalDate.now();
		String searchfrmdate = fromDate;
		String searchtodate = toDate;

		searchtodate = today.format(newPattern);
		searchfrmdate = getSearchFrmDate(freq, searchfrmdate);
		log.info("Start: koavaildistrchartdispload");
		Gson gson = new Gson();

		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String loginusrname = auth.getName();
		String userId = loginusrname;
		String accountId = getDefaultAccountId();

		// KO Availability Distribution (Overall)
		List<KOInfoBean> koavaldistList = null;
		MasterDataAttributeVO masterDataAttributeVO = new MasterDataAttributeVO(accountId, appsname, asgngrp, tower, cc, cluster, userId);
		masterDataAttributeVO.setFromDateTodate(searchfrmdate, searchtodate);
		koavaldistList = koInfoService.koavaldistSP(masterDataAttributeVO);
		ReportDataAttributeVO reportDataAttributeVO = new ReportDataAttributeVO(accountId, userId, KO_AVAIL_DIST_CHART_ID, CHART_VIEW_ACTION_ID);
		reportService.insertReportUsage(reportDataAttributeVO);
		java.util.List<Item> kodis = new ArrayList<>();
		koavaldistList.forEach(koaval -> {
			kodis.add(new Item(koaval.getTower(), koaval.getCC(), koaval.getCluster(), koaval.getAssignmentGroup(),
					koaval.getApplicationName(), koaval.getKoCount()));
		});

		// Tower;
		Map<String, Integer> towersum = kodis.stream()
				.collect(Collectors.groupingBy(Item::getTower, Collectors.summingInt(Item::getKoCount)));

		List<String> towersummonthsList = new ArrayList<>();
		List<Object> towersumkoLinkedDataList = new ArrayList<>();

		// convert hashmap to list of keys and values
		towersummonthsList = towersum.keySet().stream().collect(Collectors.toCollection(ArrayList::new));
		towersumkoLinkedDataList = towersum.values().stream().collect(Collectors.toCollection(ArrayList::new));

		// CC data
		Map<String, Integer> ccsum = kodis.stream()
				.collect(Collectors.groupingBy(Item::getCC, Collectors.summingInt(Item::getKoCount)));

		List<String> ccsummonthsList = new ArrayList<>();
		List<Object> ccsumkoLinkedDataList = new ArrayList<>();

		// convert hashmap to list of keys and values
		ccsummonthsList = ccsum.keySet().stream().collect(Collectors.toCollection(ArrayList::new));
		ccsumkoLinkedDataList = ccsum.values().stream().collect(Collectors.toCollection(ArrayList::new));

		// Cluster
		Map<String, Integer> culstersum = kodis.stream()
				.collect(Collectors.groupingBy(Item::getCluster, Collectors.summingInt(Item::getKoCount)));
		List<String> culstersummonthsList = new ArrayList<>();
		List<Object> culstersumkoLinkedDataList = new ArrayList<>();

		// convert hashmap to list of keys and values
		culstersummonthsList = culstersum.keySet().stream().collect(Collectors.toCollection(ArrayList::new));
		culstersumkoLinkedDataList = culstersum.values().stream().collect(Collectors.toCollection(ArrayList::new));

		// Assignment group
		Map<String, Integer> asgmtgrpsum = kodis.stream()
				.collect(Collectors.groupingBy(Item::getAssignmentGroup, Collectors.summingInt(Item::getKoCount)));
		List<String> asgmtgrpsummonthsList = new ArrayList<>();

		// convert hashmap to list of keys and values
		asgmtgrpsummonthsList = asgmtgrpsum.keySet().stream().collect(Collectors.toCollection(ArrayList::new));

		// Application name
		Map<String, Integer> appsnamesum = kodis.stream()
				.collect(Collectors.groupingBy(Item::getApplicationName, Collectors.summingInt(Item::getKoCount)));
		List<String> appsnamesummonthsList = new ArrayList<>();
		List<Object> appsnamesumkoLinkedDataList = new ArrayList<>();

		// convert hashmap to list of keys and values
		appsnamesummonthsList = appsnamesum.keySet().stream().collect(Collectors.toCollection(ArrayList::new));
		appsnamesumkoLinkedDataList = appsnamesum.values().stream().collect(Collectors.toCollection(ArrayList::new));

		List<HashMap<String, String>> charthashmp = new ArrayList<>();
		HashMap<String, String> chartdatamp = new HashMap<>();

		chartdatamp.put(TOWER_MONTHS_LIST, jsonReplace(towersummonthsList)); // strTowersummonthsListrep);
		chartdatamp.put(TOWER_KOLINKED_DATALIST, jsonReplace(towersumkoLinkedDataList)); // strTowersumkoLinkedDataListrep);
		chartdatamp.put(CC_MONTHS_LIST, jsonReplace(ccsummonthsList)); // strCCsummonthsListrep);
		chartdatamp.put(CC_KOLINKED_DATALIST, jsonReplace(ccsumkoLinkedDataList)); // strCCsumkoLinkedDataListrep);
		chartdatamp.put(STRCULSTER_SUM_MONTHSLIST, jsonReplace(culstersummonthsList)); // strCulstersummonthsListrep);
		chartdatamp.put(CULSTER_KOLINKED_DATALIST, jsonReplace(culstersumkoLinkedDataList)); // strCulstersumkoLinkedDataListrep);
		chartdatamp.put(ASGMTGRP_MONTHSLIST, jsonReplace(asgmtgrpsummonthsList)); // strAsgmtgrpsummonthsListrep);
		chartdatamp.put(ASGMTGRP_KOLINKED_DATALIST, jsonReplace(appsnamesumkoLinkedDataList)); // strAppsnamesumkoLinkedDataListrep);
		chartdatamp.put("strAppsname_sum_monthsList", jsonReplace(appsnamesummonthsList)); // strAppsnamesummonthsListrep);
		chartdatamp.put("strAppsname_sum_koLinkedDataList", jsonReplace(appsnamesumkoLinkedDataList)); // strAppsnamesumkoLinkedDataListrep);
		charthashmp.add(chartdatamp);

		String chartdatajson = gson.toJson(chartdatamp);
		log.info("End: try_koavaildistrchartdispload");
		return chartdatajson;
	}

	/**
	 * Gets the search frm date.
	 *
	 * @param freq the freq
	 * @param searchfrmdate1 the searchfrmdate 1
	 * @return the search frm date
	 */
	private String getSearchFrmDate(String freq, String searchfrmdate1) {
		String searchfrmdate = searchfrmdate1;
		LocalDate today = LocalDate.now();
		DateTimeFormatter newPattern = DateTimeFormatter.ofPattern(YYYMMDD);

		LocalDate wkstrday = today;
		boolean isNonMonday = !Objects.equals(wkstrday.getDayOfWeek(), DayOfWeek.MONDAY);
		while (isNonMonday) {
			wkstrday = wkstrday.minusDays(1);
			isNonMonday = !Objects.equals(wkstrday.getDayOfWeek(), DayOfWeek.MONDAY);
		}
		// Go forward to get Sunday
		LocalDate wkendday = today;
		boolean isNonSunday=!Objects.equals(wkendday.getDayOfWeek(), DayOfWeek.SUNDAY);
		while (isNonSunday) {
			wkendday = wkendday.plusDays(1);
			isNonSunday=!Objects.equals(wkendday.getDayOfWeek(), DayOfWeek.SUNDAY);
		}
		switch (freq.toLowerCase(Locale.getDefault())) {
		case "daily":
			searchfrmdate = today.format(newPattern);
			break;
		case "weekly":
			searchfrmdate = wkstrday.format(newPattern);
			break;
		case "monthly":
			searchfrmdate = today.withDayOfMonth(1).format(newPattern);
			break;
		case "quartely":
			LocalDate thremnthstartday = today.minusMonths(3);
			searchfrmdate = thremnthstartday.format(DateTimeFormatter.ofPattern(YYYMMDD));
			break;
		case "half yearly":
			LocalDate sixmnthstartday = today.minusMonths(6);
			searchfrmdate = (sixmnthstartday).format(DateTimeFormatter.ofPattern(YYYMMDD));
			break;
		case "annual":
			LocalDate sixmnthstartday1 = today.minusMonths(12);
			searchfrmdate = (sixmnthstartday1).format(DateTimeFormatter.ofPattern(YYYMMDD));
			break;
		case "year to date":
			searchfrmdate = (today.withDayOfYear(1)).format(newPattern);
			break;
		default:
			break;
		}
		return searchfrmdate;
	}

	/**
	 * Inclinkdistrchartdispgetload.
	 *
	 * @param freq          the freq
	 * @param fromDate the from date
	 * @param toDate the to date
	 * @param tower         the tower
	 * @param cc            the cc
	 * @param cluster       the cluster
	 * @param asgngrp       the asgngrp
	 * @param appsname      the appsname
	 * @return the string
	 */
	@RequestMapping(value = "/inclinkdistrchartdispload", headers = ACCEPT_TYPES, method = RequestMethod.GET)
	public @ResponseBody String inclinkdistrchartdispgetload(@RequestParam(value = FREQ) String freq,
			@RequestParam(value = FROM_DATE) String fromDate, @RequestParam(value = TO_DATE_STRING) String toDate,
			@RequestParam(value = TOWER) String tower, @RequestParam(value = "cc") String cc,
			@RequestParam(value = CLUSTER_STRING) String cluster, @RequestParam(value = ASGNGRP) String asgngrp,
			@RequestParam(value = APPSNAME) String appsname) {

		DateTimeFormatter newPattern = DateTimeFormatter.ofPattern(YYYMMDD);
		LocalDate today = LocalDate.now();
		String searchfrmdate = fromDate;
		String searchtodate = toDate;

		searchtodate = today.format(newPattern);
		searchfrmdate = getSearchFrmDate(freq, searchfrmdate);

		log.info("Start: inclinkdistrchartdispload");
		Gson gson = new Gson();
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String loginusrname = auth.getName();
		String userId = loginusrname;
		String accountId = getDefaultAccountId();

		// KO Availability Distribution (Overall)

		List<KOInfoBean> koavaldistList = null;
		MasterDataAttributeVO masterDataAttributeVO = new MasterDataAttributeVO(accountId, appsname, asgngrp, tower, cc, cluster, userId);
		masterDataAttributeVO.setFromDateTodate(searchfrmdate, searchtodate);		
		koavaldistList = koInfoService.inclinked(masterDataAttributeVO);
		ReportDataAttributeVO reportDataAttributeVO = new ReportDataAttributeVO(accountId, userId, INC_LINK_DIST_CHART_ID, CHART_VIEW_ACTION_ID);
		reportService.insertReportUsage(reportDataAttributeVO);
		java.util.List<Item> kodis = new ArrayList<>();
		koavaldistList.forEach(koaval -> {
			kodis.add(new Item(koaval.getTower(), koaval.getCC(), koaval.getCluster(), koaval.getAssignmentGroup(),
					koaval.getApplicationName(), koaval.getTicketCount()));
		});

		// Tower;
		Map<String, Integer> towersum = kodis.stream()
				.collect(Collectors.groupingBy(Item::getTower, Collectors.summingInt(Item::getKoCount)));

		List<String> towersummonthsList = new ArrayList<>();
		List<Object> towersumkoLinkedDataList = new ArrayList<>();

		// convert hashmap to list of keys and values
		towersummonthsList = towersum.keySet().stream().collect(Collectors.toCollection(ArrayList::new));
		towersumkoLinkedDataList = towersum.values().stream().collect(Collectors.toCollection(ArrayList::new));

		// CC data
		Map<String, Integer> ccsum = kodis.stream()
				.collect(Collectors.groupingBy(Item::getCC, Collectors.summingInt(Item::getKoCount)));

		List<String> ccsummonthsList = new ArrayList<>();
		List<Object> ccsumkoLinkedDataList = new ArrayList<>();

		// convert hashmap to list of keys and values
		ccsummonthsList = ccsum.keySet().stream().collect(Collectors.toCollection(ArrayList::new));
		ccsumkoLinkedDataList = ccsum.values().stream().collect(Collectors.toCollection(ArrayList::new));

		// Cluster
		Map<String, Integer> culstersum = kodis.stream()
				.collect(Collectors.groupingBy(Item::getCluster, Collectors.summingInt(Item::getKoCount)));
		List<String> culstersummonthsList = new ArrayList<>();
		List<Object> culstersumkoLinkedDataList = new ArrayList<>();

		// convert hashmap to list of keys and values
		culstersummonthsList = culstersum.keySet().stream().collect(Collectors.toCollection(ArrayList::new));
		culstersumkoLinkedDataList = culstersum.values().stream().collect(Collectors.toCollection(ArrayList::new));

		// Assignment group
		Map<String, Integer> asgmtgrpsum = kodis.stream()
				.collect(Collectors.groupingBy(Item::getAssignmentGroup, Collectors.summingInt(Item::getKoCount)));

		List<String> asgmtgrpsummonthsList = new ArrayList<>();
		List<Object> asgmtgrpsumkoLinkedDataList = new ArrayList<>();

		// convert hashmap to list of keys and values
		asgmtgrpsummonthsList = asgmtgrpsum.keySet().stream().collect(Collectors.toCollection(ArrayList::new));
		asgmtgrpsumkoLinkedDataList = asgmtgrpsum.values().stream().collect(Collectors.toCollection(ArrayList::new));

		// Application name
		Map<String, Integer> appsnamesum = kodis.stream()
				.collect(Collectors.groupingBy(Item::getApplicationName, Collectors.summingInt(Item::getKoCount)));
		List<String> appsnamesummonthsList = new ArrayList<>();
		List<Object> appsnamesumkoLinkedDataList = new ArrayList<>();

		// convert hashmap to list of keys and values
		appsnamesummonthsList = appsnamesum.keySet().stream().collect(Collectors.toCollection(ArrayList::new));
		appsnamesumkoLinkedDataList = appsnamesum.values().stream().collect(Collectors.toCollection(ArrayList::new));

		List<HashMap<String, String>> charthashmp = new ArrayList<>();
		HashMap<String, String> chartdatamp = new HashMap<>();
		chartdatamp.put(TOWER_MONTHS_LIST, jsonReplace(towersummonthsList)); // strTowersummonthsListrep);
		chartdatamp.put(TOWER_KOLINKED_DATALIST, jsonReplace(towersumkoLinkedDataList)); // strTowersumkoLinkedDataListrep);
		chartdatamp.put(CC_MONTHS_LIST, jsonReplace(ccsummonthsList)); // strCCsummonthsListrep);
		chartdatamp.put(CC_KOLINKED_DATALIST, jsonReplace(ccsumkoLinkedDataList)); // strCCsumkoLinkedDataListrep);
		chartdatamp.put(STRCULSTER_SUM_MONTHSLIST, jsonReplace(culstersummonthsList)); // strCulstersummonthsListrep);
		chartdatamp.put(CULSTER_KOLINKED_DATALIST, jsonReplace(culstersumkoLinkedDataList)); // strCulstersumkoLinkedDataListrep);
		chartdatamp.put(ASGMTGRP_MONTHSLIST, jsonReplace(asgmtgrpsummonthsList)); // strAsgmtgrpsummonthsListrep);
		chartdatamp.put(ASGMTGRP_KOLINKED_DATALIST, jsonReplace(asgmtgrpsumkoLinkedDataList)); // strAsgmtgrpsumkoLinkedDataListrep);
		chartdatamp.put("strAppsname_sum_monthsList", jsonReplace(appsnamesummonthsList)); // strAppsnamesummonthsListrep);
		chartdatamp.put("strAppsname_sum_koLinkedDataList", jsonReplace(appsnamesumkoLinkedDataList)); // strAppsnamesumkoLinkedDataListrep);
		charthashmp.add(chartdatamp);
		String chartdatajson = gson.toJson(chartdatamp);

		log.info("End: try_koavaildistrchartdispload");
		return chartdatajson;
	}

	/**
	 * Json replace.
	 *
	 * @param obj the obj
	 * @return the string
	 */
	private String jsonReplace(Object obj) {
		Gson gson = new Gson();
		String str = gson.toJson(obj);
		return str.replaceAll("\"", "@@");
	}

	/**
	 * Mttrchrtdisploadchrtdispgetload.
	 *
	 * @param freq the freq
	 * @param searchfrmdateform the searchfrmdateform
	 * @param searchtodateform the searchtodateform
	 * @param tower the tower
	 * @param cc the cc
	 * @param cluster the cluster
	 * @param asgngrp the asgngrp
	 * @param appsname the appsname
	 * @return the string
	 */
	@RequestMapping(value = "/mttrchrtdispload", headers = ACCEPT_TYPES, method = RequestMethod.GET)
	public @ResponseBody String mttrchrtdisploadchrtdispgetload(@RequestParam(value = FREQ) String freq,
			@RequestParam(value = FROM_DATE) String searchfrmdateform,
			@RequestParam(value = TO_DATE_STRING) String searchtodateform, @RequestParam(value = TOWER) String tower,
			@RequestParam(value = "cc") String cc, @RequestParam(value = CLUSTER_STRING) String cluster,
			@RequestParam(value = ASGNGRP) String asgngrp, @RequestParam(value = APPSNAME) String appsname) {

		String searchfrmdate = null;
		String searchtodate = null;
		DateTimeFormatter newPattern = DateTimeFormatter.ofPattern(YYYMMDD);
		LocalDate today = LocalDate.now();
		searchtodate = today.format(newPattern);
		searchfrmdate = getSearchFrmDate(freq, searchfrmdate);
		if (freq.equalsIgnoreCase("Custom")) {
			searchfrmdate = searchfrmdateform;
			searchtodate = searchtodateform;
		}
		log.info("Start: mttrchrtchrtdispload");
		Gson gson = new Gson();
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String loginusrname = auth.getName();
		String userId = loginusrname;
		String accountId = getDefaultAccountId();

		// KO Availability Distribution (Overall)
		List<KOInfoBean> koavaldistList = null;
		MasterDataAttributeVO masterDataAttributeVO = new MasterDataAttributeVO(accountId, "", asgngrp, tower, cc, cluster, "");
		masterDataAttributeVO.setFromDateTodate(searchfrmdate, searchtodate);
		koavaldistList = koInfoService.mttrchrt(masterDataAttributeVO);
		ReportDataAttributeVO reportDataAttributeVO = new ReportDataAttributeVO(accountId, userId, KO_LINK_DIST_CHART_ID, CHART_VIEW_ACTION_ID);
		reportService.insertReportUsage(reportDataAttributeVO);
		java.util.List<Item> kodis = new ArrayList<>();
		koavaldistList.forEach(koaval -> {
			kodis.add(new Item(koaval.getTicketMonth(), koaval.getTower(), koaval.getCC(), koaval.getCluster(),
					koaval.getAssignmentGroup(), koaval.getTicketCount(), koaval.getAllIncidentsmttr(),
					koaval.getTicketLinkCount(), koaval.getLinkTicketsmttr()));
		});
        DecimalFormat df = new DecimalFormat("#.00");
		// Tower;
		
        Map<String, Integer> counting_allinc = kodis.stream()
				.collect(Collectors.groupingBy(Item::getTicketMonth,LinkedHashMap::new ,Collectors.summingInt(Item::getTicketCount)));
		
		Map<String, Long> counting_allinc_cnt = kodis.stream()
				.collect(Collectors.groupingBy(Item::getTicketMonth,LinkedHashMap::new ,Collectors.counting()));
		
		Map<String, Integer> counting_link = kodis.stream()
				.filter((Item) -> !Objects.equals(Item.getLinkedTicketsmttr(), 0))
				.collect(Collectors.groupingBy(Item::getTicketMonth,LinkedHashMap::new, Collectors.summingInt(Item::getTicketLinkedCount)));
		
		Map<String, Long> counting_link_cnt = kodis.stream()
				.filter((Item) -> !Objects.equals(Item.getLinkedTicketsmttr(), 0))
				.collect(Collectors.groupingBy(Item::getTicketMonth,LinkedHashMap::new, Collectors.counting()));
		
		Map<String, Double> towerallincmttr_pp = (kodis.stream().collect(Collectors.groupingBy(
				Item::getTicketMonth, LinkedHashMap::new, Collectors.summingDouble(Item::getAllIncidentsmttr))));
		Map<String, Double> towerlinktckmttr_pp = kodis.stream().collect(Collectors.groupingBy(
				Item::getTicketMonth, LinkedHashMap::new, Collectors.summingDouble(Item::getLinkedTicketsmttr)));
		
		final LinkedHashMap<String, String> towerallincmttr = new LinkedHashMap<String, String>();				
		for (Map.Entry me : towerallincmttr_pp.entrySet()) {                       
            if (counting_allinc.containsKey(me.getKey())) {
           double val=(((towerallincmttr_pp.get(me.getKey())/60))/(counting_allinc_cnt.get(me.getKey())));
           towerallincmttr.put(me.getKey().toString(),String.valueOf(df.format(val))); 
           }
         }                         
	    
	        final LinkedHashMap<String, String> towerlinktckmttr = new LinkedHashMap<String, String>();					
            for (Map.Entry me : towerlinktckmttr_pp.entrySet()) {
                if (counting_link.containsKey(me.getKey())) {
                 double val=(((towerlinktckmttr_pp.get(me.getKey())/60))/(counting_link_cnt.get(me.getKey())));
                 towerlinktckmttr.put(me.getKey().toString(),String.valueOf(df.format(val))); 
                 }
               }  

		// convert hashmap to list of keys and values
		List<String> towersumallincmttrmonthsList = towerallincmttr.keySet().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		List<Object> towersumallincmttrList = towerallincmttr.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		List<Object> towersumlinktckmttrList = towerlinktckmttr.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		List<Object> towercountingmttrList = counting_allinc.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		List<Object> towercountingmttrlinkList = counting_link.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));

		// CC data
		Map<String, Double> ccallincmttr_pp = kodis.stream().collect(Collectors.groupingBy(Item::getTicketMonth,
				LinkedHashMap::new, Collectors.summingDouble(Item::getAllIncidentsmttr)));
		Map<String, Double> cclinktckmttr_pp = kodis.stream().collect(Collectors.groupingBy(Item::getTicketMonth,
				LinkedHashMap::new, Collectors.summingDouble(Item::getLinkedTicketsmttr)));
		
		final LinkedHashMap<String, String> ccallincmttr = new LinkedHashMap<String, String>();				
        for (Map.Entry me : ccallincmttr_pp.entrySet()) {                          
            if (counting_allinc.containsKey(me.getKey())) {
           double val=(((ccallincmttr_pp.get(me.getKey())/60))/(counting_allinc_cnt.get(me.getKey())));
           ccallincmttr.put(me.getKey().toString(),String.valueOf(df.format(val))); 
           }
         }                         
	        final LinkedHashMap<String, String> cclinktckmttr = new LinkedHashMap<String, String>();					
	        for (Map.Entry me : cclinktckmttr_pp.entrySet()) {
                if (counting_link.containsKey(me.getKey())) {
                 double val=(((cclinktckmttr_pp.get(me.getKey())/60))/(counting_link_cnt.get(me.getKey())));
                 cclinktckmttr.put(me.getKey().toString(),String.valueOf(df.format(val))); 
                 }
               }  


		// convert hashmap to list of keys and values
		List<String> ccsumallincmttrmonthsList = ccallincmttr.keySet().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		List<Object> ccsumallincmttrList = ccallincmttr.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		List<Object> ccsumlinktckmttrList = cclinktckmttr.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));

		// Cluster
		Map<String, Double> culsterallincmttr_pp = kodis.stream().collect(Collectors.groupingBy(
				Item::getTicketMonth, LinkedHashMap::new, Collectors.summingDouble(Item::getAllIncidentsmttr)));
		Map<String, Double> culsterlinktckmttr_pp = kodis.stream().collect(Collectors.groupingBy(
				Item::getTicketMonth, LinkedHashMap::new, Collectors.summingDouble(Item::getLinkedTicketsmttr)));
		
		final LinkedHashMap<String, String> culsterallincmttr = new LinkedHashMap<String, String>();				
		for (Map.Entry me : culsterallincmttr_pp.entrySet()) {                           
            if (counting_allinc.containsKey(me.getKey())) {
           double val=(((culsterallincmttr_pp.get(me.getKey())/60))/(counting_allinc_cnt.get(me.getKey())));
           culsterallincmttr.put(me.getKey().toString(),String.valueOf(df.format(val))); 
           }
         }                         
	        final LinkedHashMap<String, String> culsterlinktckmttr = new LinkedHashMap<String, String>();					
            for (Map.Entry me : culsterlinktckmttr_pp.entrySet()) {
                if (counting_link.containsKey(me.getKey())) {
                     double val=(((culsterlinktckmttr_pp.get(me.getKey())/60))/(counting_link_cnt.get(me.getKey())));
                 culsterlinktckmttr.put(me.getKey().toString(),String.valueOf(df.format(val))); 
                 }
               }  

		// convert hashmap to list of keys and values
		List<String> culstersumallincmttrmonthsList = culsterallincmttr.keySet().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		List<Object> culstersumallincmttrList = culsterallincmttr.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		List<Object> culstersumlinktckmttrList = culsterlinktckmttr.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));

		// Assignment group
		Map<String, Double> asgmtgrpallincmttr_pp = kodis.stream().collect(Collectors.groupingBy(
				Item::getTicketMonth, LinkedHashMap::new, Collectors.summingDouble(Item::getAllIncidentsmttr)));
		Map<String, Double> asgmtgrplinktckmttr_pp = kodis.stream().collect(Collectors.groupingBy(
				Item::getTicketMonth, LinkedHashMap::new, Collectors.summingDouble(Item::getLinkedTicketsmttr)));
		
		final LinkedHashMap<String, String> asgmtgrpallincmttr = new LinkedHashMap<String, String>();				
        for (Map.Entry me : asgmtgrpallincmttr_pp.entrySet()) {                          
            if (counting_allinc.containsKey(me.getKey())) {
           double val=(((asgmtgrpallincmttr_pp.get(me.getKey())/60))/(counting_allinc_cnt.get(me.getKey())));
           asgmtgrpallincmttr.put(me.getKey().toString(),String.valueOf(df.format(val))); 
           }
         }                         
	    
	        final LinkedHashMap<String, String> asgmtgrplinktckmttr = new LinkedHashMap<String, String>();					
            for (Map.Entry me : asgmtgrplinktckmttr_pp.entrySet()) {
                if (counting_link.containsKey(me.getKey())) {
                     double val=(((asgmtgrplinktckmttr_pp.get(me.getKey())/60))/(counting_link_cnt.get(me.getKey())));
                 asgmtgrplinktckmttr.put(me.getKey().toString(),String.valueOf(df.format(val))); 
                 }
               }  

		// convert hashmap to list of keys and values
		List<String> asgmtgrpsumallincmttrmonthsList = asgmtgrpallincmttr.keySet().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		List<Object> asgmtgrpsumallincmttrList = asgmtgrpallincmttr.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		List<Object> asgmtgrpsumlinktckmttrList = asgmtgrplinktckmttr.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));

		List<HashMap<String, String>> charthashmp = new ArrayList<>();
		HashMap<String, String> chartdatamp = new HashMap<>();

		chartdatamp.put(TOWER_MONTHS_LIST, jsonReplace(towersumallincmttrmonthsList)); // strTowersumincmttrmonthsListrep);
		chartdatamp.put(TOWER_KOLINKED_DATALIST, jsonReplace(towersumallincmttrList)); // strTowersumallincmttrListrep);
		chartdatamp.put("strTower_sum_koNotLinkedDataList", jsonReplace(towersumlinktckmttrList)); // strTowersumlinktckmttrListrep);
		chartdatamp.put("strcountmttrListrep", jsonReplace(towercountingmttrList));
		chartdatamp.put("strcountmttrlinkListrep", jsonReplace(towercountingmttrlinkList));
		chartdatamp.put(CC_MONTHS_LIST, jsonReplace(ccsumallincmttrmonthsList)); // strCCsumincmttrmonthsListrep);
		chartdatamp.put(CC_KOLINKED_DATALIST, jsonReplace(ccsumallincmttrList)); // strCCsumallincmttrListrep);
		chartdatamp.put("strCC_sum_koNotLinkedDataList", jsonReplace(ccsumlinktckmttrList)); // strCCsumlinktckmttrListrep);
		chartdatamp.put(STRCULSTER_SUM_MONTHSLIST, jsonReplace(culstersumallincmttrmonthsList)); // strCulstersumincmttrmonthsListrep);
		chartdatamp.put(CULSTER_KOLINKED_DATALIST, jsonReplace(culstersumallincmttrList)); // strCulstersumallincmttrListrep);
		chartdatamp.put("strCulster_sum_koNotLinkedDataList", jsonReplace(culstersumlinktckmttrList)); // strCulstersumlinktckmttrListrep);
		chartdatamp.put(ASGMTGRP_MONTHSLIST, jsonReplace(asgmtgrpsumallincmttrmonthsList)); // strAsgmtgrpsumincmttrmonthsListrep);
		chartdatamp.put(ASGMTGRP_KOLINKED_DATALIST, jsonReplace(asgmtgrpsumallincmttrList)); // strAsgmtgrpsumallincmttrListrep);
		chartdatamp.put("strAsgmtgrp_sum_koNotLinkedDataList", jsonReplace(asgmtgrpsumlinktckmttrList)); // strAsgmtgrpsumlinktckmttrListrep);
		charthashmp.add(chartdatamp);

		String chartdatajson = gson.toJson(chartdatamp);
		log.info("End: mttrchrtchrtdispload");
		return chartdatajson;
	}

	/**
	 * Kolinkvsnotlinkchrtdispgetload.
	 *
	 * @param freq             the freq
	 * @param searchfrmdateform the searchfrmdateform
	 * @param searchtodateform the searchtodateform
	 * @param tower            the tower
	 * @param cc               the cc
	 * @param cluster          the cluster
	 * @param asgngrp          the asgngrp
	 * @param appsname         the appsname
	 * @return the string
	 */

	@RequestMapping(value = "/kolinkvsnotlinkchrtdispload", headers = ACCEPT_TYPES, method = RequestMethod.GET)
	public @ResponseBody String kolinkvsnotlinkchrtdispgetload(@RequestParam(value = FREQ) String freq,
			@RequestParam(value = FROM_DATE) String searchfrmdateform,
			@RequestParam(value = TO_DATE_STRING) String searchtodateform, @RequestParam(value = TOWER) String tower,
			@RequestParam(value = "cc") String cc, @RequestParam(value = CLUSTER_STRING) String cluster,
			@RequestParam(value = ASGNGRP) String asgngrp, @RequestParam(value = APPSNAME) String appsname) {
		LocalDate today = LocalDate.now();
		String searchtodate = today.format(DateTimeFormatter.ofPattern(YYYMMDD));
		String searchfrmdate = getSearchFrmDate(freq, "");
		if (freq.equalsIgnoreCase("Custom")) {
			searchfrmdate = searchfrmdateform;
			searchtodate = searchtodateform;
		}
		log.info("Start: kolinkvsnotlinkchrtdispload");
		Gson gson = new Gson();
		String userId = getAuth().getName(); // loginusrname;
		String accountId = getDefaultAccountId();

		// KO Availability Distribution (Overall)
		MasterDataAttributeVO masterDataAttributeVO = new MasterDataAttributeVO(accountId, appsname, asgngrp, tower,cc, cluster,  userId);
		masterDataAttributeVO.setFromDateTodate(searchfrmdate, searchtodate);
		List<KOInfoBean> koavaldistList = koInfoService.linkvsnotlinked(masterDataAttributeVO);
		ReportDataAttributeVO reportDataAttributeVO = new ReportDataAttributeVO(accountId, userId, KO_LINK_DIST_CHART_ID, CHART_VIEW_ACTION_ID);
		reportService.insertReportUsage(reportDataAttributeVO);
		java.util.List<Item> kodis = new ArrayList<>();
		koavaldistList.forEach(koaval -> {
			kodis.add(new Item(koaval.getTower(), koaval.getCC(), koaval.getCluster(), koaval.getAssignmentGroup(),
					koaval.getApplicationName(), koaval.getLinked(), koaval.getNon_Linked()));
		});

		// Tower;
		Map<String, Integer> towersumlink = kodis.stream()
				.collect(Collectors.groupingBy(Item::getTower, Collectors.summingInt(Item::getLinked)));
		Map<String, Integer> towersumnotlink = kodis.stream()
				.collect(Collectors.groupingBy(Item::getTower, Collectors.summingInt(Item::getNot_Linked)));
		// convert hashmap to list of keys and values
		List<String> towersummonthsList = towersumlink.keySet().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		List<Object> towersumkoLinkedDataList = towersumlink.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		List<Object> towersumkoNotLinkedDataList = towersumnotlink.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));

		// CC data
		Map<String, Integer> ccsumlink = kodis.stream()
				.collect(Collectors.groupingBy(Item::getCC, Collectors.summingInt(Item::getLinked)));
		Map<String, Integer> ccsumnotlink = kodis.stream()
				.collect(Collectors.groupingBy(Item::getCC, Collectors.summingInt(Item::getNot_Linked)));

		// convert hashmap to list of keys and values
		List<String> ccsummonthsList = ccsumlink.keySet().stream().collect(Collectors.toCollection(ArrayList::new));
		List<Object> ccsumkoLinkedDataList = ccsumlink.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		List<Object> ccsumkoNotLinkedDataList = ccsumnotlink.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));

		// Cluster
		Map<String, Integer> culstersumlink = kodis.stream()
				.collect(Collectors.groupingBy(Item::getCluster, Collectors.summingInt(Item::getLinked)));
		Map<String, Integer> culstersumnotlink = kodis.stream()
				.collect(Collectors.groupingBy(Item::getCluster, Collectors.summingInt(Item::getNot_Linked)));

		// convert hashmap to list of keys and values
		List<String> culstersummonthsList = culstersumlink.keySet().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		List<Object> culstersumkoLinkedDataList = culstersumlink.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		List<Object> culstersumkoNotLinkedDataList = culstersumnotlink.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));

		// Assignment group
		Map<String, Integer> asgmtgrpsumlink = kodis.stream()
				.collect(Collectors.groupingBy(Item::getAssignmentGroup, Collectors.summingInt(Item::getLinked)));
		Map<String, Integer> asgmtgrpsumnotlink = kodis.stream()
				.collect(Collectors.groupingBy(Item::getAssignmentGroup, Collectors.summingInt(Item::getNot_Linked)));

		// convert hashmap to list of keys and values
		List<String> asgmtgrpsummonthsList = asgmtgrpsumlink.keySet().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		List<Object> asgmtgrpsumkoLinkedDataList = asgmtgrpsumlink.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		List<Object> asgmtgrpsumkoNotLinkedDataList = asgmtgrpsumnotlink.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));

		// Application name
		Map<String, Integer> appsnamesumLink = kodis.stream()
				.collect(Collectors.groupingBy(Item::getApplicationName, Collectors.summingInt(Item::getLinked)));
		Map<String, Integer> appsnamesumNotLink = kodis.stream()
				.collect(Collectors.groupingBy(Item::getApplicationName, Collectors.summingInt(Item::getNot_Linked)));

		// convert hashmap to list of keys and values
		List<String> appsnamesummonthsList = appsnamesumLink.keySet().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		List<Object> appsnamesumkoLinkedDataList = appsnamesumLink.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		List<Object> appsnamesumkoNotLinkedDataList = appsnamesumNotLink.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));

		List<HashMap<String, String>> charthashmp = new ArrayList<>();
		HashMap<String, String> chartdatamp = new HashMap<>();
		chartdatamp.put(TOWER_MONTHS_LIST, jsonReplace(towersummonthsList)); // strTowersummonthsListrep);
		chartdatamp.put(TOWER_KOLINKED_DATALIST, jsonReplace(towersumkoLinkedDataList)); // strTowersumkoLinkedDataListrep);
		chartdatamp.put("strTower_sum_koNotLinkedDataList", jsonReplace(towersumkoNotLinkedDataList)); // strTowersumkoNotLinkedDataListrep);
		chartdatamp.put(CC_MONTHS_LIST, jsonReplace(ccsummonthsList)); // strCCsummonthsListrep);
		chartdatamp.put(CC_KOLINKED_DATALIST, jsonReplace(ccsumkoLinkedDataList)); // strCCsumkoLinkedDataListrep);
		chartdatamp.put("strCC_sum_koNotLinkedDataList", jsonReplace(ccsumkoNotLinkedDataList)); // strCCsumkoNotLinkedDataListrep);
		chartdatamp.put(STRCULSTER_SUM_MONTHSLIST, jsonReplace(culstersummonthsList)); // strCulstersummonthsListrep);
		chartdatamp.put(CULSTER_KOLINKED_DATALIST, jsonReplace(culstersumkoLinkedDataList)); // strCulstersumkoLinkedDataListrep);
		chartdatamp.put("strCulster_sum_koNotLinkedDataList", jsonReplace(culstersumkoNotLinkedDataList)); // strCulstersumkoNotLinkedDataListrep);
		chartdatamp.put(ASGMTGRP_MONTHSLIST, jsonReplace(asgmtgrpsummonthsList)); // strAsgmtgrpsummonthsListrep);
		chartdatamp.put(ASGMTGRP_KOLINKED_DATALIST, jsonReplace(asgmtgrpsumkoLinkedDataList)); // strAsgmtgrpsumkoLinkedDataListrep);
		chartdatamp.put("strAsgmtgrp_sum_koNotLinkedDataList", jsonReplace(asgmtgrpsumkoNotLinkedDataList)); // strAsgmtgrpsumkoNotLinkedDataListrep);
		chartdatamp.put("strAppsname_sum_monthsList", jsonReplace(appsnamesummonthsList)); // strAppsnamesummonthsListrep);
		chartdatamp.put("strAppsname_sum_koLinkedDataList", jsonReplace(appsnamesumkoLinkedDataList)); // strAppsnamesumkoLinkedDataListrep);
		chartdatamp.put("strAppsname_sum_koNotLinkedDataList", jsonReplace(appsnamesumkoNotLinkedDataList)); // strAppsnamesumkoNotLinkedDataListrep);
		charthashmp.add(chartdatamp);
		log.info("End: kolinkvsnotlinkchrtdispload");
		return gson.toJson(chartdatamp);
	}

	/**
	 * Gets the auth.
	 *
	 * @return the auth
	 */
	private Authentication getAuth() {
		SecurityContext sc = SecurityContextHolder.getContext();
		return sc.getAuthentication();
	}

	/**
	 * Gets the user account.
	 *
	 * @return the user account
	 */
	private int getUserAccount() {
		String accountId = getDefaultAccountId();
		UserBean ub = userService.getUserAccountType(accountId);
		return Objects.nonNull(ub) ? ub.getIsGeneric() : -1;
	}

	/**
	 * Gets the logged user.
	 *
	 * @return the logged user
	 */
	private String getLoggedUser() {
		SecurityContext sc = SecurityContextHolder.getContext();
		Authentication auth = sc.getAuthentication();
		return auth.getName();
	}

	/**
	 * Kousagechrtdisploadchrtdispgetload.
	 *
	 * @param freq the freq
	 * @param searchfrmdateform the searchfrmdateform
	 * @param searchtodateform the searchtodateform
	 * @param tower the tower
	 * @param cc the cc
	 * @param cluster the cluster
	 * @param asgngrp the asgngrp
	 * @param appsname the appsname
	 * @return the string
	 */
	@RequestMapping(value = "/kousagechrtdispload", headers = "Accept=*/*", method = RequestMethod.GET)
	public @ResponseBody String kousagechrtdisploadchrtdispgetload(@RequestParam(value = "freq") String freq,
			@RequestParam(value = "fromdate") String searchfrmdateform,
			@RequestParam(value = "todate") String searchtodateform, @RequestParam(value = "tower") String tower,
			@RequestParam(value = "cc") String cc, @RequestParam(value = "cluster") String cluster,
			@RequestParam(value = "asgngrp") String asgngrp, @RequestParam(value = "appsname") String appsname) {
		String searchfrmdate = null;
		String searchtodate = null;
		DateTimeFormatter newPattern = DateTimeFormatter.ofPattern(YYYMMDD);
		LocalDate today = LocalDate.now();
		searchtodate = today.format(newPattern);
		searchfrmdate = getSearchFrmDate(freq, searchfrmdate);
		if (freq.equalsIgnoreCase("Custom")) {
			searchfrmdate = searchfrmdateform;
			searchtodate = searchtodateform;
		}
		log.info("Start: KO usage chart");
		Gson gson = new Gson();
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String loginusrname = auth.getName();
		String userId = loginusrname;
		String accountId = getDefaultAccountId();
		// KO Availability Distribution (Overall)
		List<KOInfoBean> koavaldistList = null;
		MasterDataAttributeVO masterDataAttributeVO = new MasterDataAttributeVO(accountId, appsname, asgngrp, tower,cc, cluster,  userId);
		masterDataAttributeVO.setFromDateTodate(searchfrmdate, searchtodate);
		koavaldistList = koInfoService.kousagechrt(masterDataAttributeVO);
		ReportDataAttributeVO reportDataAttributeVO = new ReportDataAttributeVO(accountId, userId, KO_LINK_DIST_CHART_ID, CHART_VIEW_ACTION_ID);
		reportService.insertReportUsage(reportDataAttributeVO);
		java.util.List<KOusageItem> kodis = new ArrayList<>();
		koavaldistList.forEach(koaval -> {
			kodis.add(new KOusageItem(koaval.getTicketMonth(), koaval.getTower(), koaval.getCC(), koaval.getCluster(),
					koaval.getAssignmentGroup(), koaval.getApplicationName(), koaval.getKoIDCount(),
					koaval.getGenericKoIDCount()));
		});
		// Tower;
		Map<String, Integer> towerallinckousg = kodis.stream().collect(Collectors.groupingBy(
				KOusageItem::getTicketMonth, LinkedHashMap::new, Collectors.summingInt(KOusageItem::getKoIDCount)));
		Map<String, Integer> towerlinktckkousg = kodis.stream()
				.collect(Collectors.groupingBy(KOusageItem::getTicketMonth, LinkedHashMap::new,
						Collectors.summingInt(KOusageItem::getGenericKoIDCount)));
		// convert hashmap to list of keys and values
		List<String> towersumallincmttrmonthsList = towerallinckousg.keySet().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		List<Object> towersumallincmttrList = towerallinckousg.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		List<Object> towersumlinktckmttrList = towerlinktckkousg.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		// CC data
		Map<String, Integer> ccallinckousg = kodis.stream().collect(Collectors.groupingBy(KOusageItem::getTicketMonth,
				LinkedHashMap::new, Collectors.summingInt(KOusageItem::getKoIDCount)));
		Map<String, Integer> cclinktckkousg = kodis.stream().collect(Collectors.groupingBy(KOusageItem::getTicketMonth,
				LinkedHashMap::new, Collectors.summingInt(KOusageItem::getGenericKoIDCount)));

		// convert hashmap to list of keys and values
		List<String> ccsumallincmttrmonthsList = ccallinckousg.keySet().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		List<Object> ccsumallincmttrList = ccallinckousg.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		List<Object> ccsumlinktckmttrList = cclinktckkousg.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		// Cluster
		Map<String, Integer> culsterallinckousg = kodis.stream().collect(Collectors.groupingBy(
				KOusageItem::getTicketMonth, LinkedHashMap::new, Collectors.summingInt(KOusageItem::getKoIDCount)));
		Map<String, Integer> culsterlinktckkousg = kodis.stream()
				.collect(Collectors.groupingBy(KOusageItem::getTicketMonth, LinkedHashMap::new,
						Collectors.summingInt(KOusageItem::getGenericKoIDCount)));

		// convert hashmap to list of keys and values
		List<String> culstersumallincmttrmonthsList = culsterallinckousg.keySet().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		List<Object> culstersumallincmttrList = culsterallinckousg.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		List<Object> culstersumlinktckmttrList = culsterlinktckkousg.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		// Assignment group
		Map<String, Integer> asgmtgrpallinckousg = kodis.stream().collect(Collectors.groupingBy(
				KOusageItem::getTicketMonth, LinkedHashMap::new, Collectors.summingInt(KOusageItem::getKoIDCount)));
		Map<String, Integer> asgmtgrplinktckkousg = kodis.stream()
				.collect(Collectors.groupingBy(KOusageItem::getTicketMonth, LinkedHashMap::new,
						Collectors.summingInt(KOusageItem::getGenericKoIDCount)));
		// convert hashmap to list of keys and values
		List<String> asgmtgrpsumallincmttrmonthsList = asgmtgrpallinckousg.keySet().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		List<Object> asgmtgrpsumallincmttrList = asgmtgrpallinckousg.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		List<Object> asgmtgrpsumlinktckmttrList = asgmtgrplinktckkousg.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		// Application name
		List<HashMap<String, String>> charthashmp = new ArrayList<>();
		HashMap<String, String> chartdatamp = new HashMap<>();
		chartdatamp.put(TOWER_MONTHS_LIST, jsonReplace(towersumallincmttrmonthsList)); // strTowersumincmttrmonthsListrep);
		chartdatamp.put(TOWER_KOLINKED_DATALIST, jsonReplace(towersumallincmttrList)); // strTowersumallincmttrListrep);
		chartdatamp.put("strTower_sum_koNotLinkedDataList", jsonReplace(towersumlinktckmttrList)); // strTowersumlinktckmttrListrep);
		chartdatamp.put(CC_MONTHS_LIST, jsonReplace(ccsumallincmttrmonthsList)); // strCCsumincmttrmonthsListrep);
		chartdatamp.put(CC_KOLINKED_DATALIST, jsonReplace(ccsumallincmttrList)); // strCCsumallincmttrListrep);
		chartdatamp.put("strCC_sum_koNotLinkedDataList", jsonReplace(ccsumlinktckmttrList)); // strCCsumlinktckmttrListrep);
		chartdatamp.put(STRCULSTER_SUM_MONTHSLIST, jsonReplace(culstersumallincmttrmonthsList)); // strCulstersumincmttrmonthsListrep);
		chartdatamp.put(CULSTER_KOLINKED_DATALIST, jsonReplace(culstersumallincmttrList)); // strCulstersumallincmttrListrep);
		chartdatamp.put("strCulster_sum_koNotLinkedDataList", jsonReplace(culstersumlinktckmttrList)); // strCulstersumlinktckmttrListrep);
		chartdatamp.put(ASGMTGRP_MONTHSLIST, jsonReplace(asgmtgrpsumallincmttrmonthsList)); // strAsgmtgrpsumincmttrmonthsListrep);
		chartdatamp.put(ASGMTGRP_KOLINKED_DATALIST, jsonReplace(asgmtgrpsumallincmttrList)); // strAsgmtgrpsumallincmttrListrep);
		chartdatamp.put("strAsgmtgrp_sum_koNotLinkedDataList", jsonReplace(asgmtgrpsumlinktckmttrList)); // strAsgmtgrpsumlinktckmttrListrep);
		charthashmp.add(chartdatamp);
		String chartdatajson = gson.toJson(chartdatamp);

		log.info("End: KO usage chart");
		return chartdatajson;
	}
	
	/**
	 * Gets the account name.
	 *
	 * @return the account name
	 */
	private String getAccountName() {
		SecurityContext sc = SecurityContextHolder.getContext();
		Authentication auth = sc.getAuthentication();
		List<SettingBean> sbList = helpService.accountAccess(auth.getName());
		return Objects.nonNull(sbList) && sbList.size() > 0 && Objects.nonNull(sbList.get(0)) && Objects.nonNull(sbList.get(0).getAccountName())
				? sbList.get(0).getAccountName()
				: "Unknown";
	}
	
	/**
	 * Search type ahead host search.
	 *
	 * @param searchStr the search str
	 * @param server the server
	 * @return the response entity
	 */
	@JsonIgnoreProperties
	@RequestMapping(value = "/searchTypeAheadHostSearch")
	public @ResponseBody ResponseEntity<?> searchTypeAheadHostSearch(@RequestParam(value = "str") String searchStr,@RequestParam(value = "server") String server){
		log.info("searchTypeAheadHostSearch  Start");
		Gson gson = new Gson();
		try {
			String url = "http://"+server+"/search?search_str="+searchStr;
			List<HttpMessageConverter<?>> messageConverters = new ArrayList<HttpMessageConverter<?>>();
			MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
			converter.setSupportedMediaTypes(Collections.singletonList(MediaType.ALL));        
			messageConverters.add(converter);  
			RestTemplate restTemplate = new RestTemplate();
			restTemplate.setMessageConverters(messageConverters); 
			Object result = restTemplate.getForObject(url, Object.class);
			log.info("searchTypeAheadHostSearch  End");
			return ResponseEntity.ok(gson.toJson(result));
			
		}catch (RestClientException e) {
			log.info("Error "+e);
		}
		log.info("Retrun null ");
		return ResponseEntity.ok("");	
		
	}
	
	/**
	 * Search type ahead host save.
	 *
	 * @param searchStr the search str
	 * @param server the server
	 * @return the response entity
	 */
	@JsonIgnoreProperties
	@RequestMapping(value = "/searchTypeAheadHostSave")
	public @ResponseBody ResponseEntity<?> searchTypeAheadHostSave(@RequestParam(value = "str") String searchStr,@RequestParam(value = "server") String server){
		log.info("searchTypeAheadHostSave  Start");
		Gson gson = new Gson();
		try {
			String url = "http://"+server+"/save?train_str="+searchStr;
			List<HttpMessageConverter<?>> messageConverters = new ArrayList<HttpMessageConverter<?>>();
			MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
			converter.setSupportedMediaTypes(Collections.singletonList(MediaType.ALL));        
			messageConverters.add(converter);  
			RestTemplate restTemplate = new RestTemplate();
			restTemplate.setMessageConverters(messageConverters); 
			Object result = restTemplate.getForObject(url, Object.class);
			return ResponseEntity.ok(gson.toJson(result));
		}catch (RestClientException e) {
			log.info("Error "+e);
		}
		log.info("Retrun null");
		return ResponseEntity.ok("");	
		
	}
	/**
	 * Compliancechrtdispgetload.
	 *
	 * @param freq             the freq
	 * @param searchfrmdateform the searchfrmdateform
	 * @param searchtodateform the searchtodateform
	 * @param tower            the tower
	 * @param cc               the cc
	 * @param cluster          the cluster
	 * @param asgngrp          the asgngrp
	 * @param appsname         the appsname
	 * @return the string
	 */

	@RequestMapping(value = "/compliancechrtdispgetload", headers = ACCEPT_TYPES, method = RequestMethod.GET)
	public @ResponseBody String compliancechrtdispgetload(@RequestParam(value = FREQ) String freq,
			@RequestParam(value = FROM_DATE) String searchfrmdateform,
			@RequestParam(value = TO_DATE_STRING) String searchtodateform, @RequestParam(value = TOWER) String tower,
			@RequestParam(value = "cc") String cc, @RequestParam(value = CLUSTER_STRING) String cluster,
			@RequestParam(value = ASGNGRP) String asgngrp, @RequestParam(value = APPSNAME) String appsname) {
		LocalDate today = LocalDate.now();
		String searchtodate = today.format(DateTimeFormatter.ofPattern(YYYMMDD));
		String searchfrmdate = getSearchFrmDate(freq, "");
		if (freq.equalsIgnoreCase("Custom")) {
			searchfrmdate = searchfrmdateform;
			searchtodate = searchtodateform;
		}
		log.info("Start: Compliancechrtdispgetload");
		Gson gson = new Gson();
		String userId = getAuth().getName(); // loginusrname;
		String accountId = getDefaultAccountId();

		// Compliance (Overall)
		MasterDataAttributeVO masterDataAttributeVO = new MasterDataAttributeVO(accountId, appsname, asgngrp, tower,cc, cluster,  userId);
		masterDataAttributeVO.setFromDateTodate(searchfrmdate, searchtodate);
		List<ComplianceBean> koavaldistList = koInfoService.compliancechart(masterDataAttributeVO);
		ReportDataAttributeVO reportDataAttributeVO = new ReportDataAttributeVO(accountId, userId, COMPLIANCE_CHART_ID, CHART_VIEW_ACTION_ID);
		reportService.insertReportUsage(reportDataAttributeVO);
		java.util.List<ComplianceItem> kodis = new ArrayList<>();
		koavaldistList.forEach(koaval -> {
			kodis.add(new ComplianceItem(koaval.getMonths(),koaval.getTower(), koaval.getCc(), koaval.getCluster() ,koaval.getGroup(),
					koaval.getIncResolved(),koaval.getSrResolved(),koaval.getTotalResolved(), koaval.getKoCreated(), koaval.getKoLinked(), 
					koaval.getResVsLinked(),koaval.getApplicationName(),koaval.getAssignmentGroup()));
		});

		// Tower;
		Map<String, Integer> towerTotRes = kodis.stream()
				.collect(Collectors.groupingBy(ComplianceItem::getMonths,LinkedHashMap::new, Collectors.summingInt(ComplianceItem::getTotalResolved)));
		Map<String, Double> towerResVsLink = kodis.stream()
				.collect(Collectors.groupingBy(ComplianceItem::getMonths,LinkedHashMap::new, Collectors.summingDouble(ComplianceItem::getResVsLinked)));
		Map<String, Integer> kolink = kodis.stream()
				.collect(Collectors.groupingBy(ComplianceItem::getMonths,LinkedHashMap::new, Collectors.summingInt(ComplianceItem::getKoLinked)));
		// convert hashmap to list of keys and values
		List<String> towersummonthsList = towerTotRes.keySet().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		List<Object> towersumkoLinkedDataList = towerTotRes.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		List<Object> towersumkoNotLinkedDataList = kolink.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		List<Object>koLinkedDataList = towerResVsLink.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));

		// CC data
		Map<String, Integer> ccTotRes = kodis.stream()
				.collect(Collectors.groupingBy(ComplianceItem::getMonths,LinkedHashMap::new, Collectors.summingInt(ComplianceItem::getTotalResolved)));
		Map<String, Double> ccResVsLinked = kodis.stream()
				.collect(Collectors.groupingBy(ComplianceItem::getMonths,LinkedHashMap::new, Collectors.summingDouble(ComplianceItem::getResVsLinked)));
		Map<String, Integer> ccsumkolink = kodis.stream()
				.collect(Collectors.groupingBy(ComplianceItem::getMonths,LinkedHashMap::new, Collectors.summingInt(ComplianceItem::getKoLinked)));
		// convert hashmap to list of keys and values
		List<String> ccsummonthsList = ccTotRes.keySet().stream().collect(Collectors.toCollection(ArrayList::new));
		List<Object> ccsumkoLinkedDataList = ccTotRes.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		List<Object> ccsumkoNotLinkedDataList = ccsumkolink.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		List<Object> cckoLinkedDataList = ccResVsLinked.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		// Cluster
		Map<String, Integer> culsterTotRes = kodis.stream()
				.collect(Collectors.groupingBy(ComplianceItem::getMonths,LinkedHashMap::new, Collectors.summingInt(ComplianceItem::getTotalResolved)));
		Map<String, Double> culsterResVSLink = kodis.stream()
				.collect(Collectors.groupingBy(ComplianceItem::getMonths,LinkedHashMap::new, Collectors.summingDouble(ComplianceItem::getResVsLinked)));
		Map<String, Integer> culsterkolink = kodis.stream()
				.collect(Collectors.groupingBy(ComplianceItem::getMonths,LinkedHashMap::new, Collectors.summingInt(ComplianceItem::getKoLinked)));

		// convert hashmap to list of keys and values
		List<String> culstersummonthsList = culsterTotRes.keySet().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		List<Object> culstersumkoLinkedDataList = culsterTotRes.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		List<Object> culstersumkoNotLinkedDataList = culsterkolink.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		List<Object> culsterkoLinkedDataList = culsterResVSLink.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		// Assignment group
		Map<String, Integer> asgmtgrpTotRes = kodis.stream()
				.collect(Collectors.groupingBy(ComplianceItem::getMonths,LinkedHashMap::new, Collectors.summingInt(ComplianceItem::getTotalResolved)));
		Map<String, Double> asgmtgrpResVsLink = kodis.stream()
				.collect(Collectors.groupingBy(ComplianceItem::getMonths,LinkedHashMap::new, Collectors.summingDouble(ComplianceItem::getResVsLinked)));
		Map<String, Integer> asgmtgrpkolink = kodis.stream()
				.collect(Collectors.groupingBy(ComplianceItem::getMonths,LinkedHashMap::new, Collectors.summingInt(ComplianceItem::getKoLinked)));

		// convert hashmap to list of keys and values
		List<String> asgmtgrpsummonthsList = asgmtgrpTotRes.keySet().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		List<Object> asgmtgrpsumkoLinkedDataList = asgmtgrpTotRes.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		List<Object> asgmtgrpsumkoNotLinkedDataList = asgmtgrpkolink.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		List<Object> asgmtgrpkoLinkedDataList = asgmtgrpResVsLink.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));

		// Application name
		Map<String, Integer> appsnameTotRes = kodis.stream()
				.collect(Collectors.groupingBy(ComplianceItem::getMonths,LinkedHashMap::new, Collectors.summingInt(ComplianceItem::getTotalResolved)));
		Map<String, Double> appsnameResVsLink = kodis.stream()
				.collect(Collectors.groupingBy(ComplianceItem::getMonths,LinkedHashMap::new, Collectors.summingDouble(ComplianceItem::getResVsLinked)));
		Map<String, Integer> appsnameKOLink = kodis.stream()
				.collect(Collectors.groupingBy(ComplianceItem::getMonths,LinkedHashMap::new, Collectors.summingInt(ComplianceItem::getKoLinked)));
		// convert hashmap to list of keys and values
		List<String> appsnamesummonthsList = appsnameTotRes.keySet().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		List<Object> appsnamesumkoLinkedDataList = appsnameTotRes.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		List<Object> appsnamesumkoNotLinkedDataList = appsnameKOLink.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		List<Object> appsnamekoLinkedDataList = appsnameResVsLink.values().stream()
				.collect(Collectors.toCollection(ArrayList::new));
		
		List<HashMap<String, String>> charthashmp = new ArrayList<>();
		HashMap<String, String> chartdatamp = new HashMap<>();
		chartdatamp.put(TOWER_MONTHS_LIST, jsonReplace(towersummonthsList)); // strTowersummonthsListrep);
		chartdatamp.put(TOWER_KOLINKED_DATALIST, jsonReplace(towersumkoLinkedDataList)); // strTowersumkoLinkedDataListrep);
		chartdatamp.put("strTower_sum_koNotLinkedDataList", jsonReplace(towersumkoNotLinkedDataList)); // strTowersumkoNotLinkedDataListrep);
		chartdatamp.put("strTower_koLinkedDataList", jsonReplace(koLinkedDataList));
		chartdatamp.put(CC_MONTHS_LIST, jsonReplace(ccsummonthsList)); // strCCsummonthsListrep);
		chartdatamp.put(CC_KOLINKED_DATALIST, jsonReplace(ccsumkoLinkedDataList)); // strCCsumkoLinkedDataListrep);
		chartdatamp.put("strCC_sum_koNotLinkedDataList", jsonReplace(ccsumkoNotLinkedDataList)); // strCCsumkoNotLinkedDataListrep);
		chartdatamp.put("strCC_cckoLinkedDataList", jsonReplace(cckoLinkedDataList));
		chartdatamp.put(STRCULSTER_SUM_MONTHSLIST, jsonReplace(culstersummonthsList)); // strCulstersummonthsListrep);
		chartdatamp.put(CULSTER_KOLINKED_DATALIST, jsonReplace(culstersumkoLinkedDataList)); // strCulstersumkoLinkedDataListrep);
		chartdatamp.put("strCulster_sum_koNotLinkedDataList", jsonReplace(culstersumkoNotLinkedDataList)); // strCulstersumkoNotLinkedDataListrep);
		chartdatamp.put("strCulster_koLinkedDataList", jsonReplace(culsterkoLinkedDataList));
		chartdatamp.put(ASGMTGRP_MONTHSLIST, jsonReplace(asgmtgrpsummonthsList)); // strAsgmtgrpsummonthsListrep);
		chartdatamp.put(ASGMTGRP_KOLINKED_DATALIST, jsonReplace(asgmtgrpsumkoLinkedDataList)); // strAsgmtgrpsumkoLinkedDataListrep);
		chartdatamp.put("strAsgmtgrp_sum_koNotLinkedDataList", jsonReplace(asgmtgrpsumkoNotLinkedDataList)); // strAsgmtgrpsumkoNotLinkedDataListrep);
		chartdatamp.put("strAsgmtgrp_koLinkedDataList", jsonReplace(asgmtgrpkoLinkedDataList));
		chartdatamp.put("strAppsname_sum_monthsList", jsonReplace(appsnamesummonthsList)); // strAppsnamesummonthsListrep);
		chartdatamp.put("strAppsname_sum_koLinkedDataList", jsonReplace(appsnamesumkoLinkedDataList)); // strAppsnamesumkoLinkedDataListrep);
		chartdatamp.put("strAppsname_sum_koNotLinkedDataList", jsonReplace(appsnamesumkoNotLinkedDataList)); // strAppsnamesumkoNotLinkedDataListrep);
		chartdatamp.put("strAppsname_koLinkedDataList", jsonReplace(appsnamekoLinkedDataList));
		charthashmp.add(chartdatamp);
		log.info("End: Compliancechrtdispgetload");
		return gson.toJson(chartdatamp);
	}	
	
	/**
	 * Ko Creation report.
	 *
	 * @param koInfo  the ko info
	 * @param model   the model
	 * @param request the request
	 * @return the string
	 */
	@GetMapping("/koCreationReport")
	public String koCreationReport(@ModelAttribute("koCreationReportFormDetail") KOInfoBean koInfo, Model model,
			HttpServletRequest request) {
		String accountId = getDefaultAccountId();
		model.addAttribute(REPORT_CATEGORIZATION, request.getParameter(REPORT_CATEGORIZATION));
		model.addAttribute(COMPONENT_TYPE, request.getParameter(COMPONENT_TYPE));
		model.addAttribute(REPORT_TYPE_STRING, request.getParameter(REPORT_TYPE_STRING));
		model.addAttribute(REPORT_NAME, request.getParameter(REPORT_NAME));
		model.addAttribute(REPORT_FREQUENCY, request.getParameter(REPORT_FREQUENCY));
		model.addAttribute(FROM_DATE_STRING, request.getParameter(FROM_DATE_STRING));
		model.addAttribute(TO_DATE, request.getParameter(TO_DATE));

		if (!StringUtils.isEmpty(accountId)) {
			model.addAttribute(DEFAULT_ACCOUNTNAME,
					ticketDataService.getAccountNameByAccountId(Integer.parseInt(accountId)));
		}

		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String loginusrname = auth.getName();
		String appName = request.getParameter(APPNAME);
		ReportDataAttributeVO reportDataAttributeVO = new ReportDataAttributeVO(accountId, loginusrname, KO_USAGE_REPORT_ID, VIEW_ACTION_ID);
		reportService.insertReportUsage(reportDataAttributeVO);
		koInfo.setApplicationName(getStringOrNull(appName));
		List<KOInfoBean> koInfoBeanListusage = null;
		MasterDataAttributeVO masterDataAttributeVO = new MasterDataAttributeVO(accountId, koInfo.getApplicationName(), koInfo.getAssignmentGroup(), koInfo.getTower(), koInfo.getCC(), koInfo.getCluster(), "");
		masterDataAttributeVO.setFromDateTodate(koInfo.getFromDate(), koInfo.getToDate());
		koInfoBeanListusage = koInfoService.koCreationRepo(masterDataAttributeVO.getFromDate(), masterDataAttributeVO.getToDate());

		UserBean ubean = userService.getUserAccountType(accountId);
		int isGeneric = ubean.getIsGeneric();
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		model.addAttribute(IS_GENERIC, isGeneric);

		model.addAttribute("koCreationReportList", koInfoBeanListusage);
		model.addAttribute(FROM_HEADING, "KO Creation Report List");

		return "koCreationReport";
	}

	/**
	 * Ko Creation report POST.
	 *
	 * @param koInfo  the ko info
	 * @param model   the model
	 * @param request the request
	 * @return the string
	 */
	@PostMapping("/koCreationReport")
	public String koCreationReportPOST(@ModelAttribute("koCreationReportFormDetail") KOInfoBean koInfo, Model model,
			HttpServletRequest request) {
		String accountId = getDefaultAccountId();
		model.addAttribute(REPORT_CATEGORIZATION, request.getParameter(REPORT_CATEGORIZATION));
		model.addAttribute(COMPONENT_TYPE, request.getParameter(COMPONENT_TYPE));
		model.addAttribute(REPORT_TYPE_STRING, request.getParameter(REPORT_TYPE_STRING));
		model.addAttribute(REPORT_NAME, request.getParameter(REPORT_NAME));
		model.addAttribute(REPORT_FREQUENCY, request.getParameter(REPORT_FREQUENCY));
		model.addAttribute(FROM_DATE_STRING, request.getParameter(FROM_DATE_STRING));
		model.addAttribute(TO_DATE, request.getParameter(TO_DATE));
		if (!StringUtils.isEmpty(accountId)) {
			model.addAttribute(DEFAULT_ACCOUNTNAME,
					ticketDataService.getAccountNameByAccountId(Integer.parseInt(accountId)));
		}

		List<KOInfoBean> koInfoBeanListusage = null;
		MasterDataAttributeVO masterDataAttributeVO = new MasterDataAttributeVO(accountId, koInfo.getApplicationName(), koInfo.getAssignmentGroup(), koInfo.getTower(), koInfo.getCC(), koInfo.getCluster(), "");
		masterDataAttributeVO.setFromDateTodate(koInfo.getFromDate(), koInfo.getToDate());
		koInfoBeanListusage = koInfoService.koCreationRepo(masterDataAttributeVO.getFromDate(), masterDataAttributeVO.getToDate());

		UserBean ubean = userService.getUserAccountType(accountId);
		int isGeneric = ubean.getIsGeneric();
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		model.addAttribute(IS_GENERIC, isGeneric);

		model.addAttribute("koCreationReportList", koInfoBeanListusage);
		model.addAttribute(FROM_HEADING, "KO Creation Report List");

		return "koCreationReport";
	}
	/**
	 * Ko Metrics report.
	 *
	 * @param koInfo  the ko info
	 * @param model   the model
	 * @param request the request
	 * @return the string
	 */
	@GetMapping("/koMetricsReport")
	public String koMetricsReport(@ModelAttribute("koMetricsReportFormDetail") KOInfoBean koInfo,KOMetricsBean koMBean, Model model,
			HttpServletRequest request) {
		String accountId = getDefaultAccountId();
		model.addAttribute(REPORT_CATEGORIZATION, request.getParameter(REPORT_CATEGORIZATION));
		model.addAttribute(COMPONENT_TYPE, request.getParameter(COMPONENT_TYPE));
		model.addAttribute(REPORT_TYPE_STRING, request.getParameter(REPORT_TYPE_STRING));
		model.addAttribute(REPORT_NAME, request.getParameter(REPORT_NAME));
		model.addAttribute(REPORT_FREQUENCY, request.getParameter(REPORT_FREQUENCY));
		model.addAttribute(FROM_DATE_STRING, request.getParameter(FROM_DATE_STRING));
		model.addAttribute(TO_DATE, request.getParameter(TO_DATE));

		if (!StringUtils.isEmpty(accountId)) {
			model.addAttribute(DEFAULT_ACCOUNTNAME,
					ticketDataService.getAccountNameByAccountId(Integer.parseInt(accountId)));
		}

		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String loginusrname = auth.getName();
		String appName = request.getParameter(APPNAME);
		ReportDataAttributeVO reportDataAttributeVO = new ReportDataAttributeVO(accountId, loginusrname, KO_USAGE_REPORT_ID, VIEW_ACTION_ID);
		reportService.insertReportUsage(reportDataAttributeVO);
		koInfo.setApplicationName(getStringOrNull(appName));
		
		List<KOMetricsBean> koInfoBeanListusage = null;
		MasterDataAttributeVO masterDataAttributeVO = new MasterDataAttributeVO(accountId, koInfo.getApplicationName(), koInfo.getAssignmentGroup(), koInfo.getTower(), koInfo.getCC(), koInfo.getCluster(), "");
		masterDataAttributeVO.setFromDateTodate(koInfo.getFromDate(), koInfo.getToDate());
		koInfoBeanListusage = koInfoService.koMetricsRepo(masterDataAttributeVO.getFromDate(), masterDataAttributeVO.getToDate());
		
		//List<KOMetricsBean> koMetList = koInfoBeanListusage;
		Set<String> headerSet = new LinkedHashSet<String>();
		Set<String> towerSet = new LinkedHashSet<String>();
		Map<String, KOMetricsBean> headerVal = new LinkedHashMap<String, KOMetricsBean>();
		Map<String, Map<String, KOMetricsBean>> rowHeaderVal = new LinkedHashMap<String, Map<String, KOMetricsBean>>();
		for(KOMetricsBean kb : koInfoBeanListusage){
			headerSet.add(kb.getTimeline());
			headerVal.put(kb.getTower()+"@@"+kb.getTimeline(), kb);
			towerSet.add(kb.getTower());
		}
		for(String tw : towerSet){
			Map<String, KOMetricsBean> hdVal = new LinkedHashMap<String, KOMetricsBean>();
			for(String tl : headerSet){
				if(headerVal.containsKey(tw+"@@"+tl)){
					hdVal.put(tl,headerVal.get(tw+"@@"+tl));
				}else{
					hdVal.put(tl,new KOMetricsBean());
				}
			}
			rowHeaderVal.put(tw, hdVal);
		}
		 
		
		UserBean ubean = userService.getUserAccountType(accountId);
		int isGeneric = ubean.getIsGeneric();
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		model.addAttribute(IS_GENERIC, isGeneric);

		model.addAttribute("headerSet", headerSet);
		model.addAttribute("rowHeaderVal", rowHeaderVal);
		model.addAttribute(FROM_HEADING, "KO Metrics Report");

		return "koMetricsReport";
	}

	/**
	 * Ko Metrics report POST.
	 *
	 * @param koInfo  the ko info
	 * @param model   the model
	 * @param request the request
	 * @return the string
	 */
	@PostMapping("/koMetricsReport")
	public String koMetricsReportPOST(@ModelAttribute("koMetricsReportFormDetail") KOInfoBean koInfo, Model model,
			HttpServletRequest request) {
		String accountId = getDefaultAccountId();
		model.addAttribute(REPORT_CATEGORIZATION, request.getParameter(REPORT_CATEGORIZATION));
		model.addAttribute(COMPONENT_TYPE, request.getParameter(COMPONENT_TYPE));
		model.addAttribute(REPORT_TYPE_STRING, request.getParameter(REPORT_TYPE_STRING));
		model.addAttribute(REPORT_NAME, request.getParameter(REPORT_NAME));
		model.addAttribute(REPORT_FREQUENCY, request.getParameter(REPORT_FREQUENCY));
		model.addAttribute(FROM_DATE_STRING, request.getParameter(FROM_DATE_STRING));
		model.addAttribute(TO_DATE, request.getParameter(TO_DATE));
		if (!StringUtils.isEmpty(accountId)) {
			model.addAttribute(DEFAULT_ACCOUNTNAME,
					ticketDataService.getAccountNameByAccountId(Integer.parseInt(accountId)));
		}

		List<KOMetricsBean> koInfoBeanListusage = null;
		MasterDataAttributeVO masterDataAttributeVO = new MasterDataAttributeVO(accountId, koInfo.getApplicationName(), koInfo.getAssignmentGroup(), koInfo.getTower(), koInfo.getCC(), koInfo.getCluster(), "");
		masterDataAttributeVO.setFromDateTodate(koInfo.getFromDate(), koInfo.getToDate());
		koInfoBeanListusage = koInfoService.koMetricsRepo(masterDataAttributeVO.getFromDate(), masterDataAttributeVO.getToDate());
		//List<KOMetricsBean> koMetList = koInfoBeanListusage;
				Set<String> headerSet = new LinkedHashSet<String>();
				Set<String> towerSet = new LinkedHashSet<String>();
				Map<String, KOMetricsBean> headerVal = new LinkedHashMap<String, KOMetricsBean>();
				Map<String, Map<String, KOMetricsBean>> rowHeaderVal = new LinkedHashMap<String, Map<String, KOMetricsBean>>();
				for(KOMetricsBean kb : koInfoBeanListusage){
					headerSet.add(kb.getTimeline());
					headerVal.put(kb.getTower()+"@@"+kb.getTimeline(), kb);
					towerSet.add(kb.getTower());
				}
				for(String tw : towerSet){
					Map<String, KOMetricsBean> hdVal = new LinkedHashMap<String, KOMetricsBean>();
					for(String tl : headerSet){
						if(headerVal.containsKey(tw+"@@"+tl)){
							hdVal.put(tl,headerVal.get(tw+"@@"+tl));
						}else{
							hdVal.put(tl,new KOMetricsBean());
						}
					}
					rowHeaderVal.put(tw, hdVal);
				}
				 
				
				UserBean ubean = userService.getUserAccountType(accountId);
				int isGeneric = ubean.getIsGeneric();
				int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
				model.addAttribute("isHelpdeskVisible", helpdeskStatus);
				model.addAttribute(IS_GENERIC, isGeneric);

				model.addAttribute("headerSet", headerSet);
				model.addAttribute("rowHeaderVal", rowHeaderVal);
		model.addAttribute(FROM_HEADING, "KO Metrics Report");

		return "koMetricsReport";
	}
}
