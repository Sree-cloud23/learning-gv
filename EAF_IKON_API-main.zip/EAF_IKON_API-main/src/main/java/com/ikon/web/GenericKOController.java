package com.ikon.web;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;
import java.util.Properties;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.persistence.PersistenceException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import com.ikon.dto.KOInfoBean;
import com.ikon.dto.KOReviewerBean;
import com.ikon.dto.KoDataAttribute;
import com.ikon.dto.KoDataAttributeVO;
import com.ikon.dto.MasterDataAttributeVO;
import com.ikon.dto.ReportDataAttributeVO;
import com.ikon.dto.SearchDataAttributeVO;
import com.ikon.dto.SettingBean;
import com.ikon.dto.TicketDataAttributeVO;
import com.ikon.dto.TicketDataBean;
import com.ikon.dto.UserBean;
import com.ikon.model.BusinessProcessMaster;
import com.ikon.model.KOUsage;
import com.ikon.repository.BusinessProcessRepository;
import com.ikon.repository.KOInfoRepository;
import com.ikon.repository.KOUsageRepository;
import com.ikon.rest.web.models.Authentication;
import com.ikon.rest.web.models.SecurityContext;
import com.ikon.rest.web.models.SecurityContextHolder;
import com.ikon.service.AccessControlService;
import com.ikon.service.HelpDeskService;
import com.ikon.service.KOInfoService;
import com.ikon.service.KOUsageService;
import com.ikon.service.MLDBProcess;
import com.ikon.service.ReportService;
import com.ikon.service.TicketDataService;
import com.ikon.service.UserService;
import com.mongodb.MongoException;

import lombok.extern.slf4j.Slf4j;

/**
 * The Class GenericKOController.
 */
@Controller
@Slf4j
public class GenericKOController {

	/** The Constant log. */
	//private static final log log = LogManager.getlog(GenericKOController.class);

	/** The ko info service. */
	@Inject
	private transient KOInfoService koInfoService;

	/** The ticket data service. */
	@Inject
	private transient TicketDataService ticketDataService;

	/** The access control service. */
	@Inject
	private transient AccessControlService accessControlService;

	/** The k O usage repository. */
	@Inject
	private transient KOUsageRepository kOUsageRepository;

	/** The k O info repository. */
	@Inject
	private transient KOInfoRepository kOInfoRepository;

	/** The ikon controller. */
	@Inject
	private transient IKONController ikonController;

	/** The business process repository. */
	@Inject
	private transient BusinessProcessRepository businessRepository;

	/** The report service. */
	@Inject
	private transient ReportService reportService;

	/** The help service. */
	@Inject
	private transient HelpDeskService helpService;

	/** The ko service service. */
	@Inject
	private KOUsageService koUsageService;

	/** The Constant KO_APPROVAL_CYCLE_REPORT_ID. */
	private static final String KO_APPROVAL_CYCLE_REPORT_ID = "11";

	/** The Constant VIEW_ACTION_ID. */
	private static final String VIEW_ACTION_ID = "1";

	/** The user service. */
	@Inject
	private transient UserService userService;

	/** The Constant HEADER_CREATE_KO. */
	private static final String HEADER_CREATE_KO = "Create KO";

	/** The Constant DISPLAY ERROR. */
	private static final String DISPLAY_ERROR = "displayerror";

	/** The Constant SHOW_RELATED_KO_STRING. */
	private static final String SHOW_RELATED_KO_STRING = "showRelatedKOs";

	/** The Constant CREATED_BY_STRING. */
	private static final String CREATED_BY_STRING = "createdBy";

	/** The Constant ALL_CREATED_BY_LIST. */
	private static final String ALL_CREATED_BY_LIST = "allCreatedByList";

	/** The Constant REPORT_TYPE_STRING. */
	private static final String REPORT_TYPE_STRING = "reportType";

	/** The Constant LONG_DESCRIPTION_STRING. */
	private static final String LONG_DESCRIPTION_STRING = "Long Description";

	/** The Constant SHORT_DESCRIPTION_STRING. */
	private static final String SHORT_DESCRIPTION_STRING = "Short Description";

	/** The Constant APPLICATION_NAMELIST. */
	private static final String APPLICATION_NAMELIST = "allApplicationNameList";

	/** The Constant CREATEKO_FORM. */
	private static final String CREATEKO_FORM = "createKOForm";

	/** The Constant TRUE. */
	private static final String TRUE = "true";

	/** The Constant SYMPTOMS. */
	private static final String SYMPTOMS = "Symptoms";

	/** The Constant FILTER_SELECTION. */
	private static final String FILTER_SELECTION = "filterSelection";

	/** The Constant ALL_ASSIGNMENT_GROUPLIST. */
	private static final String ALL_ASSIGNMENT_GROUPLIST = "allAssignmentGroupList";

	/** The Constant ALL_PUBLICATION_STATUSLIST. */
	private static final String ALL_PUBLICATION_STATUSLIST = "allPublicationStatusList";

	/** The Constant STATUS. */
	private static final String STATUS = "Status";

	/** The Constant FROM_HEADING. */
	private static final String FROM_HEADING = "formheading";

	/** The Constant APPROVED. */
	private static final String APPROVED = "Approved";

	/** The Constant READONLY_KO. */
	private static final String READONLY_KO = "readonlyko";

	/** The Constant ATTACHMENT_PRESENT. */
	private static final String ATTACHMENT_PRESENT = "attachmentPresent";

	/** The Constant KO_ID. */
	private static final String KO_ID = "KO ID";

	/** The Constant RESOLUTION_NOTES. */
	private static final String RESOLUTION_NOTES = "Resolution Notes";

	/** The Constant TICKETID_FROMVIEW. */
	private static final String TICKETID_FROMVIEW = "ticketIdFromView";

	/** The Constant PUBLISHED. */
	private static final String PUBLISHED = "Published";

	/** The Constant MODILE LIST. */
	private static final String MODULE_LIST = "moduleList";

	/** The Constant PERMISSION DENIED. */
	private static final String PERMISSION_DENIED = "permissionDenied";

	/** The Constant BP LVL1. */
	private static final String BP_LVL1 = "Business process Level 1";

	/** The Constant BP LVL2. */
	private static final String BP_LVL2 = "Business process Level 2";

	/** The Constant BP LVL3. */
	private static final String BP_LVL3 = "Business process Level 3";

	/** The Constant GEN USER. */
	private static final String GEN_USER = "User belongs to Generic account";

	/** The Constant GEN EN USER. */
	private static final String GEN_EN_USER = "User belongs to Generic enabled account";

	/** The Constant USER NOT EXISTS. */
	private static final String USER_NOT_EXISTS = "User does not exists";

	/** The Constant NOT GEN USER. */
	private static final String NOT_GEN_USER = "User does not belongs to Generic account";

	/** The Constant CRAETE GEN REQ. */
	private static final String CRAETE_GEN_REQ = "/createKOGeneric";

	/** The Constant MODULE NAME. */
	private static final String MODULE_NAME = "Module Name";

	/** The Constant ONE. */
	private static final int ONE = 1;

	/** The Constant TWO. */
	private static final int TWO = 2;

	/** The Constant CREATE_KO. */
	private static final Integer CREATE_KO = 1;

	/** The Constant EDIT_KO. */
	private static final Integer EDIT_KO = 0;

	/** The Constant REPORT_CATEGORIZATION. */
	private static final String REPORT_CATEGORIZATION = "reportCategorization";

	/** The Constant REPORT_NAME. */
	private static final String REPORT_NAME = "reportName";

	/** The Constant REPORT_FREQUENCY. */
	private static final String REPORT_FREQUENCY = "reportFrequency";

	/** The Constant COMPONENT_TYPE. */
	private static final String COMPONENT_TYPE = "componentType";

	/** The Constant FROM_DATE_STRING. */
	private static final String FROM_DATE_STRING = "fromDate";

	/** The Constant TO_DATE. */
	private static final String TO_DATE = "toDate";
	/** The Constant FROM_PAGE. */
	private static final String FROM_PAGE ="fromPage";
	
	/** The ikon controller. */
	@Inject
	private transient KOController koController;
	
	/** The helpdesk controller. */
	@Inject
	private transient HelpDeskController helpdeskController;
	
	/** The Constant INTERNAL_REQ. */
	private static final String INTERNAL_REQ ="internal";
	/** The Constant EXTERNAL_REQ. */
	private static final String EXTERNAL_REQ ="external";
	
	/** The ml DB process. */
	@Inject
	private transient MLDBProcess mlDBProcess;
	
	/** The Constant INDRAFT. */
	private static final String INDRAFT = "InDraft";

	/**
	 * Get default account id.
	 *
	 * @return the default account id
	 */
	private String getDefaultAccountId() {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String loginusrname = auth.getName();

		String accountId = String.valueOf(accessControlService.getAccessDetailByUserId(loginusrname).getAccountId());
		return accountId;
	}

	/**
	 * Ko list.
	 *
	 * @param koInfo  the ko info
	 * @param model   the model
	 * @param request the request
	 * @return the string
	 */
	@GetMapping("/koListGeneric")
	public String koListGeneric(@ModelAttribute("kolinkFormDetail") KOInfoBean koInfo, Model model,
			HttpServletRequest request) {
		log.info("Start: koListGeneric");
		String accountId = getDefaultAccountId();
		String userId = getLoggedUser();
		int isGeneric = getUserAccount();
		switch (isGeneric) {
		case 1:
			log.info(GEN_USER);
			break;
		case 2:
			log.info(GEN_EN_USER);
			break;
		case 0:
			log.info(NOT_GEN_USER);
			return PERMISSION_DENIED;
		case -1:
			log.info(USER_NOT_EXISTS);
			return null;
		default:
			return PERMISSION_DENIED;
		}

		if (!StringUtils.isEmpty(request.getParameter(CREATED_BY_STRING))) {
			koInfo.setCreatedBy(request.getParameter(CREATED_BY_STRING));
		}
		String appName = request.getParameter("appName");
		koInfo.setApplicationName((String) ifNotNull(appName, appName, koInfo.getApplicationName()));
		List<KOInfoBean> koInfoBeanList = null;

		List<KOUsage> koUsageList = kOUsageRepository.findAll();
		List<KOInfoBean> koInfoList = koInfoService.getAllKos(accountId);
		boolean relatedko = false;
		if (!StringUtils.isEmpty(request.getParameter(SHOW_RELATED_KO_STRING))) {
			koInfoBeanList = koInfoService.showAllRelatedKOs(request.getParameter(SHOW_RELATED_KO_STRING));
			koInfoBeanList.forEach(koib -> {
				TicketDataBean tdb = new TicketDataBean();
				tdb.setRelevPerc(koib.getRelevPerc());
				tdb.setUsagePerc(koib.getUsagePerc());
				ikonController.processRelevUsagePerc(koUsageList, koInfoList, tdb);
				koib.setRelevPerc(tdb.getRelevPerc());
				koib.setUsagePerc(tdb.getUsagePerc());
				koib.setTicketLinkedCount(tdb.getTicketLinkedCount());
				koib.setSeperatedKoID(tdb.getSeperatedKoID());
				koib.setSeperatedKoPerc(tdb.getSeperatedKoPerc());
				koib.setSeperatedKoRelID(tdb.getSeperatedKoRelID());
				koib.setSeperatedKoRelPer(tdb.getSeperatedKoRelPer());

				if (!StringUtils.isEmpty(koib.getSelectedKoForResolution())
						&& koib.getSelectedKoForResolution().equalsIgnoreCase(koib.getKoID())) {
					koib.setIsSelectedForResolution("yes");
				}
			});
			model.addAttribute("relatedko", TRUE);
			model.addAttribute(READONLY_KO, TRUE);
			model.addAttribute(SHOW_RELATED_KO_STRING, request.getParameter(SHOW_RELATED_KO_STRING));
			relatedko = true;
		} else {
			KoDataAttributeVO KoAttrVo= new KoDataAttributeVO();
			KoAttrVo.setMasterDtAttrVo(new MasterDataAttributeVO(accountId,"", "", "", "", "", userId));
			KoAttrVo.setKoDtAttr(new KoDataAttribute("", "", "", "", "", koInfo.getKoType()));	
			koInfoBeanList = koInfoService.kolistviewSP(KoAttrVo);
		}
		String filterSelection = request.getParameter(FILTER_SELECTION);

		if (!StringUtils.isEmpty(filterSelection)) {
			model.addAttribute(FILTER_SELECTION, filterSelection);
		}
		addKoInfoListstoModel(model, koInfoBeanList);
		addViewSerialNumToKoBean(koInfoBeanList);
		List<String> selectedValsArr = getKoValueArray(relatedko);
		model.addAttribute("isGeneric", isGeneric);
		model.addAttribute("koType", koInfo.getKoType());
		
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);

		model.addAttribute("koInfoList", koInfoBeanList);
		log.info("End: koListGeneric");
		return returnKO(model, koInfoBeanList, selectedValsArr);

	}

	/**
	 * Gets the ko value array.
	 *
	 * @param relatedko the relatedko
	 * @return the ko value array
	 */
	private List<String> getKoValueArray(boolean relatedko) {
		ArrayList<String> selectedValsArr = new ArrayList<>();
		if (relatedko) {
			selectedValsArr = new ArrayList<>(Arrays.asList(KO_ID, SHORT_DESCRIPTION_STRING, LONG_DESCRIPTION_STRING,
					MODULE_NAME, BP_LVL1, BP_LVL2, BP_LVL3, STATUS, SYMPTOMS, RESOLUTION_NOTES, "KO Rel%", "KO Usage",
					"# Inc Linked"));
		} else {
			selectedValsArr = new ArrayList<>(Arrays.asList(KO_ID, SHORT_DESCRIPTION_STRING, LONG_DESCRIPTION_STRING,
					MODULE_NAME, BP_LVL1, BP_LVL2, BP_LVL3, "Created By", STATUS, SYMPTOMS, RESOLUTION_NOTES));
		}
		return selectedValsArr;
	}

	/**
	 * Adds the view serial num to ko bean.
	 *
	 * @param koInfoBeanList the ko info bean list
	 */
	private void addViewSerialNumToKoBean(List<KOInfoBean> koInfoBeanList) {

		int serialNum = 1;
		for (KOInfoBean koInfoBean : koInfoBeanList) {
			koInfoBean.setKoViewSerialNum(serialNum++);
		}
	}

	/**
	 * Adds the ko info liststo model.
	 *
	 * @param model the model
	 * @param koInfoBeanList the ko info bean list
	 */
	private void addKoInfoListstoModel(Model model, List<KOInfoBean> koInfoBeanList) {
		Set<String> allApplicationNameList = new TreeSet<String>();
		Set<String> allAssignmentGroupList = new TreeSet<String>();
		Set<String> allCreatedByList = new TreeSet<String>();
		Set<String> allPublicationStatusList = new TreeSet<String>();
		koInfoBeanList.forEach(koInfoBean -> {

			if (Objects.equals(koInfoBean.getAttachmentPresent(), ONE)) {
				model.addAttribute(ATTACHMENT_PRESENT, "Y");
			} else {
				model.addAttribute(ATTACHMENT_PRESENT, "N");
			}
			if (!StringUtils.isEmpty(koInfoBean.getApplicationName())) {
				allApplicationNameList.add(koInfoBean.getApplicationName());
			}
			if (!StringUtils.isEmpty(koInfoBean.getAssignmentGroup())) {
				allAssignmentGroupList.add(koInfoBean.getAssignmentGroup());
			}
			if (!StringUtils.isEmpty(koInfoBean.getCreatedBy())) {
				allCreatedByList.add(koInfoBean.getCreatedBy());
			}
			if (!StringUtils.isEmpty(koInfoBean.getPublicationStatus())) {
				allPublicationStatusList.add(koInfoBean.getPublicationStatus());
			}

		});
		model.addAttribute(APPLICATION_NAMELIST, allApplicationNameList);
		model.addAttribute(ALL_ASSIGNMENT_GROUPLIST, allAssignmentGroupList);
		model.addAttribute(ALL_CREATED_BY_LIST, allCreatedByList);
		model.addAttribute(ALL_PUBLICATION_STATUSLIST, allPublicationStatusList);
	}

	/**
	 * Ko list post.
	 *
	 * @param koInfo  the ko info
	 * @param model   the model
	 * @param request the request
	 * @return the string
	 */
	@PostMapping("/koListGeneric")
	public String koListPostGeneric(@ModelAttribute("kolinkFormDetail") KOInfoBean koInfo, Model model,
			HttpServletRequest request) {
		log.info("Start: koListGenericPost");
		String accountId = getDefaultAccountId();
		String userId = getLoggedUser();
		int isGeneric = getUserAccount();
		switch (isGeneric) {
		case 1:
			log.info(GEN_USER);
			break;
		case 2:
			log.info(GEN_EN_USER);
			break;
		case 0:
			log.info(NOT_GEN_USER);
			return PERMISSION_DENIED;
		case -1:
			log.info(USER_NOT_EXISTS);
			return null;
		default:
			return PERMISSION_DENIED;
		}

		String KOID = request.getParameter("kosearchbox");
		String relatedko = request.getParameter("relatedko");
		koInfo.setCreatedBy(getStringOrNull(request.getParameter(CREATED_BY_STRING)));
		KoDataAttributeVO KoAttrVo= new KoDataAttributeVO();
		KoAttrVo.setMasterDtAttrVo(new MasterDataAttributeVO(accountId,koInfo.getApplicationName(), koInfo.getAssignmentGroup(), "", "", "", userId));
		KoAttrVo.setKoDtAttr(new KoDataAttribute(KOID, koInfo.getPublicationStatus(), "", "", koInfo.getCreatedBy(), koInfo.getKoType()));
		List<KOInfoBean> koInfoBeanList = koInfoService.kolistviewSP(KoAttrVo);

		String filterSelection = request.getParameter(FILTER_SELECTION);
		ifNotNullAddToModel(model, filterSelection, FILTER_SELECTION);
		addKoInfoListstoModel(model, koInfoBeanList);
		addViewSerialNumToKoBean(koInfoBeanList);

		List<KOUsage> koUsageList = kOUsageRepository.findAll();
		List<KOInfoBean> koInfoList = koInfoService.getAllKos(accountId);
		if (!StringUtils.isEmpty(request.getParameter(SHOW_RELATED_KO_STRING))) {

			koInfoBeanList = koInfoService.showAllRelatedKOs(request.getParameter(SHOW_RELATED_KO_STRING));
			koInfoBeanList.forEach(koib -> {
				TicketDataBean tdb = new TicketDataBean();
				tdb.setRelevPerc(koib.getRelevPerc());
				tdb.setUsagePerc(koib.getUsagePerc());
				ikonController.processRelevUsagePerc(koUsageList, koInfoList, tdb);
				koib.setRelevPerc(tdb.getRelevPerc());
				koib.setUsagePerc(tdb.getUsagePerc());
				koib.setTicketLinkedCount(tdb.getTicketLinkedCount());
				koib.setSeperatedKoID(tdb.getSeperatedKoID());
				koib.setSeperatedKoPerc(tdb.getSeperatedKoPerc());
			});
			model.addAttribute("relatedko", TRUE);
			model.addAttribute(READONLY_KO, TRUE);
			model.addAttribute(SHOW_RELATED_KO_STRING, request.getParameter(SHOW_RELATED_KO_STRING));
		}

		model.addAttribute("koInfoList", koInfoBeanList);
		log.info("End: koListGenericPost");
		List<String> selectedValsArr = getKoValueArray(relatedko.equalsIgnoreCase(TRUE));
		List<String> selectedValsNew = new ArrayList<String>();
		if (Objects.nonNull(koInfo) && Objects.nonNull(koInfo.getSelectedVals())) {
			selectedValsNew = new ArrayList<String>(Arrays.asList(koInfo.getSelectedVals().split(",")));
		}
		selectedValsNew.removeAll(selectedValsArr);
		List<String> notPresentList = selectedValsNew;
		Collections.sort(notPresentList);
		if (Objects.nonNull(notPresentList) && !notPresentList.isEmpty()) {
			selectedValsArr.addAll(notPresentList);
		}
		model.addAttribute("isGeneric", isGeneric);
		model.addAttribute("koType", koInfo.getKoType());
		
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		
		return returnKO(model, koInfoBeanList, selectedValsArr);
	}

	/**
	 * If not null add to model.
	 *
	 * @param model the model
	 * @param o1 the o 1
	 * @param s the s
	 */
	private void ifNotNullAddToModel(Model model, Object o1, String s) {
		if (!StringUtils.isEmpty(o1)) {
			model.addAttribute(s, o1);
		}
	}

	/**
	 * Return KO summary.
	 *
	 * @param model            the model
	 * @param koInfoBeanList   the ko info bean list
	 * @param selectedValsList the selected vals list
	 * @return the string
	 */
	private String returnKO(Model model, List<KOInfoBean> koInfoBeanList, List<String> selectedValsList) {
		model.addAttribute("selectedValsLists", selectedValsList);
		if (selectedValsList.contains("ITSM Tool")) {
			model.addAttribute("ITSM_Tool", TRUE);
		}
		if (selectedValsList.contains("Attachment Present")) {
			model.addAttribute("Attachment_Present", TRUE);
		}
		if (selectedValsList.contains("AttachmentName")) {
			model.addAttribute("AttachmentName", TRUE);
		}
		if (selectedValsList.contains("KO Create Date")) {
			model.addAttribute("KO_Create_Date", TRUE);
		}
		model.addAttribute(FROM_HEADING, "Generic KO List");
		return "koListGeneric";
	}

	/**
	 * Edits the generic KO.
	 *
	 * @param koId the ko id
	 * @param modelAndView the model and view
	 * @param model the model
	 * @param request the request
	 * @param koInfo the ko info
	 * @return the model and view
	 */
	@GetMapping(value = "/editGenericKO/{koId}")
	public ModelAndView editGenericKO(@PathVariable String koId, ModelAndView modelAndView, Model model,
			HttpServletRequest request, @ModelAttribute(CREATEKO_FORM) KOInfoBean koInfo) {

		log.info("Start: editGenericKO");
		String userId = getLoggedUser();
		int isGeneric = getUserAccount();
		switch (isGeneric) {
		case 1:
			log.info(GEN_USER);
			break;
		case 2:
			log.info(GEN_EN_USER);
			break;
		case 0:
			log.info(NOT_GEN_USER);
			return new ModelAndView(PERMISSION_DENIED);
		case -1:
			log.info(USER_NOT_EXISTS);
			return null;
		default:
			return new ModelAndView(PERMISSION_DENIED);
		}
		updateModel(request, model);
		String accountId = getDefaultAccountId();
		modelAndView.addObject(FROM_HEADING, "Edit Generic KO");
		List<KOInfoBean> koInfoBeanList = editKODetail(Objects.equals(TWO, isGeneric), koId, accountId);
		setKoBeanDocName(koInfoBeanList);
		KOInfoBean koInfoBean = (KOInfoBean) getFirstElement(koInfoBeanList);
		List<String> tagsList = getTagsList(koInfoBean);
		model.addAttribute("tagsListVal", ifNotNull(koInfoBean, tagsList, "No tags to display"));
		List<KOInfoBean> reviewCommentsList = retrieveReviewComments(Objects.equals(TWO, isGeneric), koId);
		List<KOInfoBean> reviewCommentsCopy = new ArrayList<KOInfoBean>();

		int serialNum = addKOSerialNo(reviewCommentsList);
		KOInfoBean koPublishStatusBean = null;

		// get KO reviwerlist
		MasterDataAttributeVO masterDataAttributeVO = new MasterDataAttributeVO(getDefaultAccountId(), koInfoBean.getApplicationName(), "", "", "", "", userId);
		List<KOReviewerBean> koReviewersList = koInfoService.getKOReviewersByAssignmentGroup(masterDataAttributeVO, EDIT_KO);
		model.addAttribute("koReviewersList", koReviewersList);

		if (Objects.nonNull(reviewCommentsList) && reviewCommentsList.size() > 0) {
			reviewCommentsCopy = reviewCommentsList.stream()
					.filter(tdb -> !StringUtils.isEmpty(tdb.getReviewComments())).collect(Collectors.toList());
			koPublishStatusBean = reviewCommentsList.get(0);
			koPublishStatusBean.setTicketLinkedCount(
					Objects.equals(TWO, isGeneric) ? ticketDataService.getNoOfIncLinkedForKO(koPublishStatusBean.getKoID(),accountId) : 0);
			model.addAttribute("koPublishStatus", koPublishStatusBean);
		}
		String accountName = getAccountName();
		model.addAttribute("accountName",accountName);
		model.addAttribute("reviewCommentsList", reviewCommentsCopy);
		model.addAttribute("nextSerialNum", serialNum);
		model.addAttribute(CREATEKO_FORM, koInfoBean);
		model.addAttribute("koPublicationStatusVal", koInfoBean.getPublicationStatus());
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		model.addAttribute("loggedInUserId", auth.getName());

		model.addAttribute("isGeneric", isGeneric);
		
		int koEnabledStatus = koController.getKOEnabledStatus(Integer.parseInt(accountId));
		model.addAttribute("isKOEnabled", koEnabledStatus);
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		
		if ((Objects.nonNull(auth) && !StringUtils.isEmpty(auth.getName()) && Objects.nonNull(koPublishStatusBean)))
			updateEditKoModel(model, auth.getName(), koPublishStatusBean, koInfoBean);
		if (!StringUtils.isEmpty(request.getParameter(SHOW_RELATED_KO_STRING))) {
			model.addAttribute(SHOW_RELATED_KO_STRING, request.getParameter(SHOW_RELATED_KO_STRING));
		}
		log.info("End: editGenericKO");
		return new ModelAndView("editGenericKO");

	}
	
	/**
	 * Gets the account name.
	 *
	 * @return the account name
	 */
	private String getAccountName() {
		SecurityContext sc = SecurityContextHolder.getContext();
		Authentication auth = sc.getAuthentication();
		List<SettingBean> sbList = helpService.accountAccess(auth.getName());
		return Objects.nonNull(sbList) && sbList.size() > 0 && Objects.nonNull(sbList.get(0)) && Objects.nonNull(sbList.get(0).getAccountName())
				? sbList.get(0).getAccountName()
				: "Unknown";
	}

	/**
	 * Adds the KO serial no.
	 *
	 * @param koInfoList the ko info list
	 * @return the int
	 */
	private int addKOSerialNo(List<KOInfoBean> koInfoList) {
		int serialNum = 1;
		for (KOInfoBean kb : koInfoList) {
			if (!StringUtils.isEmpty(kb.getReviewComments())) {
				kb.setKOSerialNo(serialNum++);
			}
		}
		return serialNum;
	}

	/**
	 * Retrieve review comments.
	 *
	 * @param b the b
	 * @param koId the ko id
	 * @return the list
	 */
	private List<KOInfoBean> retrieveReviewComments(boolean b, String koId) {
		return b ? koInfoService.retrieveGSReviewComments(koId) : koInfoService.retrieveReviewComments(koId);
	}

	/**
	 * Edits the KO detail.
	 *
	 * @param b the b
	 * @param koId the ko id
	 * @param accountId the account id
	 * @return the list
	 */
	private List<KOInfoBean> editKODetail(boolean b, String koId, String accountId) {
		return b ? koInfoService.editGenericKODetail(koId, accountId) : koInfoService.editKODetail(koId);
	}

	/**
	 * If not null.
	 *
	 * @param o1 the o 1
	 * @param o2 the o 2
	 * @param o3 the o 3
	 * @return the object
	 */
	private Object ifNotNull(Object o1, Object o2, Object o3) {
		return Objects.nonNull(o1) ? o2 : o3;
	}

	/**
	 * Update edit ko model.
	 *
	 * @param model the model
	 * @param userId the user id
	 * @param koPublishStatusBean the ko publish status bean
	 * @param koInfoBean the ko info bean
	 */
	private void updateEditKoModel(Model model, String userId, KOInfoBean koPublishStatusBean, KOInfoBean koInfoBean) {
		if (!userId.equalsIgnoreCase(koPublishStatusBean.getReviewedBy()))
			if (!userId.equalsIgnoreCase(koPublishStatusBean.getCreatedBy()))
				model.addAttribute(READONLY_KO, TRUE);
			else if (Objects.nonNull(koInfoBean.getPublicationStatus())
					&& koInfoBean.getPublicationStatus().contains("Review")) {
				model.addAttribute(READONLY_KO, TRUE);
			}
		if ((userId.equalsIgnoreCase(koPublishStatusBean.getReviewedBy())
				&& !userId.equalsIgnoreCase(koPublishStatusBean.getCreatedBy())
				&& Objects.nonNull(koInfoBean.getPublicationStatus()))
				&& (koInfoBean.getPublicationStatus().contains("Rework")
						|| koInfoBean.getPublicationStatus().contains("Draft")
						|| koInfoBean.getPublicationStatus().contains(PUBLISHED))) {
			model.addAttribute(READONLY_KO, TRUE);
		}
		if ((Objects.nonNull(koInfoBean.getPublicationStatus()) && koInfoBean.getPublicationStatus().contains(APPROVED))) {
			model.addAttribute(READONLY_KO, TRUE);
		}
	}

	/**
	 * Gets the tags list.
	 *
	 * @param koInfoBean the ko info bean
	 * @return the tags list
	 */
	private List<String> getTagsList(KOInfoBean koInfoBean) {
		List<String> tagsList = new ArrayList<String>();
		if (Objects.nonNull(koInfoBean) && !StringUtils.isEmpty(koInfoBean.getKOSingleTags())) {
			String singleTags = koInfoBean.getKOSingleTags();
			String[] singleTagsArr = singleTags.split(",");
			singleTagsArr = Arrays.copyOfRange(singleTagsArr, 0, singleTagsArr.length < 4 ? singleTagsArr.length : 4);
			tagsList.addAll(Arrays.asList(singleTagsArr));
		}
		if (Objects.nonNull(koInfoBean) && !StringUtils.isEmpty(koInfoBean.getKOBigramTags())) {
			String bigramTags = koInfoBean.getKOBigramTags();
			String[] bigramTagsArr = bigramTags.split(",");
			bigramTagsArr = Arrays.copyOfRange(bigramTagsArr, 0, bigramTagsArr.length < 3 ? bigramTagsArr.length : 3);
			tagsList.addAll(Arrays.asList(bigramTagsArr));
		}
		if (Objects.nonNull(koInfoBean) && !StringUtils.isEmpty(koInfoBean.getKOTrigramTags())) {
			String trigramTags = koInfoBean.getKOTrigramTags();
			String[] trigramTagsArr = trigramTags.split(",");
			trigramTagsArr = Arrays.copyOfRange(trigramTagsArr, 0,
					trigramTagsArr.length < 2 ? trigramTagsArr.length : 2);
			tagsList.addAll(Arrays.asList(trigramTagsArr));
		}
		return tagsList;
	}

	/**
	 * Sets the ko bean doc name.
	 *
	 * @param koInfoBeanList the new ko bean doc name
	 */
	private void setKoBeanDocName(List<KOInfoBean> koInfoBeanList) {
		String[] fileNameStrArr = null;
		String fileName = "";
		for (KOInfoBean kobean : koInfoBeanList) {
			if (StringUtils.isEmpty(kobean.getAttachmentName())) {
				if (!StringUtils.isEmpty(kobean.getAttachmentPath())) {
					fileNameStrArr = kobean.getAttachmentPath().replace("\\", "/").split("/");
				}
				if (Objects.nonNull(fileNameStrArr) && fileNameStrArr.length > 0) {
					fileName = fileNameStrArr[fileNameStrArr.length - 1].replace("\\", "").replace("/", "");
				}
				kobean.setAttachmentDocumentName(fileName);
			} else {
				kobean.setAttachmentDocumentName(kobean.getAttachmentName());
				kobean.setAttachmentPath(String.join("\\", kobean.getAttachmentPath(),kobean.getAttachmentName()));
			}
		}
	}

	/**
	 * Update model.
	 *
	 * @param request the request
	 * @param model the model
	 */
	private void updateModel(HttpServletRequest request, Model model) {
		if (!StringUtils.isEmpty(request.getParameter(READONLY_KO))) {
			model.addAttribute(READONLY_KO, TRUE);
		}
		if (!StringUtils.isEmpty(request.getParameter("fromPage"))) {
			model.addAttribute(FROM_PAGE, "koac");
		}
		if (!StringUtils.isEmpty(request.getParameter(TICKETID_FROMVIEW))
				|| !StringUtils.isEmpty(request.getParameter(READONLY_KO))) {
			model.addAttribute(FROM_HEADING, "View Generic KO");
			model.addAttribute(TICKETID_FROMVIEW, request.getParameter(TICKETID_FROMVIEW));
		} else {
			model.addAttribute(FROM_HEADING, "Edit Generic KO");
		}
	}

	/**
	 * Edits the KO.
	 *
	 * @param koInfo       the ko info
	 * @param modelAndView the model and view
	 * @param request      the request
	 * @param files        the files
	 * @param model        the model
	 * @return the string
	 * @throws UnsupportedEncodingException 
	 */
	@PostMapping(value = "/editGenericKO/{koId}")
	public String editGenericKO(@ModelAttribute(CREATEKO_FORM) KOInfoBean koInfo, ModelAndView modelAndView,
			HttpServletRequest request, @RequestParam("file") MultipartFile[] files, Model model) throws UnsupportedEncodingException {

		log.info("Start: editGenericKO");
		String userId = getLoggedUser();
		int isGeneric = getUserAccount();
		switch (isGeneric) {
		case 1:
			log.info(GEN_USER);
			break;
		case 2:
			log.info(NOT_GEN_USER);
			return PERMISSION_DENIED;
		case -1:
			log.info(USER_NOT_EXISTS);
			return null;
		default:
			return PERMISSION_DENIED;
		}
		updateModel(request, model);
		int totalExistingRec = 0;
		if (!StringUtils.isEmpty(request.getParameter("totalExistingRec"))) {
			totalExistingRec = Integer.parseInt(request.getParameter("totalExistingRec"));
		}
		model.addAttribute(FROM_HEADING, "Generic KO List");
		String indexCountStr = request.getParameter("lastIndexVal");
		int indexCount = 0;
		if (!StringUtils.isEmpty(indexCountStr)) {
			indexCount = Integer.parseInt(indexCountStr);
		} else {
			indexCount = totalExistingRec;
		}
		String reviewComment = "";
		String reworkArea = "";
		String actionVal = "";
		int newActionRequired = 0;

		for (int recCnt = 1; recCnt < indexCount + 1; recCnt++) {
			String recCntStr = String.valueOf(recCnt);
			reviewComment = request.getParameter(koInfoService.strConcat("reviewcomments_" , recCntStr));
			reworkArea = request.getParameter(koInfoService.strConcat("reworkarea_" , recCntStr));
			actionVal = request.getParameter(koInfoService.strConcat("checkboxID_" , recCntStr));
			if (!StringUtils.isEmpty(actionVal) && actionVal.equalsIgnoreCase("on")) {
				newActionRequired = 1;
			} else {
				newActionRequired = 0;
			}
			koInfo.setNewReviewComment(reviewComment);
			koInfo.setNewReworkArea(reworkArea);
			koInfo.setNewActionRequired(newActionRequired);
			if (recCnt >= totalExistingRec) {
				koInfoService.insertReviewComment(koInfo);
			}
		}
		
		String accountId = getDefaultAccountId();
		int koEnabledStatus = koController.getKOEnabledStatus(Integer.parseInt(accountId));
		model.addAttribute("isKOEnabled", koEnabledStatus);
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		
		model.addAttribute("koPublicationStatusVal", koInfo.getPublicationStatus());
		koInfoService.updateGenericKODetail(koInfo, files, userId);
		Integer bplId = businessRepository.findBusinessProcessId(koInfo.getBnsProL3());
		koInfo.setBusinessProcessLevelid(bplId);
	//	MongoDBprocess.updateGenericData(koInfo, koInfo.getPublicationStatus());
		mlDBProcess.updateGenericData(koInfo, koInfo.getPublicationStatus());
		log.info("End: editGenericKO");
		return "redirect:../editGenericKO/" + koInfo.getKoID();

	}

//	Rainy's code started
	// generic create ko
	/**
	 * Creates the KO.
	 *
	 * @param modelAndView the model and view
	 * @param model        the model
	 * @param request      the request
	 * @param koInfo       the ko info
	 * @param session      the session
	 * @return the model and view
	 */
	@GetMapping(value = CRAETE_GEN_REQ)
	public ModelAndView genericcreateKO(ModelAndView modelAndView, Model model, HttpServletRequest request,
			@ModelAttribute(CREATEKO_FORM) KOInfoBean koInfo, HttpSession session) {
		log.info("Start: createKO");
		int isGeneric = getUserAccount();
		switch (isGeneric) {
		case 1:
			log.info(GEN_USER);
			break;
		case 2:
			log.info(NOT_GEN_USER);
			return new ModelAndView("redirect:/createKO");
		case -1:
			log.info(USER_NOT_EXISTS);
			return null;
		default:
			return new ModelAndView(PERMISSION_DENIED);
		}
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String loginusrname = auth.getName();
		koInfo.setAccountID(Integer.parseInt(getDefaultAccountId()));
		List<BusinessProcessMaster> moduleListSp = koInfoService.findModulesAndlevels(loginusrname);
		List<String> moduleList = new ArrayList<>();
		Set<String> moduleSet = new LinkedHashSet<>();
		for (BusinessProcessMaster businessObject : moduleListSp) {
			moduleSet.add(businessObject.getApplicationName());
		}
		model.addAttribute("isGeneric", isGeneric);
		
		String accountId = getDefaultAccountId();
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		
		moduleList.addAll(moduleSet);
		request.setAttribute(MODULE_LIST, moduleList);
		model.addAttribute(FROM_HEADING, HEADER_CREATE_KO);
		model.addAttribute(CREATEKO_FORM, koInfo);
		session.removeAttribute(DISPLAY_ERROR);
		log.info("End: createKO");
		return new ModelAndView("createKOGeneric");
	}

	/**
	 * Creates the KO.
	 *
	 * @param koInfo        the ko info
	 * @param bindingResult the binding result
	 * @param modelAndView  the model and view
	 * @param request       the request
	 * @param files         the files
	 * @param model         the model
	 * @param session       the session
	 * @param errors        the errors
	 * @return the string
	 */
	@PostMapping(value = "/createGenericKO")
	public String genericcreateKO(@Valid @ModelAttribute(CREATEKO_FORM) KOInfoBean koInfo, BindingResult bindingResult,
			ModelAndView modelAndView, HttpServletRequest request, @RequestParam("file") MultipartFile[] files,
			Model model, HttpSession session, Errors errors) {
		String loginusrname = getLoggedUser();
		int isGeneric = getUserAccount();
		String accountId = getDefaultAccountId();
		switch (isGeneric) {
		case 1:
			log.info(GEN_USER);
			break;
		case 2:
			log.info(NOT_GEN_USER);
			return PERMISSION_DENIED;
		case -1:
			log.info(USER_NOT_EXISTS);
			return null;
		default:
			return PERMISSION_DENIED;
		}
		if (bindingResult.hasFieldErrors()) {

			session.setAttribute(DISPLAY_ERROR, "Mandatory columns necessary.");
			model.addAttribute(FROM_HEADING, HEADER_CREATE_KO);
			koInfo.setAccountID(Integer.parseInt(getDefaultAccountId()));
			List<String> moduleList = getModuleList(loginusrname);
			request.setAttribute(MODULE_LIST, moduleList);
			return CRAETE_GEN_REQ;
		}

		koInfo.setAccountID(Integer.parseInt(getDefaultAccountId()));

		List<KOInfoBean> koInfoBeanList;
		KOInfoBean koInfoBeanList_value = null;
		try {
			koInfoBeanList = koInfoService.insertGenericKODetail(koInfo, files);
		} catch (IllegalAccessException | PersistenceException e) {
			session.setAttribute(DISPLAY_ERROR, "Issue while inserting data in DB,Please contact IKON support Team");
			model.addAttribute(FROM_HEADING, HEADER_CREATE_KO);
			List<String> moduleList = getModuleList(loginusrname);
			request.setAttribute(MODULE_LIST, moduleList);
			return CRAETE_GEN_REQ;
		}

		// comment for redirecting to Ko Approval cycle page after successfully creation
		koInfoBeanList_value = (KOInfoBean) getFirstElement(koInfoBeanList);
		model.addAttribute(FROM_HEADING, HEADER_CREATE_KO);
		String createactionval = koInfo.getKoStage();

		// Send an email to
		if (!StringUtils.isEmpty(koInfo.getApproverUserID()) && createactionval.equalsIgnoreCase("ReviewSubmit")) {
			koInfoService.assignAndEmailReviewer(koInfoBeanList_value.getVar_ko(), koInfo.getApproverUserID());
		} else {
			koInfoService.sendmailtoreviewer(koInfoBeanList_value.getVar_ko(), createactionval);
		}
		try {
			Integer bplId = businessRepository.findBusinessProcessId(koInfo.getBnsProL3());
			String koId = kOInfoRepository.findKoId();
			koInfo.setKoID(koId);
			koInfo.setBusinessProcessLevelid(bplId);
			//MongoDBprocess.insertGenericData(koInfo);
			mlDBProcess.insertGenericData(koInfo);

		} catch (MongoException | IOException e) {
			List<String> moduleList = getModuleList(loginusrname);
			request.setAttribute(MODULE_LIST, moduleList);
			session.setAttribute(DISPLAY_ERROR, "Issue while inserting data in DB,Please contact IKON support Team");
			model.addAttribute("isGeneric", isGeneric);
			model.addAttribute(FROM_HEADING, HEADER_CREATE_KO);
			int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
			model.addAttribute("isHelpdeskVisible", helpdeskStatus);
			log.info("exception in MongoDBprocess: " + e);
			return CRAETE_GEN_REQ;
		}
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		
		//June Deployment J_BG02 start
		if(koInfo.getKoStage().equalsIgnoreCase(INDRAFT)) {
			return "redirect:/koListGeneric";
		}
		else {
			return "redirect:/genericKoApprovalCycleList";
		}
		//June Deployment J_BG02 end

	}

	/**
	 * Gets the first element.
	 *
	 * @param koInfoBeanList the ko info bean list
	 * @return the first element
	 */
	@SuppressWarnings("rawtypes")
	private Object getFirstElement(List koInfoBeanList) {
		return Objects.nonNull(koInfoBeanList) && koInfoBeanList.size() > 0 && Objects.nonNull(koInfoBeanList.get(0))
				? koInfoBeanList.get(0)
				: null;
	}

	/**
	 * Gets the module list.
	 *
	 * @param loginusrname the loginusrname
	 * @return the module list
	 */
	private List<String> getModuleList(String loginusrname) {
		List<String> moduleList = new ArrayList<>();
		List<BusinessProcessMaster> moduleListSp = koInfoService.findModulesAndlevels(loginusrname);
		Set<String> moduleSet = new LinkedHashSet<>();
		moduleListSp.forEach(businessObject -> {
			moduleSet.add(businessObject.getApplicationName());
		});
		moduleList.addAll(moduleSet);
		return moduleList;
	}

	/**
	 * Find bp 1.
	 *
	 * @param appname the appname
	 * @return the list
	 */
	@GetMapping(value = "/findBP1")
	@ResponseBody
	public List<String> findBp1(@RequestParam String appname) {

		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String loginusrname = auth.getName();
		List<String> bp1List = new ArrayList<>();
		Set<String> bp1Set = new LinkedHashSet<>();
		List<BusinessProcessMaster> moduleListSp = koInfoService.findModulesAndlevels(loginusrname);
		for (BusinessProcessMaster businessObject : moduleListSp) {
			String bp1 = businessObject.getBnsProL1();
			String app = businessObject.getApplicationName();
			if (app.equalsIgnoreCase(appname)) {
				bp1Set.add(bp1);
			}
		}
		bp1List.addAll(bp1Set);
		return bp1List;
	}

	/**
	 * Find bp 2.
	 *
	 * @param businessProcess1 the business process 1
	 * @return the list
	 */
	@GetMapping(value = "/findBP2")
	@ResponseBody
	public List<String> findBp2(@RequestParam String businessProcess1) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String loginusrname = auth.getName();
		List<String> bp2List = new ArrayList<>();
		Set<String> bp2Set = new LinkedHashSet<>();
		List<BusinessProcessMaster> moduleListSp = koInfoService.findModulesAndlevels(loginusrname);
		for (BusinessProcessMaster businessObject : moduleListSp) {
			String bp1 = businessObject.getBnsProL1();
			String bp2 = businessObject.getBnsProL2();

			if (bp1.equalsIgnoreCase(businessProcess1)) {
				bp2Set.add(bp2);
			}
		}
		bp2List.addAll(bp2Set);
		return bp2List;
	}

	/**
	 * Find bp 3.
	 *
	 * @param businessProcess1 the business process 1
	 * @param businessProcess2 the business process 2
	 * @return the list
	 */
	@GetMapping(value = "/findBP3")
	@ResponseBody
	public List<String> findBp3(@RequestParam String businessProcess1, @RequestParam String businessProcess2) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String loginusrname = auth.getName();
		List<String> bp3List = new ArrayList<>();
		Set<String> bp3Set = new LinkedHashSet<>();
		List<BusinessProcessMaster> moduleListSp = koInfoService.findModulesAndlevels(loginusrname);
		for (BusinessProcessMaster businessObject : moduleListSp) {
			String bp1 = businessObject.getBnsProL1();
			String bp2 = businessObject.getBnsProL2();
			String bp3 = businessObject.getBnsProL3();
			if (bp1.equalsIgnoreCase(businessProcess1) && bp2.equalsIgnoreCase(businessProcess2)) {
				bp3Set.add(bp3);
			}
		}
		bp3List.addAll(bp3Set);
		return bp3List;
	}

	/**
	 * Find approvers.
	 *
	 * @param appname the appname
	 * @return the list
	 */
	@GetMapping(value = "/findApprovers")
	@ResponseBody
	public List<KOReviewerBean> findApprovers(@RequestParam String appname) {
		String userId = getLoggedUser();
		MasterDataAttributeVO masterDataAttributeVO = new MasterDataAttributeVO(getDefaultAccountId(), appname, "", "", "", "", userId);		
		return koInfoService.getKOReviewersByAssignmentGroup(masterDataAttributeVO, CREATE_KO);
	}

	/**
	 * Ko approval cycle list.
	 *
	 * @param koInfo  the ko info
	 * @param model   the model
	 * @param request the request
	 * @return the string
	 */
	@GetMapping("/genericKoApprovalCycleList")
	public String generickoApprovalCycleList(@ModelAttribute("kolinkFormDetail") KOInfoBean koInfo, Model model,
			HttpServletRequest request) {
		log.info("Start: koApprovalCycleList");
		String accountId = getDefaultAccountId();
		String userId = getLoggedUser();
		int isGeneric = getUserAccount();
		switch (isGeneric) {
		case 1:
			log.info(GEN_USER);
			break;
		case 2:
			log.info(NOT_GEN_USER);
			return PERMISSION_DENIED;
		case -1:
			log.info(USER_NOT_EXISTS);
			return null;
		default:
			return PERMISSION_DENIED;
		}
		model.addAttribute("reportCategorization", request.getParameter("reportCategorization"));
		model.addAttribute("componentType", request.getParameter("componentType"));
		model.addAttribute(REPORT_TYPE_STRING, request.getParameter(REPORT_TYPE_STRING));
		model.addAttribute("reportName", request.getParameter("reportName"));
		model.addAttribute("reportFrequency", request.getParameter("reportFrequency"));
		model.addAttribute(FROM_DATE_STRING, request.getParameter(FROM_DATE_STRING));
		model.addAttribute(TO_DATE, request.getParameter(TO_DATE));
		String fromDate = request.getParameter(FROM_DATE_STRING);
		koInfo.setFromDate(getStringOrNull(fromDate));
		String toDate = request.getParameter(TO_DATE);
		koInfo.setToDate(getStringOrNull(toDate));
		if (!StringUtils.isEmpty(accountId)) {
			model.addAttribute("defaultAccountName",
					ticketDataService.getAccountNameByAccountId(Integer.parseInt(accountId)));
		}
		String loginusrname = userId;
		koInfo.setCreatedBy(getStringOrNull(request.getParameter(CREATED_BY_STRING)));
		String fromReport = request.getParameter("fromReport");
		if (!StringUtils.isEmpty(fromReport)) {
			ReportDataAttributeVO reportDataAttributeVO = new ReportDataAttributeVO(accountId, loginusrname, KO_APPROVAL_CYCLE_REPORT_ID,VIEW_ACTION_ID);
			reportService.insertReportUsage(reportDataAttributeVO);
		}
		String appName = request.getParameter("appName");
		if (!StringUtils.isEmpty(appName)) {
			koInfo.setApplicationName(appName);
		}
		List<KOInfoBean> koInfoBeanList = null;
		if (!StringUtils.isEmpty(request.getParameter(SHOW_RELATED_KO_STRING))) {
			koInfoBeanList = koInfoService.showAllRelatedKOs(request.getParameter(SHOW_RELATED_KO_STRING));
			model.addAttribute(READONLY_KO, TRUE);
		} else {
			KoDataAttributeVO koDtAttrVO= new KoDataAttributeVO();
			MasterDataAttributeVO masterDtAttrVo = new MasterDataAttributeVO(accountId,koInfo.getApplicationName(), koInfo.getAssignmentGroup(), "", "", "", userId);
			masterDtAttrVo.setFromDateTodate(koInfo.getFromDate(), koInfo.getToDate());
			masterDtAttrVo.setAllLevels(koInfo.getBnsProL1(),koInfo.getBnsProL2(), koInfo.getBnsProL3());
			koDtAttrVO.setMasterDtAttrVo(masterDtAttrVo);
			KoDataAttribute koDtAtrr = new KoDataAttribute("", koInfo.getPublicationStatus(), "", "", koInfo.getCreatedBy(), 0);
			koDtAtrr.setReviewedBy(koInfo.getReviewedBy());
			koDtAtrr.setReworkComplete("3");
			koDtAtrr.setReviewComments("3");
			koDtAttrVO.setKoDtAttr(koDtAtrr);
			koInfoBeanList = koInfoService.genericKoApprovalCycleListSP(koDtAttrVO);
		}
		String filterSelection = request.getParameter(FILTER_SELECTION);

		if (!StringUtils.isEmpty(filterSelection)) {
			model.addAttribute(FILTER_SELECTION, filterSelection);
		}
		addKOInfoDetailsToModel(model, koInfoBeanList);
		List<KOInfoBean> koInfoBeanListCopy = getKoInfoBeanCopy(koInfoBeanList);
		model.addAttribute("isGeneric", isGeneric);
		model.addAttribute("koInfoList", koInfoBeanListCopy);
		model.addAttribute(FROM_HEADING, "Generic KO Approval Cycle List");
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		log.info("End: koApprovalCycleList");
		return "genericKoApprovalCycleList";
	}

	/**
	 * Gets the ko info bean copy.
	 *
	 * @param koInfoBeanList the ko info bean list
	 * @return the ko info bean copy
	 */
	private List<KOInfoBean> getKoInfoBeanCopy(List<KOInfoBean> koInfoBeanList) {
		int serialNum = 1;
		boolean koIdExists = false;
		List<KOInfoBean> koInfoBeanListCopy = new ArrayList<KOInfoBean>();
		for (KOInfoBean koInfoBean : koInfoBeanList) {
			koIdExists = false;
			for (KOInfoBean koInfoBean1 : koInfoBeanListCopy) {
				if (!StringUtils.isEmpty(koInfoBean.getKoID())
						&& koInfoBean.getKoID().equalsIgnoreCase(koInfoBean1.getKoID())) {
					koIdExists = true;
				}
			}
			if (!koIdExists) {
				koInfoBean.setKoViewSerialNum(serialNum++);

				setKoInfoBeanYorN(koInfoBean);

				koInfoBeanListCopy.add(koInfoBean);
			}
		}
		return koInfoBeanListCopy;
	}

	/**
	 * Sets the ko info bean yor N.
	 *
	 * @param koInfoBean the new ko info bean yor N
	 */
	private void setKoInfoBeanYorN(KOInfoBean koInfoBean) {

		if (!StringUtils.isEmpty(koInfoBean.getPublicationStatus())
				&& (koInfoBean.getPublicationStatus().contains(APPROVED)
						|| koInfoBean.getPublicationStatus().contains(PUBLISHED))) {
			koInfoBean.setReviewedYorN("Y");
			koInfoBean.setApprovedYorN("Y");
			koInfoBean.setReworkCompletedYorN("Y");
		} else {
			koInfoBean.setReviewedYorN(koInfoBean.getPublicationStatus().contains("Rework") ? "Y" : "N");
			koInfoBean.setReworkCompletedYorN(koInfoBean.getPublicationStatus().contains("Review") ? "Y" : "N");
			koInfoBean.setApprovedYorN("N");
		}

		if (!StringUtils.isEmpty(koInfoBean.getReviewComments())) {
			koInfoBean.setReviewCommentsYorN("Y");
		} else {
			koInfoBean.setReviewCommentsYorN("N");
		}
	}

	/**
	 * Adds the KO info details to model.
	 *
	 * @param model the model
	 * @param koInfoBeanList the ko info bean list
	 */
	private void addKOInfoDetailsToModel(Model model, List<KOInfoBean> koInfoBeanList) {

		Set<String> allApplicationNameList = new TreeSet<String>();
		Set<String> allAssignmentGroupList = new TreeSet<String>();
		Set<String> allCreatedByList = new TreeSet<String>();
		Set<String> allReviewedByList = new TreeSet<String>();
		Set<String> allPublicationStatusList = new TreeSet<String>();
		Set<String> allBusinessLevel1 = new TreeSet<String>();
		Set<String> allBusinessLevel2 = new TreeSet<String>();
		Set<String> allBusinessLevel3 = new TreeSet<String>();

		koInfoBeanList.forEach(koList -> {
			if (!StringUtils.isEmpty(koList.getApplicationName())) {
				allApplicationNameList.add(koList.getApplicationName());
			}
			if (!StringUtils.isEmpty(koList.getAssignmentGroup())) {
				allAssignmentGroupList.add(koList.getAssignmentGroup());
			}
			if (!StringUtils.isEmpty(koList.getCreatedBy())) {
				allCreatedByList.add(koList.getCreatedBy());
			}
			if (!StringUtils.isEmpty(koList.getReviewedBy())) {
				allReviewedByList.add(koList.getReviewedBy());
			}
			if (!StringUtils.isEmpty(koList.getPublicationStatus())) {
				allPublicationStatusList.add(koList.getPublicationStatus());
			}
		});

		model.addAttribute(APPLICATION_NAMELIST, allApplicationNameList);
		model.addAttribute(ALL_ASSIGNMENT_GROUPLIST, allAssignmentGroupList);
		model.addAttribute(ALL_CREATED_BY_LIST, allCreatedByList);
		model.addAttribute("allReviewedByList", allReviewedByList);
		model.addAttribute(ALL_PUBLICATION_STATUSLIST, allPublicationStatusList);
		model.addAttribute("allBusinessLevel1", allBusinessLevel1);
		model.addAttribute("allBusinessLevel2", allBusinessLevel2);
		model.addAttribute("allBusinessLevel3", allBusinessLevel3);
	}

	/**
	 * Gets the string or null.
	 *
	 * @param string the string
	 * @return the string or null
	 */
	private String getStringOrNull(String string) {
		return !StringUtils.isEmpty(string) ? string : null;
	}

	/**
	 * Search.
	 *
	 * @param model   the model
	 * @param koInfo  the ko info
	 * @param request the request
	 * @param session the session
	 * @return the string
	 */
	@GetMapping("/searchGeneric")
	public String search(Model model, @ModelAttribute("searchFormDetail") KOInfoBean koInfo, HttpServletRequest request,
			HttpSession session) {
		String userID = getLoggedUser();
			log.info("Start: searchGeneric");
			int isGeneric = getUserAccount();
			switch (isGeneric) {
			case 1:
				log.info(GEN_USER);
				break;
			case 2:
				log.info(NOT_GEN_USER);
				return PERMISSION_DENIED;
			case -1:
				log.info(USER_NOT_EXISTS);
				return null;
			default:
				return PERMISSION_DENIED;
			}
			loadSearchTypeAheadURLs(model,request);
			List<SettingBean> accountAccesslist = helpService.accountAccess(userID);
			model.addAttribute("isGeneric", isGeneric);
			model.addAttribute("accountAccesslist", accountAccesslist);
			model.addAttribute(FROM_HEADING, "Search Page");
			
			String accountId = getDefaultAccountId();
			int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
			model.addAttribute("isHelpdeskVisible", helpdeskStatus);
			
			log.info("End: search");
			return "searchPageGeneric";
		
	}

	/**
	 * Load search type ahead UR ls.
	 *
	 * @param model the model
	 */
	private void loadSearchTypeAheadURLs(Model model,HttpServletRequest request) {
		ClassLoader loader = Thread.currentThread().getContextClassLoader();
		try(InputStream reader = loader.getResourceAsStream("application.properties");) {
			
			Properties prop = new Properties();
			prop.load(reader);
			model.addAttribute("searchTypeAheadHost", prop.getProperty("searchTypeAheadHost"));
			
			String serverName = prop.getProperty("ikon2.login.external.url");
			StringBuffer url = request.getRequestURL();
			
			 if(!url.toString().contains(serverName)) {
				 model.addAttribute("requestType", INTERNAL_REQ);
			 }
			 else {
				 model.addAttribute("requestType", EXTERNAL_REQ);
			 }
		} catch (IOException e) {
			log.error(e.getMessage());
		}

	}

	/**
	 * Search tickets and K os.
	 *
	 * @param koInfo  the ko info
	 * @param model   the model
	 * @param request the request
	 * @param session the session
	 * @return the string
	 */
	@PostMapping(value = "/searchGeneric")
	public String searchTicketsAndKOs(@ModelAttribute("searchFormDetail") KOInfoBean koInfo, Model model,
			HttpServletRequest request, HttpSession session) {
			log.info("Start: searchTicketsAndKOs for input string - " + koInfo.getKosearchbox());
			int isGeneric = getUserAccount();
			switch (isGeneric) {
			case 1:
				log.info(GEN_USER);
				break;
			case 2:
				log.info(NOT_GEN_USER);
				return PERMISSION_DENIED;
			default:
				return PERMISSION_DENIED;
			}
			List<KOInfoBean> simplesearchkolistList = null;
			loadSearchTypeAheadURLs(model,request);
			String searchString = koInfo.getProcessedSearchString();
			String ticketorkoval = koInfo.getTicketorko();
			String searchid = "1";

			if (!StringUtils.isEmpty(searchString) && !StringUtils.isEmpty(ticketorkoval)) {
				if (ticketorkoval.equalsIgnoreCase("KO")) {
					TicketDataAttributeVO tktDtAttrVO = new TicketDataAttributeVO();
					tktDtAttrVO.setMasterDtAttrVo(new MasterDataAttributeVO("", koInfo.getApplicationName(), koInfo.getAssignmentGroup(), "", "", "", ""));
					tktDtAttrVO.setKoDtAttr(new KoDataAttribute("", koInfo.getPublicationStatus(), "", "", koInfo.getCreatedBy(), 0));
					SearchDataAttributeVO searchDtAttrVo = new SearchDataAttributeVO();
					searchDtAttrVo.setSearch(searchString);
					searchDtAttrVo.setSearchid(searchid);
					tktDtAttrVO.setSearchDtAttrVo(searchDtAttrVo);
					simplesearchkolistList = koInfoService.genericKOSearch(tktDtAttrVO);
				}
				Set<String> applicationNameList = new HashSet<String>();
				Set<String> publicationstatusList = new HashSet<String>();
				Set<String> CreatedbyList = new HashSet<String>();
				Set<String> businessLevel1List = new HashSet<String>();
				Set<String> businessLevel2List = new HashSet<String>();
				Set<String> businessLevel3List = new HashSet<String>();

				if (Objects.nonNull(simplesearchkolistList)) {
					for (KOInfoBean koInfoBean : simplesearchkolistList) {
						applicationNameList.add(koInfoBean.getApplicationName());
						publicationstatusList.add(koInfoBean.getPublicationStatus());
						CreatedbyList.add(koInfoBean.getCreatedBy());
						businessLevel1List.add(koInfoBean.getBnsProL1());
						businessLevel2List.add(koInfoBean.getBnsProL2());
						businessLevel3List.add(koInfoBean.getBnsProL3());
					}
				}
				model.addAttribute("isGeneric", isGeneric);
				model.addAttribute("searchCategory", ticketorkoval);
				model.addAttribute("allApplicationNameList", applicationNameList);
				model.addAttribute("allPublicationStatusList", publicationstatusList);
				model.addAttribute("allCreatedByList", CreatedbyList);
				model.addAttribute("simplesearchkolistList", simplesearchkolistList);
				model.addAttribute(FROM_HEADING, "Search Page");
				model.addAttribute("searchFormDetail", koInfo);
				model.addAttribute("allBusinessLevel1List", businessLevel1List);
				model.addAttribute("allBusinessLevel2List", businessLevel2List);
				model.addAttribute("allBusinessLevel3List", businessLevel3List);
				
				String accountId = getDefaultAccountId();
				int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
				model.addAttribute("isHelpdeskVisible", helpdeskStatus);

			}
			log.info("End: searchTicketsAndKOs for processed string - " + koInfo.getProcessedSearchString());
			return "searchPageGeneric";
		
	}

	/**
	 * Gets the user account.
	 *
	 * @return the user account
	 */
	private int getUserAccount() {
		String accountId = getDefaultAccountId();
		UserBean ub = userService.getUserAccountType(accountId);
		return Objects.nonNull(ub) ? ub.getIsGeneric() : -1;
	}

	/**
	 * Gets the logged user.
	 *
	 * @return the logged user
	 */
	private String getLoggedUser() {
		SecurityContext sc = SecurityContextHolder.getContext();
		Authentication auth = sc.getAuthentication();
		return auth.getName();
	}

	/**
	 * Generic KO creation report.
	 *
	 * @param koBean  the koBean bean
	 * @param model   the model
	 * @param request the request
	 * @return the string
	 */
	@GetMapping("/genericKoCreationReport")
	public String genericKoCreationReport(@ModelAttribute("genericKoCreationDetail") KOInfoBean koBean, Model model,
			HttpServletRequest request) {
		log.info("Start: GenericKoCreationReport");
		int isGeneric = getUserAccount();
		String accountId = getDefaultAccountId();

		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String userId = auth.getName();
		MasterDataAttributeVO masterDataAttributeVO = new MasterDataAttributeVO();
		masterDataAttributeVO.setAccId(accountId);
		masterDataAttributeVO.setAppName(koBean.getApplicationName());
		masterDataAttributeVO.setFromDateTodate(koBean.getFromDate(), koBean.getToDate());
		masterDataAttributeVO.setAllLevels(koBean.getBnsProL1(), koBean.getBnsProL2(), koBean.getBnsProL3());
		List<KOInfoBean> koCreationData = koUsageService.gKOCreationReport(masterDataAttributeVO);
		if (Objects.nonNull(koCreationData) && koCreationData.size() > 0) {
			model.addAttribute("koCreationDataVal", koCreationData);
		}
		model.addAttribute("isGeneric", isGeneric);
		List<SettingBean> accountNamelist = helpService.accountAccess(userId);
		model.addAttribute("accountNamelist", accountNamelist);
		model.addAttribute(REPORT_CATEGORIZATION, request.getParameter(REPORT_CATEGORIZATION));
		model.addAttribute(COMPONENT_TYPE, request.getParameter(COMPONENT_TYPE));
		model.addAttribute(REPORT_TYPE_STRING, request.getParameter(REPORT_TYPE_STRING));
		model.addAttribute(REPORT_NAME, request.getParameter(REPORT_NAME));
		model.addAttribute(REPORT_FREQUENCY, request.getParameter(REPORT_FREQUENCY));
		model.addAttribute(FROM_DATE_STRING, request.getParameter(FROM_DATE_STRING));
		model.addAttribute(TO_DATE, request.getParameter(TO_DATE));
		model.addAttribute(FROM_HEADING, "KO Creation Report");
		
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		
		log.info("End: GenericKoCreationReport");
		return "genericKoCreationReport";
	}

	/**
	 * Generic KO creation report.
	 *
	 * @param koBean  the koBean bean
	 * @param model   the model
	 * @param request the request
	 * @return the string
	 */
	@GetMapping("/genericKoCloneReport")
	public String genericKoCloneReport(@ModelAttribute("genericKoCloneDetail") KOInfoBean koBean, Model model,
			HttpServletRequest request) {
		log.info("Start: GenericKoCloneReport");
		int isGeneric = getUserAccount();
		String accountId = getDefaultAccountId();

		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String userId = auth.getName();
		MasterDataAttributeVO masterDataAttributeVO = new MasterDataAttributeVO();
		masterDataAttributeVO.setAccId(accountId);
		masterDataAttributeVO.setAppName(koBean.getApplicationName());
		masterDataAttributeVO.setFromDateTodate(koBean.getFromDate(), koBean.getToDate());
		masterDataAttributeVO.setAllLevels(koBean.getBnsProL1(), koBean.getBnsProL2(), koBean.getBnsProL3());		
		List<KOInfoBean> koCreationData = koUsageService.gKOCloneReport(masterDataAttributeVO);
		if (Objects.nonNull(koCreationData) && koCreationData.size() > 0) {
			model.addAttribute("koCreationDataVal", koCreationData);
		}
		List<SettingBean> accountNamelist = helpService.accountAccess(userId);
		model.addAttribute("isGeneric", isGeneric);
		model.addAttribute("accountNamelist", accountNamelist);
		model.addAttribute(REPORT_CATEGORIZATION, request.getParameter(REPORT_CATEGORIZATION));
		model.addAttribute(COMPONENT_TYPE, request.getParameter(COMPONENT_TYPE));
		model.addAttribute(REPORT_TYPE_STRING, request.getParameter(REPORT_TYPE_STRING));
		model.addAttribute(REPORT_NAME, request.getParameter(REPORT_NAME));
		model.addAttribute(REPORT_FREQUENCY, request.getParameter(REPORT_FREQUENCY));
		model.addAttribute(FROM_DATE_STRING, request.getParameter(FROM_DATE_STRING));
		model.addAttribute(TO_DATE, request.getParameter(TO_DATE));
		model.addAttribute(FROM_HEADING, "KO Cloned Report");
		
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		
		log.info("End: GenericKoCloneReport");
		return "genericKoCloneReport";
	}

	/**
	 * Generic KO creation report.
	 *
	 * @param koBean  the koBean bean
	 * @param model   the model
	 * @param request the request
	 * @return the string
	 */
	@GetMapping("/genericPerformanceReport")
	public String genericPerformReport(@ModelAttribute("genericPerformanceDetail") KOInfoBean koBean, Model model,
			HttpServletRequest request) {
		log.info("Start: GenericPerformanceReport");
		int isGeneric = getUserAccount();
		String accountId = getDefaultAccountId();
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String userId = auth.getName();
		MasterDataAttributeVO masterDataAttributeVO = new MasterDataAttributeVO();
		masterDataAttributeVO.setAccId(accountId);
		masterDataAttributeVO.setAppName(koBean.getApplicationName());
		masterDataAttributeVO.setFromDateTodate(koBean.getFromDate(), koBean.getToDate());
		masterDataAttributeVO.setAllLevels(koBean.getBnsProL1(), koBean.getBnsProL2(), koBean.getBnsProL3());		
		List<KOInfoBean> koCreationData = koUsageService.gtopPerformanceReport(masterDataAttributeVO);

		if (Objects.nonNull(koCreationData) && koCreationData.size() > 0) {
			model.addAttribute("koCreationDataVal", koCreationData);
		}
		List<SettingBean> accountNamelist = null;
		accountNamelist = helpService.accountAccess(userId);
		model.addAttribute("isGeneric", isGeneric);
		model.addAttribute("accountNamelist", accountNamelist);
		model.addAttribute(REPORT_CATEGORIZATION, request.getParameter(REPORT_CATEGORIZATION));
		model.addAttribute(COMPONENT_TYPE, request.getParameter(COMPONENT_TYPE));
		model.addAttribute(REPORT_TYPE_STRING, request.getParameter(REPORT_TYPE_STRING));
		model.addAttribute(REPORT_NAME, request.getParameter(REPORT_NAME));
		model.addAttribute(REPORT_FREQUENCY, request.getParameter(REPORT_FREQUENCY));
		model.addAttribute(FROM_DATE_STRING, request.getParameter(FROM_DATE_STRING));
		model.addAttribute(TO_DATE, request.getParameter(TO_DATE));
		model.addAttribute(FROM_HEADING, "Top Performance Report");
		
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		
		log.info("End: GenericPerformanceReport");
		return "genericPerformanceReport";
	}
	
	
}
