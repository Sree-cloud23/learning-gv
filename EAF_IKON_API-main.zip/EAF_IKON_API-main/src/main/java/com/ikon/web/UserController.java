package com.ikon.web;

import java.util.List;
import java.util.Objects;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ikon.dto.LandingScreenBean;
import com.ikon.dto.UserBean;
import com.ikon.model.AccountInfo;
import com.ikon.model.UserMaster;
import com.ikon.repository.AccountInfoRepository;
import com.ikon.repository.UserRepository;
import com.ikon.rest.web.models.Authentication;
import com.ikon.rest.web.models.SecurityContextHolder;
import com.ikon.rooca2.JWTTokenGenerator;
import com.ikon.service.AccessControlService;
import com.ikon.service.HelpDeskService;
import com.ikon.service.UserService;
import com.ikon.validator.IKONUtils;


/**
 * The Class UserController.
 */
@Controller
public class UserController {

	/** The user service. */
	@Autowired
	private transient UserService userService;

	/** The access control service. */
	@Autowired
	private transient AccessControlService accessControlService;

	/** The user repository. */
	@Autowired
	private transient UserRepository userRepository;
	
	/**  The Token Generator Utility. */
	@Autowired
	private transient JWTTokenGenerator jwtTokenGenerator;
	
	/**  The env. */
	@Autowired
	private Environment env;
	
	/** The Constant MESSAGE_STRING. */
	private static final String MESSAGE_STRING ="message";

	/** The Constant FORM_HEADING_STRING. */
	private static final String FORM_HEADING_STRING ="formheading";

	/** The Constant ACCOUNT_LOCKED_STRING. */
	private static final String ACCOUNT_LOCKED_STRING ="User account got locked";
	
	/** The Constant ONE. */
	private static final int ONE = 1;
	
	/** The Constant TWO. */
	private static final int TWO = 2;
	
	/** The Constant THREE. */
	private static final int THREE = 3;
	
	/** The Constant FOUR. */
	private static final int FOUR = 4;
	
	/** The Constant FIVE. */
	private static final int FIVE = 5;
	
	/** The Constant SIX. */
	private static final int SIX = 6;
	
	/** The Constant SEVEN. */
	private static final int SEVEN = 7;
	
	/** The Constant EIGHT. */
	private static final int EIGHT = 8;
	
	/** The Constant REDIRECT_KOLIST_GENERIC. */
	private static final String REDIRECT_KOLIST_GENERIC ="redirect:koListGeneric";
	
	/** The helpdesk controller. */
	@Inject
	private transient HelpDeskController helpdeskController;
	
	/** The help service. */
	@Inject
	private transient HelpDeskService helpService;
	
	/** The AccountInfoRepository controller. */
	@Inject
	private transient AccountInfoRepository accInfoRepo;
	//START:May Deployment-SPRINT1
	/** The Constant IS_GENERIC. */
	private static final String IS_GENERIC = "isGeneric";
	//END:May Deployment-SPRINT1
	
	/**
	 * Login.
	 *
	 * @param user    the user
	 * @param model   the model
	 * @param error   the error
	 * @param logout  the logout
	 * @param request the request
	 * @return the string
	 */
	@GetMapping("/login")
	public String login(@ModelAttribute("userForm") UserMaster user, Model model, String error, String logout,
			HttpServletRequest request) {
		if (Objects.nonNull(logout))
			((Model) model).addAttribute(MESSAGE_STRING, "You have been logged out successfully.");
		model.addAttribute(FORM_HEADING_STRING, "login");
		
		int accountId = 1;
		List<AccountInfo> accountInfoList = accInfoRepo.findAll();
		for(AccountInfo accountInfo:accountInfoList){
			 accountId = accountInfo.getAccountId();
		}
		int helpdeskStatus = helpdeskController.getDisplayStatus(accountId);
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		
		return "login";
	}

	/**
	 * Loginfailed.
	 *
	 * @param request  the request
	 * @param user     the user
	 * @param model    the model
	 * @param password the password
	 * @return the string
	 */
	//@RequestMapping(value = "/login/failed")
	/*
	 * public String loginfailed(HttpServletRequest request,
	 * 
	 * @ModelAttribute(UsernamePasswordAuthenticationFilter.
	 * SPRING_SECURITY_FORM_USERNAME_KEY) String user, Model model,
	 * 
	 * @ModelAttribute(UsernamePasswordAuthenticationFilter.
	 * SPRING_SECURITY_FORM_PASSWORD_KEY) String password) {
	 * 
	 * int noofAtmpts = 0, noofAtmpts_chk = 0;
	 * 
	 * UserMaster user1 = userRepository.findByName(user); String errorMessage = "";
	 * 
	 * if (Objects.nonNull(user1) && Objects.nonNull(user1.getName())) noofAtmpts =
	 * userService.checkAttempts(user);
	 * 
	 * if (Objects.isNull(user1)||
	 * Objects.equals(userRepository.findByNameAndIsactive(user,(short) 1).size(),
	 * 0)) { model.addAttribute(MESSAGE_STRING,
	 * "Enter user have no access in IKON"); errorMessage = ""; } else if
	 * (noofAtmpts <= TWO) { userService.updateAttempts(user);
	 * 
	 * int noofAtmpts_lockchk = userService.checkAttempts(user); if
	 * (Objects.equals(noofAtmpts_lockchk, THREE)) {
	 * model.addAttribute(MESSAGE_STRING, ACCOUNT_LOCKED_STRING); errorMessage =
	 * ACCOUNT_LOCKED_STRING; } else { errorMessage =
	 * "Wrong password, unsuccessful attempt #" + noofAtmpts_lockchk; }
	 * 
	 * } else if (Objects.equals(noofAtmpts, THREE)) {
	 * model.addAttribute(MESSAGE_STRING, ACCOUNT_LOCKED_STRING); errorMessage =
	 * ACCOUNT_LOCKED_STRING; } else { model.addAttribute(MESSAGE_STRING,
	 * "Enter user have no access in IKON"); errorMessage = ""; }
	 * 
	 * if (Objects.nonNull(user1)) noofAtmpts_chk = userService.checkAttempts(user);
	 * model.addAttribute("noofAtmpts", noofAtmpts_chk); if
	 * (!IKONUtils.isNullOrEmpty(errorMessage)) { userService.insertUserLogin(user,
	 * getDefaultAccountIdWithoutLogin(user), errorMessage); } return "login"; }
	 */
	/**
	 * Welcome.
	 *
	 * @param model        the model
	 * @param modelAndView the model and view
	 * @param request the request
	 * @return the model and view
	 */
	@GetMapping({ "/", "/welcome" })
	public ModelAndView welcome(Model model, ModelAndView modelAndView, HttpServletRequest request) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String username = auth.getName(); 
		HttpSession session = request.getSession();
	
		String token = jwtTokenGenerator.generateToken(username);
		String rooca2Url = env.getProperty("rooca2.login.url");
		session.setAttribute("rooca2url", rooca2Url+token);
		
		UserMaster userMaster = userRepository.findByName(username);
		userMaster.setTokenid(token);userMaster.setIsactive((short) 1);userMaster.setIsloggedin((short)1);
		userRepository.save(userMaster); 
		try {
			
			List<UserMaster> userBeanList = null;
            userBeanList = userRepository.findByNameAndIsactive(username,(short) 1);
            if (Objects.isNull(userBeanList) || Objects.equals(userBeanList.size(), 0)) {
                  model.addAttribute("message", "Enter user have no access in IKON");
                  modelAndView.setViewName("login");
            }
            else {
			userService.resetAttempts(username);

			LandingScreenBean accessControlBean = userService.getUserDetail(username);
			boolean isGenericUser=isGenericUser();
			switch (accessControlBean.getDefaultLandingPage()) {
			case ONE:
				modelAndView.setViewName(!isGenericUser?"redirect:dashboard":REDIRECT_KOLIST_GENERIC);
				break;
			case TWO:
				modelAndView.setViewName(!isGenericUser?"redirect:ticketSummary?fromLogin=1&searchTypeChosen=2":REDIRECT_KOLIST_GENERIC);
				model.addAttribute(FORM_HEADING_STRING, "Ticket Summary");
				break;
			case THREE:
				modelAndView.setViewName(!isGenericUser?"redirect:search":"redirect:searchGeneric");
				break;
//				START:May Deployment-SPRINT1
			case FOUR:
				modelAndView.setViewName("redirect:reportsChartsView");
				break;
//				END:May Deployment-SPRINT1
			case FIVE:
				modelAndView.setViewName(!isGenericUser?"redirect:koList":REDIRECT_KOLIST_GENERIC);
				break;
			case SIX:
				modelAndView.setViewName("redirect:viewProfile");
				break;
				//START:May Deployment-SPRINT1
			case SEVEN:
				modelAndView.setViewName("redirect:underconstruction");
				break;
				//END:May Deployment-SPRINT1
			case EIGHT:
				modelAndView.setViewName("redirect:setting");
				break;
			default:
				modelAndView.setViewName(!isGenericUser?"redirect:ticketSummary?fromLogin=1":REDIRECT_KOLIST_GENERIC);
				model.addAttribute(FORM_HEADING_STRING, "Ticket Summary");
				break;
			}
			userService.insertUserLogin(username, getDefaultAccountId(), "");
            }
			return modelAndView;
		} catch (HibernateException e) {
			userService.insertUserLogin(username, getDefaultAccountId(), e.getMessage());
			return null;
		}
	}

	/**
	 * Checks if is generic user.
	 *
	 * @return true, if is generic user
	 */
	private boolean isGenericUser() {
		String accountId = getDefaultAccountId();
		UserBean ub= userService.getUserAccountType(accountId);
		return Objects.nonNull(ub) && ub.getIsGeneric().equals(1) ? true: false;		
	}

	/**
	 * Incident detail.
	 *
	 * @param model the model
	 * @return the string
	 */
	@GetMapping({ "/incidentDetail" })
	public String incidentDetail(Model model) {
		return "incident";
	}
	
	/**
	 * Gets the default account id.
	 *
	 * @return the default account id
	 */
	private String getDefaultAccountId() {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String loginusrname = auth.getName();

		String accountId = String.valueOf(accessControlService.getAccessDetailByUserId(loginusrname).getAccountId());
		return Objects.isNull(accountId)?"":accountId;
	}

	/**
	 * Gets the default account id without login.
	 *
	 * @param loginusrname the loginusrname
	 * @return the default account id without login
	 */
	private String getDefaultAccountIdWithoutLogin(String loginusrname) {
		Long acctId = accessControlService.getAccessDetailByUserId(loginusrname).getAccountId();
		String accountId = "1";
		if (Objects.nonNull(acctId)) {
			accountId = String.valueOf(acctId);
		}
		return accountId;
	}

	/**
	 * User logged in report.
	 *
	 * @param userBean the user bean
	 * @param model    the model
	 * @param request  the request
	 * @return the string
	 */
	@GetMapping("/userLoggedInReport")
	public String userLoggedInReport(@ModelAttribute("userLoggedInReportFormDetail") UserBean userBean, Model model,
			HttpServletRequest request) {
		List<UserBean> userLoggedInData = null;
		userLoggedInData = userService.getUserLoggedIndetail(userBean.getFromDate(), userBean.getToDate());
		int isGeneric = getUserAccount();
		String accountId = getDefaultAccountId();
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		model.addAttribute("reportCategorization", request.getParameter("reportCategorization"));
		model.addAttribute("componentType", request.getParameter("componentType"));
		model.addAttribute("reportType", request.getParameter("reportType"));
		model.addAttribute("reportName", request.getParameter("reportName"));
		model.addAttribute("reportFrequency", request.getParameter("reportFrequency"));
		model.addAttribute("fromDate", request.getParameter("fromDate"));
		model.addAttribute("toDate", request.getParameter("toDate"));
		model.addAttribute(FORM_HEADING_STRING, "User Login Report");
		model.addAttribute("userLoggedInDetails", userLoggedInData);
		model.addAttribute("isGeneric", isGeneric);
		return "userLoggedInReport";
	}
	
	/**
	 * Gets the user account.
	 *
	 * @return the user account
	 */
	private int getUserAccount() {
		String accountId = getDefaultAccountId();
		UserBean ub = userService.getUserAccountType(accountId);
		return Objects.nonNull(ub) ? ub.getIsGeneric() : -1;
	}
	
	
	//START:May Deployment-SPRINT1

	 /** Underconstruction detail.
	 * May Deployment-SPRINT1
	 * @param model the model
	 * @return the string
	 */
	@GetMapping({ "/underconstruction" })
	public String underconstruction(Model model) {
		String accountId = getDefaultAccountId();
		model.addAttribute(FORM_HEADING_STRING, "Underconstruction");
		UserBean ubean = userService.getUserAccountType(accountId);
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		int isGeneric = ubean.getIsGeneric();
		model.addAttribute(IS_GENERIC, isGeneric);
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		return "underconstruction";
	}
	//END:May Deployment-SPRINT1
}
