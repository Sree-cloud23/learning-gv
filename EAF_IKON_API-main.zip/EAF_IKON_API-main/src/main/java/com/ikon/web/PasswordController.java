package com.ikon.web;

import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.ikon.model.UserMaster;
import com.ikon.repository.UserRepository;
import com.ikon.rest.web.models.Authentication;
import com.ikon.rest.web.models.SecurityContextHolder;
import com.ikon.service.EmailService;
import com.ikon.service.HelpDeskService;
import com.ikon.service.UserService;

import lombok.extern.slf4j.Slf4j;


/**
 * The Class PasswordController.
 */
@Controller
@Slf4j
public class PasswordController {

	/** The user service. */
	@Inject
	private transient UserService userService;

	/** The email service. */
	@Inject
	private transient EmailService emailService;

	/** The b crypt password encoder. */
	/*
	 * @Inject private transient BCryptPasswordEncoder bCryptPasswordEncoder;
	 */
	/** The user repository. */
	@Inject
	private transient UserRepository userRepository;
	
	/** The help service. */
	@Inject
	private transient HelpDeskService helpService;
	
	/** The Constant log. */
	//private static final log log = LogManager.getlog(PasswordController.class);
	
	/** The Constant Change password. */
	private static final String CHANGE_PASSWORD = "Change Password";
	
	/** The Constant FORM_HEADING. */
	private static final String FORM_HEADING = "formheading";
	
	/** The Constant Changepassword. */
	private static final String CHNG_PASSWORD = "changePassword";
	
	/** The helpdesk controller. */
	@Inject
	private transient HelpDeskController helpdeskController;
	
	/**
	 * Display forgot password page.
	 *
	 * @param modelAndView the model and view
	 * @return the model and view
	 */
	@RequestMapping(value = "/needAssistance", method = RequestMethod.GET)
	public ModelAndView displayForgotPasswordPage(ModelAndView modelAndView) {
		modelAndView.addObject(FORM_HEADING, "Need Assistance");
		return new ModelAndView("needAssistance");
	}

	/**
	 * Process forgot password form.
	 *
	 * @param modelAndView the model and view
	 * @param userEmail the user email
	 * @param request the request
	 * @return the model and view
	 */
	/*
	 * @RequestMapping(value = "/needAssistance", method = RequestMethod.POST)
	 * public ModelAndView processForgotPasswordForm(ModelAndView
	 * modelAndView, @RequestParam("email_ID") String userEmail, HttpServletRequest
	 * request) {log.info("Start: processForgotPasswordForm");
	 * 
	 * UserMaster userid = userRepository.findByEmail(userEmail).orElse(null);
	 * List<UserMaster> userBeanList = null;
	 * 
	 * if (Objects.nonNull(userid)) { userBeanList =
	 * userRepository.findByNameAndIsactive(userid.getName(),(short) 1); } //sprint
	 * may deployment start if (Objects.isNull(userBeanList) ||
	 * Objects.equals(userBeanList.size(), 0)) {
	 * modelAndView.addObject("successMessage",
	 * "No account found for this email id. Please try again."); } //sprint may
	 * deployment end else { // Lookup user in database by e-mail
	 * Optional<UserMaster> optional = userService.findUserByEmail(userEmail); if
	 * (!optional.isPresent()) { modelAndView.addObject("successMessage",
	 * "We didn't find an account for that e-mail address."); } else {
	 * 
	 * // Generate random 36-character string token for reset password UserMaster
	 * user = optional.get(); user.setResetToken(UUID.randomUUID().toString());
	 * 
	 * // Save token to database userService.saveReset(user);
	 * 
	 * String uri = request.getRequestURI(); String url =
	 * request.getRequestURL().toString(); String appUrl = url.replaceFirst(uri,
	 * "")+ request.getServletContext().getContextPath();
	 * 
	 * if(appUrl.contains(String.join(".", "tools","in","capgemini"))) {
	 * appUrl.replace("http", "https"); }
	 * 
	 * // Email message SimpleMailMessage passwordResetEmail = new
	 * SimpleMailMessage(); passwordResetEmail.setFrom(userEmail);
	 * passwordResetEmail.setTo(user.getEmail());
	 * passwordResetEmail.setSubject("Password Reset Request");
	 * 
	 * String linkurl = appUrl + "/reset?token=" + user.getResetToken() + "&user=" +
	 * user.getName();
	 * 
	 * passwordResetEmail .setText("Hello " + user.getUserId() +
	 * ",\nTo reset your password, click the link below:\n" + linkurl + "\n" +
	 * "\nRegards,\n" + "Capgemini IKON Team.");
	 * 
	 * //reset password from external link changes begin String username =
	 * user.getUserId(); String accountId =
	 * helpService.getDefaultAccountId(username); //reset password from external
	 * link changes end try { emailService.sendEmail(passwordResetEmail); } catch
	 * (MailException e) { //reset password from external link changes begin
	 * helpService.infomailsave(userEmail,user.getEmail(),"",passwordResetEmail.
	 * getSubject(), passwordResetEmail.getText(),Integer.parseInt(accountId));
	 * 
	 * log.info("Exception in reset password");
	 * 
	 * modelAndView.addObject("successMessage",
	 * "A password reset link has been sent to " + userEmail+
	 * "\n Please contact to support team @ natools_ikon.in@capgemini.com for any assistance."
	 * ); modelAndView.setViewName("needAssistance"); return modelAndView; }
	 * 
	 * // Add success message to view modelAndView.addObject("successMessage",
	 * "A password reset link has been sent to " + userEmail); } }
	 * log.info("End: processForgotPasswordForm");
	 * modelAndView.addObject("formheading", "Need Assistance");
	 * modelAndView.setViewName("needAssistance"); return modelAndView; }
	 */

	/**
	 * Display reset password page.
	 *
	 * @param modelAndView the model and view
	 * @param token the token
	 * @param username the username
	 * @param model the model
	 * @return the model and view
	 */
	@RequestMapping(value = "/reset", method = RequestMethod.GET)
	public ModelAndView displayResetPasswordPage(ModelAndView modelAndView, @RequestParam("token") String token,
			@RequestParam("user") String username, Model model) {

		Optional<UserMaster> user = userService.findUserByResetToken(token);

		if (Objects.nonNull(user) && Objects.nonNull(user.get())) {
			modelAndView.addObject("username", user.get().getUserId());
		}

		if (Objects.nonNull(user) && user.isPresent()) { // Token found in DB
			modelAndView.addObject("resetToken", token);
		} else { // Token not found in DB
			modelAndView.addObject("errorMessage", "Oops!  This is an invalid password reset link.");
		}
		modelAndView.addObject(FORM_HEADING, CHANGE_PASSWORD);
		modelAndView.setViewName(CHNG_PASSWORD);
		
		String accountId = helpService.getDefaultAccountId(username);
		
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		
		return modelAndView;
	}

	/**
	 * Sets the new password.
	 *
	 * @param token the token
	 * @param userid the userid
	 * @param modelAndView the model and view
	 * @param requestParams the request params
	 * @param redir the redir
	 * @param um the um
	 * @param model the model
	 * @return the model and view
	 */
	@RequestMapping(value = "/reset", method = RequestMethod.POST)
	public ModelAndView setNewPassword(@RequestParam(name = "token") String token,
			@RequestParam(name = "user") String userid, ModelAndView modelAndView,
			@RequestParam Map<String, String> requestParams, RedirectAttributes redir,
			@ModelAttribute("loginform") UserMaster um,Model model) {

		Optional<UserMaster> user = userService.findUserByResetToken(token);

		if (user.isPresent()) {
			UserMaster resetUser = user.get();

			//resetUser.setPassword(bCryptPasswordEncoder.encode(um.getPassword()));
			resetUser.setResetToken("0");
			userService.saveChangePwd(resetUser);

			// In order to set a model attribute on a redirect, we must use RedirectAttributes
			redir.addFlashAttribute("message", "You have successfully reset your password.You may now login.");
			modelAndView.setViewName("redirect:login");
			
			String accountId = helpService.getDefaultAccountId(userid);
			int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
			model.addAttribute("isHelpdeskVisible", helpdeskStatus);
			
			return modelAndView;
		} else {
			modelAndView.addObject("errorMessage", "Oops!  This is an invalid password reset link.");
			modelAndView.addObject(FORM_HEADING, CHANGE_PASSWORD);
			modelAndView.setViewName(CHNG_PASSWORD);
			
		}
		return modelAndView;
	}

	/**
	 * Change password.
	 *
	 * @param model the model
	 * @param modelAndView the model and view
	 * @return the model and view
	 */
	@GetMapping("/changePassword")
	public ModelAndView changePassword(Model model, ModelAndView modelAndView) {
		model.addAttribute("userForm2", new UserMaster());
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String loginusrname = auth.getName();
		
		String accountId = helpService.getDefaultAccountId(loginusrname);
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);
		
		modelAndView.addObject("username", loginusrname);
		modelAndView.setViewName(CHNG_PASSWORD);
		model.addAttribute(FORM_HEADING, CHANGE_PASSWORD);
		return modelAndView;
	}

	/**
	 * Sets the change password.
	 *
	 * @param modelAndView the model and view
	 * @param um the um
	 * @param redir the redir
	 * @param model the model
	 * @return the model and view
	 */
	@RequestMapping(value = "/changePassword", method = RequestMethod.POST)
	public ModelAndView setChangePassword(ModelAndView modelAndView, @ModelAttribute("loginform") UserMaster um,
			RedirectAttributes redir, Model model) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String loginusrname = auth.getName();
		UserMaster user = userRepository.findByName(loginusrname);
		
		String accountId = helpService.getDefaultAccountId(loginusrname);
		int helpdeskStatus = helpdeskController.getDisplayStatus(Integer.parseInt(accountId));
		model.addAttribute("isHelpdeskVisible", helpdeskStatus);

		if (Objects.nonNull(user))
		{
			//user.setPassword(bCryptPasswordEncoder.encode(um.getPassword()));
			user.setResetToken("0");
			userService.saveChangePwd(user);
			redir.addFlashAttribute("message", "You have successfully reset your password.You may now login.");
			modelAndView.setViewName("redirect:login");
			return modelAndView;

		} else {
			modelAndView.addObject("errorMessage", "Oops!  This is an invalid password reset link.");
			modelAndView.addObject(FORM_HEADING, CHANGE_PASSWORD);
			modelAndView.setViewName(CHNG_PASSWORD);
		}

		return modelAndView;
	}

	/**
	 * Handle missing params.
	 *
	 * @param ex the ex
	 * @return the model and view
	 */
	// Going to reset page without a token redirects to login page
	@ExceptionHandler(MissingServletRequestParameterException.class)
	public ModelAndView handleMissingParams(MissingServletRequestParameterException ex) {
		return new ModelAndView("redirect:login");
	}
}